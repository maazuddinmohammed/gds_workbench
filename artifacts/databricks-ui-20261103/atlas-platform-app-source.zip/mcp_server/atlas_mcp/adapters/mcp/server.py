"""MCP server composition and non-tool routes."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager, suppress
from typing import cast

from mcp.server.mcpserver import MCPServer
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from atlas_mcp import __version__
from atlas_mcp.adapters.auth.identity import IdentityProvider
from atlas_mcp.application.authorization import AuthorizationService
from atlas_mcp.application.profiling.execution import ConnectorProfilingExecutor
from atlas_mcp.application.profiling.service import ProfilingService, ProfilingWorker
from atlas_mcp.configuration import AuthMode, RuntimeSettings
from atlas_mcp.domain.errors import DependencyUnavailableError
from atlas_mcp.infrastructure.databricks_sql import (
    ConnectorDatabricksSqlExecutor,
    DatabricksSqlExecutor,
)
from atlas_mcp.infrastructure.postgres import (
    Database,
    DatabricksConnectionDatabase,
    WriteDatabase,
)
from atlas_mcp.tools.catalog.inspect_metadata import (
    register_inspect_metadata_tool,
)
from atlas_mcp.tools.change_sets.metadata import (
    register_metadata_change_set_tools,
)
from atlas_mcp.tools.change_sets.project import register_project_change_set_tools
from atlas_mcp.tools.databricks.execute_sql import (
    register_execute_databricks_sql_tool,
)
from atlas_mcp.tools.modeling.project_details import register_list_projects_tool
from atlas_mcp.tools.modeling.project_input_scope import (
    register_get_project_input_scope_tool,
)
from atlas_mcp.tools.modeling.read_mapping_context import register_read_mapping_context_tool
from atlas_mcp.tools.modeling.read_project_section import (
    register_read_project_section_tool,
)
from atlas_mcp.tools.profiling import register_profiling_tools
from atlas_mcp.tools.snapshots.metadata.describe_metadata_dataset import (
    register_describe_metadata_dataset_tool,
)
from atlas_mcp.tools.snapshots.metadata.get_metadata_snapshot import (
    register_create_metadata_snapshot_tool,
)
from atlas_mcp.tools.snapshots.project.describe_project_dataset import (
    register_describe_project_dataset_tool,
)
from atlas_mcp.tools.snapshots.project.get_project_snapshot import (
    register_create_project_snapshot_tool,
)
from atlas_mcp.tools.snapshots.storage import AzureSnapshotStore, SnapshotStore
from atlas_mcp.tools.tenants.get_tenant_details import (
    register_get_tenant_details_tool,
)
from atlas_mcp.tools.tenants.list_tenants import register_list_tenants_tool
from atlas_mcp.tools.tenants.tenant_locks import register_tenant_lock_tools

from .atlas_bridge_gate import AtlasBridgeGate
from .tool_audit import ToolCallAuditMiddleware

MCP_SERVER_VERSION = __version__


def create_mcp_server(
    settings: RuntimeSettings,
    database: Database,
    identity_provider: IdentityProvider,
    snapshot_store: SnapshotStore | None = None,
    databricks_executor: DatabricksSqlExecutor | None = None,
) -> MCPServer[None]:
    shared_snapshot_store = snapshot_store or AzureSnapshotStore(settings)
    sql_executor = databricks_executor or ConnectorDatabricksSqlExecutor()
    profiling_service = ProfilingService(cast(WriteDatabase, database))
    profiling_worker = ProfilingWorker(profiling_service, ConnectorProfilingExecutor())

    @asynccontextmanager
    async def lifespan(_server: MCPServer[None]) -> AsyncGenerator[None]:
        await database.open()
        with suppress(DependencyUnavailableError):
            await database.expire_tenant_locks()
        expiry_task = asyncio.create_task(_expire_tenant_locks(database))
        profiling_task = asyncio.create_task(profiling_worker.run_forever())
        try:
            yield None
        finally:
            expiry_task.cancel()
            profiling_task.cancel()
            with suppress(asyncio.CancelledError):
                await profiling_task
            with suppress(asyncio.CancelledError):
                await expiry_task
            await shared_snapshot_store.close()
            await database.close()

    authorizer = AuthorizationService()
    audit = ToolCallAuditMiddleware(
        database=database,
        identity_provider=identity_provider,
        authorizer=authorizer,
    )
    server = MCPServer[None](
        name="atlas-mcp",
        title="Atlas MCP",
        version=MCP_SERVER_VERSION,
        description="Governed GDS context, Snapshot, and Change Set workflows.",
        instructions=(
            "This server exposes governed reads, Snapshots, Tenant Locks, Change Sets, and "
            "bounded Databricks SQL, and deterministic Profiling runs. Clients own interaction; "
            "Profiling SQL, execution, and persistence run on the server. The "
            "server derives identity and authorization and enforces Tenant Lock ownership, "
            "revision fencing, idempotency, validation, dependency order, and audit. Lock "
            "override and Apply are separate high-impact operations that require explicit "
            "approval before invocation. Project Input Scope must Apply before Profiling "
            "or project "
            "development. Mapping must Apply before Code or Validation. Mapping and Code "
            "reference schema-qualified Logical or Dimensional Entities. Target export and "
            "metadata registration are optional downstream handoff steps. For Project work, a "
            "Project revision mismatch requires a fresh Snapshot and reassessment without auto- "
            "merge. Metadata has no Tenant-wide revision; current state is protected by the "
            "Tenant Lock and server validation. Summarize safe results; never copy credentials, "
            "signed URLs, raw rows, prompts, or raw tool output into chat. Requested generated- "
            "artifact previews remain allowed. execute_databricks_sql defaults to "
            "environment_code=dev, requires qualified persistent relations, and permits only "
            "reads or unqualified temporary objects."
        ),
        lifespan=lifespan,
        # Audit wraps the gate so refused Stage upload attempts are recorded too.
        middleware=[
            audit,
            AtlasBridgeGate(allow_in_memory=settings.auth_mode is AuthMode.DEV),
        ],
    )

    register_list_tenants_tool(
        server,
        database=database,
        identity_provider=identity_provider,
        authorizer=authorizer,
        audit=audit,
        cursor_signing_key=settings.cursor_signing_key,
    )
    register_get_tenant_details_tool(
        server,
        database=database,
        identity_provider=identity_provider,
        authorizer=authorizer,
        audit=audit,
    )
    register_list_projects_tool(
        server,
        database=database,
        identity_provider=identity_provider,
        authorizer=authorizer,
        audit=audit,
        cursor_signing_key=settings.cursor_signing_key,
    )
    register_get_project_input_scope_tool(
        server,
        database=database,
        identity_provider=identity_provider,
        authorizer=authorizer,
        audit=audit,
        cursor_signing_key=settings.cursor_signing_key,
    )
    register_tenant_lock_tools(
        server,
        database=cast(WriteDatabase, database),
        identity_provider=identity_provider,
        audit=audit,
    )
    register_metadata_change_set_tools(
        server,
        database=cast(WriteDatabase, database),
        identity_provider=identity_provider,
        authorizer=authorizer,
        audit=audit,
    )
    register_project_change_set_tools(
        server,
        database=cast(WriteDatabase, database),
        identity_provider=identity_provider,
        authorizer=authorizer,
        audit=audit,
    )
    register_inspect_metadata_tool(
        server,
        database=database,
        identity_provider=identity_provider,
        authorizer=authorizer,
        audit=audit,
        cursor_signing_key=settings.cursor_signing_key,
    )
    register_read_project_section_tool(
        server,
        database=database,
        identity_provider=identity_provider,
        authorizer=authorizer,
        audit=audit,
        cursor_signing_key=settings.cursor_signing_key,
    )
    register_read_mapping_context_tool(
        server,
        database=database,
        identity_provider=identity_provider,
        authorizer=authorizer,
        audit=audit,
        cursor_signing_key=settings.cursor_signing_key,
    )

    register_execute_databricks_sql_tool(
        server,
        database=cast(DatabricksConnectionDatabase, database),
        identity_provider=identity_provider,
        authorizer=authorizer,
        audit=audit,
        executor=sql_executor,
        max_rows=settings.databricks_sql_max_rows,
        timeout_seconds=settings.databricks_sql_timeout_seconds,
    )
    register_profiling_tools(
        server,
        service=profiling_service,
        identity_provider=identity_provider,
        audit=audit,
    )
    register_describe_project_dataset_tool(
        server,
        identity_provider=identity_provider,
        audit=audit,
    )
    register_create_project_snapshot_tool(
        server,
        database=database,
        identity_provider=identity_provider,
        authorizer=authorizer,
        audit=audit,
        store=shared_snapshot_store,
        download_ttl_seconds=settings.metadata_snapshot_download_ttl_seconds,
        retention_hours=settings.metadata_snapshot_retention_hours,
        max_archive_bytes=settings.metadata_snapshot_max_archive_bytes,
    )
    register_describe_metadata_dataset_tool(
        server,
        identity_provider=identity_provider,
        audit=audit,
    )
    register_create_metadata_snapshot_tool(
        server,
        database=database,
        identity_provider=identity_provider,
        authorizer=authorizer,
        audit=audit,
        store=shared_snapshot_store,
        download_ttl_seconds=settings.metadata_snapshot_download_ttl_seconds,
        retention_hours=settings.metadata_snapshot_retention_hours,
        max_archive_bytes=settings.metadata_snapshot_max_archive_bytes,
    )

    async def live(_request: Request) -> Response:
        return JSONResponse(
            {"status": "live"},
            headers={"Cache-Control": "no-store"},
        )

    async def ready(_request: Request) -> Response:
        readiness = await database.readiness()
        tools = await server.list_tools()
        return JSONResponse(
            {
                "status": "ready" if readiness.ready else "not_ready",
                "code": readiness.code,
                "schema_version": settings.schema_version,
                "mcp_server_version": MCP_SERVER_VERSION,
                "tool_count": len(tools),
            },
            status_code=200 if readiness.ready else 503,
            headers={"Cache-Control": "no-store"},
        )

    async def oauth_protected_resource_metadata(_request: Request) -> Response:
        return JSONResponse(
            {
                "resource": settings.mcp_public_url,
                "authorization_servers": [
                    f"https://login.microsoftonline.com/{settings.entra_tenant_id}/v2.0"
                ],
                "scopes_supported": [f"{settings.mcp_public_url}/workbench.access"],
                "bearer_methods_supported": ["header"],
            },
            headers={"Cache-Control": "public, max-age=300"},
        )

    server.custom_route("/health/live", methods=["GET"])(live)
    server.custom_route("/health/ready", methods=["GET"])(ready)
    server.custom_route("/.well-known/oauth-protected-resource", methods=["GET"])(
        oauth_protected_resource_metadata
    )
    server.custom_route("/.well-known/oauth-protected-resource/mcp", methods=["GET"])(
        oauth_protected_resource_metadata
    )
    return server


async def _expire_tenant_locks(database: Database) -> None:
    while True:
        await asyncio.sleep(60)
        try:
            await database.expire_tenant_locks()
        except DependencyUnavailableError:
            continue
