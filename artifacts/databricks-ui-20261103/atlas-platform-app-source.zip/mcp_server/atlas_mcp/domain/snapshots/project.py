"""Project Snapshot registry and its MCP-writable Project Change Set subset."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, cast

from pydantic import BaseModel, ConfigDict

from atlas_mcp.domain.modeling_records import (
    AnalysisResultRecord,
    AttributeEnrichmentRecord,
    ContextGroupRecord,
    ContextRecord,
    ContextTypeRecord,
    DimensionalAttributeRecord,
    DimensionalEntityRecord,
    DimensionalFactTypeRecord,
    DimensionalRelationshipRecord,
    GeneratedCodeRecord,
    GeneratedCodeSourceSystemRecord,
    LogicalAttributeRecord,
    LogicalEntityRecord,
    LogicalEntityTypeRecord,
    LogicalRelationshipRecord,
    MappingAttributeRecord,
    MappingObjectRecord,
    ModelingRecord,
    ObjectEnrichmentRecord,
    ProfilingProfileRecord,
    ProjectDetailsRecord,
    ProjectInputScopeRecord,
    SubjectAreaRecord,
    SubjectAreaTableRecord,
    ValidationCheckRecord,
    ValidationGroupRecord,
)
from atlas_mcp.domain.portable_validation import (
    PROJECT_RECORD_VALIDATIONS,
    record_validation_contract,
)

from .project_guidance import enrich_project_dataset_schema

type ProjectSection = Literal[
    "project_input_scope",
    "profiling",
    "enrichment",
    "analysis",
    "context",
    "subject_area",
    "logical",
    "dimensional",
    "mapping",
    "code_generation",
    "validation",
]

type ProjectDataset = Literal[
    "project_details",
    "project_input_scope",
    "profiling_profile",
    "object_enrichment",
    "attribute_enrichment",
    "analysis_result",
    "context_type",
    "context_group",
    "context_record",
    "subject_area",
    "subject_area_table",
    "logical_entity_type",
    "logical_entity",
    "logical_attribute",
    "logical_relationship",
    "dimensional_fact_type",
    "dimensional_entity",
    "dimensional_attribute",
    "dimensional_relationship",
    "mapping_object",
    "mapping_attribute",
    "generated_code",
    "generated_code_source_system",
    "validation_group",
    "validation_check",
]

type ProjectChangeSetDataset = Literal[
    "project_details",
    "project_input_scope",
    "profiling_profile",
    "object_enrichment",
    "attribute_enrichment",
    "analysis_result",
    "context_group",
    "context_record",
    "subject_area",
    "subject_area_table",
    "logical_entity",
    "logical_attribute",
    "logical_relationship",
    "dimensional_entity",
    "dimensional_attribute",
    "dimensional_relationship",
    "mapping_object",
    "mapping_attribute",
    "generated_code",
    "generated_code_source_system",
    "validation_group",
    "validation_check",
]

PROJECT_SECTIONS: tuple[ProjectSection, ...] = (
    "project_input_scope",
    "profiling",
    "enrichment",
    "analysis",
    "context",
    "subject_area",
    "logical",
    "dimensional",
    "mapping",
    "code_generation",
    "validation",
)


@dataclass(frozen=True, slots=True)
class ModelingDatasetDefinition:
    name: ProjectDataset
    section: ProjectSection
    row_model: type[ModelingRecord]
    canonical_key: tuple[str, ...]
    change_set_eligible: bool = True

    @property
    def rows_path(self) -> str:
        return f"data/{self.section}/{self.name}/rows.jsonl"

    @property
    def schema_path(self) -> str:
        return f"schemas/project/{self.name}.schema.json"


class ContractModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)


class ProjectInputScopeSection(ContractModel):
    details: ProjectDetailsRecord
    objects: tuple[ProjectInputScopeRecord, ...]


class ProfilingSection(ContractModel):
    profiles: tuple[ProfilingProfileRecord, ...]


class EnrichmentSection(ContractModel):
    objects: tuple[ObjectEnrichmentRecord, ...] = ()
    attributes: tuple[AttributeEnrichmentRecord, ...] = ()


class AnalysisSection(ContractModel):
    relationships: tuple[AnalysisResultRecord, ...]


class ContextSection(ContractModel):
    types: tuple[ContextTypeRecord, ...]
    groups: tuple[ContextGroupRecord, ...]
    records: tuple[ContextRecord, ...]


class SubjectAreaSection(ContractModel):
    areas: tuple[SubjectAreaRecord, ...]
    tables: tuple[SubjectAreaTableRecord, ...]


class LogicalSection(ContractModel):
    entity_types: tuple[LogicalEntityTypeRecord, ...] = ()
    entities: tuple[LogicalEntityRecord, ...]
    attributes: tuple[LogicalAttributeRecord, ...]
    relationships: tuple[LogicalRelationshipRecord, ...]


class DimensionalSection(ContractModel):
    fact_types: tuple[DimensionalFactTypeRecord, ...] = ()
    entities: tuple[DimensionalEntityRecord, ...]
    attributes: tuple[DimensionalAttributeRecord, ...]
    relationships: tuple[DimensionalRelationshipRecord, ...]


class MappingSection(ContractModel):
    objects: tuple[MappingObjectRecord, ...]
    attributes: tuple[MappingAttributeRecord, ...]


class CodeGenerationSection(ContractModel):
    artifacts: tuple[GeneratedCodeRecord, ...]
    source_systems: tuple[GeneratedCodeSourceSystemRecord, ...]


class ValidationSection(ContractModel):
    groups: tuple[ValidationGroupRecord, ...]
    checks: tuple[ValidationCheckRecord, ...]


class ProjectSnapshot(ContractModel):
    schema_version: Literal["3.0"] = "3.0"
    project_id: int
    project_name: str
    project_revision: int
    is_locked: bool = False
    project_tenant_code: str | None = None
    other_active_project_names: tuple[str, ...] = ()
    project_input_scope: ProjectInputScopeSection
    enrichment: EnrichmentSection = EnrichmentSection()
    profiling: ProfilingSection
    analysis: AnalysisSection
    context: ContextSection
    subject_area: SubjectAreaSection
    logical: LogicalSection
    dimensional: DimensionalSection
    mapping: MappingSection
    code_generation: CodeGenerationSection = CodeGenerationSection(
        artifacts=(),
        source_systems=(),
    )
    validation: ValidationSection = ValidationSection(groups=(), checks=())


def project_snapshot_records(
    snapshot: ProjectSnapshot,
) -> dict[str, tuple[ModelingRecord, ...]]:
    """Flatten one Project Snapshot into its shared dataset registry."""
    return {
        "project_details": (snapshot.project_input_scope.details,),
        "project_input_scope": snapshot.project_input_scope.objects,
        "profiling_profile": snapshot.profiling.profiles,
        "object_enrichment": snapshot.enrichment.objects,
        "attribute_enrichment": snapshot.enrichment.attributes,
        "analysis_result": snapshot.analysis.relationships,
        "context_type": snapshot.context.types,
        "context_group": snapshot.context.groups,
        "context_record": snapshot.context.records,
        "subject_area": snapshot.subject_area.areas,
        "subject_area_table": snapshot.subject_area.tables,
        "logical_entity_type": snapshot.logical.entity_types,
        "logical_entity": snapshot.logical.entities,
        "logical_attribute": snapshot.logical.attributes,
        "logical_relationship": snapshot.logical.relationships,
        "dimensional_fact_type": snapshot.dimensional.fact_types,
        "dimensional_entity": snapshot.dimensional.entities,
        "dimensional_attribute": snapshot.dimensional.attributes,
        "dimensional_relationship": snapshot.dimensional.relationships,
        "mapping_object": snapshot.mapping.objects,
        "mapping_attribute": snapshot.mapping.attributes,
        "generated_code": snapshot.code_generation.artifacts,
        "generated_code_source_system": snapshot.code_generation.source_systems,
        "validation_group": snapshot.validation.groups,
        "validation_check": snapshot.validation.checks,
    }


def build_project_dataset_schema(
    definition: ModelingDatasetDefinition,
) -> dict[str, object]:
    # Validation mode includes every JSON representation accepted when staging records.
    # Snapshot-serialized values remain a valid subset of this contract.
    generated = definition.row_model.model_json_schema(mode="validation")
    properties = generated.get("properties")
    if not isinstance(properties, dict):
        raise ValueError(f"{definition.name} generated an invalid JSON Schema")
    schema: dict[str, object] = {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": definition.schema_path,
        "title": definition.row_model.__name__,
        "description": (
            f"One exact ID-free {definition.name} record "
            + (
                "shared by Project Snapshots and Project Change Sets."
                if definition.change_set_eligible
                else "available only through Project Snapshot and read tools."
            )
        ),
        "type": "object",
        "additionalProperties": False,
        "$defs": generated.get("$defs", {}),
        "properties": cast(dict[str, object], properties),
        "required": generated.get("required", []),
        "x-gds-dataset": definition.name,
        "x-gds-section": definition.section,
        "x-gds-canonical-key": list(definition.canonical_key),
        "x-gds-database-ids-included": False,
        "x-gds-portable-identity-fields": ["context_record_id"]
        if definition.name == "context_record"
        else [],
        "x-gds-change-set-eligible": definition.change_set_eligible,
    }
    enrich_project_dataset_schema(definition.name, schema)
    rules = PROJECT_RECORD_VALIDATIONS.get(definition.name)
    if rules is not None:
        schema["x-gds-record-validation"] = record_validation_contract(rules)
    return schema


DATASETS = (
    ModelingDatasetDefinition(
        name="project_details",
        section="project_input_scope",
        row_model=ProjectDetailsRecord,
        canonical_key=(),
    ),
    ModelingDatasetDefinition(
        name="project_input_scope",
        section="project_input_scope",
        row_model=ProjectInputScopeRecord,
        canonical_key=(
            "tenant_code",
            "system_code",
            "connection_code",
            "object_schema",
            "object_name",
        ),
    ),
    ModelingDatasetDefinition(
        name="profiling_profile",
        section="profiling",
        row_model=ProfilingProfileRecord,
        canonical_key=(
            "tenant_code",
            "system_code",
            "connection_code",
            "object_schema",
            "object_name",
            "attribute_name",
        ),
    ),
    ModelingDatasetDefinition(
        name="object_enrichment",
        section="enrichment",
        row_model=ObjectEnrichmentRecord,
        canonical_key=(
            "tenant_code",
            "system_code",
            "connection_code",
            "object_schema",
            "object_name",
        ),
    ),
    ModelingDatasetDefinition(
        name="attribute_enrichment",
        section="enrichment",
        row_model=AttributeEnrichmentRecord,
        canonical_key=(
            "tenant_code",
            "system_code",
            "connection_code",
            "object_schema",
            "object_name",
            "attribute_name",
        ),
    ),
    ModelingDatasetDefinition(
        name="analysis_result",
        section="analysis",
        row_model=AnalysisResultRecord,
        canonical_key=(
            "from_tenant_code",
            "from_system_code",
            "from_connection_code",
            "from_object_schema",
            "from_object_name",
            "from_attribute_name",
            "to_tenant_code",
            "to_system_code",
            "to_connection_code",
            "to_object_schema",
            "to_object_name",
            "to_attribute_name",
            "relationship_kind",
        ),
    ),
    ModelingDatasetDefinition(
        name="context_type",
        section="context",
        row_model=ContextTypeRecord,
        canonical_key=("context_type_name",),
        change_set_eligible=False,
    ),
    ModelingDatasetDefinition(
        name="context_group",
        section="context",
        row_model=ContextGroupRecord,
        canonical_key=("context_group_name",),
    ),
    ModelingDatasetDefinition(
        name="context_record",
        section="context",
        row_model=ContextRecord,
        canonical_key=("context_record_id",),
    ),
    ModelingDatasetDefinition(
        name="subject_area",
        section="subject_area",
        row_model=SubjectAreaRecord,
        canonical_key=("subject_area_name",),
    ),
    ModelingDatasetDefinition(
        name="subject_area_table",
        section="subject_area",
        row_model=SubjectAreaTableRecord,
        canonical_key=(
            "subject_area_name",
            "tenant_code",
            "system_code",
            "connection_code",
            "object_schema",
            "object_name",
        ),
    ),
    ModelingDatasetDefinition(
        name="logical_entity_type",
        section="logical",
        row_model=LogicalEntityTypeRecord,
        canonical_key=("logical_entity_type_code",),
        change_set_eligible=False,
    ),
    ModelingDatasetDefinition(
        name="logical_entity",
        section="logical",
        row_model=LogicalEntityRecord,
        canonical_key=("logical_entity_schema_name", "logical_entity_name"),
    ),
    ModelingDatasetDefinition(
        name="logical_attribute",
        section="logical",
        row_model=LogicalAttributeRecord,
        canonical_key=(
            "logical_entity_schema_name",
            "logical_entity_name",
            "logical_attribute_name",
        ),
    ),
    ModelingDatasetDefinition(
        name="logical_relationship",
        section="logical",
        row_model=LogicalRelationshipRecord,
        # One foreign-key Attribute points at one parent.
        canonical_key=(
            "from_logical_entity_schema_name",
            "from_logical_entity_name",
            "from_logical_attribute_name",
        ),
    ),
    ModelingDatasetDefinition(
        name="dimensional_fact_type",
        section="dimensional",
        row_model=DimensionalFactTypeRecord,
        canonical_key=("dimensional_fact_type_code",),
        change_set_eligible=False,
    ),
    ModelingDatasetDefinition(
        name="dimensional_entity",
        section="dimensional",
        row_model=DimensionalEntityRecord,
        canonical_key=("dimensional_entity_schema_name", "dimensional_entity_name"),
    ),
    ModelingDatasetDefinition(
        name="dimensional_attribute",
        section="dimensional",
        row_model=DimensionalAttributeRecord,
        canonical_key=(
            "dimensional_entity_schema_name",
            "dimensional_entity_name",
            "dimensional_attribute_name",
        ),
    ),
    ModelingDatasetDefinition(
        name="dimensional_relationship",
        section="dimensional",
        row_model=DimensionalRelationshipRecord,
        # One foreign-key Attribute points at one dimension.
        canonical_key=(
            "from_dimensional_entity_schema_name",
            "from_dimensional_entity_name",
            "from_dimensional_attribute_name",
        ),
    ),
    ModelingDatasetDefinition(
        name="mapping_object",
        section="mapping",
        row_model=MappingObjectRecord,
        canonical_key=(
            "modeled_entity_type",
            "modeled_entity_schema_name",
            "modeled_entity_name",
            "source_system_code",
        ),
    ),
    ModelingDatasetDefinition(
        name="mapping_attribute",
        section="mapping",
        row_model=MappingAttributeRecord,
        canonical_key=(
            "modeled_entity_type",
            "modeled_entity_schema_name",
            "modeled_entity_name",
            "modeled_attribute_name",
            "source_system_code",
        ),
    ),
    ModelingDatasetDefinition(
        name="generated_code",
        section="code_generation",
        row_model=GeneratedCodeRecord,
        canonical_key=(
            "modeled_entity_type",
            "modeled_entity_schema_name",
            "modeled_entity_name",
            "artifact_name",
        ),
    ),
    ModelingDatasetDefinition(
        name="generated_code_source_system",
        section="code_generation",
        row_model=GeneratedCodeSourceSystemRecord,
        canonical_key=(
            "modeled_entity_type",
            "modeled_entity_schema_name",
            "modeled_entity_name",
            "artifact_name",
            "source_system_code",
        ),
    ),
    ModelingDatasetDefinition(
        name="validation_group",
        section="validation",
        row_model=ValidationGroupRecord,
        canonical_key=(
            "tenant_code",
            "system_code",
            "validation_group_name",
        ),
    ),
    ModelingDatasetDefinition(
        name="validation_check",
        section="validation",
        row_model=ValidationCheckRecord,
        canonical_key=(
            "tenant_code",
            "system_code",
            "validation_group_name",
            "validation_check_name",
        ),
    ),
)

DATASETS_BY_NAME = {definition.name: definition for definition in DATASETS}
CHANGE_SET_DATASETS = tuple(definition for definition in DATASETS if definition.change_set_eligible)
CHANGE_SET_DATASETS_BY_NAME = {definition.name: definition for definition in CHANGE_SET_DATASETS}
# Changed only by governed web commands and Profiling runs, so MCP Stage refuses them.
# Atlas mirrors this list in atlas/atlas-plugin/atlas-local-workbench/core.js.
WEB_MANAGED_PROJECT_DATASETS: frozenset[ProjectChangeSetDataset] = frozenset(
    {"project_input_scope", "profiling_profile"}
)
