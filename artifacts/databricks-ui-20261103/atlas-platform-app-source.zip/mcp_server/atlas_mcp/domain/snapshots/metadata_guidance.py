"""Project-friendly authoring guidance for shared Metadata dataset contracts."""

from __future__ import annotations

from dataclasses import dataclass
from typing import cast

from atlas_mcp.domain.snapshots.description import (
    DatasetColumnAcceptedValues,
    DatasetColumnDescription,
    DatasetColumnReference,
    DatasetDescription,
    JsonScalar,
)

from .metadata import DATASETS, DatasetDefinition

_CONSTRAINT_KEYS = (
    "format",
    "minLength",
    "maxLength",
    "pattern",
    "minimum",
    "maximum",
    "exclusiveMinimum",
    "exclusiveMaximum",
    "minItems",
    "maxItems",
)


@dataclass(frozen=True, slots=True)
class ColumnGuidance:
    description: str
    population_guidance: str
    examples: tuple[JsonScalar, ...] = ()


_EXACT_GUIDANCE = {
    "value": ColumnGuidance(
        "Optional additional details stored as JSONB.",
        "Use only when the user explicitly requests extra details. Leave null otherwise. "
        "Preserve existing JSON; it does not change orchestration behavior by itself.",
    ),
    "member_group_name": ColumnGuidance(
        "Optional execution filter for a Copy Group within the same Tenant and System.",
        "Use only when explicitly requested and supported by the System. Copy Group Control "
        "links the Copy Group to a Member Group; null means no Member Group filter.",
    ),
    "member_code": ColumnGuidance(
        "Member business code, unique within its Member Group.",
        "Use the requested filter member code. Tenant/System/Member Group identify its parent.",
    ),
    "member_attribute_name": ColumnGuidance(
        "Attribute name used by the orchestration framework for this Member filter.",
        "Use the exact requested source Attribute name; use null when unspecified. "
        "Metadata registration does not execute or invent a filter.",
    ),
    "attribute_custom_code": ColumnGuidance(
        "Replacement SELECT expression for SQL-based Source or Bronze ingestion.",
        "Blank leaves the column unchanged. Populated code replaces the column completely; "
        "include its output alias and any required cast. File copying ignores this field. "
        "For APIs, confirm the orchestration implementation before using it.",
    ),
    "attribute_data_type": ColumnGuidance(
        "Physical data type of the Attribute.",
        "Use the data-type spelling accepted by the owning platform, including precision "
        "or scale when applicable.",
        ("varchar(200)",),
    ),
    "attribute_inferred_data_type": ColumnGuidance(
        "Source or inferred semantic data type, separate from physical storage.",
        "Preserve the physical attribute_data_type. Populate this field from source "
        "schema evidence or conservative sample inference; use null when unknown. "
        "Downstream authoring should consider it when choosing types and explicit casts.",
        ("DECIMAL(18,2)",),
    ),
    "attribute_nullability": ColumnGuidance(
        "Whether the physical Attribute permits null values.",
        "Use true when null is permitted and false when every row must contain a value.",
        (True,),
    ),
    "attribute_ordinal_position": ColumnGuidance(
        "One-based position of the Attribute within its Object.",
        "Use a positive integer unique within the Object and preserve the intended column order.",
        (1,),
    ),
    "batch_attribute_name": ColumnGuidance(
        "Optional Attribute used to identify or partition ingestion batches for the Object.",
        "Use null when the Object has no batch Attribute; otherwise use an Attribute name "
        "belonging to this Object.",
        ("batch_id",),
    ),
    "copy_group_control_initial_load_date": ColumnGuidance(
        "Initial effective date recorded for this Copy Group control state.",
        "Use an ISO 8601 date or null when the initial-load date has not been established.",
        ("2026-01-01",),
    ),
    "copy_group_control_last_run_time": ColumnGuidance(
        "Timestamp of the most recently completed run represented by this control state.",
        "Use an ISO 8601 timestamp with an offset, or null before the first completed run.",
        ("2026-01-01T12:00:00Z",),
    ),
    "copy_group_control_last_run_value": ColumnGuidance(
        "Last incremental watermark or cursor value stored for this control state.",
        "Use the exact serialized value expected by the incremental extraction logic; use "
        "null when no watermark exists.",
    ),
    "copy_source_file_delimiter": ColumnGuidance(
        "Delimiter used when reading a delimited source file.",
        "Use null for non-delimited sources; otherwise provide the exact delimiter characters.",
        (",",),
    ),
    "copy_source_file_name": ColumnGuidance(
        "Intermediate landing filename used by the orchestration framework.",
        "Use the framework's confirmed landing naming convention; use null when unnecessary.",
        ("orders.csv",),
    ),
    "copy_source_file_pattern": ColumnGuidance(
        "Intermediate landing file pattern used by the orchestration framework.",
        "Use the framework's confirmed naming/pattern convention; use null when unnecessary.",
        ("orders_*.csv",),
    ),
    "copy_source_incremental_sql_script": ColumnGuidance(
        "Optional SQL filter fragment for incremental Copy execution.",
        "Include WHERE in the stored fragment; it is not added automatically. Use only "
        "confirmed framework placeholders. Blank appends no filter.",
    ),
    "copy_source_initial_sql_script": ColumnGuidance(
        "Optional SQL filter fragment for initial Copy execution.",
        "Include WHERE in the stored fragment; it is not added automatically. Use only "
        "confirmed framework placeholders. Blank appends no filter.",
    ),
    "copy_source_order": ColumnGuidance(
        "Sort order of the Copy within its Copy Group.",
        "Use a positive integer, normally 1. Equal values are allowed; "
        "this is a sort hint, not a completion barrier.",
        (1,),
    ),
    "copy_source_record_limit": ColumnGuidance(
        "Optional chunking parameter represented as an integer string.",
        "Use the selected Chunk Type's description/code to determine its meaning; do not "
        "assume it is an ordinary SQL row limit. Blank when chunking does not need it.",
        ("100000",),
    ),
    "copy_source_record_limit_attribute": ColumnGuidance(
        "Optional parameter used by the selected chunking logic.",
        "Populate only as required by the Chunk Type's documented implementation.",
        ("created_time",),
    ),
    "fc_attribute_name": ColumnGuidance(
        "Optional foreign-catalog name of the Attribute.",
        "Use null when the Connection does not use a foreign catalog; otherwise copy the "
        "Attribute name exactly as exposed by that catalog.",
    ),
    "fc_object_name": ColumnGuidance(
        "Optional foreign-catalog name of the Object.",
        "Use null when the Connection does not use a foreign catalog; otherwise copy the "
        "Object name exactly as exposed by that catalog.",
    ),
    "fc_object_schema": ColumnGuidance(
        "Optional foreign-catalog schema containing the Object.",
        "Use null when the Connection does not use a foreign catalog; otherwise copy the "
        "schema exactly as exposed by that catalog.",
    ),
    "foreign_catalog": ColumnGuidance(
        "Optional external catalog associated with the Connection.",
        "Use null when has_foreign_catalog is false; otherwise provide the exact accessible "
        "catalog name.",
        ("source_catalog",),
    ),
    "gds_admin_catalog": ColumnGuidance(
        "Catalog containing administrative GDS metadata for the Tenant.",
        "Provide the exact accessible catalog name configured for GDS administration.",
        ("gds_admin",),
    ),
    "gds_connection_code": ColumnGuidance(
        "Connection code of the optional GDS data-store Connection for the Tenant.",
        "Populate this together with gds_connection_tenant_code and "
        "gds_connection_system_code, or set all three fields to null.",
    ),
    "gds_connection_system_code": ColumnGuidance(
        "System code of the optional GDS data-store Connection for the Tenant.",
        "Populate this together with gds_connection_tenant_code and gds_connection_code, "
        "or set all three fields to null.",
    ),
    "gds_connection_tenant_code": ColumnGuidance(
        "Tenant code owning the optional GDS data-store Connection.",
        "Populate this together with gds_connection_system_code and gds_connection_code, "
        "or set all three fields to null.",
    ),
    "has_foreign_catalog": ColumnGuidance(
        "Whether the Connection exposes its Objects through a foreign catalog.",
        "Use true only when foreign_catalog and foreign-catalog Object names are meaningful.",
        (False,),
    ),
    "is_active": ColumnGuidance(
        "Whether the record is active for normal governed use.",
        "Use true for an effective record and false to retain it as inactive history.",
        (True,),
    ),
    "is_global_data_store": ColumnGuidance(
        "Whether the Connection is the governed global data-store Connection.",
        "Use true only for a Connection intentionally designated as a global data store.",
        (False,),
    ),
    "is_locked": ColumnGuidance(
        "Whether this Object or Attribute is protected from metadata authoring.",
        "Preserve the current value. A locked Object protects itself and all its "
        "Attributes; an Attribute lock additionally protects that Attribute.",
        (False,),
    ),
    "is_mapped": ColumnGuidance(
        "Reserved mapping flag, currently unused by downstream orchestration.",
        "Default new records to false; preserve existing values on unrelated edits.",
        (False,),
    ),
    "is_masking_required": ColumnGuidance(
        "Whether downstream handling must mask the Attribute.",
        "Use true when the Attribute is classified as requiring masking; otherwise use false.",
        (False,),
    ),
    "is_member_group_required": ColumnGuidance(
        "Whether this Copy Group uses Member Group filtering during orchestration.",
        "Use true only when explicitly requested for a System supporting Member Group filters. "
        "Otherwise use false and a null Member Group on Copy Group Control.",
        (False,),
    ),
    "is_meta_data": ColumnGuidance(
        "Whether the Attribute contains operational metadata rather than business data.",
        "Use true for audit, lineage, or framework-maintained Attributes; otherwise use false.",
        (False,),
    ),
    "is_natural_key": ColumnGuidance(
        "Whether the Attribute is part of the Object's business or natural key.",
        "Use true only when the Attribute participates in the stable business identity.",
        (False,),
    ),
    "is_purge": ColumnGuidance(
        "Reserved purge flag, currently unused by downstream orchestration.",
        "Default new records to false; preserve existing values on unrelated edits.",
        (False,),
    ),
    "is_surrogate_key": ColumnGuidance(
        "Whether the Attribute is a generated surrogate key.",
        "Use true only for a generated technical identifier, not a business key.",
        (False,),
    ),
    "member_group_initial_load_date": ColumnGuidance(
        "Initial load date assigned to the Member Group.",
        "Use an ISO 8601 date or null when the Member Group has no fixed initial date.",
        ("2026-01-01",),
    ),
    "object_transformation": ColumnGuidance(
        "Reserved Object transformation field; current orchestration does not use it.",
        "Default blank. Attribute custom code, not this field, supplies SELECT replacements.",
    ),
    "process_group_dependency_order": ColumnGuidance(
        "Dependency level of the Process Group within its Zone phase.",
        "Use a positive integer, default 1 for new groups. Equal levels may run together; "
        "lower levels must finish successfully before higher levels. "
        "Review existing groups explicitly.",
        (1,),
    ),
    "process_execution_order": ColumnGuidance(
        "Execution order of the Process within its Process Group.",
        "Use a positive integer representing the intended order; lower values execute first.",
        (1,),
    ),
    "process_executable": ColumnGuidance(
        "Executable, notebook, procedure, or job name invoked by the Process.",
        "Provide the exact executable identifier understood at process_location.",
        ("load_orders",),
    ),
    "process_location": ColumnGuidance(
        "Location containing the Process executable.",
        "Provide the governed workspace path, schema, or runtime location expected by the "
        "selected Process Type.",
        ("/Shared/etl",),
    ),
    "source_tenant_code": ColumnGuidance(
        "Tenant whose data the Object contains.",
        "Use the actual source Tenant. For Bronze, Silver, and Gold this may differ from "
        "tenant_code, system_code, and connection_code, which identify the GDS placement.",
        ("ACME",),
    ),
    "tenant_catalog": ColumnGuidance(
        "Primary data catalog assigned to the Tenant.",
        "Provide the exact accessible catalog name used for the Tenant's governed data.",
        ("acme_data",),
    ),
    "tenant_visibility": ColumnGuidance(
        "Visibility boundary of the Tenant.",
        "Use private for Tenant-scoped visibility or global only for intentionally shared "
        "Tenant metadata.",
        ("private",),
    ),
}

_EXAMPLES = {
    "lane_code": "DATA_PLATFORM",
    "lane_name": "Enterprise Data Platform",
    "tenant_code": "ACME",
    "tenant_name": "Acme",
    "system_code": "ERP",
    "system_name": "Enterprise ERP",
    "connection_code": "SOURCE",
    "connection_name": "ERP Source",
    "object_schema": "sales",
    "object_name": "orders",
    "attribute_name": "customer_id",
    "zone_code": "source",
    "copy_group_name": "Daily Orders",
    "member_group_name": "North America",
    "process_group_name": "Silver Orders",
    "chunk_type_name": "date_range",
    "file_type_name": "csv",
    "data_operation_name": "merge",
    "process_type_name": "notebook",
}


def build_metadata_dataset_description(
    definition: DatasetDefinition,
    properties: dict[str, object],
    required_fields: set[str],
) -> DatasetDescription:
    """Describe every field using the exact schema plus curated authoring guidance."""
    columns: list[DatasetColumnDescription] = []
    for name in definition.row_model.model_fields:
        raw_schema = properties.get(name)
        if not isinstance(raw_schema, dict):
            raise ValueError(f"{definition.name}.{name} has no property schema")
        property_schema = cast(dict[str, object], raw_schema)
        guidance = _column_guidance(name)
        references = _column_references(definition, name)
        fixed_values = dict(definition.fixed_values)
        value_contract = _accepted_values(
            name,
            property_schema,
            fixed_values=fixed_values,
            references=references,
        )
        population_guidance = _population_guidance(
            definition,
            name,
            guidance.population_guidance,
            fixed_values=fixed_values,
            references=references,
        )
        column = DatasetColumnDescription(
            name=name,
            data_types=tuple(_data_types(property_schema)),
            required=name in required_fields,
            nullable="null" in _data_types(property_schema),
            description=guidance.description,
            population_guidance=population_guidance,
            accepted_values=value_contract,
            examples=guidance.examples or _examples(name),
        )
        column_document = column.model_dump(mode="json")
        property_schema["description"] = guidance.description
        property_schema["x-gds-population-guidance"] = population_guidance
        property_schema["x-gds-accepted-values"] = column_document["accepted_values"]
        if column.examples:
            property_schema["examples"] = column_document["examples"]
        columns.append(column)
    return DatasetDescription(
        population_rules=metadata_population_rules(definition),
        columns=tuple(columns),
    )


def metadata_population_rules(definition: DatasetDefinition) -> tuple[str, ...]:
    """Publish dataset-level rules that cannot be explained by one field alone."""
    rules = [
        "Supply every required column. A required nullable column must still be present; "
        "use null only when its column guidance permits it.",
        (
            f"The normalized natural key is ({', '.join(definition.canonical_key)}); "
            "one record must be unique by this complete key."
        ),
    ]
    if not definition.change_set_eligible:
        rules.append(
            "This dataset is read-only Snapshot context and cannot be staged in a Metadata "
            "Change Set."
        )
    for constraint in definition.unique_constraints:
        if constraint != definition.canonical_key:
            rules.append(f"Values must also be unique by ({', '.join(constraint)}).")
    for field, value in definition.fixed_values:
        rules.append(f"{field} must be exactly {value!r} in this dataset.")
    for reference in definition.references:
        candidates = [
            candidate.name
            for candidate in DATASETS
            if candidate.record_type == reference.target_record_type
        ]
        nullable = "may all be null" if reference.nullable else "must all be populated"
        rules.append(
            f"Reference columns ({', '.join(reference.columns)}) {nullable} and, when "
            f"populated, must match ({', '.join(reference.target_columns)}) in one of: "
            f"{', '.join(candidates)}."
        )
    if definition.name in {"copy_group", "member_group", "member", "copy_group_control", "copy"}:
        rules.append(
            "Pipeline triggers take one Tenant and a comma-separated System list. Omitted Copy "
            "Groups select all Copy Groups in each selected System; provided groups "
            "restrict execution "
            "to those groups. Member Groups are optional Copy Group filters for "
            "supporting Systems. "
            "Create or apply member filtering only when the user explicitly requests it."
        )
    if definition.name == "tenant":
        rules.append(
            "gds_connection_tenant_code, gds_connection_system_code, and "
            "gds_connection_code must be populated together or all set to null."
        )
    if definition.record_type == "object":
        rules.append(
            "source_tenant_code identifies its metadata/user-selected owner, independently of "
            "Project ownership. "
            "tenant_code, "
            "system_code, and connection_code identify its physical Connection."
        )
    if definition.name in {"bronze_object", "silver_object", "gold_object"}:
        rules.append(
            "Use the applicable GDS Tenant/System/Connection for physical placement; do "
            "not replace it with the source Tenant."
        )
    if definition.name == "source_object":
        rules.append(
            "Source profiling requires the Connection foreign catalog plus fc_object_schema, "
            "fc_object_name, and each fc_attribute_name; no direct source connection is allowed."
        )
    return tuple(rules)


def _column_guidance(name: str) -> ColumnGuidance:
    exact = _EXACT_GUIDANCE.get(name)
    if exact is not None:
        return exact
    label = _label(name)
    if name.endswith("_description"):
        subject = _label(name.removesuffix("_description"))
        return ColumnGuidance(
            f"Plain-language description of the {subject}.",
            "Provide concise business or operational context; use null when no description "
            "is available.",
        )
    if name.endswith("_code"):
        return ColumnGuidance(
            f"Stable code identifying the {label.removesuffix(' Code')}.",
            "Use the canonical code from the referenced record when a reference is declared; "
            "otherwise use a stable nonblank code and do not use a database ID.",
            _examples(name),
        )
    if name.endswith("_name"):
        return ColumnGuidance(
            f"Name identifying the {label.removesuffix(' Name')}.",
            "Use the exact name from the referenced record when a reference is declared; "
            "otherwise provide a stable nonblank name.",
            _examples(name),
        )
    if name.endswith("_schema"):
        return ColumnGuidance(
            f"Schema containing the {label.removesuffix(' Schema')}.",
            "Use the exact platform schema name. Preserve case only when the owning platform "
            "treats it as significant.",
            _examples(name),
        )
    raise ValueError(f"Metadata column guidance is missing for {name}")


def _accepted_values(
    name: str,
    schema: dict[str, object],
    *,
    fixed_values: dict[str, object],
    references: tuple[DatasetColumnReference, ...],
) -> DatasetColumnAcceptedValues:
    constraints = _constraints(schema)
    if name in fixed_values:
        return DatasetColumnAcceptedValues(
            kind="fixed",
            values=(_json_scalar(fixed_values[name]),),
            references=references,
            constraints=constraints,
        )
    enum_values = _enum_values(schema)
    if enum_values:
        return DatasetColumnAcceptedValues(
            kind="literal",
            values=tuple(_json_scalar(value) for value in enum_values),
            references=references,
            constraints=constraints,
        )
    if [value for value in _data_types(schema) if value != "null"] == ["boolean"]:
        return DatasetColumnAcceptedValues(
            kind="literal",
            values=(False, True),
            references=references,
            constraints=constraints,
        )
    if references:
        return DatasetColumnAcceptedValues(
            kind="reference",
            values=(),
            references=references,
            constraints=constraints,
        )
    return DatasetColumnAcceptedValues(
        kind="constrained" if constraints else "freeform",
        values=(),
        references=(),
        constraints=constraints,
    )


def _column_references(
    definition: DatasetDefinition,
    name: str,
) -> tuple[DatasetColumnReference, ...]:
    result: list[DatasetColumnReference] = []
    for reference in definition.references:
        if name not in reference.columns:
            continue
        position = reference.columns.index(name)
        result.append(
            DatasetColumnReference(
                record_type=reference.target_record_type,
                datasets=tuple(
                    candidate.name
                    for candidate in DATASETS
                    if candidate.record_type == reference.target_record_type
                ),
                column=reference.target_columns[position],
                composite_columns=reference.columns,
                target_columns=reference.target_columns,
                nullable=reference.nullable,
            )
        )
    return tuple(result)


def _population_guidance(
    definition: DatasetDefinition,
    name: str,
    base: str,
    *,
    fixed_values: dict[str, object],
    references: tuple[DatasetColumnReference, ...],
) -> str:
    additions: list[str] = []
    if name in fixed_values:
        additions.append(f"For this dataset, use exactly {fixed_values[name]!r}.")
    if references:
        targets = "; ".join(
            f"column {reference.column} in dataset(s) {', '.join(reference.datasets)}"
            for reference in references
        )
        additions.append(
            f"The value must be copied from the referenced value source(s): {targets} "
            "Populate every field in each composite reference together."
        )
    if name in definition.canonical_key:
        additions.append(
            "This field is part of the natural key; changing it identifies a different record."
        )
    return " ".join((base, *additions))


def _data_types(schema: dict[str, object]) -> list[str]:
    result: list[str] = []
    raw_type = schema.get("type")
    if isinstance(raw_type, str):
        result.append(raw_type)
    elif isinstance(raw_type, list):
        result.extend(item for item in cast(list[object], raw_type) if isinstance(item, str))
    raw_any_of = schema.get("anyOf")
    if isinstance(raw_any_of, list):
        for branch in cast(list[object], raw_any_of):
            if isinstance(branch, dict):
                for item in _data_types(cast(dict[str, object], branch)):
                    if item not in result:
                        result.append(item)
    return result


def _enum_values(schema: dict[str, object]) -> list[object]:
    if "const" in schema:
        return [schema["const"]]
    raw_enum = schema.get("enum")
    if isinstance(raw_enum, list):
        return cast(list[object], raw_enum)
    raw_any_of = schema.get("anyOf")
    if isinstance(raw_any_of, list):
        values: list[object] = []
        for branch in cast(list[object], raw_any_of):
            if isinstance(branch, dict):
                values.extend(_enum_values(cast(dict[str, object], branch)))
        return values
    return []


def _json_scalar(value: object) -> JsonScalar:
    if value is None or isinstance(value, str | int | float | bool):
        return value
    raise ValueError("Metadata accepted value is not a JSON scalar")


def _constraints(schema: dict[str, object]) -> dict[str, object]:
    result = {key: schema[key] for key in _CONSTRAINT_KEYS if key in schema}
    raw_any_of = schema.get("anyOf")
    if isinstance(raw_any_of, list):
        for branch in cast(list[object], raw_any_of):
            if isinstance(branch, dict):
                result.update(_constraints(cast(dict[str, object], branch)))
    return result


def _examples(name: str) -> tuple[JsonScalar, ...]:
    direct = _EXAMPLES.get(name)
    if direct is not None:
        return (direct,)
    for prefix in (
        "source_",
        "target_",
        "object_",
        "connection_",
        "scope_",
    ):
        if name.startswith(prefix):
            inherited = _EXAMPLES.get(name.removeprefix(prefix))
            if inherited is not None:
                return (inherited,)
    return ()


def _label(name: str) -> str:
    return name.replace("_", " ").replace("gds", "GDS").replace("fc", "foreign-catalog").title()
