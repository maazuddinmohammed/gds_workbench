"""Transport-independent domain policy."""
