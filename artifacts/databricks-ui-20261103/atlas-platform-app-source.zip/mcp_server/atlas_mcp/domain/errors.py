"""Stable, non-disclosing application failures."""

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class AuthenticationError(Exception):
    """Stable authentication failure shared by deployment adapters."""

    public_code: str
    message: str
    http_status: int

    def __str__(self) -> str:
        return self.message


@dataclass(slots=True)
class AtlasError(Exception):
    code: str
    message: str

    def __str__(self) -> str:
        return self.message


class InvalidRequestError(AtlasError):
    def __init__(self, message: str = "The request is invalid.") -> None:
        super().__init__(code="invalid_request", message=message)


class AuthorizationDeniedError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="authorization_denied",
            message="The current Principal is not authorized for this operation.",
        )


class TenantNotFoundError(AtlasError):
    def __init__(self) -> None:
        super().__init__(code="tenant_not_found", message="Tenant was not found.")


class TenantLockRequiredError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="tenant_lock_required",
            message="An active Tenant Lock owned by the current Principal is required.",
        )


class TenantLockedError(AtlasError):
    def __init__(self, owner_display_name: str) -> None:
        super().__init__(
            code="tenant_locked",
            message=f"Tenant is locked by {owner_display_name}.",
        )


class ProjectLockedError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="project_locked",
            message=(
                "This Project is locked. A human must unlock it in the web application "
                "before changes."
            ),
        )


class ProjectWorkflowConflictError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="project_workflow_conflict",
            message="Cancel or finish queued and running workflows before locking this Project.",
        )


class TenantWorkflowConflictError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="tenant_workflow_conflict",
            message="Another Workflow Run is already active for this Tenant.",
        )


class MetadataChangeSetNotFoundError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="metadata_change_set_not_found",
            message="Metadata Change Set was not found for the current Principal and Tenant.",
        )


class MetadataChangeSetNotActiveError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="metadata_change_set_not_active",
            message="Metadata Change Set is no longer active.",
        )


class MetadataChangeSetNotValidatedError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="metadata_change_set_not_validated",
            message="Metadata Change Set must pass validation before it can be applied.",
        )


class ObjectLockedError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="object_locked",
            message="Object is locked; neither it nor its Attributes can be changed.",
        )


class AttributeLockedError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="attribute_locked",
            message="Attribute is locked and cannot be changed.",
        )


class MappingBranchUnavailableError(AtlasError):
    def __init__(self, record_number: int) -> None:
        super().__init__(
            code="mapping_branch_unavailable",
            message=(
                f"mapping_object record {record_number} makes a Mapping active for a System "
                "that is not one of its Entity's Mapping branches. A Logical Entity maps only "
                "from its source tables' Systems; a Dimensional Entity only from the Systems "
                "of the Logical Entities it is built from."
            ),
        )


class CandidateDigestConflictError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="candidate_digest_conflict",
            message=(
                "The Change Set candidate is not the validated candidate approved for Apply; "
                "validate again and get a new Apply approval."
            ),
        )


class ProjectChangeSetNotFoundError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="project_change_set_not_found",
            message="Project Change Set was not found for the current Principal and Project.",
        )


class ProjectChangeSetNotActiveError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="project_change_set_not_active",
            message="Project Change Set is no longer active.",
        )


class ProjectChangeSetNotValidatedError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="project_change_set_not_validated",
            message="Project Change Set must pass validation before it can be applied.",
        )


class DraftRevisionConflictError(AtlasError):
    def __init__(self, current_revision: int | None = None) -> None:
        message = (
            f"Draft revision changed; current revision is {current_revision}."
            if current_revision is not None
            else "Draft revision changed; inspect the current Change Set before retrying."
        )
        super().__init__(
            code="draft_revision_conflict",
            message=message,
        )


class StageBatchConflictError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="stage_batch_conflict",
            message="A different active Stage Batch already exists for this dataset.",
        )


class StageBatchNotFoundError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="stage_batch_not_found",
            message="Stage Batch was not found for this Change Set and Principal.",
        )


class StageBatchNotActiveError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="stage_batch_not_active",
            message="Stage Batch is no longer active.",
        )


class StageBatchIncompleteError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="stage_batch_incomplete",
            message="Stage Batch chunks do not match its approved manifest.",
        )


class StageChunkConflictError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="stage_chunk_conflict",
            message="This chunk index already contains different records.",
        )


class WebManagedDatasetError(AtlasError):
    def __init__(self, dataset: str) -> None:
        super().__init__(
            code="web_managed_dataset",
            message=f"{dataset} is managed in the web application and cannot be staged.",
        )


class DependencyUnavailableError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="dependency_unavailable",
            message="A required dependency is unavailable.",
        )


class DatabricksConnectionNotFoundError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="databricks_connection_not_found",
            message="An active source Connection was not found.",
        )


class DatabricksConnectionConfigurationError(AtlasError):
    def __init__(self, reason: str) -> None:
        messages = {
            "missing": (
                "The Connection is missing a complete Databricks host, HTTP path, "
                "and token configuration."
            ),
            "environment": ("The requested active Environment was not found for the Connection."),
            "global_connection": ("The source Tenant has no active Global Data Store Connection."),
            "invalid": "The Connection has invalid Databricks configuration values.",
        }
        super().__init__(
            code=f"databricks_connection_configuration_{reason}",
            message=messages.get(reason, messages["invalid"]),
        )


class DatabricksConnectionFailedError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="databricks_connection_failed",
            message=(
                "The Databricks SQL Warehouse connection failed. Check the configured "
                "host, HTTP path, token, Warehouse state, and network access."
            ),
        )


class DatabricksStatementFailedError(AtlasError):
    def __init__(self, statement_index: int) -> None:
        super().__init__(
            code="databricks_statement_failed",
            message=(
                f"Databricks rejected statement {statement_index}. Check its syntax, "
                "object names, permissions, and temporary-object support."
            ),
        )


class DatabricksResultTooLargeError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="databricks_result_too_large",
            message="The bounded Databricks result is too large to return safely.",
        )
