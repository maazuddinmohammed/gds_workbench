"""Tenant MCP tools."""
