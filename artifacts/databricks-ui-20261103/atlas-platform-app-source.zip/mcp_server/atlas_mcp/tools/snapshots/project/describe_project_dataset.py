"""Read-only projection of the shared Project dataset registry."""

# Pyright cannot see that @server.tool registers this nested handler.
# pyright: reportUnusedFunction=false

from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, cast

from mcp.server.mcpserver import Context, MCPServer
from mcp.types import ToolAnnotations

from atlas_mcp.adapters.auth.identity import AuthenticationError, IdentityProvider
from atlas_mcp.adapters.mcp.tool_audit import ToolCallAuditMiddleware
from atlas_mcp.application.project_read import POLICY, ContractModel
from atlas_mcp.domain.errors import AtlasError, InvalidRequestError
from atlas_mcp.domain.snapshots.description import (
    DatasetColumnDescription,
    compact_authoring_schema,
)
from atlas_mcp.domain.snapshots.project import (
    DATASETS_BY_NAME,
    ProjectDataset,
    ProjectSection,
    build_project_dataset_schema,
)
from atlas_mcp.domain.snapshots.project_guidance import project_dataset_population_rules


class DescribeProjectDatasetResult(ContractModel):
    schema_version: Literal["1.0"] = "1.0"
    detail: Literal["compact", "full"]
    dataset: ProjectDataset
    section: ProjectSection
    change_set_eligible: bool
    database_ids_included: Literal[False] = False
    canonical_key: tuple[str, ...]
    population_rules: tuple[str, ...]
    authoring_schema: dict[str, object]
    columns: tuple[DatasetColumnDescription, ...] | None
    record_schema: dict[str, object] | None
    usage: tuple[str, ...]


class ProjectDatasetToolError(Exception):
    """A bounded contract-description failure safe for MCP serialization."""


def register_describe_project_dataset_tool(
    server: MCPServer[None],
    *,
    identity_provider: IdentityProvider,
    audit: ToolCallAuditMiddleware,
) -> None:
    @server.tool(
        description=(
            "Describe one Project dataset before authoring it. Compact detail returns its "
            "canonical key, population and validation rules, and concise ID-free authoring "
            "schema. Full detail additionally returns per-column guidance and the exact JSON "
            "Schema. Neither mode returns Project records."
        ),
        annotations=ToolAnnotations(
            read_only_hint=True,
            destructive_hint=False,
            idempotent_hint=True,
            open_world_hint=False,
        ),
        meta={"gds/toolPolicy": POLICY.value},
        structured_output=True,
    )
    async def describe_project_dataset(
        ctx: Context[None],
        dataset: ProjectDataset,
        detail: Literal["compact", "full"] = "compact",
        schema_version: Literal["1.0"] = "1.0",
    ) -> DescribeProjectDatasetResult:
        del schema_version
        try:
            identity_provider.request_principal(ctx.request_context.request)
            definition = DATASETS_BY_NAME.get(dataset)
            if definition is None:
                raise InvalidRequestError("The Project dataset is unknown.")
            record_schema = build_project_dataset_schema(definition)
            raw_rules = record_schema.get("x-gds-population-rules", [])
            raw_columns = record_schema.get("x-gds-columns", [])
            if not isinstance(raw_rules, list) or not isinstance(raw_columns, list):
                raise ValueError("The Project dataset authoring guidance is invalid.")
            rule_documents = cast(list[object], raw_rules)
            column_documents = cast(list[object], raw_columns)
            if not all(isinstance(rule, str) for rule in rule_documents) or not all(
                isinstance(column, dict) for column in column_documents
            ):
                raise ValueError("The Project dataset authoring guidance is invalid.")
            usage = ("Use every required field and no unlisted field.",)
            if definition.change_set_eligible:
                usage += (
                    "Use canonical names, never database IDs, in Project Change Set records.",
                    "Each staged dataset completely replaces that pending dataset.",
                    "An empty staged record list clears that pending dataset.",
                )
            else:
                usage += ("This dataset is read-only through MCP; it cannot be staged or applied.",)
            usage += project_dataset_population_rules(definition.name)
            return DescribeProjectDatasetResult(
                detail=detail,
                dataset=definition.name,
                section=definition.section,
                change_set_eligible=definition.change_set_eligible,
                canonical_key=definition.canonical_key,
                population_rules=tuple(cast(list[str], rule_documents)),
                authoring_schema=compact_authoring_schema(record_schema),
                columns=(
                    tuple(
                        DatasetColumnDescription.model_validate(column, strict=False)
                        for column in cast(list[dict[str, object]], column_documents)
                    )
                    if detail == "full"
                    else None
                ),
                record_schema=record_schema if detail == "full" else None,
                usage=usage,
            )
        except AuthenticationError as error:
            raise ProjectDatasetToolError(f"{error.public_code}: {error.message}") from None
        except AtlasError as error:
            raise ProjectDatasetToolError(f"{error.code}: {error.message}") from None
        except Exception:
            raise ProjectDatasetToolError(
                "internal_error: The operation could not be completed."
            ) from None

    audit.register_tool(
        "describe_project_dataset",
        policy=POLICY,
        summarize_input=_audit_input,
        retain_arguments={"dataset", "detail", "schema_version"},
    )


def _audit_input(arguments: Mapping[str, Any]) -> dict[str, str]:
    dataset = arguments.get("dataset")
    return {
        "schema_version": ("1.0" if arguments.get("schema_version", "1.0") == "1.0" else "invalid"),
        "detail": (
            arguments.get("detail", "compact")
            if arguments.get("detail", "compact") in {"compact", "full"}
            else "invalid"
        ),
        "dataset": (
            dataset if isinstance(dataset, str) and dataset in DATASETS_BY_NAME else "invalid"
        ),
    }
