"""Metadata Snapshot tool package."""
