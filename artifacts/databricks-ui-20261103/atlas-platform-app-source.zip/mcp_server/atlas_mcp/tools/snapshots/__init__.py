"""Snapshot tools."""
