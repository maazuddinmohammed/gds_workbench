"""Read-only runtime diagnostics."""
