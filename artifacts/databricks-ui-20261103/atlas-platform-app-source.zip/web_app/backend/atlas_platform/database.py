"""Least-privilege PostgreSQL adapter for the web runtime role."""

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import Any, LiteralString

from atlas_mcp.infrastructure.postgres import (
    ReadinessRecord,
    ReadIsolation,
    ReadTransaction,
    WriteTransaction,
    raise_postgres_error,
)
from psycopg import AsyncConnection
from psycopg import Error as PsycopgError
from psycopg.errors import InsufficientPrivilege
from psycopg.rows import dict_row
from psycopg_pool import AsyncConnectionPool

type QueryParameters = tuple[Any, ...]

_READINESS_SQL = """
WITH workflow_functions(signature, required_source, direct_execute) AS (
    VALUES
        ('application.claim_next_workflow_run(integer)',
         ARRAY['%application.claim_workflow_run(p_lease_duration_seconds, ''web'')%'], TRUE),
        ('application.claim_workflow_run(integer,character varying)',
         ARRAY['%ready AS MATERIALIZED%clock_timestamp() AS claimed_time%',
               '%workflow_run_revision_stale%', '%workflow_run_authorization_unavailable%'], FALSE),
        ('application.renew_workflow_run_claim(bigint,uuid,integer)',
         ARRAY['%FOR NO KEY UPDATE OF run;%PERFORM project.assert_writable(v_project_id);%'
               'v_heartbeat_time := clock_timestamp();%'
               'workflow_run_claim_expires_time > v_heartbeat_time%'], TRUE),
        ('application.release_workflow_run_claim(bigint,uuid)',
         ARRAY['%FOR NO KEY UPDATE OF run;%PERFORM project.assert_writable(v_project_id);%'
               'v_released_time := clock_timestamp();%'
               'workflow_run_claim_expires_time > v_released_time%'], TRUE),
        ('application.assert_workflow_run_claim(bigint,uuid)',
         ARRAY['%FOR UPDATE OF run;%v_expires_time <= clock_timestamp()%'], TRUE),
        ('application.fail_workflow_run(uuid,uuid,character varying,bigint,bigint,'
         'character varying,character varying)',
         ARRAY['%Workflow Run has a durable authoring outcome%'], TRUE),
        ('application.get_profiling_execution_context('
         'uuid,uuid,character varying,bigint,bigint)',
         ARRAY['%FOR KEY SHARE OF run FOR SHARE OF target_project%'], TRUE),
        ('application.get_analysis_validation_execution_context('
         'uuid,uuid,character varying,bigint,bigint,character varying)',
         ARRAY['%FOR KEY SHARE OF run FOR SHARE OF target_project%'], TRUE),
        ('application.get_metadata_enrichment_execution_context('
         'uuid,uuid,character varying,bigint,bigint)',
         ARRAY['%FOR KEY SHARE OF run FOR SHARE OF target_project%'], TRUE)
)
SELECT current_setting('server_version_num')::INTEGER / 10000 AS postgres_major,
       to_regclass('application.workflow_run') IS NOT NULL
       AND to_regclass('application.metadata_review_event') IS NOT NULL
       AND EXISTS (SELECT 1 FROM pg_catalog.pg_trigger
                    WHERE tgrelid = to_regclass('application.metadata_review_event')
                      AND tgname = 'guard_metadata_review_event' AND tgenabled = 'O')
       AND EXISTS (SELECT 1 FROM pg_catalog.pg_constraint
                    WHERE conrelid = to_regclass('application.metadata_review_event')
                      AND conname = 'uq_metadata_review_request' AND contype = 'u')
       AND to_regclass('application.workflow_run_model_request') IS NOT NULL
       AND (SELECT count(*) = 3 FROM information_schema.columns
             WHERE table_schema = 'application' AND table_name = 'workflow_run'
               AND (column_name, data_type) IN (
                   ('usage_tracking_version', 'smallint'),
                   ('usage_tracked_recovery_count', 'integer'),
                   ('usage_history_incomplete', 'boolean')
               ))
       AND (SELECT count(*) = 8 FROM information_schema.columns
             WHERE table_schema = 'application' AND table_name = 'workflow_run_model_request'
               AND ((column_name, data_type) IN (
                   ('pricing_basis', 'character varying'),
                   ('pricing_valid_from', 'timestamp with time zone'),
                   ('pricing_valid_until', 'timestamp with time zone'),
                   ('pricing_max_input_tokens', 'bigint')
               ) OR (column_name IN ('pricing_input_usd_per_million',
                   'pricing_cached_input_usd_per_million',
                   'pricing_cache_write_input_usd_per_million',
                   'pricing_output_usd_per_million')
                   AND data_type = 'numeric' AND numeric_precision = 15 AND numeric_scale = 8)))
       AND EXISTS (SELECT 1 FROM pg_catalog.pg_proc
                    WHERE oid = to_regprocedure(
                        'application.begin_workflow_run_usage('
                        'uuid,uuid,character varying,bigint,bigint,uuid)'
                    ) AND prorettype = 'character varying'::REGTYPE)
       AND to_regclass('application.workflow_stage') IS NOT NULL
       AND to_regclass('application.workflow_stage_variable') IS NOT NULL
       AND to_regclass('application.prompt_template') IS NOT NULL
       AND to_regclass('application.workflow_run_object_selection') IS NOT NULL
       AND to_regclass('application.workflow_run_entity_selection') IS NOT NULL
       AND to_regclass('workflow.modeled_entity') IS NOT NULL
       AND to_regclass('workflow.modeled_attribute') IS NOT NULL
       AND (SELECT count(*) = 2 FROM information_schema.columns
             WHERE table_schema = 'project' AND table_name = 'project'
               AND column_name IN ('logical_schemas', 'dimensional_schemas')
               AND data_type = 'jsonb' AND is_nullable = 'NO')
       AND EXISTS (SELECT 1 FROM information_schema.columns
                    WHERE table_schema = 'project' AND table_name = 'project'
                      AND column_name = 'logical_entity_scd_type'
                      AND data_type = 'character varying'
                      AND character_maximum_length = 10 AND is_nullable = 'YES')
       AND EXISTS (SELECT 1 FROM information_schema.columns
                    WHERE table_schema = 'project' AND table_name = 'project'
                      AND column_name = 'dimensional_entity_scd_type'
                      AND data_type = 'character varying'
                      AND character_maximum_length = 10 AND is_nullable = 'YES')
       AND (SELECT count(*) = 2 FROM information_schema.columns
             WHERE table_schema = 'project' AND table_name = 'project'
               AND column_name IN ('logical_coverage_threshold_percent',
                                   'dimensional_coverage_threshold_percent')
               AND data_type = 'integer' AND is_nullable = 'NO')
       AND (SELECT count(*) = 2 FROM information_schema.columns
             WHERE table_schema = 'project' AND table_name = 'project'
               AND column_name IN ('logical_enforce_coverage_threshold',
                                   'dimensional_enforce_coverage_threshold')
               AND data_type = 'boolean' AND is_nullable = 'NO')
       AND to_regclass('workflow.generated_code') IS NOT NULL
       AND to_regclass('project.project_event_log') IS NOT NULL AS schema_ready,
       current_user = 'gds_web_write'
       AND EXISTS (
           SELECT 1
             FROM pg_catalog.pg_roles AS runtime_login
            WHERE runtime_login.rolname = session_user
              AND runtime_login.rolcanlogin
              AND NOT runtime_login.rolsuper
              AND NOT runtime_login.rolinherit
              AND NOT runtime_login.rolcreatedb
              AND NOT runtime_login.rolcreaterole
              AND NOT runtime_login.rolreplication
              AND NOT runtime_login.rolbypassrls
              AND (
                  SELECT count(*)
                    FROM pg_catalog.pg_auth_members AS membership
                   WHERE membership.member = runtime_login.oid
              ) = 1
              AND EXISTS (
                  SELECT 1
                    FROM pg_catalog.pg_auth_members AS membership
                    JOIN pg_catalog.pg_roles AS runtime_group
                      ON runtime_group.oid = membership.roleid
                   WHERE membership.member = runtime_login.oid
                     AND runtime_group.rolname = 'gds_web_write'
                     AND NOT membership.admin_option
                     AND NOT membership.inherit_option
                     AND membership.set_option
              )
       ) AS role_ready,
       has_table_privilege(
           'gds_web_write',
           'application.workflow_run',
           'SELECT'
       )
       AND NOT has_table_privilege(
           'gds_web_write', 'application.workflow_run_model_request', 'INSERT,UPDATE,DELETE'
       )
       AND NOT has_table_privilege(
           'gds_web_write', 'application.metadata_review_event',
           'SELECT,INSERT,UPDATE,DELETE,TRUNCATE,REFERENCES,TRIGGER'
       )
       AND NOT EXISTS (
           SELECT 1 FROM workflow_functions AS required
            WHERE required.direct_execute
              AND NOT coalesce(has_function_privilege(
                  'gds_web_write', to_regprocedure(required.signature), 'EXECUTE'
              ), FALSE)
       )
       AND EXISTS (
           -- SECURITY DEFINER must be able to read and lock the Run itself.
           -- FOR UPDATE needs UPDATE on any column, not a table-wide grant.
           SELECT 1 FROM pg_catalog.pg_proc AS claim_guard
            WHERE claim_guard.oid = to_regprocedure(
                'application.assert_workflow_run_claim(bigint,uuid)'
            )
              AND has_schema_privilege(claim_guard.proowner, 'application', 'USAGE')
              AND has_any_column_privilege(
                  claim_guard.proowner, to_regclass('application.workflow_run'), 'UPDATE'
              )
              AND (
                  SELECT count(*) = 4 AND bool_and(has_column_privilege(
                      claim_guard.proowner, attribute.attrelid, attribute.attnum, 'SELECT'
                  ))
                    FROM pg_catalog.pg_attribute AS attribute
                   WHERE attribute.attrelid = to_regclass('application.workflow_run')
                     AND attribute.attnum > 0 AND NOT attribute.attisdropped
                     AND attribute.attname IN (
                         'workflow_run_id', 'workflow_run_state',
                         'workflow_run_claim_token_digest', 'workflow_run_claim_expires_time'
                     )
              )
       )
       AND NOT EXISTS (
           SELECT 1 FROM unnest(ARRAY[
               'application.authorize_project_record_review('
               'uuid,uuid,character varying,bigint,bigint)'
           ]) AS required_review_function(signature)
           WHERE NOT coalesce(has_function_privilege(
               'gds_web_write', to_regprocedure(required_review_function.signature), 'EXECUTE'
           ), FALSE)
       )
       AND NOT EXISTS (
           SELECT 1 FROM unnest(ARRAY[
               'application.begin_workflow_run_usage('
               'uuid,uuid,character varying,bigint,bigint,uuid)',
               'application.begin_workflow_run_model_request('
               'uuid,uuid,character varying,bigint,bigint,uuid,uuid,uuid,'
               'character varying,integer,integer,jsonb)',
               'application.complete_workflow_run_model_request('
               'uuid,uuid,character varying,bigint,bigint,uuid,uuid,'
               'bigint,bigint,bigint,bigint,bigint,bigint,boolean)'
           ]) AS required_usage_function(signature)
           WHERE NOT coalesce(has_function_privilege(
               'gds_web_write', to_regprocedure(required_usage_function.signature), 'EXECUTE'
           ), FALSE)
       )
       AND coalesce(has_function_privilege(
           'gds_web_write',
           to_regprocedure(
           'application.create_project(uuid,uuid,character varying,bigint,'
           'character varying,character varying,jsonb,jsonb,text,jsonb,text,jsonb,jsonb,'
           'character varying,character varying,character varying,'
           'character varying,integer,integer,character varying,character varying,'
           'integer,integer,boolean,boolean)'),
           'EXECUTE'
       ), FALSE)
       AND has_function_privilege(
           'gds_web_write',
           'workflow.list_tenant_visible_objects(bigint)',
           'EXECUTE'
       )
       AND has_function_privilege(
           'gds_web_write',
           'workflow.list_project_object_eligibility(bigint)',
           'EXECUTE'
       )
       AND has_function_privilege(
           'gds_web_write',
           'workflow.list_project_attribute_eligibility(bigint)',
           'EXECUTE'
       )
       AND coalesce(
           has_function_privilege(
               'gds_web_write',
               to_regprocedure(
                   'application.get_profiling_execution_context('
                   'uuid,uuid,character varying,bigint,bigint)'
               ),
               'EXECUTE'
           ),
           FALSE
       )
       AND has_function_privilege(
           'gds_web_write',
           'workflow.list_mapping_source_objects('
           'bigint,bigint,character varying,bigint)',
           'EXECUTE'
       )
       AND coalesce(has_function_privilege(
           'gds_web_write',
           to_regprocedure('workflow.list_mapping_branches(bigint,character varying)'),
           'EXECUTE'
       ), FALSE)
       AND has_function_privilege(
           'gds_web_write',
           'workflow.list_code_generation_target_context('
           'bigint,character varying,character varying)',
           'EXECUTE'
       )
       AND has_table_privilege(
           'gds_web_write',
           'mcp.project_change_set',
           'SELECT,INSERT,UPDATE'
       )
       AND has_function_privilege(
           'gds_web_write',
           'mcp.create_metadata_change_set('
           'uuid,uuid,character varying,bigint,uuid,uuid)',
           'EXECUTE'
       )
       AND NOT EXISTS (
           SELECT 1
             FROM unnest(ARRAY[
                      'mcp.apply_project_enrichment_change_set('
                      || 'uuid,uuid,character varying,bigint,uuid,bigint,character varying)',
                      'mcp.stage_metadata_change_set('
                      || 'uuid,uuid,character varying,bigint,uuid,bigint,jsonb,uuid)',
                      'mcp.get_metadata_change_set(uuid,uuid,character varying,bigint,uuid)',
                      'mcp.record_metadata_change_set_validation('
                      || 'uuid,uuid,character varying,bigint,uuid,bigint,'
                      || 'boolean,character,jsonb,uuid,uuid)',
                      'mcp.apply_metadata_change_set('
                      || 'uuid,uuid,character varying,bigint,uuid,bigint,'
                      || 'character,uuid)',
                      'mcp.archive_metadata_change_set('
                      || 'uuid,uuid,character varying,bigint,uuid,bigint,uuid)'
                  ]) AS required_web_mcp_function(signature)
            WHERE NOT has_function_privilege(
                      'gds_web_write',
                      required_web_mcp_function.signature,
                      'EXECUTE'
                  )
       )
       AND NOT has_table_privilege(
           'gds_web_write',
           'mcp.metadata_change_set',
           'SELECT,INSERT,UPDATE,DELETE'
       )
       AND NOT has_function_privilege(
           'gds_web_write',
           'mcp.begin_metadata_stage_batch('
           'uuid,uuid,character varying,bigint,uuid,bigint,uuid,'
           'character varying,integer,integer,character,uuid)',
           'EXECUTE'
       )
       AND NOT has_function_privilege(
           'gds_web_write',
           'mcp.get_databricks_sql_connection_values(bigint,text)',
           'EXECUTE'
       )
       AND NOT EXISTS (
           SELECT 1
             FROM pg_catalog.pg_proc AS mcp_function
             JOIN pg_catalog.pg_namespace AS namespace_record
               ON namespace_record.oid = mcp_function.pronamespace
            WHERE namespace_record.nspname = 'mcp'
              AND has_function_privilege(
                      'gds_web_write',
                      mcp_function.oid,
                      'EXECUTE'
                  )
              AND NOT EXISTS (
                      SELECT 1
                        FROM unnest(ARRAY[
                                 'mcp.create_metadata_change_set('
                                 || 'uuid,uuid,character varying,bigint,uuid,uuid)',
                                 'mcp.apply_project_enrichment_change_set('
                      || 'uuid,uuid,character varying,bigint,uuid,bigint,character varying)',
                      'mcp.stage_metadata_change_set('
                                 || 'uuid,uuid,character varying,bigint,uuid,'
                                 || 'bigint,jsonb,uuid)',
                                 'mcp.get_metadata_change_set('
                                 || 'uuid,uuid,character varying,bigint,uuid)',
                                 'mcp.record_metadata_change_set_validation('
                                 || 'uuid,uuid,character varying,bigint,uuid,bigint,'
                                 || 'boolean,character,jsonb,uuid,uuid)',
                                 'mcp.apply_metadata_change_set('
                                 || 'uuid,uuid,character varying,bigint,uuid,bigint,'
                                 || 'character,uuid)',
                                 'mcp.archive_metadata_change_set('
                                 || 'uuid,uuid,character varying,bigint,uuid,bigint,uuid)'
                             ]) AS allowed_web_mcp_function(signature)
                       WHERE to_regprocedure(
                                 allowed_web_mcp_function.signature
                             ) = mcp_function.oid
                  )
       )
       AND has_table_privilege(
           'gds_web_write',
           'workflow.subject_area',
           'SELECT,INSERT,UPDATE'
       )
       AND NOT has_table_privilege(
           'gds_web_write',
           'workflow.attribute_profile',
           'INSERT,UPDATE'
       )
       AND NOT has_table_privilege(
           'gds_web_write',
           'core.connection_value',
           'SELECT'
       ) AS privileges_ready,
       EXISTS (
           SELECT 1
             FROM information_schema.columns AS column_record
            WHERE column_record.table_schema = 'application'
              AND column_record.table_name = 'workflow_run'
              AND column_record.column_name = 'tenant_id'
              AND column_record.data_type = 'bigint'
              AND column_record.is_nullable = 'NO'
       )
       AND EXISTS (
           SELECT 1
             FROM pg_catalog.pg_constraint AS constraint_record
            WHERE constraint_record.conrelid =
                  'application.workflow_run'::REGCLASS
              AND constraint_record.conname = 'fk_workflow_run_project'
              AND constraint_record.contype = 'f'
              AND constraint_record.convalidated
              AND pg_catalog.pg_get_constraintdef(constraint_record.oid) =
                  'FOREIGN KEY (project_id, tenant_id) '
                  'REFERENCES project.project(project_id, tenant_id)'
       )
       AND EXISTS (
           SELECT 1
             FROM pg_catalog.pg_index AS index_record
             JOIN pg_catalog.pg_class AS index_relation
               ON index_relation.oid = index_record.indexrelid
            WHERE index_record.indrelid = 'application.workflow_run'::REGCLASS
              AND index_relation.relname = 'uq_workflow_run_running_tenant'
              AND index_record.indisunique
              AND index_record.indisvalid
              AND index_record.indisready
              AND index_record.indnkeyatts = 1
              AND pg_catalog.pg_get_indexdef(
                      index_relation.oid,
                      1,
                      TRUE
                  ) = 'tenant_id'
              AND pg_catalog.pg_get_expr(
                      index_record.indpred,
                      index_record.indrelid
                  ) = '((workflow_run_state)::text = ''running''::text)'
       )
       AND EXISTS (
           SELECT 1
             FROM pg_catalog.pg_proc AS function_record
            WHERE function_record.oid = pg_catalog.to_regprocedure(
                      'application.start_workflow_run('
                      'uuid,uuid,character varying,bigint,bigint)'
                  )
              AND function_record.prosecdef
              AND function_record.provolatile = 'v'
              AND function_record.proconfig =
                  ARRAY['search_path=pg_catalog']::TEXT[]
              AND function_record.prosrc LIKE
                  '%active_run.tenant_id = v_run.tenant_id%'
              AND function_record.prosrc LIKE
                  '%uq_workflow_run_running_tenant%'
              AND function_record.prosrc LIKE '%tenant_workflow_conflict%'
       )
       -- Application deployment does not update installed SQL. Reject the older
       -- claim/context locks that prevent heartbeats during slow preparation.
       AND NOT EXISTS (
           SELECT 1 FROM workflow_functions AS required
            WHERE NOT EXISTS (
                SELECT 1 FROM pg_catalog.pg_proc AS installed
                 WHERE installed.oid = to_regprocedure(required.signature)
                   AND installed.prosecdef
                   AND installed.provolatile = 'v'
                   AND installed.proconfig = ARRAY['search_path=pg_catalog']::TEXT[]
                   AND regexp_replace(installed.prosrc, '[[:space:]]+', ' ', 'g')
                       LIKE ALL (required.required_source)
            )
       )
       AND EXISTS (
           SELECT 1 FROM information_schema.columns
            WHERE table_schema = 'application' AND table_name = 'prompt_template_version'
              AND column_name = 'agent_tool_names' AND udt_name = '_text'
       ) AS workflow_guard_ready,
       (SELECT count(*) = 31
          FROM application.workflow_stage)
       AND (SELECT count(*) = 31
              FROM application.workflow_stage
             WHERE is_active)
       AND (SELECT count(*) = 271
              FROM application.workflow_stage_variable)
       AND (SELECT count(*) = 271
              FROM application.workflow_stage_variable
             WHERE is_active) AS application_reference_ready
"""

# No web transaction may wait forever. These limits sit above normal work, including a
# large result commit that briefly blocks a heartbeat, so they only end stuck waits: a
# held lock or stalled statement then fails with a safe error instead of a silent hang.
_TRANSACTION_LIMITS_SQL = """
SELECT set_config('lock_timeout', '60s', TRUE),
       set_config('statement_timeout', '600s', TRUE),
       set_config('idle_in_transaction_session_timeout', '300s', TRUE)
"""


class _WebTransaction:
    def __init__(self, connection: AsyncConnection[Any]) -> None:
        self._connection = connection

    async def fetch_one(
        self,
        query: LiteralString,
        parameters: QueryParameters = (),
    ) -> dict[str, Any] | None:
        result = await self._connection.execute(query, parameters)
        row: dict[str, Any] | None = await result.fetchone()
        return row

    async def fetch_all(
        self,
        query: LiteralString,
        parameters: QueryParameters = (),
    ) -> list[dict[str, Any]]:
        result = await self._connection.execute(query, parameters)
        rows: list[dict[str, Any]] = await result.fetchall()
        return rows


class WebPostgresDatabase:
    def __init__(
        self,
        *,
        dsn: str,
        pool_min: int,
        pool_max: int,
        pool_timeout_seconds: int,
    ) -> None:
        self._pool = AsyncConnectionPool(
            conninfo=dsn,
            min_size=pool_min,
            max_size=pool_max,
            timeout=pool_timeout_seconds,
            kwargs={"autocommit": True, "row_factory": dict_row},
            open=False,
            name="gds-web",
        )

    async def open(self) -> None:
        await self._pool.open(wait=False)

    async def close(self) -> None:
        await self._pool.close()

    async def readiness(self) -> ReadinessRecord:
        try:
            async with self._transaction(read_only=True) as connection:
                result = await connection.execute(_READINESS_SQL)
                row = await result.fetchone()
            if row is None or row["postgres_major"] != 18:
                return ReadinessRecord(ready=False, code="database_version_invalid")
            if not row["schema_ready"]:
                return ReadinessRecord(ready=False, code="database_schema_unavailable")
            if not row["workflow_guard_ready"] or not row["application_reference_ready"]:
                return ReadinessRecord(ready=False, code="database_schema_unavailable")
            if not row["role_ready"] or not row["privileges_ready"]:
                return ReadinessRecord(ready=False, code="database_role_invalid")
            return ReadinessRecord(ready=True, code="ready")
        except InsufficientPrivilege:
            return ReadinessRecord(ready=False, code="database_role_invalid")
        except PsycopgError:
            return ReadinessRecord(ready=False, code="database_unavailable")

    @asynccontextmanager
    async def _transaction(
        self,
        *,
        read_only: bool,
        isolation: ReadIsolation = ReadIsolation.READ_COMMITTED,
    ) -> AsyncGenerator[AsyncConnection[Any]]:
        async with self._pool.connection() as connection, connection.transaction():
            if isolation is ReadIsolation.REPEATABLE_READ:
                statement = "SET TRANSACTION ISOLATION LEVEL REPEATABLE READ"
                if read_only:
                    statement += ", READ ONLY"
                await connection.execute(statement)
            elif read_only:
                await connection.execute("SET TRANSACTION READ ONLY")
            await connection.execute("SET LOCAL ROLE gds_web_write")
            await connection.execute(_TRANSACTION_LIMITS_SQL)
            yield connection

    @asynccontextmanager
    async def read_transaction(
        self,
        *,
        isolation: ReadIsolation = ReadIsolation.READ_COMMITTED,
    ) -> AsyncGenerator[ReadTransaction]:
        try:
            async with self._transaction(
                read_only=True,
                isolation=isolation,
            ) as connection:
                yield _WebTransaction(connection)
        except PsycopgError as exc:
            raise_postgres_error(exc)

    @asynccontextmanager
    async def write_transaction(
        self,
        *,
        isolation: ReadIsolation = ReadIsolation.READ_COMMITTED,
    ) -> AsyncGenerator[WriteTransaction]:
        try:
            async with self._transaction(
                read_only=False,
                isolation=isolation,
            ) as connection:
                yield _WebTransaction(connection)
        except PsycopgError as exc:
            raise_postgres_error(exc)
