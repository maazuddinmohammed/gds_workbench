"""Shared deterministic local-fake context and tool helpers."""

from __future__ import annotations

import re
from typing import cast

from atlas_mcp.domain.errors import InvalidRequestError
from pydantic import JsonValue

from atlas_platform.features.workflows.authoring.agent_execution import (
    AgentExecutionRequest,
)

TARGET_REFERENCE = re.compile(r"^[a-z][a-z0-9_]{0,99}$")


def original_context(context: JsonValue) -> dict[str, JsonValue]:
    if not isinstance(context, dict) or set(context) != {"original_context", "repair"}:
        raise InvalidRequestError("The local fake agent context is invalid.")
    repair = context.get("repair")
    if repair is not None and not isinstance(repair, dict):
        raise InvalidRequestError("The local fake agent context is invalid.")
    original = context.get("original_context")
    if not isinstance(original, dict):
        raise InvalidRequestError("The local fake agent context is invalid.")
    return original


FAKE_SOURCE_FIELDS = (
    "tenant_code",
    "system_code",
    "connection_code",
    "object_schema",
    "object_name",
)


def code_generation_target_refs(context: JsonValue) -> tuple[str, ...]:
    if not isinstance(context, dict) or set(context) != {
        "original_context",
        "repair",
    }:
        raise InvalidRequestError("The local fake agent context is invalid.")
    original = context.get("original_context")
    if not isinstance(original, dict) or set(original) != {"targets"}:
        raise InvalidRequestError("The local fake agent context is invalid.")
    targets = original.get("targets")
    if not isinstance(targets, list) or not 1 <= len(targets) <= 50_000:
        raise InvalidRequestError("The local fake agent context is invalid.")

    target_refs: list[str] = []
    for target in targets:
        if not isinstance(target, dict) or set(target) != {"target_ref", "context"}:
            raise InvalidRequestError("The local fake agent context is invalid.")
        target_ref = target.get("target_ref")
        if not isinstance(target_ref, str) or TARGET_REFERENCE.fullmatch(target_ref) is None:
            raise InvalidRequestError("The local fake agent context is invalid.")
        target_refs.append(target_ref)
    if len(target_refs) != len(set(target_refs)):
        raise InvalidRequestError("The local fake agent context is invalid.")
    return tuple(target_refs)


def selected_source_objects(
    context: JsonValue,
) -> tuple[dict[str, JsonValue], ...]:
    if not isinstance(context, dict) or set(context) != {
        "original_context",
        "repair",
    }:
        raise InvalidRequestError("The local fake agent context is invalid.")
    original = context.get("original_context")
    if not isinstance(original, dict):
        raise InvalidRequestError("The local fake agent context is invalid.")
    selected = original.get("selected_objects")
    if not isinstance(selected, list) or not 1 <= len(selected) <= 50_000:
        raise InvalidRequestError("The local fake agent context is invalid.")

    required = (
        "tenant_code",
        "system_code",
        "connection_code",
        "object_schema",
        "object_name",
    )
    sources: list[dict[str, JsonValue]] = []
    identities: set[tuple[str, ...]] = set()
    for selected_item in selected:
        if not isinstance(selected_item, dict):
            raise InvalidRequestError("The local fake agent context is invalid.")
        source = selected_item.get("object")
        if not isinstance(source, dict):
            raise InvalidRequestError("The local fake agent context is invalid.")
        values = tuple(source.get(name) for name in required)
        if any(
            not isinstance(value, str) or not value.strip() or len(value.encode("utf-8")) > 400
            for value in values
        ):
            raise InvalidRequestError("The local fake agent context is invalid.")
        identity = cast(tuple[str, ...], values)
        normalized = tuple(value.strip().casefold() for value in identity)
        if normalized in identities:
            raise InvalidRequestError("The local fake agent context is invalid.")
        identities.add(normalized)
        sources.append(dict(zip(required, identity, strict=True)))
    return tuple(sources)


def named_tool_items(
    request: AgentExecutionRequest, tool_name: str
) -> tuple[list[dict[str, JsonValue]], int]:
    """Read the same cursor pages available to the remote model, without private catalog access."""
    catalog = request.local_tool_catalog
    if catalog is None or tool_name not in request.allowed_tool_names:
        raise InvalidRequestError("The local fake agent context is invalid.")
    rows: list[dict[str, JsonValue]] = []
    arguments: dict[str, JsonValue] = {}
    cursors: set[str] = set()
    calls = 0
    while True:
        page = catalog.invoke(tool_name, arguments)
        calls += 1
        if not isinstance(page, dict) or not isinstance(page.get("items"), list):
            raise InvalidRequestError("The local fake agent context is invalid.")
        for item in cast(list[JsonValue], page["items"]):
            if not isinstance(item, dict):
                raise InvalidRequestError("The local fake agent context is invalid.")
            rows.append(item)
        cursor = page.get("next_cursor")
        if cursor is None:
            if page.get("is_complete") is not True:
                raise InvalidRequestError("The local fake agent context is invalid.")
            return rows, calls
        if not isinstance(cursor, str) or not cursor or cursor in cursors:
            raise InvalidRequestError("The local fake agent context is invalid.")
        cursors.add(cursor)
        arguments = {"cursor": cursor}


def tool_assisted_source_objects(
    request: AgentExecutionRequest,
) -> tuple[tuple[dict[str, JsonValue], ...], int]:
    catalog = request.local_tool_catalog
    if catalog is None:
        raise InvalidRequestError("The local fake agent context is invalid.")
    if "get_objects" in request.allowed_tool_names:
        rows, calls = named_tool_items(request, "get_objects")
        context: JsonValue = {
            "original_context": {"selected_objects": [{"object": row} for row in rows]},
            "repair": None,
        }
        return selected_source_objects(context), calls
    manifest_calls = int("get_agent_context_manifest" in request.allowed_tool_names)
    manifest = (
        catalog.invoke("get_agent_context_manifest", {})
        if manifest_calls
        else original_context(request.context)
    )
    if not isinstance(request.context, dict) or set(request.context) != {
        "original_context",
        "repair",
    }:
        raise InvalidRequestError("The local fake agent context is invalid.")
    if request.context.get("original_context") != manifest:
        raise InvalidRequestError("The local fake agent context is invalid.")
    if request.context.get("repair") is not None:
        repair = request.context.get("repair")
        if not isinstance(repair, dict):
            raise InvalidRequestError("The local fake agent context is invalid.")
    if not isinstance(manifest, dict):
        raise InvalidRequestError("The local fake agent context is invalid.")
    counts = manifest.get("dataset_counts")
    if not isinstance(counts, dict):
        raise InvalidRequestError("The local fake agent context is invalid.")
    selected_count = counts.get("selected_object")
    if (
        isinstance(selected_count, bool)
        or not isinstance(selected_count, int)
        or not 1 <= selected_count <= 50_000
    ):
        raise InvalidRequestError("The local fake agent context is invalid.")

    dataset_definition = next(
        (
            definition
            for definition in catalog.definitions
            if definition.name == "get_agent_context_dataset"
        ),
        None,
    )
    if dataset_definition is None:
        raise InvalidRequestError("The local fake agent context is invalid.")
    properties = dataset_definition.input_schema.get("properties")
    if not isinstance(properties, dict):
        raise InvalidRequestError("The local fake agent context is invalid.")
    limit_schema = properties.get("limit")
    if not isinstance(limit_schema, dict):
        raise InvalidRequestError("The local fake agent context is invalid.")
    page_limit = limit_schema.get("maximum")
    if (
        isinstance(page_limit, bool)
        or not isinstance(page_limit, int)
        or not 1 <= page_limit <= 1_000
    ):
        raise InvalidRequestError("The local fake agent context is invalid.")

    sources: list[dict[str, JsonValue]] = []
    identities: set[tuple[str, ...]] = set()
    offset = 0
    page_calls = 0
    while offset < selected_count:
        limit = min(page_limit, selected_count - offset)
        page = catalog.invoke(
            "get_agent_context_dataset",
            {"dataset": "selected_object", "offset": offset, "limit": limit},
        )
        page_calls += 1
        if page_calls > selected_count or not isinstance(page, dict):
            raise InvalidRequestError("The local fake agent context is invalid.")
        items = page.get("items")
        next_offset = page.get("next_offset")
        if (
            page.get("dataset") != "selected_object"
            or page.get("total_count") != selected_count
            or page.get("offset") != offset
            or not isinstance(items, list)
            or len(items) != limit
        ):
            raise InvalidRequestError("The local fake agent context is invalid.")
        for item in items:
            if not isinstance(item, dict):
                raise InvalidRequestError("The local fake agent context is invalid.")
            source = _source_from_tool_item(item)
            identity = tuple(
                cast(str, source[name]).strip().casefold() for name in FAKE_SOURCE_FIELDS
            )
            if identity in identities:
                raise InvalidRequestError("The local fake agent context is invalid.")
            identities.add(identity)
            sources.append(source)
        expected_next = offset + limit
        if expected_next < selected_count:
            if next_offset != expected_next:
                raise InvalidRequestError("The local fake agent context is invalid.")
            offset = expected_next
        else:
            if next_offset is not None:
                raise InvalidRequestError("The local fake agent context is invalid.")
            offset = selected_count
    if len(sources) != selected_count:
        raise InvalidRequestError("The local fake agent context is invalid.")
    return tuple(sources), page_calls + manifest_calls


def tool_assisted_logical_sources(
    request: AgentExecutionRequest,
) -> tuple[
    tuple[dict[str, JsonValue], ...],
    tuple[dict[str, JsonValue], ...],
    int,
]:
    source_objects, tool_call_count = tool_assisted_source_objects(request)
    if "get_objects" in request.allowed_tool_names:
        groups, calls = named_tool_items(request, "get_object_details")
        selected: list[JsonValue] = []
        for group in groups:
            source = _source_from_tool_item(group)
            attributes = group.get("attributes")
            if not isinstance(attributes, list) or any(
                not isinstance(attribute, dict) for attribute in attributes
            ):
                raise InvalidRequestError("The local fake agent context is invalid.")
            selected.append(
                {
                    "object": source,
                    "attributes": [
                        {**source, **cast(dict[str, JsonValue], attribute)}
                        for attribute in attributes
                    ],
                }
            )
        context: JsonValue = {"original_context": {"selected_objects": selected}, "repair": None}
        return source_objects, analysis_selected_attributes(context), tool_call_count + calls
    catalog = request.local_tool_catalog
    context = request.context
    if catalog is None or not isinstance(context, dict):
        raise InvalidRequestError("The local fake agent context is invalid.")
    manifest = context.get("original_context")
    if not isinstance(manifest, dict):
        raise InvalidRequestError("The local fake agent context is invalid.")
    counts = manifest.get("dataset_counts")
    if not isinstance(counts, dict):
        raise InvalidRequestError("The local fake agent context is invalid.")
    selected_count = counts.get("selected_attribute")
    if (
        isinstance(selected_count, bool)
        or not isinstance(selected_count, int)
        or not 0 <= selected_count <= 50_000
    ):
        raise InvalidRequestError("The local fake agent context is invalid.")

    dataset_definition = next(
        (
            definition
            for definition in catalog.definitions
            if definition.name == "get_agent_context_dataset"
        ),
        None,
    )
    properties = (
        dataset_definition.input_schema.get("properties")
        if dataset_definition is not None
        else None
    )
    limit_schema = properties.get("limit") if isinstance(properties, dict) else None
    page_limit = limit_schema.get("maximum") if isinstance(limit_schema, dict) else None
    if (
        isinstance(page_limit, bool)
        or not isinstance(page_limit, int)
        or not 1 <= page_limit <= 1_000
    ):
        raise InvalidRequestError("The local fake agent context is invalid.")

    source_attributes: list[dict[str, JsonValue]] = []
    identities: set[tuple[str, ...]] = set()
    offset = 0
    page_calls = 0
    while offset < selected_count:
        limit = min(page_limit, selected_count - offset)
        page = catalog.invoke(
            "get_agent_context_dataset",
            {"dataset": "selected_attribute", "offset": offset, "limit": limit},
        )
        page_calls += 1
        if page_calls > max(selected_count, 1) or not isinstance(page, dict):
            raise InvalidRequestError("The local fake agent context is invalid.")
        items = page.get("items")
        next_offset = page.get("next_offset")
        if (
            page.get("dataset") != "selected_attribute"
            or page.get("total_count") != selected_count
            or page.get("offset") != offset
            or not isinstance(items, list)
            or len(items) != limit
        ):
            raise InvalidRequestError("The local fake agent context is invalid.")
        for item in items:
            if not isinstance(item, dict):
                raise InvalidRequestError("The local fake agent context is invalid.")
            source = _source_from_tool_item(item)
            attribute_name = item.get("attribute_name")
            if (
                not isinstance(attribute_name, str)
                or not attribute_name.strip()
                or len(attribute_name.encode("utf-8")) > 400
            ):
                raise InvalidRequestError("The local fake agent context is invalid.")
            source["attribute_name"] = attribute_name
            identity = tuple(
                cast(str, source[name]).strip().casefold()
                for name in (*FAKE_SOURCE_FIELDS, "attribute_name")
            )
            if identity in identities:
                raise InvalidRequestError("The local fake agent context is invalid.")
            identities.add(identity)
            source_attributes.append(source)
        expected_next = offset + limit
        if expected_next < selected_count:
            if next_offset != expected_next:
                raise InvalidRequestError("The local fake agent context is invalid.")
            offset = expected_next
        else:
            if next_offset is not None:
                raise InvalidRequestError("The local fake agent context is invalid.")
            offset = selected_count
    return source_objects, tuple(source_attributes), tool_call_count + page_calls


def _source_from_tool_item(
    item: dict[str, JsonValue],
) -> dict[str, JsonValue]:
    required = (
        "tenant_code",
        "system_code",
        "connection_code",
        "object_schema",
        "object_name",
    )
    source: dict[str, JsonValue] = {}
    for name in required:
        value = item.get(name)
        if not isinstance(value, str) or not value.strip() or len(value.encode("utf-8")) > 400:
            raise InvalidRequestError("The local fake agent context is invalid.")
        source[name] = value
    return source


def analysis_selected_attributes(
    context: JsonValue,
) -> tuple[dict[str, JsonValue], ...]:
    if not isinstance(context, dict) or set(context) != {
        "original_context",
        "repair",
    }:
        raise InvalidRequestError("The local fake agent context is invalid.")
    original = context.get("original_context")
    if not isinstance(original, dict):
        raise InvalidRequestError("The local fake agent context is invalid.")
    selected = original.get("selected_objects")
    if not isinstance(selected, list) or not 1 <= len(selected) <= 50_000:
        raise InvalidRequestError("The local fake agent context is invalid.")

    required = (
        "tenant_code",
        "system_code",
        "connection_code",
        "object_schema",
        "object_name",
        "attribute_name",
    )
    attributes: list[dict[str, JsonValue]] = []
    identities: set[tuple[str, ...]] = set()
    for selected_item in selected:
        if not isinstance(selected_item, dict):
            raise InvalidRequestError("The local fake agent context is invalid.")
        raw_attributes = selected_item.get("attributes")
        if not isinstance(raw_attributes, list):
            raise InvalidRequestError("The local fake agent context is invalid.")
        for raw_attribute in raw_attributes:
            if not isinstance(raw_attribute, dict):
                raise InvalidRequestError("The local fake agent context is invalid.")
            values = tuple(raw_attribute.get(name) for name in required)
            if any(
                not isinstance(value, str) or not value.strip() or len(value.encode("utf-8")) > 400
                for value in values
            ):
                raise InvalidRequestError("The local fake agent context is invalid.")
            identity = cast(tuple[str, ...], values)
            normalized = tuple(value.strip().casefold() for value in identity)
            if normalized in identities:
                raise InvalidRequestError("The local fake agent context is invalid.")
            identities.add(normalized)
            attributes.append(dict(zip(required, identity, strict=True)))
            if len(attributes) > 50_000:
                raise InvalidRequestError("The local fake agent context is invalid.")
    return tuple(attributes)


def modeled_output_schema(context: JsonValue, workflow: str) -> str:
    """Use the first configured schema; a fake must not invent authoring configuration."""
    original = original_context(context)
    details = original.get("project_details")
    schemas = (
        details.get(f"{workflow}_schemas") if isinstance(details, dict) else original.get("schemas")
    )
    if not isinstance(schemas, list) or not schemas or not isinstance(schemas[0], dict):
        raise InvalidRequestError("The local fake agent output schemas are unavailable.")
    name = schemas[0].get("schema_name")
    if not isinstance(name, str) or not name.strip() or len(name) > 400:
        raise InvalidRequestError("The local fake agent output schemas are invalid.")
    return name


def dimensional_logical_sources(
    selected: JsonValue,
) -> tuple[tuple[dict[str, JsonValue], ...], tuple[dict[str, JsonValue], ...]]:
    """Project the selected Logical records into complete lineage keys."""
    if not isinstance(selected, list) or not 1 <= len(selected) <= 50_000:
        raise InvalidRequestError("The local fake agent context is invalid.")
    entity_fields = ("logical_entity_schema_name", "logical_entity_name")
    entities: list[dict[str, JsonValue]] = []
    attributes: list[dict[str, JsonValue]] = []
    seen: set[tuple[str, ...]] = set()
    for item in selected:
        if (
            not isinstance(item, dict)
            or not isinstance(item.get("entity"), dict)
            or not isinstance(item.get("attributes"), list)
        ):
            raise InvalidRequestError("The local fake agent context is invalid.")
        entity = cast(dict[str, JsonValue], item["entity"])
        key = {name: entity.get(name) for name in entity_fields}
        if any(not isinstance(v, str) or not v.strip() for v in key.values()):
            raise InvalidRequestError("The local fake agent context is invalid.")
        identity = tuple(cast(str, key[name]).strip().casefold() for name in entity_fields)
        if identity in seen:
            raise InvalidRequestError("The local fake agent context is invalid.")
        seen.add(identity)
        entities.append(key)
        for attribute in cast(list[JsonValue], item["attributes"]):
            if not isinstance(attribute, dict):
                raise InvalidRequestError("The local fake agent context is invalid.")
            name = attribute.get("logical_attribute_name")
            if (
                not isinstance(name, str)
                or not name.strip()
                or any(attribute.get(field) != key[field] for field in entity_fields)
            ):
                raise InvalidRequestError("The local fake agent context is invalid.")
            attributes.append({**key, "logical_attribute_name": name})
    return tuple(entities), tuple(attributes)
