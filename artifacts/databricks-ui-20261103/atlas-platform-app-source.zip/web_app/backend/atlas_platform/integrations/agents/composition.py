"""Compose configured Agent execution without provider I/O."""

from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any, cast

from atlas_mcp.domain.errors import InvalidRequestError
from pydantic import JsonValue

from atlas_platform.capabilities import (
    AgentCapabilityRegistry,
    select_agent_runtime_capabilities,
)
from atlas_platform.features.workflows.authoring.agent_execution import (
    AgentExecutionAdapter,
    AgentExecutionRequest,
    AgentExecutionResult,
    AgentExecutionRouter,
)
from atlas_platform.features.workflows.usage.contracts import AgentUsageRecorder
from atlas_platform.integrations.agents.adapters import (
    FoundryApiKeyAuthentication,
    FoundryModelAuthentication,
    ManagedModelAuthentication,
    OpenAIAgentsSdkAdapter,
)
from atlas_platform.integrations.agents.configuration import AgentRuntimeConfiguration
from atlas_platform.integrations.agents.fake_dimensional import (
    fake_dimensional_candidate,
)
from atlas_platform.integrations.agents.fake_logical import (
    fake_logical_candidate,
    fake_table_index,
)
from atlas_platform.integrations.agents.fake_mapping import (
    fake_mapping_candidate,
    fake_mapping_context_from_tools,
)
from atlas_platform.integrations.agents.fake_shared import (
    analysis_selected_attributes,
    code_generation_target_refs,
    dimensional_logical_sources,
    modeled_output_schema,
    named_tool_items,
    original_context,
    selected_source_objects,
    tool_assisted_logical_sources,
)
from atlas_platform.integrations.agents.fake_subject_areas import (
    fake_subject_area_candidate,
)


class LocalFakeAgentAdapter:
    """Deterministic local boundary with no external I/O or prompt/tool-output echo."""

    def __init__(self, *, sdk_code: str) -> None:
        self.sdk_code = sdk_code

    async def execute(self, request: AgentExecutionRequest) -> AgentExecutionResult:
        if request.execution_mode == "one_shot" and (
            request.allowed_tool_names or request.local_tool_catalog is not None
        ):
            raise InvalidRequestError("The local fake does not support this agent execution path.")
        if request.execution_mode == "tool_assisted" and (
            request.local_tool_catalog is None
            or request.allowed_tool_names
            != tuple(definition.name for definition in request.local_tool_catalog.definitions)
        ):
            raise InvalidRequestError("The local fake does not support this agent execution path.")
        tool_call_count = 0
        if request.workflow == "metadata_enrichment" and request.stage == "candidate_authoring":
            properties = request.output_schema.get("properties")
            description_schema = (
                properties.get("descriptions") if isinstance(properties, dict) else None
            )
            refs = (
                description_schema.get("required") if isinstance(description_schema, dict) else None
            )
            if not isinstance(refs, list) or not all(isinstance(ref, str) for ref in refs):
                raise InvalidRequestError("The local enrichment target schema is unavailable.")
            descriptions: dict[str, JsonValue] = {}
            for ref in refs:
                if not isinstance(ref, str):
                    continue
                try:
                    key = cast(JsonValue, json.loads(ref))
                    name = key[-1] if isinstance(key, list) and key else ref
                except ValueError:
                    name = ref
                descriptions[ref] = f"Synthetic local description for {name}."
            payload: dict[str, JsonValue] = {"descriptions": descriptions}
            if isinstance(properties, dict) and "attributes" in properties:
                payload["attributes"] = {
                    ref: {
                        name: None
                        for name in ("is_natural_key", "is_primary_key", "is_nullable", "is_pii")
                    }
                    for ref in descriptions
                }
            candidate = cast(JsonValue, payload)
        elif request.workflow == "mapping":
            if request.stage == "mapping_authoring" and request.execution_mode == "tool_assisted":
                mapping_context, tool_call_count = fake_mapping_context_from_tools(request)
                candidate = fake_mapping_candidate(mapping_context)
            elif request.stage == "mapping_authoring" and request.execution_mode == "one_shot":
                mapping_context = original_context(request.context)
                candidate = fake_mapping_candidate(mapping_context)
            else:
                raise InvalidRequestError(
                    "The local fake does not support this agent execution path."
                )
        elif request.workflow == "code_generation" and request.stage == "sql_generation":
            target_systems: dict[str, list[JsonValue]]
            code_context = original_context(request.context)
            if code_context.get("__gds_downstream_inputs__") == "code_generation":
                values = cast(dict[str, JsonValue], code_context["values"])
                target_ref = values.get("target_ref")
                systems = values.get("source_systems")
                if "get_code_source_systems" in request.allowed_tool_names:
                    systems, calls = named_tool_items(request, "get_code_source_systems")
                    tool_call_count += calls
                if not isinstance(target_ref, str) or not isinstance(systems, list):
                    raise InvalidRequestError("The local Code context is unavailable.")
                target_systems = {
                    target_ref: [
                        row["system_code"]
                        for row in systems
                        if isinstance(row, dict) and isinstance(row.get("system_code"), str)
                    ],
                }
            else:
                target_systems = {
                    target_ref: [] for target_ref in code_generation_target_refs(request.context)
                }
            candidate = cast(
                JsonValue,
                {
                    "artifacts": [
                        {
                            "target_ref": target_ref,
                            **(
                                {
                                    "artifact_name": f"{target_ref}.sql",
                                    "artifact_role": "target_transformation",
                                    "source_system_codes": system_codes,
                                }
                                if code_context.get("__gds_downstream_inputs__")
                                == "code_generation"
                                else {}
                            ),
                            "generated_sql": f"SELECT {position};\n",
                        }
                        for position, (target_ref, system_codes) in enumerate(
                            target_systems.items(), start=1
                        )
                    ]
                },
            )
        elif request.workflow == "validation" and request.stage == "validation_generation":
            validation_context = original_context(request.context)
            if validation_context.get("__gds_downstream_inputs__") == "validation":
                validation_context = cast(dict[str, JsonValue], validation_context["values"])
            system_ref = validation_context.get("system_ref")
            if not isinstance(system_ref, str):
                raise InvalidRequestError(
                    "The local fake does not support this agent execution path."
                )
            mapping_evidence = validation_context.get("mapping_evidence", [])
            for reader in ("get_mapping_evidence", "get_current_code"):
                if reader in request.allowed_tool_names:
                    rows, calls = named_tool_items(request, reader)
                    tool_call_count += calls
                    if reader == "get_mapping_evidence":
                        mapping_evidence = rows
            checks: list[dict[str, JsonValue]] = []
            for evidence in mapping_evidence if isinstance(mapping_evidence, list) else []:
                if not isinstance(evidence, dict) or not isinstance(evidence.get("context"), dict):
                    continue
                context = cast(dict[str, JsonValue], evidence["context"])
                target = context.get("target_metadata")
                if not isinstance(target, dict):
                    continue
                coordinates = [
                    target.get(key) for key in ("tenant_catalog", "object_schema", "object_name")
                ]
                attributes = target.get("attributes")
                required = (
                    [
                        attribute["attribute_name"]
                        for attribute in attributes
                        if isinstance(attribute, dict)
                        and attribute.get("attribute_nullability") is False
                        and attribute.get("is_active", True)
                        and isinstance(attribute.get("attribute_name"), str)
                    ]
                    if isinstance(attributes, list)
                    else []
                )
                if not required or not all(
                    isinstance(value, str) and value for value in coordinates
                ):
                    continue
                relation = ".".join(
                    "`" + str(value).replace("`", "``") + "`" for value in coordinates
                )
                predicate = " OR ".join(
                    "`" + str(name).replace("`", "``") + "` IS NULL" for name in required
                )
                checks.append(
                    {
                        "validation_check_name": (
                            f"{target['object_schema']}.{target['object_name']}RequiredValues"
                        ),
                        "validation_check_description": (
                            "Detects missing required values on loaded rows. "
                            "Synthetic local authoring; SQL has not been executed."
                        ),
                        "validation_category_code": "technical.required_values",
                        "validation_severity": "blocking",
                        "validation_query_sql": (
                            f"SELECT COUNT(*) FROM {relation} WHERE {predicate}"
                        ),
                        "validation_comparison_query_sql": None,
                        "validation_result_data_type": "integer",
                        "validation_comparison_operator": "equal",
                        "validation_comparison_value_type": "literal",
                        "validation_comparison_value": 0,
                    }
                )
            if not checks:
                raise InvalidRequestError(
                    "The local fake requires mapped target metadata with required "
                    "Attributes to demonstrate Validation."
                )
            candidate = cast(
                JsonValue,
                {
                    "system_ref": system_ref,
                    "validation_groups": [
                        {
                            "validation_group_name": "TechnicalRequiredValues",
                            "validation_group_description": (
                                "Required-value integrity for mapped targets. "
                                "Synthetic local example."
                            ),
                            "validation_checks": checks,
                        }
                    ],
                },
            )
        elif request.workflow == "analysis_inference" and request.stage == "per_table_authoring":
            # Link the focus table's first column to the first key another table offers.
            inputs = cast(dict[str, Any], original_context(request.context)["prompt_inputs"])
            focus = inputs["focus_table"]
            target = next(
                (
                    f"{entry['table']}.{column['attribute_name']}"
                    for entry in inputs["key_directory"]
                    if entry["table"] != focus["table"]
                    for column in entry["key_columns"]
                ),
                None,
            )
            candidate = cast(
                JsonValue,
                {
                    "relationships": []
                    if target is None
                    else [
                        {
                            "from_attribute_name": focus["attributes"][0]["attribute_name"],
                            "to": target,
                            "relationship_kind": "reference",
                            "inferred_cardinality": "unknown",
                        }
                    ]
                },
            )
        elif request.workflow == "analysis_inference" and request.stage == "relationship_inference":
            if request.execution_mode == "tool_assisted":
                _source_objects, attributes, tool_call_count = tool_assisted_logical_sources(
                    request
                )
            elif request.execution_mode == "one_shot":
                attributes = analysis_selected_attributes(request.context)
            else:
                raise InvalidRequestError(
                    "The local fake does not support this agent execution path."
                )
            relationships: list[dict[str, JsonValue]] = []
            if len(attributes) >= 2:
                source, target = attributes[:2]
                relationships.append(
                    {
                        **{f"from_{name}": value for name, value in source.items()},
                        **{f"to_{name}": value for name, value in target.items()},
                        "relationship_kind": "reference",
                        "inferred_cardinality": "unknown",
                    }
                )
            candidate = cast(JsonValue, {"relationships": relationships})
        elif request.workflow in {"logical", "dimensional"} and (
            request.stage == "optimize_authoring"
        ):
            # The fake has no cross-area judgment to add; an empty answer is a no-op.
            candidate = cast(
                JsonValue,
                {"entities": [], "relationships": [], "retire": []}
                if request.workflow == "logical"
                else {"entities": [], "attributes": [], "relationships": []},
            )
        elif request.workflow == "dimensional" and request.stage == "build_authoring":
            if request.execution_mode == "tool_assisted":
                selected_entities, tool_call_count = named_tool_items(
                    request, "get_selected_logical_entities"
                )
                source_entities, source_attributes = dimensional_logical_sources(
                    cast(JsonValue, selected_entities)
                )
            elif request.execution_mode == "one_shot":
                source_entities, source_attributes = dimensional_logical_sources(
                    original_context(request.context).get("selected_logical_entities")
                )
            else:
                raise InvalidRequestError(
                    "The local fake does not support this agent execution path."
                )
            candidate = fake_dimensional_candidate(
                schema_name=modeled_output_schema(request.context, "dimensional"),
                source_entities=source_entities,
                source_attributes=source_attributes,
            )
        elif request.workflow == "logical" and request.stage == "build_authoring":
            if request.execution_mode == "tool_assisted":
                source_objects, source_attributes, tool_call_count = tool_assisted_logical_sources(
                    request
                )
            elif request.execution_mode == "one_shot":
                source_objects = selected_source_objects(request.context)
                source_attributes = analysis_selected_attributes(request.context)
            else:
                raise InvalidRequestError(
                    "The local fake does not support this agent execution path."
                )
            candidate = fake_logical_candidate(
                schema_name=modeled_output_schema(request.context, "logical"),
                table_index=fake_table_index(request),
                source_objects=source_objects,
                source_attributes=source_attributes,
            )
        elif request.workflow == "subject_area" and request.stage == "candidate_authoring":
            if request.execution_mode == "tool_assisted":
                scope_tables, tool_call_count = named_tool_items(request, "get_scope_tables")
            else:
                values = original_context(request.context).get("prompt_inputs")
                scope_tables = (
                    cast(list[dict[str, JsonValue]], values.get("scope_tables"))
                    if isinstance(values, dict)
                    else []
                )
            candidate = fake_subject_area_candidate(scope_tables=tuple(scope_tables))
        else:
            raise InvalidRequestError("The local fake does not support this agent execution path.")
        return AgentExecutionResult(
            candidate=candidate,
            turn_count=1,
            tool_call_count=tool_call_count,
        )

    def __repr__(self) -> str:
        return f"LocalFakeAgentAdapter(sdk_code={self.sdk_code!r})"


def create_agent_execution_router(
    *,
    configuration: AgentRuntimeConfiguration,
    capabilities: AgentCapabilityRegistry,
    provider_authentications: Mapping[str, ManagedModelAuthentication] | None = None,
    usage_recorder: AgentUsageRecorder | None = None,
) -> AgentExecutionRouter:
    adapters: tuple[AgentExecutionAdapter, ...]
    registered_deployments = {
        (model.provider_code, model.code): (model.deployment_name, model.api_protocol)
        for model in capabilities.models
    }
    for connection in configuration.connections:
        connection_key = (connection.provider_code, connection.model_code)
        if connection_key not in registered_deployments:
            raise ValueError("A configured Agent model deployment is not registered")
        if registered_deployments[connection_key] != (
            connection.model_endpoint,
            connection.api_protocol,
        ):
            raise ValueError(
                "The configured Agent model deployment does not match the Agent registry"
            )
    runtime_capabilities = (
        capabilities
        if configuration.mode == "fake"
        else select_agent_runtime_capabilities(
            capabilities,
            configured_models={
                (connection.provider_code, connection.model_code)
                for connection in configuration.connections
            },
        )
    )
    configured_provider_codes = {
        connection.authentication_key for connection in configuration.connections
    }
    authentications = {} if provider_authentications is None else dict(provider_authentications)
    if provider_authentications is not None and set(authentications) != configured_provider_codes:
        raise ValueError(
            "Every configured Agent provider requires exactly one authentication adapter"
        )
    if configuration.mode == "fake":
        adapters = tuple(
            LocalFakeAgentAdapter(sdk_code=sdk.code) for sdk in runtime_capabilities.sdks
        )
    else:
        if provider_authentications is None:
            for provider_code in configured_provider_codes:
                provider_connections = tuple(
                    connection
                    for connection in configuration.connections
                    if connection.authentication_key == provider_code
                )
                connection = provider_connections[0]
                resource_configuration = (
                    connection.openai_base_url,
                    connection.anthropic_base_url,
                    connection.token_scope,
                    connection.foundry_client_credentials,
                    connection.foundry_api_key,
                )
                if any(
                    (
                        candidate.openai_base_url,
                        candidate.anthropic_base_url,
                        candidate.token_scope,
                        candidate.foundry_client_credentials,
                        candidate.foundry_api_key,
                    )
                    != resource_configuration
                    for candidate in provider_connections[1:]
                ):
                    raise ValueError(
                        "Foundry model deployments must share one resource and authentication"
                    )
                base_url = (
                    connection.anthropic_base_url
                    if connection.api_protocol == "anthropic_messages"
                    else connection.openai_base_url
                )
                if base_url is None:
                    raise ValueError("Foundry authentication configuration is incomplete")
                if connection.foundry_api_key is not None:
                    if (
                        connection.token_scope is not None
                        or connection.foundry_client_credentials is not None
                    ):
                        raise ValueError("Foundry authentication configuration is incomplete")
                    authentications[provider_code] = FoundryApiKeyAuthentication(
                        base_url=base_url,
                        api_key=connection.foundry_api_key,
                    )
                else:
                    if (
                        connection.token_scope is None
                        or connection.foundry_client_credentials is None
                    ):
                        raise ValueError("Foundry authentication configuration is incomplete")
                    credentials = connection.foundry_client_credentials
                    authentications[provider_code] = FoundryModelAuthentication(
                        base_url=base_url,
                        token_scope=connection.token_scope,
                        tenant_id=str(credentials.tenant_id),
                        client_id=str(credentials.client_id),
                        client_secret=credentials.client_secret,
                    )
        configured_adapters: list[AgentExecutionAdapter] = []
        for sdk in runtime_capabilities.sdks:
            if sdk.code == "openai_agents_sdk":
                configured_adapters.append(
                    OpenAIAgentsSdkAdapter(
                        connections=configuration.connections,
                        model_authentications=authentications,
                    )
                )
            else:
                raise ValueError("The configured Agent SDK is unsupported")
        adapters = tuple(configured_adapters)
    return AgentExecutionRouter(
        capabilities=runtime_capabilities,
        adapters=adapters,
        resources=tuple(authentications.values()),
        usage_recorder=usage_recorder,
    )
