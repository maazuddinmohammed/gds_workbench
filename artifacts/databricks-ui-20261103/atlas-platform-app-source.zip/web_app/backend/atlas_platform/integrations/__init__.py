"""External-system adapter boundaries."""
