"""Atlas Platform FastAPI backend."""
