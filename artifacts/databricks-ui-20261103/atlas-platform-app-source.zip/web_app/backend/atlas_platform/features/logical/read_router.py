"""Tenant-owned normalized Logical model review HTTP routes."""

from typing import Annotated

from atlas_mcp.application.identity import IdentityProvider
from atlas_mcp.domain.authorization import RequestPrincipal
from fastapi import APIRouter, Depends, Path, Query

from atlas_platform.dependencies import principal_dependency
from atlas_platform.features.logical.read_contracts import (
    LogicalAttributeDetail,
    LogicalAttributeFilters,
    LogicalAttributeListQuery,
    LogicalAttributePage,
    LogicalEntityDetail,
    LogicalEntityFilters,
    LogicalEntityListQuery,
    LogicalEntityPage,
    LogicalRelationshipDetail,
    LogicalRelationshipFilters,
    LogicalRelationshipListQuery,
    LogicalRelationshipPage,
    ModelSubjectAreaPage,
)
from atlas_platform.features.logical.read_service import LogicalService


def create_logical_router(
    *,
    identity_provider: IdentityProvider,
    service: LogicalService,
) -> APIRouter:
    """Create the Logical review router for later runtime composition."""
    authenticate = principal_dependency(identity_provider)
    router = APIRouter(
        prefix="/api/v1/tenants/{tenant_id}/projects/{project_id}/logical",
        tags=["logical"],
    )

    async def list_subject_areas(
        tenant_id: Annotated[int, Path(gt=0)],
        project_id: Annotated[int, Path(gt=0)],
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> ModelSubjectAreaPage:
        return await service.list_subject_areas(
            principal, tenant_id=tenant_id, project_id=project_id
        )

    router.add_api_route(
        "/subject-areas",
        list_subject_areas,
        methods=["GET"],
        response_model=ModelSubjectAreaPage,
    )

    async def list_entities(
        tenant_id: Annotated[int, Path(gt=0)],
        project_id: Annotated[int, Path(gt=0)],
        query: Annotated[LogicalEntityListQuery, Query()],
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> LogicalEntityPage:
        filters = LogicalEntityFilters.model_validate(
            {
                "active": query.active,
                "locked": query.locked,
                "name_exact": query.name_exact,
                "name_prefix": query.name_prefix,
                "subject_area_id": query.subject_area_id,
            },
            strict=True,
        )
        return await service.list_entities(
            principal,
            tenant_id=tenant_id,
            project_id=project_id,
            filters=filters,
            page_size=query.page_size,
            cursor=query.cursor,
        )

    router.add_api_route(
        "/entities",
        list_entities,
        methods=["GET"],
        response_model=LogicalEntityPage,
    )

    async def read_entity(
        tenant_id: Annotated[int, Path(gt=0)],
        project_id: Annotated[int, Path(gt=0)],
        logical_entity_id: Annotated[int, Path(gt=0)],
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> LogicalEntityDetail:
        return await service.read_entity(
            principal,
            tenant_id=tenant_id,
            project_id=project_id,
            logical_entity_id=logical_entity_id,
        )

    router.add_api_route(
        "/entities/{logical_entity_id}",
        read_entity,
        methods=["GET"],
        response_model=LogicalEntityDetail,
    )

    async def list_attributes(
        tenant_id: Annotated[int, Path(gt=0)],
        project_id: Annotated[int, Path(gt=0)],
        query: Annotated[LogicalAttributeListQuery, Query()],
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> LogicalAttributePage:
        filters = LogicalAttributeFilters.model_validate(
            {
                "active": query.active,
                "locked": query.locked,
                "name_exact": query.name_exact,
                "name_prefix": query.name_prefix,
                "logical_entity_id": query.logical_entity_id,
            },
            strict=True,
        )
        return await service.list_attributes(
            principal,
            tenant_id=tenant_id,
            project_id=project_id,
            filters=filters,
            page_size=query.page_size,
            cursor=query.cursor,
        )

    router.add_api_route(
        "/attributes",
        list_attributes,
        methods=["GET"],
        response_model=LogicalAttributePage,
    )

    async def read_attribute(
        tenant_id: Annotated[int, Path(gt=0)],
        project_id: Annotated[int, Path(gt=0)],
        logical_attribute_id: Annotated[int, Path(gt=0)],
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> LogicalAttributeDetail:
        return await service.read_attribute(
            principal,
            tenant_id=tenant_id,
            project_id=project_id,
            logical_attribute_id=logical_attribute_id,
        )

    router.add_api_route(
        "/attributes/{logical_attribute_id}",
        read_attribute,
        methods=["GET"],
        response_model=LogicalAttributeDetail,
    )

    async def list_relationships(
        tenant_id: Annotated[int, Path(gt=0)],
        project_id: Annotated[int, Path(gt=0)],
        query: Annotated[LogicalRelationshipListQuery, Query()],
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> LogicalRelationshipPage:
        filters = LogicalRelationshipFilters.model_validate(
            {
                "active": query.active,
                "locked": query.locked,
                "name_exact": query.name_exact,
                "name_prefix": query.name_prefix,
                "logical_entity_id": query.logical_entity_id,
            },
            strict=True,
        )
        return await service.list_relationships(
            principal,
            tenant_id=tenant_id,
            project_id=project_id,
            filters=filters,
            page_size=query.page_size,
            cursor=query.cursor,
        )

    router.add_api_route(
        "/relationships",
        list_relationships,
        methods=["GET"],
        response_model=LogicalRelationshipPage,
    )

    async def read_relationship(
        tenant_id: Annotated[int, Path(gt=0)],
        project_id: Annotated[int, Path(gt=0)],
        logical_relationship_id: Annotated[int, Path(gt=0)],
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> LogicalRelationshipDetail:
        return await service.read_relationship(
            principal,
            tenant_id=tenant_id,
            project_id=project_id,
            logical_relationship_id=logical_relationship_id,
        )

    router.add_api_route(
        "/relationships/{logical_relationship_id}",
        read_relationship,
        methods=["GET"],
        response_model=LogicalRelationshipDetail,
    )
    return router
