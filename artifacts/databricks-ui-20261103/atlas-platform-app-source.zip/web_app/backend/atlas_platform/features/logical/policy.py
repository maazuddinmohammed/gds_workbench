"""Deterministic Logical audit-column projection."""

from __future__ import annotations

import json
from typing import Literal, cast

from atlas_mcp.application.change_sets.project import StageProjectChange
from atlas_mcp.application.change_sets.project_validation import validate_staged_records
from atlas_mcp.domain.errors import InvalidRequestError
from atlas_mcp.domain.modeling_policy import (
    GoldAuditPolicy as LogicalAuditPolicy,
)
from atlas_mcp.domain.modeling_policy import (
    GoldPolicyColumn as LogicalAuditPolicyColumn,
)
from atlas_mcp.domain.modeling_records import (
    LogicalAttributeRecord,
    LogicalEntityRecord,
    normalize_project_key_value,
)
from atlas_mcp.domain.snapshots.project import LogicalSection
from pydantic import BaseModel, ValidationError

from atlas_platform.features.workflows.authoring.audit_policy import effective_audit_template


def project_logical_audit_policy(
    *,
    changes: tuple[StageProjectChange, ...],
    applied: LogicalSection | None,
    raw_template: dict[str, object] | None,
) -> tuple[StageProjectChange, ...]:
    """Add the configured audit columns to every effective active Logical Entity."""

    policy = _parse_policy(effective_audit_template(raw_template))
    baseline = applied or LogicalSection(entities=(), attributes=(), relationships=())
    changes_by_dataset = {change.dataset: change for change in changes}
    if len(changes_by_dataset) != len(changes) or any(
        not change.dataset.startswith("logical_") for change in changes
    ):
        raise InvalidRequestError("Logical policy projection received invalid input.")

    changed_entities = _parse_records(
        changes_by_dataset.get("logical_entity"),
        dataset="logical_entity",
        record_type=LogicalEntityRecord,
    )
    changed_attributes = _parse_records(
        changes_by_dataset.get("logical_attribute"),
        dataset="logical_attribute",
        record_type=LogicalAttributeRecord,
    )
    entities = {_entity_key(record): record for record in baseline.entities}
    entities.update({_entity_key(record): record for record in changed_entities})
    attributes = {_attribute_key(record): record for record in baseline.attributes}
    attributes.update({_attribute_key(record): record for record in changed_attributes})

    projected: list[LogicalAttributeRecord] = []
    for entity_key, entity in sorted(entities.items()):
        if not entity.logical_entity_is_active:
            continue
        entity_attributes: list[LogicalAttributeRecord] = [
            record for key, record in attributes.items() if key[:2] == entity_key
        ]
        # Existing tables retain their approved key/ordinal contract. New tables
        # get an own generated key without relabelling the source business key.
        if entity_key not in {_entity_key(row) for row in baseline.entities} or any(
            row.logical_attribute_is_surrogate_key and row.logical_attribute_ordinal_position == 1
            for row in entity_attributes
        ):
            surrogates = [
                row for row in entity_attributes if row.logical_attribute_is_surrogate_key
            ]
            if len(surrogates) > 1:
                raise InvalidRequestError("A new Logical Entity needs one own surrogate key.")
            if surrogates:
                surrogate = surrogates[0]
                if surrogate.sources or surrogate.logical_attribute_is_nullable:
                    raise InvalidRequestError(
                        "An own generated surrogate cannot have physical sources."
                    )
            else:
                name = f"{entity.logical_entity_name}ID"
                if (*entity_key, normalize_project_key_value(name)) in attributes:
                    raise InvalidRequestError(
                        "The generated key name conflicts with a business Attribute."
                    )
                surrogate = LogicalAttributeRecord(
                    logical_entity_schema_name=entity.logical_entity_schema_name,
                    logical_entity_name=entity.logical_entity_name,
                    logical_attribute_name=name,
                    logical_attribute_definition=(
                        f"Generated identifier for {entity.logical_entity_name}."
                    ),
                    logical_attribute_data_type="BIGINT",
                    logical_attribute_is_nullable=False,
                    logical_attribute_is_natural_key=False,
                    logical_attribute_is_surrogate_key=True,
                    logical_attribute_ordinal_position=1,
                    logical_attribute_is_audit_column=False,
                    logical_attribute_is_active=True,
                    logical_attribute_is_locked=False,
                    sources=(),
                )
            ordered = [
                surrogate,
                *sorted(
                    (row for row in entity_attributes if row != surrogate),
                    key=lambda row: (row.logical_attribute_ordinal_position, _attribute_key(row)),
                ),
            ]
            entity_attributes = []
            for ordinal, row in enumerate(ordered, start=1):
                desired = row.model_copy(update={"logical_attribute_ordinal_position": ordinal})
                attributes[_attribute_key(desired)] = desired
                projected.append(desired)
                entity_attributes.append(desired)
        next_ordinal = 1 + max(
            (
                record.logical_attribute_ordinal_position
                for record in entity_attributes
                if not record.logical_attribute_is_audit_column
            ),
            default=0,
        )
        for offset, column in enumerate(policy.columns):
            key = (*entity_key, normalize_project_key_value(column.semantic_name))
            existing = attributes.get(key)
            desired = _policy_attribute(
                entity=entity,
                column=column,
                ordinal=next_ordinal + offset,
                existing=existing,
            )
            if existing != desired:
                projected.append(desired)
            attributes[key] = desired

    changed_attribute_by_key = {_attribute_key(record): record for record in changed_attributes}
    for record in projected:
        changed_attribute_by_key[_attribute_key(record)] = record
    applied_attributes = {_attribute_key(record): record for record in baseline.attributes}
    changed_attribute_by_key = {
        key: record
        for key, record in changed_attribute_by_key.items()
        if applied_attributes.get(key) != record
    }

    output: list[StageProjectChange] = []
    for dataset in ("logical_entity", "logical_attribute", "logical_relationship"):
        if dataset == "logical_attribute":
            records = [
                record.model_dump(mode="json")
                for _, record in sorted(changed_attribute_by_key.items())
            ]
        else:
            change = changes_by_dataset.get(dataset)
            records = [] if change is None else change.records
        if records:
            output.append(StageProjectChange(dataset=dataset, records=records))
    return tuple(output)


def _parse_policy(raw_template: dict[str, object]) -> LogicalAuditPolicy:
    try:
        return LogicalAuditPolicy.model_validate_json(
            json.dumps(
                raw_template,
                ensure_ascii=False,
                allow_nan=False,
                separators=(",", ":"),
            ),
            strict=True,
        )
    except TypeError, ValueError, ValidationError:
        raise InvalidRequestError("The Silver audit-column template is invalid.") from None


def _parse_records[T: BaseModel](
    change: StageProjectChange | None,
    *,
    dataset: Literal["logical_entity", "logical_attribute"],
    record_type: type[T],
) -> tuple[T, ...]:
    if change is None:
        return ()
    records, issues = validate_staged_records(dataset, change.records)
    if issues:
        raise InvalidRequestError("Logical policy projection received invalid input.")
    return tuple(cast(T, record) for record in records if isinstance(record, record_type))


def _policy_attribute(
    *,
    entity: LogicalEntityRecord,
    column: LogicalAuditPolicyColumn,
    ordinal: int,
    existing: LogicalAttributeRecord | None,
) -> LogicalAttributeRecord:
    if existing is not None and (
        not existing.logical_attribute_is_audit_column
        or normalize_project_key_value(existing.logical_attribute_data_type)
        != normalize_project_key_value(column.data_type)
        or existing.logical_attribute_is_nullable != column.nullable
        or (
            existing.sources
            and normalize_project_key_value(column.semantic_name) != "sourcesystemid"
        )
    ):
        raise InvalidRequestError(
            "A configured Logical audit column conflicts with an existing Attribute."
        )
    desired = LogicalAttributeRecord(
        logical_entity_schema_name=entity.logical_entity_schema_name,
        logical_entity_name=entity.logical_entity_name,
        logical_attribute_name=column.semantic_name,
        logical_attribute_definition=column.definition or column.semantic_name,
        logical_attribute_data_type=column.data_type,
        logical_attribute_is_nullable=column.nullable,
        logical_attribute_is_natural_key=(
            existing.logical_attribute_is_natural_key if existing else False
        ),
        logical_attribute_is_surrogate_key=False,
        logical_attribute_ordinal_position=ordinal,
        logical_attribute_is_audit_column=True,
        logical_attribute_is_active=True,
        logical_attribute_is_locked=(
            existing.logical_attribute_is_locked if existing is not None else False
        ),
        sources=(existing.sources if existing is not None else ()),
    )
    if existing is not None and existing.logical_attribute_is_locked and existing != desired:
        raise InvalidRequestError("A locked Logical audit column cannot be projected.")
    return desired


def _entity_key(record: LogicalEntityRecord) -> tuple[str, str]:
    return (
        normalize_project_key_value(record.logical_entity_schema_name),
        normalize_project_key_value(record.logical_entity_name),
    )


def _attribute_key(record: LogicalAttributeRecord) -> tuple[str, str, str]:
    return (
        normalize_project_key_value(record.logical_entity_schema_name),
        normalize_project_key_value(record.logical_entity_name),
        normalize_project_key_value(record.logical_attribute_name),
    )


__all__ = [
    "LogicalAuditPolicy",
    "LogicalAuditPolicyColumn",
    "project_logical_audit_policy",
]
