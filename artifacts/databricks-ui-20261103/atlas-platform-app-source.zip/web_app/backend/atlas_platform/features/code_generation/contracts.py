"""Public contracts for stored SQL Code Generation review and download."""

from datetime import datetime
from typing import Literal, Self

from atlas_mcp.domain.errors import AtlasError
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    ValidationInfo,
    field_validator,
    model_validator,
)

from atlas_platform.features.mapping.read_contracts import (
    ModeledEntityReference,
    SourceSystemReference,
)

type MappingEntityType = Literal["logical_entity", "dimensional_entity"]

MAX_SELECTED_ARTIFACTS = 25
MAX_EXPORT_ARTIFACTS = 5_000
MAX_BULK_SQL_BYTES = 32 * 1024 * 1024


class ContractModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)


class ExportSqlArtifactsRequest(ContractModel):
    """Export every active stored SQL file in one layer, including stale files."""

    entity_type: MappingEntityType
    expected_project_revision: int = Field(gt=0)


class CodeGenerationTargetFilters(ContractModel):
    entity_type: MappingEntityType | None = None
    system_id: int | None = Field(default=None, gt=0)
    system_code: str | None = Field(default=None, min_length=1, max_length=100)
    source_system_id: int | None = Field(default=None, gt=0)
    source_system_code: str | None = Field(default=None, min_length=1, max_length=100)

    @field_validator(
        "entity_type",
        "system_code",
        "source_system_code",
        mode="before",
    )
    @classmethod
    def normalize_text(cls, value: object, info: ValidationInfo) -> object:
        if not isinstance(value, str):
            return value
        normalized = value.strip(" ").lower()
        if not normalized:
            raise ValueError(f"{info.field_name} must be nonblank")
        return normalized


class CodeGenerationTargetQuery(BaseModel):
    model_config = ConfigDict(extra="forbid")

    entity_type: MappingEntityType | None = None
    system_id: int | None = Field(default=None, gt=0)
    system_code: str | None = Field(default=None, max_length=100)
    source_system_id: int | None = Field(default=None, gt=0)
    source_system_code: str | None = Field(default=None, max_length=100)
    page_size: int = Field(default=50, ge=1, le=200)
    cursor: str | None = Field(default=None, max_length=2048)

    @field_validator(
        "entity_type",
        "system_code",
        "source_system_code",
        mode="before",
    )
    @classmethod
    def normalize_text(cls, value: object, info: ValidationInfo) -> object:
        if not isinstance(value, str):
            return value
        normalized = value.strip(" ").lower()
        if not normalized:
            raise ValueError(f"{info.field_name} must be nonblank")
        return normalized


class StoredSqlArtifactSummary(ContractModel):
    generated_sql_artifact_id: int = Field(gt=0)
    artifact_name: str = Field(min_length=1, max_length=400)
    workflow_run_id: int | None = Field(default=None, gt=0)
    generated_at: datetime
    generated_code_status: Literal["active", "inactive", "deprecated"]
    generated_code_is_locked: bool
    source_system_codes: tuple[str, ...] = Field(max_length=200)
    artifact_is_current: bool


class CodeMappingSupport(ContractModel):
    mapping_object_id: int = Field(gt=0)
    source: ModeledEntityReference
    source_system: SourceSystemReference
    dependency_order: int = Field(ge=0)
    object_transformation_missing: bool = False
    unmapped_attribute_count: int = Field(default=0, ge=0)
    unmapped_attribute_names: tuple[str, ...] = Field(default=(), max_length=200)


class CodeGenerationTargetSummary(ContractModel):
    is_locked: bool = False
    target: ModeledEntityReference
    entity_type: MappingEntityType
    mapping_supports: tuple[CodeMappingSupport, ...] = Field(
        min_length=1,
        max_length=200,
    )
    mapping_support_count: int = Field(gt=0)
    mapping_supports_truncated: bool
    source_systems: tuple[SourceSystemReference, ...] = Field(
        min_length=1,
        max_length=200,
    )
    source_system_count: int = Field(gt=0, le=200)
    artifacts: tuple[StoredSqlArtifactSummary, ...] = Field(max_length=5_000)
    artifact_count: int = Field(ge=0, le=5_000)

    @model_validator(mode="after")
    def validate_source_system_count(self) -> Self:
        if self.source_system_count != len(self.source_systems):
            raise ValueError("Source System count does not match returned Systems")
        if self.artifact_count != len(self.artifacts):
            raise ValueError("Artifact count does not match returned artifacts")
        return self


class CodeGenerationTargetPage(ContractModel):
    project_id: int = Field(gt=0)
    project_revision: int = Field(gt=0)
    items: tuple[CodeGenerationTargetSummary, ...] = Field(max_length=200)
    next_cursor: str | None = Field(default=None, max_length=2048)


class SqlGeneratorProvenance(ContractModel):
    generator_code: str | None = Field(
        pattern=r"^[a-z][a-z0-9_.-]{0,99}$",
    )
    generator_version: str | None = Field(
        pattern=r"^[0-9]+\.[0-9]+\.[0-9]+$",
    )
    generated_by_display_name: str = Field(min_length=1, max_length=200)


class GeneratedSqlArtifactDetail(ContractModel):
    generated_sql_artifact_id: int = Field(gt=0)
    artifact_name: str = Field(min_length=1, max_length=400)
    project_id: int = Field(gt=0)
    target: ModeledEntityReference
    entity_type: MappingEntityType
    source_systems: tuple[SourceSystemReference, ...] = Field(max_length=200)
    source_system_count: int = Field(ge=0, le=200)
    mapping_supports: tuple[CodeMappingSupport, ...] = Field(max_length=200)
    mapping_support_count: int = Field(ge=0)
    mapping_supports_truncated: bool
    artifact_is_current: bool
    generated_code_status: Literal["active", "inactive", "deprecated"]
    generated_code_is_locked: bool
    workflow_run_id: int | None = Field(default=None, gt=0)
    generator: SqlGeneratorProvenance | None
    generated_at: datetime
    generated_sql: str = Field(min_length=1, repr=False)
    generated_sql_byte_count: int = Field(gt=0)

    @model_validator(mode="after")
    def validate_bounded_sql_and_supports(self) -> Self:
        if len(self.generated_sql.encode()) != self.generated_sql_byte_count:
            raise ValueError("generated SQL byte count does not match its content")
        if self.mapping_support_count < len(self.mapping_supports):
            raise ValueError("Mapping support count is smaller than returned supports")
        if self.mapping_supports_truncated != (
            self.mapping_support_count > len(self.mapping_supports)
        ):
            raise ValueError("Mapping support truncation state is inconsistent")
        if self.source_system_count != len(self.source_systems):
            raise ValueError("Source System count does not match returned Systems")
        return self


class SqlArtifactDownload(ContractModel):
    generated_sql_artifact_id: int = Field(gt=0)
    artifact_name: str = Field(min_length=1, max_length=400)
    target: ModeledEntityReference
    entity_type: MappingEntityType
    generated_sql: str = Field(min_length=1, repr=False)
    generated_sql_byte_count: int = Field(gt=0)
    artifact_is_current: bool | None = None
    source_system_codes: tuple[str, ...] = Field(default=(), max_length=200)

    @model_validator(mode="after")
    def validate_bounded_sql(self) -> Self:
        if len(self.generated_sql.encode()) != self.generated_sql_byte_count:
            raise ValueError("generated SQL byte count does not match its content")
        return self


class GeneratedSqlArtifactNotFoundError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="generated_sql_artifact_not_found",
            message="The requested generated SQL artifact was not found.",
        )


class SqlArtifactExportEmptyError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="generated_sql_export_empty",
            message="No active SQL files are available for this layer.",
        )


class SqlArtifactBundleLimitExceededError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="generated_sql_bundle_limit_exceeded",
            message="The requested generated SQL artifacts exceed the safe bundle limit.",
        )
