"""Governed, idempotent Workflow Run creation and cancellation implementation."""

from contextlib import AbstractAsyncContextManager
from typing import Never, Protocol
from uuid import UUID

from atlas_mcp.application.authorization import AuthorizationService
from atlas_mcp.domain.authorization import ActorKind, RequestPrincipal, ToolPolicy
from atlas_mcp.domain.errors import (
    AtlasError,
    AuthorizationDeniedError,
    DependencyUnavailableError,
    InvalidRequestError,
    TenantLockedError,
    TenantLockRequiredError,
    TenantNotFoundError,
)
from atlas_mcp.infrastructure.postgres import WriteTransaction
from psycopg.types.json import Jsonb

from atlas_platform.capabilities import (
    CODE_GENERATION_AGENT_EXECUTION_MODE,
    VALIDATION_AGENT_EXECUTION_MODE,
    AgentCapabilityRegistry,
)
from atlas_platform.features.projects import ProjectNotFoundError, ProjectRevisionConflictError
from atlas_platform.features.workflows.commands.contracts import (
    CreateWorkflowRunRequest,
    WorkflowRunCancellationResult,
    WorkflowRunCommandResult,
)
from atlas_platform.features.workflows.runs import WorkflowRunNotFoundError

_PROJECT_OWNER_SQL = """
SELECT target_project.project_revision,
       target_project.default_agent_sdk_code,
       target_project.default_agent_provider_code,
       target_project.default_agent_model_code,
       target_project.default_reasoning_effort_code,
       target_project.default_max_turns,
       target_project.default_validation_retry_count
  FROM project.project AS target_project
 WHERE target_project.tenant_id = %s
   AND target_project.project_id = %s
   AND target_project.is_active
"""

# Subject Area runs group the Bronze Input Scope that Logical runs model.
_SUBJECT_AREA_SCOPE_SQL = """
SELECT coalesce(
           array_agg(scope.object_id ORDER BY scope.object_id),
           ARRAY[]::BIGINT[]
       ) AS object_ids
  FROM project.project_input_scope AS scope
  JOIN workflow.list_project_object_eligibility(%s) AS eligible
    ON eligible.object_id = scope.object_id
   AND eligible.is_project_input_eligible
   AND eligible.zone_code = 'bronze'
 WHERE scope.project_id = %s
   AND scope.is_active
"""

_CREATE_WORKFLOW_RUN_SQL = """
SELECT created.created,
       created.workflow_run_id,
       created.workflow_run_state,
       created.correlation_id,
       created.prompt_snapshot_count,
       created.project_revision,
       created.selected_scope_digest,
       created.selected_scope_count,
       created.code_generation_coverage_mode,
       created.created_time AS created_at
  FROM application.create_workflow_run(
       %s, %s, %s, %s, %s, %s, %s, %s, %s,
       %s, %s, %s, %s, %s, %s, %s, %s, %s,
       %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
  ) AS created
"""


class WorkflowCommandService(Protocol):
    async def cancel_run(
        self,
        principal: RequestPrincipal,
        *,
        tenant_id: int,
        project_id: int,
        workflow_run_id: int,
    ) -> WorkflowRunCancellationResult: ...

    async def create_run(
        self,
        principal: RequestPrincipal,
        *,
        tenant_id: int,
        project_id: int,
        correlation_id: UUID,
        command: CreateWorkflowRunRequest,
    ) -> WorkflowRunCommandResult: ...


class WorkflowCommandDatabase(Protocol):
    def write_transaction(self) -> AbstractAsyncContextManager[WriteTransaction]: ...


class DatabaseWorkflowCommandService:
    def __init__(
        self,
        *,
        database: WorkflowCommandDatabase,
        authorizer: AuthorizationService,
        agent_capability_registry: AgentCapabilityRegistry,
    ) -> None:
        self._database = database
        self._authorizer = authorizer
        self._agent_capability_registry = agent_capability_registry

    async def cancel_run(
        self,
        principal: RequestPrincipal,
        *,
        tenant_id: int,
        project_id: int,
        workflow_run_id: int,
    ) -> WorkflowRunCancellationResult:
        try:
            async with self._database.write_transaction() as transaction:
                await self._authorizer.authorize_tenant(
                    transaction,
                    principal,
                    tenant_id=tenant_id,
                    policy=ToolPolicy.TENANT_PROJECT_WRITE,
                    project_id=project_id,
                )
                row = await transaction.fetch_one(
                    """
                    SELECT changed, workflow_run_id, workflow_run_state,
                           completed_time AS completed_at
                      FROM application.cancel_workflow_run(%s, %s, %s, %s, %s, %s)
                    """,
                    _identity_triple(principal) + (tenant_id, project_id, workflow_run_id),
                )
        except Exception as error:
            _raise_safe_workflow_error(error)
        if row is None:
            raise DependencyUnavailableError()
        return WorkflowRunCancellationResult.model_validate(row, strict=True)

    async def create_run(
        self,
        principal: RequestPrincipal,
        *,
        tenant_id: int,
        project_id: int,
        correlation_id: UUID,
        command: CreateWorkflowRunRequest,
    ) -> WorkflowRunCommandResult:
        if command.project_workflow == "code_generation":
            agent_execution_mode = CODE_GENERATION_AGENT_EXECUTION_MODE
        elif command.project_workflow == "validation":
            agent_execution_mode = VALIDATION_AGENT_EXECUTION_MODE
        else:
            agent_execution_mode = command.workflow_execution_mode
        if command.agent is not None:
            self._agent_capability_registry.validate_selection(
                command.agent,
                execution_mode=agent_execution_mode,
            )
        try:
            async with self._database.write_transaction() as transaction:
                await self._authorizer.authorize_tenant(
                    transaction,
                    principal,
                    tenant_id=tenant_id,
                    policy=ToolPolicy.TENANT_PROJECT_WRITE,
                    project_id=project_id,
                )
                owner = await transaction.fetch_one(
                    _PROJECT_OWNER_SQL,
                    (tenant_id, project_id),
                )
                if owner is None:
                    raise ProjectNotFoundError()
                if command.project_workflow == "subject_area":
                    # Subject Areas group all or some active Bronze Input Scope Objects; the
                    # Objects left out keep their saved areas.
                    scope = await transaction.fetch_one(
                        _SUBJECT_AREA_SCOPE_SQL, (project_id, project_id)
                    )
                    if scope is None or not set(command.selected_object_ids) <= set(
                        scope["object_ids"]
                    ):
                        raise InvalidRequestError(
                            "Subject Area runs use active Bronze Input Scope Objects. "
                            "Refresh and run again."
                        )
                agent = command.agent
                if agent is None and agent_execution_mode is not None:
                    agent = self._agent_capability_registry.resolve_default_selection(
                        execution_mode=agent_execution_mode,
                        model_code=owner.get("default_agent_model_code"),
                        reasoning_effort_code=owner.get("default_reasoning_effort_code"),
                        max_turns=owner.get("default_max_turns"),
                        validation_retry_count=owner.get("default_validation_retry_count"),
                    )
                identity = _identity_triple(principal)
                row = await transaction.fetch_one(
                    _CREATE_WORKFLOW_RUN_SQL,
                    identity
                    + (
                        project_id,
                        command.expected_project_revision,
                        command.project_workflow,
                        command.workflow_execution_mode,
                        None if agent is None else agent.sdk_code,
                        None if agent is None else agent.provider_code,
                        None if agent is None else agent.model_code,
                        None if agent is None else agent.reasoning_effort_code,
                        None if agent is None else agent.max_turns,
                        None if agent is None else agent.validation_retry_count,
                        command.selected_object_ids,
                        command.selected_system_codes,
                        command.modeled_entity_type,
                        command.requested_batch_id,
                        correlation_id,
                        Jsonb(command.prompt_overrides),
                        command.mapping_operation,
                        command.mapping_coverage_mode,
                        command.mapping_source_system_id,
                        command.mapping_object_output_template_id,
                        command.mapping_attribute_output_template_id,
                        command.code_generation_coverage_mode,
                        Jsonb(
                            [
                                target.model_dump(mode="json")
                                for target in command.description_targets
                            ]
                        )
                        if command.description_targets is not None
                        else None,
                        Jsonb(
                            [target.model_dump(mode="json") for target in command.mapping_targets]
                        )
                        if command.mapping_targets is not None
                        else None,
                        command.code_generation_file_layout,
                        None
                        if command.project_workflow in {"logical", "dimensional"}
                        else command.selected_entity_ids,
                        command.workflow_operation,
                        command.subject_area_ids if command.workflow_operation == "build" else None,
                    ),
                )
        except Exception as error:
            _raise_safe_workflow_error(error)
        if row is None:
            raise DependencyUnavailableError()
        return WorkflowRunCommandResult.model_validate(row, strict=True)


def _identity_triple(principal: RequestPrincipal) -> tuple[UUID, UUID, str]:
    if principal.entra_tenant_id is None or principal.entra_object_id is None:
        raise AuthorizationDeniedError()
    principal_type = "service_principal" if principal.actor_kind is ActorKind.WORKLOAD else "user"
    return principal.entra_tenant_id, principal.entra_object_id, principal_type


def _raise_safe_workflow_error(error: Exception) -> Never:
    if isinstance(error, AtlasError) and not isinstance(
        error,
        DependencyUnavailableError,
    ):
        raise error
    message = _primary_database_message(error)
    if message == "Workflow Run is unavailable":
        raise WorkflowRunNotFoundError() from error
    if message == "Workflow Run belongs to another Principal":
        raise AuthorizationDeniedError() from error
    if message == "workflow_run_cancellation_conflict":
        raise AtlasError(
            "workflow_run_cancellation_conflict",
            "This run has already finished or saved its result. Refresh to see its outcome.",
        ) from error
    if message == "stale_project_revision":
        raise ProjectRevisionConflictError() from error
    if message == "metadata_description_conflict":
        raise AtlasError(
            "metadata_revision_conflict",
            "The description changed or its record is locked. Refresh and review again.",
        ) from error
    if message in {
        "Workflow Run Project is unavailable",
        "Project is unavailable",
    }:
        raise ProjectNotFoundError() from error
    if message in {
        "Global default Mapping Object output template is unavailable",
        "Global default Mapping Attribute output template is unavailable",
    }:
        raise InvalidRequestError("The global Mapping output templates are unavailable.") from error
    if message in {
        "Selected Code Generation target lacks complete applied SQL Mapping",
        "Selected Code Generation target has no active applied SQL Mapping",
    }:
        raise AtlasError(
            code="code_mapping_incomplete",
            message="Save an Object or Attribute transformation for the selected Entities "
            "before generating Code.",
        ) from error
    if message == "Selected Subject Areas are unavailable":
        raise AtlasError(
            code="subject_areas_unavailable",
            message="A selected Subject Area is no longer active. Refresh and choose again.",
        ) from error
    if message == "The selected Subject Areas have nothing to build from":
        raise AtlasError(
            code="subject_areas_empty",
            message="The selected Subject Areas have no eligible Objects to build from. "
            "Add Objects to them or choose other areas.",
        ) from error
    if message == "Optimize requires an applied model":
        raise AtlasError(
            code="optimize_model_empty",
            message="Optimize needs an applied model. Build and apply at least one Subject "
            "Area first.",
        ) from error
    if message == "Code Generation has no eligible target set":
        raise AtlasError(
            code="code_no_eligible_targets",
            message="Code Generation needs an Entity with an active Object or Attribute "
            "transformation.",
        ) from error
    if message == "Selected Code Generation System is unavailable":
        raise AtlasError(
            code="code_system_unavailable",
            message="Choose only Systems contributing to the selected Entities. "
            "Refresh the selection before generating SQL.",
        ) from error
    if (
        message == "No usable prompt is assigned to Workflow Stage"
        or message.startswith("No usable prompt is assigned to Workflow Stage ")
        or message == "Resolved prompt version is unavailable to the Project"
    ):
        raise AtlasError(
            code="workflow_prompt_unavailable",
            message="A published prompt is unavailable for this workflow. "
            "Review the Project's prompt settings before generating again.",
        ) from error
    if message == "Selected Validation System has no saved Mapping":
        raise InvalidRequestError(
            "Map this System first: Validation needs at least one Entity with a saved "
            "Mapping for each selected System."
        ) from error
    if message in {
        "Selected Scope requires Objects",
        "Selected Scope Object IDs must be positive",
        "Selected Scope Object IDs must be unique",
        "Selected Scope contains an unavailable or ineligible Object",
        "Selected Scope is required",
        "Invalid Code Generation file layout",
        "Invalid description regeneration target",
        "Validation requires selected Systems and no Object selection",
        "System selection is available only for Validation",
        "Selected System Codes must be nonblank",
        "Selected System Codes must be unique",
        "Agent configuration is required for this Workflow Run",
        "Agent configuration override must be complete",
        "Deterministic Workflow Run cannot use agent configuration",
        "Deterministic Workflow Run cannot use prompt overrides",
        "Workflow Run correlation conflict",
        "Mapping route is inferred by the server",
        "Mapping requires one complete selected target and source System pair",
        "Mapping inputs are unavailable for this Workflow Run",
        "Selected Mapping target has no preregistered header",
        "Selected Mapping target contains mixed modeled layers",
        "Selected Mapping target contains an unavailable or locked header",
        "Selected Mapping target is unavailable",
        "Selected Mapping target has a mixed or wrong-zone route",
        "Selected Mapping Object output template is unavailable",
        "Selected Mapping Attribute output template is unavailable",
    }:
        raise InvalidRequestError("The requested workflow run is invalid.") from error

    denial_code = _controlled_denial_code(message)
    if denial_code == "tenant_not_found":
        raise TenantNotFoundError() from error
    if denial_code == "tenant_lock_required":
        raise TenantLockRequiredError() from error
    if denial_code == "tenant_locked":
        raise TenantLockedError("another Principal") from error
    if denial_code == "authorization_denied":
        raise AuthorizationDeniedError() from error
    raise DependencyUnavailableError() from error


def _primary_database_message(error: Exception) -> str:
    current: BaseException = error
    for _ in range(4):
        diagnostic = getattr(current, "diag", None)
        primary = getattr(diagnostic, "message_primary", None)
        if isinstance(primary, str) and primary:
            return primary
        if current.__cause__ is None:
            return str(current)
        current = current.__cause__
    return ""


def _controlled_denial_code(message: str) -> str | None:
    prefixes = ("Workflow Run creation denied: ", "Workflow Run cancellation denied: ")
    prefix = next((value for value in prefixes if message.startswith(value)), None)
    if prefix is None:
        return None
    code = message.removeprefix(prefix)
    if code in {
        "tenant_not_found",
        "tenant_lock_required",
        "tenant_locked",
        "authorization_denied",
    }:
        return code
    return None
