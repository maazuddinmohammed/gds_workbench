"""Read-only, Tenant-scoped Project Workflow Overview persistence."""

from contextlib import AbstractAsyncContextManager
from typing import Protocol

from atlas_mcp.application.authorization import AuthorizationService
from atlas_mcp.domain.authorization import RequestPrincipal, ToolPolicy
from atlas_mcp.infrastructure.postgres import ReadIsolation, ReadTransaction

from atlas_platform.features.projects import ProjectNotFoundError
from atlas_platform.features.workflows.overview.contracts import (
    OverviewWorkflow,
    ProjectSectionState,
    ProjectSectionStatus,
    ProjectWorkflowOverview,
    QualityWarningCode,
    WorkflowLedgerEntry,
    WorkflowLedgerState,
    WorkflowMetric,
)
from atlas_platform.features.workflows.runs.contracts import MappingRunOutcome
from atlas_platform.features.workflows.runs.service import read_mapping_run_outcomes

_WORKFLOW_OVERVIEW_SQL = """
WITH target_project AS (
    SELECT project.project_id,
           project.project_revision
      FROM project.project AS project
     WHERE project.tenant_id = %s
       AND project.project_id = %s
       AND project.is_active
), metrics AS (
    SELECT 1 AS workflow_order,
           'scope'::TEXT AS workflow,
           count(scope.project_input_scope_id)::INTEGER AS result_count,
           count(scope.project_input_scope_id) FILTER (
               WHERE scope.project_input_scope_is_locked
           )::INTEGER AS locked_count,
           max(scope.updated_time) AS latest_result_updated_at
      FROM target_project
      LEFT JOIN project.project_input_scope AS scope
        ON scope.project_id = target_project.project_id
       AND scope.is_active
    UNION ALL
    SELECT 2,
           'profiling',
           count(DISTINCT profile.object_id)::INTEGER,
           0::INTEGER,
           max(profile.updated_time)
      FROM target_project
      LEFT JOIN workflow.attribute_profile AS profile
        ON profile.project_id = target_project.project_id
    UNION ALL
    SELECT 3,
           'analysis',
           count(result.analysis_result_id) FILTER (
               WHERE result.analysis_result_status = 'active'
           )::INTEGER,
           count(result.analysis_result_id) FILTER (
               WHERE result.analysis_result_status = 'active'
                 AND result.analysis_result_is_locked
           )::INTEGER,
           max(result.updated_time) FILTER (
               WHERE result.analysis_result_status = 'active'
           )
      FROM target_project
      LEFT JOIN workflow.analysis_result AS result
        ON result.project_id = target_project.project_id
    UNION ALL
    SELECT 4,
           'context',
           count(context_record.context_record_id) FILTER (
               WHERE context_record.status
                     = 'active'
           )::INTEGER,
           count(context_record.context_record_id) FILTER (
               WHERE context_record.status
                     = 'active'
                 AND context_record.is_locked
           )::INTEGER,
           max(context_record.updated_time) FILTER (
               WHERE context_record.status = 'active'
           )
      FROM target_project
      LEFT JOIN project.context_record AS context_record
        ON context_record.project_id = target_project.project_id
    UNION ALL
    SELECT 5,
           'subject_area',
           count(area.subject_area_id) FILTER (
               WHERE area.subject_area_is_active
           )::INTEGER,
           count(area.subject_area_id) FILTER (
               WHERE area.subject_area_is_active
                 AND area.subject_area_is_locked
           )::INTEGER,
           max(area.updated_time) FILTER (
               WHERE area.subject_area_is_active
           )
      FROM target_project
      LEFT JOIN workflow.subject_area AS area
        ON area.project_id = target_project.project_id
    UNION ALL
    SELECT 6,
           'logical',
           count(logical.logical_entity_id) FILTER (
               WHERE logical.logical_entity_is_active
           )::INTEGER,
           count(logical.logical_entity_id) FILTER (
               WHERE logical.logical_entity_is_active
                 AND logical.logical_entity_is_locked
           )::INTEGER,
           max(logical.updated_time) FILTER (
               WHERE logical.logical_entity_is_active
           )
      FROM target_project
      LEFT JOIN workflow.logical_entity AS logical
        ON logical.project_id = target_project.project_id
    UNION ALL
    SELECT 7,
           'dimensional',
           count(dimensional.dimensional_entity_id) FILTER (
               WHERE dimensional.dimensional_entity_is_active
           )::INTEGER,
           count(dimensional.dimensional_entity_id) FILTER (
               WHERE dimensional.dimensional_entity_is_active
                 AND dimensional.dimensional_entity_is_locked
           )::INTEGER,
           max(dimensional.updated_time) FILTER (
               WHERE dimensional.dimensional_entity_is_active
           )
      FROM target_project
      LEFT JOIN workflow.dimensional_entity AS dimensional
        ON dimensional.project_id = target_project.project_id
    UNION ALL
    SELECT 8,
           'metadata_enrichment',
           count(DISTINCT object.object_id) FILTER (
               WHERE nullif(btrim(object_enrichment.object_description), '') IS NOT NULL
                  OR nullif(btrim(attribute_enrichment.attribute_description), '') IS NOT NULL
                  OR nullif(btrim(attribute_enrichment.attribute_inferred_data_type), '')
                       IS NOT NULL
                  OR num_nonnulls(attribute_enrichment.is_natural_key,
                      attribute_enrichment.is_primary_key, attribute_enrichment.is_nullable,
                      attribute_enrichment.is_pii) > 0
           )::INTEGER,
           0::INTEGER,
           max(greatest(
               CASE WHEN nullif(btrim(object_enrichment.object_description), '') IS NOT NULL
                    THEN object_enrichment.updated_time END,
               CASE WHEN nullif(btrim(attribute_enrichment.attribute_description), '') IS NOT NULL
                      OR nullif(btrim(attribute_enrichment.attribute_inferred_data_type), '')
                       IS NOT NULL
                      OR num_nonnulls(attribute_enrichment.is_natural_key,
                      attribute_enrichment.is_primary_key, attribute_enrichment.is_nullable,
                      attribute_enrichment.is_pii) > 0
                    THEN attribute_enrichment.updated_time END
           ))
      FROM target_project
      LEFT JOIN project.project_input_scope AS scope
        ON scope.project_id = target_project.project_id AND scope.is_active
      LEFT JOIN core.object AS object
        ON object.object_id = scope.object_id AND object.is_active
      LEFT JOIN core.attribute AS attribute
        ON attribute.object_id = object.object_id AND attribute.is_active
      LEFT JOIN workflow.object_enrichment AS object_enrichment
        ON object_enrichment.project_id = target_project.project_id
       AND object_enrichment.object_id = object.object_id
      LEFT JOIN workflow.attribute_enrichment AS attribute_enrichment
        ON attribute_enrichment.project_id = target_project.project_id
       AND attribute_enrichment.attribute_id = attribute.attribute_id
    UNION ALL
    SELECT 9,
           'mapping',
           count(mapping.mapping_object_id)::INTEGER,
           count(mapping.mapping_object_id) FILTER (
               WHERE mapping.object_mapping_is_locked
           )::INTEGER,
           max(mapping.updated_time)
      FROM target_project
      LEFT JOIN workflow.mapping_object AS mapping
        ON mapping.project_id = target_project.project_id
       AND mapping.object_mapping_status = 'active'
    UNION ALL
    SELECT 10,
           'code_generation',
           count(code.generated_code_id)::INTEGER,
           count(code.generated_code_id) FILTER (
               WHERE code.generated_code_is_locked
           )::INTEGER,
           max(code.updated_time)
      FROM target_project
      LEFT JOIN workflow.generated_code AS code
        ON code.project_id = target_project.project_id
       AND code.generated_code_status = 'active'
    UNION ALL
    SELECT 11,
           'validation',
           count(validation.validation_group_id)::INTEGER,
           count(validation.validation_group_id) FILTER (
               WHERE validation.is_locked
           )::INTEGER,
           max(validation.updated_time)
      FROM target_project
      LEFT JOIN workflow.validation_group AS validation
        ON validation.project_id = target_project.project_id AND validation.is_active
), latest_run AS (
    SELECT ranked.project_workflow,
           ranked.workflow_run_id,
           ranked.workflow_run_state,
           ranked.created_time,
           ranked.completed_time
      FROM (
          SELECT run.project_workflow,
                 run.workflow_run_id,
                 run.workflow_run_state,
                 run.created_time,
                 run.completed_time,
                 row_number() OVER (
                     PARTITION BY run.project_workflow
                     ORDER BY run.created_time DESC, run.workflow_run_id DESC
                 ) AS run_order
            FROM application.workflow_run AS run
            JOIN target_project
              ON target_project.project_id = run.project_id
      ) AS ranked
     WHERE ranked.run_order = 1
)
SELECT target_project.project_id,
       target_project.project_revision,
       metrics.workflow,
       metrics.result_count,
       metrics.locked_count,
       latest_run.workflow_run_id AS latest_run_id,
       latest_run.workflow_run_state AS latest_run_state,
       latest_run.created_time AS latest_run_created_at,
       latest_run.completed_time AS latest_run_completed_at,
       metrics.latest_result_updated_at
  FROM target_project
 CROSS JOIN metrics
  LEFT JOIN latest_run
    ON latest_run.project_workflow = metrics.workflow
 ORDER BY metrics.workflow_order
"""


class WorkflowOverviewService(Protocol):
    async def read_overview(
        self,
        principal: RequestPrincipal,
        *,
        tenant_id: int,
        project_id: int,
    ) -> ProjectWorkflowOverview: ...


class WorkflowOverviewDatabase(Protocol):
    def read_transaction(
        self,
        *,
        isolation: ReadIsolation = ReadIsolation.READ_COMMITTED,
    ) -> AbstractAsyncContextManager[ReadTransaction]: ...


def _ledger_state(metric: WorkflowMetric) -> WorkflowLedgerState:
    if metric.workflow == "scope":
        return "ready" if metric.result_count else "empty"
    if metric.latest_run_state in ("queued", "running", "failed", "cancelled"):
        return metric.latest_run_state
    if metric.result_count:
        return "results_available"
    if metric.latest_run_state in ("completed", "completed_with_repair"):
        return "completed_no_results"
    return "not_started"


def _section_state(
    metric: WorkflowMetric,
    *,
    mapping_outcome: MappingRunOutcome | None = None,
) -> ProjectSectionState:
    if metric.workflow == "scope":
        return "ready" if metric.result_count else "empty"
    if metric.latest_run_state in ("queued", "running", "failed", "cancelled"):
        return metric.latest_run_state
    # A completed Run is a lifecycle fact, not a statement that its draft was
    # applied, all targets have coverage, or the stored results are still current.
    # Later external edits remain discoverable without claiming that Run made them.
    completed = metric.latest_run_state in ("completed", "completed_with_repair")
    if (
        completed
        and metric.workflow == "mapping"
        and mapping_outcome is not None
        and (mapping_outcome.failed_pair_count or mapping_outcome.partial_pair_count)
    ):
        return "results_available"
    if metric.result_count and (
        not completed
        or metric.latest_run_completed_at is None
        or metric.latest_result_updated_at is None
        or metric.latest_result_updated_at > metric.latest_run_completed_at
    ):
        return "results_available"
    return "completed" if completed else "not_run"


def _quality_warnings(
    metric: WorkflowMetric,
    result_counts: dict[OverviewWorkflow, int],
) -> tuple[QualityWarningCode, ...]:
    if metric.workflow == "profiling" and not result_counts["scope"]:
        return ("scope_empty",)
    if metric.workflow == "analysis" and not result_counts["profiling"]:
        return ("profiling_results_unavailable",)
    if metric.workflow == "dimensional" and not result_counts["logical"]:
        return ("logical_results_unavailable",)
    return ()


class DatabaseWorkflowOverviewService:
    def __init__(
        self,
        *,
        database: WorkflowOverviewDatabase,
        authorizer: AuthorizationService,
    ) -> None:
        self._database = database
        self._authorizer = authorizer

    async def read_overview(
        self,
        principal: RequestPrincipal,
        *,
        tenant_id: int,
        project_id: int,
    ) -> ProjectWorkflowOverview:
        async with self._database.read_transaction(
            isolation=ReadIsolation.REPEATABLE_READ
        ) as transaction:
            await self._authorizer.authorize_tenant(
                transaction,
                principal,
                tenant_id=tenant_id,
                policy=ToolPolicy.TENANT_READ,
                project_id=project_id,
            )
            rows = await transaction.fetch_all(
                _WORKFLOW_OVERVIEW_SQL,
                (tenant_id, project_id),
            )
            if not rows:
                raise ProjectNotFoundError()

            metrics = tuple(WorkflowMetric.model_validate(row) for row in rows)
            mapping_outcomes = await read_mapping_run_outcomes(
                transaction,
                tenant_id=tenant_id,
                project_id=project_id,
                workflow_run_ids=tuple(
                    metric.latest_run_id
                    for metric in metrics
                    if metric.workflow == "mapping" and metric.latest_run_id is not None
                ),
            )
        result_counts: dict[OverviewWorkflow, int] = {
            metric.workflow: metric.result_count for metric in metrics
        }
        items = tuple(
            WorkflowLedgerEntry(
                workflow=metric.workflow,
                result_count=metric.result_count,
                locked_count=metric.locked_count,
                latest_run_id=metric.latest_run_id,
                latest_run_state=metric.latest_run_state,
                latest_run_created_at=metric.latest_run_created_at,
                state=_ledger_state(metric),
                quality_warning_codes=_quality_warnings(metric, result_counts),
            )
            for metric in metrics
            if metric.workflow
            in (
                "scope",
                "profiling",
                "analysis",
                "context",
                "subject_area",
                "logical",
                "dimensional",
            )
        )
        by_workflow = {metric.workflow: metric for metric in metrics}
        section_states = [
            ProjectSectionStatus(section="overview", state="available"),
            ProjectSectionStatus(section="settings", state="available"),
        ]
        for workflow in (
            "scope",
            "metadata_enrichment",
            "profiling",
            "context",
            "analysis",
            "subject_area",
            "logical",
            "dimensional",
            "mapping",
            "code_generation",
            "validation",
        ):
            metric = by_workflow.get(workflow)
            if metric is None:
                continue
            section_states.append(
                ProjectSectionStatus.model_validate(
                    {
                        "section": workflow.replace("_", "-"),
                        "state": _section_state(
                            metric,
                            mapping_outcome=mapping_outcomes.get(metric.latest_run_id)
                            if metric.latest_run_id is not None
                            else None,
                        ),
                    }
                )
            )
        return ProjectWorkflowOverview(
            project_id=metrics[0].project_id,
            project_revision=metrics[0].project_revision,
            items=items,
            section_states=tuple(section_states),
        )
