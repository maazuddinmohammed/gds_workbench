"""Human lifecycle plans over existing owned records; never generate authored content."""

import hashlib
import json
from collections import defaultdict, deque
from dataclasses import asdict, dataclass, field
from typing import Literal, cast

from atlas_mcp.application.change_sets.project_validation import (
    PhysicalProjectCatalog,
    ValidatedProjectChangeSet,
    validate_future_graph,
)
from atlas_mcp.application.project_snapshot import ProjectReviewSnapshot
from atlas_mcp.domain.errors import AtlasError
from atlas_mcp.domain.modeling_records import (
    DimensionalAttributeRecord,
    DimensionalEntityRecord,
    ModelingRecord,
    normalize_project_key_value,
)
from atlas_mcp.domain.snapshots.project import DATASETS_BY_NAME, ProjectChangeSetDataset

type ProjectReviewDataset = Literal[
    "context_record",
    "subject_area",
    "subject_area_table",
    "logical_entity",
    "logical_attribute",
    "logical_relationship",
    "dimensional_entity",
    "dimensional_attribute",
    "dimensional_relationship",
    "mapping_object",
    "mapping_attribute",
    "generated_code",
    "generated_code_source_system",
    "validation_group",
    "validation_check",
]
type RecordReviewAction = Literal["lock", "unlock", "deactivate", "reactivate"]
type ProjectLayer = Literal["subject_area", "logical", "dimensional"]
type RecordIdentity = tuple[ProjectReviewDataset, int | str]

# Dataset-specific lifecycle columns and snapshot collections. Table names remain
# a separate fixed SQL allowlist in the repository. Subject Area, Logical, Dimensional
# and Validation records keep a boolean *is_active; the others keep a status text.
REVIEW_FIELDS: dict[ProjectReviewDataset, tuple[str, str, str]] = {
    "context_record": (
        "is_locked",
        "status",
        "records",
    ),
    "subject_area": ("subject_area_is_locked", "subject_area_is_active", "areas"),
    "subject_area_table": (
        "subject_area_table_is_locked",
        "subject_area_table_is_active",
        "tables",
    ),
    **{
        cast(ProjectReviewDataset, f"{layer}_{kind}"): (
            f"{layer}_{kind}_is_locked",
            f"{layer}_{kind}_is_active",
            collection,
        )
        for layer in ("logical", "dimensional")
        for kind, collection in (
            ("entity", "entities"),
            ("attribute", "attributes"),
            ("relationship", "relationships"),
        )
    },
    "mapping_object": ("object_mapping_is_locked", "object_mapping_status", "objects"),
    "mapping_attribute": ("attribute_mapping_is_locked", "attribute_mapping_status", "attributes"),
    "generated_code": ("generated_code_is_locked", "generated_code_status", "artifacts"),
    "generated_code_source_system": (
        "generated_code_source_system_is_locked",
        "generated_code_source_system_status",
        "source_systems",
    ),
    "validation_group": ("is_locked", "is_active", "groups"),
    "validation_check": ("is_locked", "is_active", "checks"),
}


def review_lifecycle(record: ModelingRecord, dataset: ProjectReviewDataset) -> tuple[bool, str]:
    """Return (is_locked, display status); boolean lifecycles show as active/inactive."""
    lock_field, status_field, _ = REVIEW_FIELDS[dataset]
    status = getattr(record, status_field)
    if status_field.endswith("is_active"):
        status = "active" if status else "inactive"
    return bool(getattr(record, lock_field)), status


@dataclass(frozen=True, slots=True)
class ProjectReviewDecision:
    dataset: ProjectReviewDataset
    record_id: int | str
    selected: bool
    reason: str
    original: ModelingRecord = field(repr=False)
    reviewed: ModelingRecord = field(repr=False)


def plan_project_record_review(
    review: ProjectReviewSnapshot,
    *,
    dataset: ProjectReviewDataset,
    record_ids: list[int | str],
    action: RecordReviewAction | Literal["delete"],
    layer: ProjectLayer | None = None,
) -> tuple[ProjectReviewDecision, ...]:
    """Close lifecycle dependencies using existing canonical identities only."""
    selected = review.records_by_id.get(dataset, {})
    if layer is None and (
        not record_ids
        or len(record_ids) != len(set(record_ids))
        or any(i not in selected for i in record_ids)
    ):
        raise AtlasError("project_record_not_found", "A selected record is unavailable.")
    records: dict[RecordIdentity, ModelingRecord] = {
        (name, i): row
        for name, rows in review.records_by_id.items()
        if name in REVIEW_FIELDS
        for i, row in rows.items()
    }
    keys: dict[tuple[ProjectReviewDataset, tuple[object, ...]], RecordIdentity] = {
        (
            name,
            tuple(
                normalize_project_key_value(getattr(row, f))
                for f in DATASETS_BY_NAME[name].canonical_key
            ),
        ): identity
        for identity, row in records.items()
        for name in (identity[0],)
    }
    required: dict[RecordIdentity, str] = {(dataset, i): "Selected record." for i in record_ids}
    if layer is not None:
        if (
            action not in {"deactivate", "delete"}
            or record_ids
            or dataset != ("subject_area" if layer == "subject_area" else f"{layer}_entity")
        ):
            raise AtlasError("invalid_request", "The layer review request is invalid.")
        required = {
            identity: f"Clear the {layer.replace('_', ' ').title()} layer."
            for identity, row in records.items()
            if DATASETS_BY_NAME[identity[0]].section == layer
            and (action == "delete" or review_lifecycle(row, identity[0])[1] == "active")
        }
    selected_identities = set(required)
    if action in {"deactivate", "reactivate", "delete"}:
        parents: dict[RecordIdentity, set[RecordIdentity]] = defaultdict(set)
        children: dict[RecordIdentity, set[RecordIdentity]] = defaultdict(set)

        def link(child: RecordIdentity, parent_dataset: ProjectReviewDataset, *key: object) -> None:
            parent = keys.get((parent_dataset, tuple(normalize_project_key_value(v) for v in key)))
            if parent is not None:
                parents[child].add(parent)
                children[parent].add(child)

        for identity, record in records.items():
            name, _ = identity
            v = record.model_dump()
            for source in v.get("sources", ()):
                if source["support_source_type"] == "context_record" and (
                    source["is_active"] or action == "delete"
                ):
                    link(identity, "context_record", source["context_record"]["context_record_id"])
            if name == "subject_area_table":
                link(identity, "subject_area", v["subject_area_name"])
            elif name in {"logical_attribute", "dimensional_attribute"}:
                record_layer = name.split("_")[0]
                link(
                    identity,
                    cast(ProjectReviewDataset, record_layer + "_entity"),
                    v[record_layer + "_entity_schema_name"],
                    v[record_layer + "_entity_name"],
                )
            elif name in {"logical_relationship", "dimensional_relationship"}:
                record_layer = name.split("_")[0]
                for side in ("from", "to"):
                    link(
                        identity,
                        cast(ProjectReviewDataset, record_layer + "_attribute"),
                        v[f"{side}_{record_layer}_entity_schema_name"],
                        v[f"{side}_{record_layer}_entity_name"],
                        v[f"{side}_{record_layer}_attribute_name"],
                    )
            elif name in {
                "mapping_object",
                "mapping_attribute",
                "generated_code",
                "generated_code_source_system",
            }:
                entity = (
                    v["modeled_entity_type"],
                    v["modeled_entity_schema_name"],
                    v["modeled_entity_name"],
                )
                record_layer = str(entity[0]).split("_")[0]
                if name in {"mapping_object", "generated_code"}:
                    link(identity, cast(ProjectReviewDataset, entity[0]), *entity[1:])
                elif name == "mapping_attribute":
                    link(identity, "mapping_object", *entity, v["source_system_code"])
                    link(
                        identity,
                        cast(ProjectReviewDataset, record_layer + "_attribute"),
                        *entity[1:],
                        v["modeled_attribute_name"],
                    )
                else:
                    link(identity, "generated_code", *entity, v["artifact_name"])
                    link(identity, "mapping_object", *entity, v["source_system_code"])
            elif name == "validation_check":
                link(
                    identity,
                    "validation_group",
                    v["tenant_code"],
                    v["system_code"],
                    v["validation_group_name"],
                )

        # Cross-layer dependencies follow explicit Logical design lineage.
        for identity, row in records.items():
            if not isinstance(row, (DimensionalEntityRecord, DimensionalAttributeRecord)):
                continue
            for source in row.sources:
                if (
                    not source.is_active and action != "delete"
                ) or source.support_source_type == "context_record":
                    continue
                if source.support_source_type == "logical_entity":
                    key = source.source_logical_entity
                    link(
                        identity,
                        "logical_entity",
                        key.logical_entity_schema_name,
                        key.logical_entity_name,
                    )
                elif source.support_source_type == "logical_attribute":
                    key = source.source_logical_attribute
                    link(
                        identity,
                        "logical_attribute",
                        key.logical_entity_schema_name,
                        key.logical_entity_name,
                        key.logical_attribute_name,
                    )

        # Mapping covers each active modeled Attribute for every source System.
        for identity, row in records.items():
            name, _ = identity
            v = row.model_dump()
            if name == "mapping_attribute":
                entity = (
                    v["modeled_entity_type"],
                    v["modeled_entity_schema_name"],
                    v["modeled_entity_name"],
                )
                attribute = keys.get(
                    (
                        cast(ProjectReviewDataset, str(entity[0]).split("_")[0] + "_attribute"),
                        tuple(
                            normalize_project_key_value(x)
                            for x in (*entity[1:], v["modeled_attribute_name"])
                        ),
                    )
                )
                header = keys.get(
                    (
                        "mapping_object",
                        tuple(
                            normalize_project_key_value(x)
                            for x in (*entity, v["source_system_code"])
                        ),
                    )
                )
                if (
                    attribute is not None
                    and header is not None
                    and (
                        review_lifecycle(records[attribute], attribute[0])[1] == "active"
                        or action in {"reactivate", "delete"}
                    )
                ):
                    link(
                        header,
                        "mapping_attribute",
                        *entity,
                        v["modeled_attribute_name"],
                        v["source_system_code"],
                    )
            elif name == "generated_code_source_system":
                code = keys.get(
                    (
                        "generated_code",
                        tuple(
                            normalize_project_key_value(v[f])
                            for f in (
                                "modeled_entity_type",
                                "modeled_entity_schema_name",
                                "modeled_entity_name",
                                "artifact_name",
                            )
                        ),
                    )
                )
                if code is not None:
                    link(
                        code,
                        "generated_code_source_system",
                        v["modeled_entity_type"],
                        v["modeled_entity_schema_name"],
                        v["modeled_entity_name"],
                        v["artifact_name"],
                        v["source_system_code"],
                    )

        active_mappings: dict[str, set[RecordIdentity]] = defaultdict(set)
        active_groups: dict[str, set[RecordIdentity]] = defaultdict(set)
        for key, row in records.items():
            if action != "delete" and review_lifecycle(row, key[0])[1] != "active":
                continue
            if key[0] == "mapping_object":
                active_mappings[
                    normalize_project_key_value(row.model_dump()["source_system_code"])
                ].add(key)
            elif key[0] == "validation_group":
                active_groups[normalize_project_key_value(row.model_dump()["system_code"])].add(key)
        code_by_entity: dict[tuple[str, ...], set[RecordIdentity]] = defaultdict(set)
        for key, row in records.items():
            if key[0] == "generated_code" and (
                action == "delete" or review_lifecycle(row, key[0])[1] == "active"
            ):
                value = row.model_dump()
                code_by_entity[
                    (
                        value["modeled_entity_type"],
                        normalize_project_key_value(value["modeled_entity_schema_name"]),
                        normalize_project_key_value(value["modeled_entity_name"]),
                    )
                ].add(key)
        queue = deque(required)
        while queue:
            identity = queue.popleft()
            for dependent in (children if action in {"deactivate", "delete"} else parents).get(
                identity, ()
            ):
                status = review_lifecycle(records[dependent], dependent[0])[1]
                if dependent not in required and (
                    action == "delete" or ((status == "active") == (action == "deactivate"))
                ):
                    required[dependent] = (
                        "Required by the selected lifecycle change and active dependency coverage."
                    )
                    queue.append(dependent)
            if action in {"deactivate", "delete"} and identity[0] == "generated_code":
                # Retire the applied Code bundle together. Removing just one
                # System's artifact must not leave the target apparently current.
                value = records[identity].model_dump()
                entity = (
                    value["modeled_entity_type"],
                    normalize_project_key_value(value["modeled_entity_schema_name"]),
                    normalize_project_key_value(value["modeled_entity_name"]),
                )
                for key in code_by_entity[entity] - required.keys():
                    required[key] = (
                        "Retire the target's Code bundle to preserve "
                        "complete System assignment coverage."
                    )
                    queue.append(key)
            if action in {"deactivate", "delete"} and identity[0] == "mapping_object":
                system = normalize_project_key_value(
                    records[identity].model_dump()["source_system_code"]
                )
                active_mappings[system].discard(identity)
                if not active_mappings[system]:
                    for key in active_groups[system] - required.keys():
                        required[key] = (
                            "This System loses its last active Mapping; "
                            "retire its Validation Group and Checks."
                        )
                        queue.append(key)
        if len(required) > 50_000:
            raise AtlasError(
                "review_conflict", "The complete review exceeds Project Change Set limits."
            )
    decisions: list[ProjectReviewDecision] = []
    for (name, record_id), reason in required.items():
        original = records[(name, record_id)]
        lock_field, status_field, _ = REVIEW_FIELDS[name]
        values = original.model_dump(mode="json")
        if action in {"lock", "unlock"}:
            values[lock_field] = action == "lock"
        elif status_field.endswith("is_active"):
            values[status_field] = action == "reactivate"
        else:
            values[status_field] = "active" if action == "reactivate" else "inactive"
        decisions.append(
            ProjectReviewDecision(
                dataset=name,
                record_id=record_id,
                selected=(name, record_id) in selected_identities,
                reason=reason,
                original=original,
                reviewed=DATASETS_BY_NAME[name].row_model.model_validate(values, strict=False),
            )
        )
    return tuple(
        sorted(decisions, key=lambda item: (not item.selected, item.dataset, item.record_id))
    )


@dataclass(frozen=True, slots=True)
class PreparedProjectReview:
    decisions: tuple[ProjectReviewDecision, ...] = field(repr=False)
    validation: ValidatedProjectChangeSet = field(repr=False)
    plan_digest: str


def prepare_project_record_review(
    review: ProjectReviewSnapshot,
    *,
    physical_scope: PhysicalProjectCatalog,
    dataset: ProjectReviewDataset,
    record_ids: list[int | str],
    action: RecordReviewAction,
    layer: ProjectLayer | None = None,
) -> PreparedProjectReview:
    decisions = plan_project_record_review(
        review, dataset=dataset, record_ids=record_ids, action=action, layer=layer
    )
    snapshot = review.snapshot
    if action == "unlock":
        originals = [item.original for item in decisions]
        lock_field, _, collection = REVIEW_FIELDS[dataset]
        section = DATASETS_BY_NAME[dataset].section
        section_value = getattr(snapshot, section)
        snapshot = snapshot.model_copy(
            update={
                section: section_value.model_copy(
                    update={
                        collection: tuple(
                            record.model_copy(update={lock_field: False})
                            if record in originals
                            else record
                            for record in getattr(section_value, collection)
                        )
                    }
                )
            }
        )
    documents: dict[ProjectChangeSetDataset, list[dict[str, object]]] = {}
    for item in decisions:
        documents.setdefault(item.dataset, []).append(item.reviewed.model_dump(mode="json"))
    validation = validate_future_graph(
        snapshot=snapshot,
        staged_documents=documents,
        physical_scope=physical_scope,
        code_authoring=action not in {"lock", "unlock"},
    )
    digest = hashlib.sha256(
        json.dumps(
            {
                "project_id": review.snapshot.project_id,
                "project_revision": review.snapshot.project_revision,
                "dataset": dataset,
                "record_ids": sorted(record_ids),
                "action": action,
                "layer": layer,
                "candidate_digest": validation.candidate_digest,
                "decisions": [
                    {
                        "dataset": item.dataset,
                        "record_id": item.record_id,
                        "original": item.original.model_dump(mode="json"),
                    }
                    for item in decisions
                ],
                "issues": [asdict(issue) for issue in validation.issues],
            },
            ensure_ascii=False,
            allow_nan=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
    ).hexdigest()
    return PreparedProjectReview(decisions=decisions, validation=validation, plan_digest=digest)
