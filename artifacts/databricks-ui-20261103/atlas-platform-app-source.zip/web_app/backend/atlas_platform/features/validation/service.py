"""Start governed Validation Runs and execute them after worker claim."""

from __future__ import annotations

import json
import logging
from hashlib import sha256
from typing import Any, Protocol, cast
from uuid import UUID

from atlas_mcp.application.authorization import AuthorizationService
from atlas_mcp.application.change_sets.project import (
    StageProjectChange,
    validate_project_stage_changes,
)
from atlas_mcp.application.change_sets.project_validation import (
    ProjectValidationIssue,
    validate_future_graph,
)
from atlas_mcp.domain.authorization import RequestPrincipal, ToolPolicy
from atlas_mcp.domain.errors import AtlasError, InvalidRequestError
from atlas_mcp.infrastructure.postgres import (
    ReadIsolation,
    ReadTransaction,
)
from pydantic import JsonValue, ValidationError

from atlas_platform.capabilities import VALIDATION_AGENT_EXECUTION_MODE
from atlas_platform.features.workflows.authoring.change_set_handoff import (
    WorkflowChangeSetFinalizer,
    WorkflowChangeSetHandoffResult,
    WorkflowChangeSetValidationError,
)
from atlas_platform.features.workflows.authoring.downstream_inputs import (
    build_downstream_readers,
    project_downstream_inputs,
)
from atlas_platform.features.workflows.authoring.lifecycle import (
    AgentWorkflowEvent,
    AgentWorkflowRunStart,
    AgentWorkflowTerminalResult,
)
from atlas_platform.features.workflows.authoring.no_op import (
    AuthoringNoOpCompleter,
    AuthoringNoOpReceipt,
    AuthoringNoOpRequest,
    authoring_no_op_candidate_digest,
)
from atlas_platform.features.workflows.authoring.plan import (
    AgentRunPlan,
    AgentRunPlanRepository,
    PostgresAgentRunPlanRepository,
    ProjectWorkflow,
)
from atlas_platform.features.workflows.authoring.progress import (
    AgentWorkflowProgress,
    intermediate_progress_points,
)
from atlas_platform.features.workflows.authoring.repair import (
    AgentCandidateValidation,
    AgentCandidateValidationError,
    AgentContextPolicy,
    AgentExecutor,
    AgentValidationIssue,
    load_default_agent_context_policy,
    project_validation_issues,
)
from atlas_platform.features.workflows.authoring.stage_runner import AgentStageRunner
from atlas_platform.features.workflows.execution.contracts import WorkflowExecutionDatabase

from .candidate import (
    ValidatedValidationSystemCandidate,
    ValidationSystemCandidateValidator,
    reconcile_validation_candidates,
)
from .context import PostgresValidationContextRepository, ValidationExecutionContext

_logger = logging.getLogger(__name__)


class ValidationContextRepository(Protocol):
    async def load(
        self,
        transaction: ReadTransaction,
        *,
        tenant_id: int,
        plan: AgentRunPlan,
    ) -> ValidationExecutionContext: ...


class ValidationLifecycle(Protocol):
    async def start(
        self,
        principal: RequestPrincipal,
        *,
        tenant_id: int,
        project_id: int,
        workflow_run_id: int,
        expected_workflow: ProjectWorkflow,
        expected_execution_mode: None,
        expected_project_revision: int,
    ) -> AgentWorkflowRunStart: ...

    async def append_event(
        self,
        principal: RequestPrincipal,
        *,
        workflow_run_id: int,
        expected_project_revision: int,
        workflow_run_claim_token: UUID,
        event: AgentWorkflowEvent,
    ) -> None: ...

    async def fail(
        self,
        principal: RequestPrincipal,
        *,
        workflow_run_id: int,
        expected_project_revision: int,
        workflow_run_claim_token: UUID,
        failure_code: str,
        safe_failure_message: str,
    ) -> AgentWorkflowTerminalResult: ...


class ValidationExecutionFailedError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="validation_execution_failed",
            message="Validation authoring failed before a validated draft was committed.",
        )


class ValidationFinalizationFailedError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="validation_finalization_failed",
            message="Validation finalization outcome could not be confirmed.",
        )


type ValidationExecutionResult = WorkflowChangeSetHandoffResult | AuthoringNoOpReceipt


class ValidationWorkflow:
    """Start separately from claimed authoring and governed draft handoff."""

    def __init__(
        self,
        *,
        database: WorkflowExecutionDatabase,
        authorizer: AuthorizationService,
        agent_executor: AgentExecutor,
        handoff: WorkflowChangeSetFinalizer,
        no_op: AuthoringNoOpCompleter,
        lifecycle: ValidationLifecycle,
        plan_repository: AgentRunPlanRepository | None = None,
        context_repository: ValidationContextRepository | None = None,
        context_policy: AgentContextPolicy | None = None,
    ) -> None:
        self._database = database
        self._authorizer = authorizer
        self._plan_repository = plan_repository or PostgresAgentRunPlanRepository()
        self._context_repository = context_repository or PostgresValidationContextRepository()
        self._context_policy = context_policy or load_default_agent_context_policy()
        self._stage_runner = AgentStageRunner(
            executor=agent_executor,
            policy=self._context_policy,
        )
        self._handoff = handoff
        self._no_op = no_op
        self._lifecycle = lifecycle

    async def start(
        self,
        principal: RequestPrincipal,
        *,
        tenant_id: int,
        project_id: int,
        workflow_run_id: int,
        expected_project_revision: int,
    ) -> AgentWorkflowRunStart:
        return await self._lifecycle.start(
            principal,
            tenant_id=tenant_id,
            project_id=project_id,
            workflow_run_id=workflow_run_id,
            expected_workflow="validation",
            expected_execution_mode=None,
            expected_project_revision=expected_project_revision,
        )

    async def execute_started(
        self,
        principal: RequestPrincipal,
        *,
        tenant_id: int,
        project_id: int,
        workflow_run_id: int,
        expected_project_revision: int,
        workflow_run_claim_token: UUID,
    ) -> ValidationExecutionResult:
        finalization_attempted = False
        changes: tuple[StageProjectChange, ...] = ()
        rejected_changes: tuple[StageProjectChange, ...] = ()
        rejected_issues: tuple[ProjectValidationIssue, ...] = ()
        try:
            async with self._database.write_transaction(
                isolation=ReadIsolation.REPEATABLE_READ
            ) as transaction:
                await self._authorizer.authorize_tenant(
                    transaction,
                    principal,
                    tenant_id=tenant_id,
                    policy=ToolPolicy.TENANT_PROJECT_WRITE,
                    project_id=project_id,
                )
                plan = await self._plan_repository.load(
                    transaction,
                    tenant_id=tenant_id,
                    project_id=project_id,
                    workflow_run_id=workflow_run_id,
                )
                self._validate_plan(
                    plan,
                    project_id=project_id,
                    workflow_run_id=workflow_run_id,
                    expected_project_revision=expected_project_revision,
                )
                context = await self._context_repository.load(
                    transaction,
                    tenant_id=tenant_id,
                    plan=plan,
                )

            snapshot, physical_scope = context.snapshot, context.physical_scope
            if snapshot is None or physical_scope is None:
                raise InvalidRequestError("The Validation graph context is unavailable.")
            system_count = len(context.systems)
            progress = AgentWorkflowProgress(
                lifecycle=self._lifecycle,
                principal=principal,
                workflow_run_id=workflow_run_id,
                expected_project_revision=expected_project_revision,
                workflow_run_claim_token=workflow_run_claim_token,
            )
            await progress.append(
                attempt=1,
                stage="validation.validation_generation",
                status="running",
                message=f"Validation generation started for {system_count} Systems.",
                current=0,
                total=system_count,
                finding_count=0,
            )

            stage_plan = plan.model_copy(
                update={"workflow_execution_mode": VALIDATION_AGENT_EXECUTION_MODE}
            )
            candidates: list[ValidatedValidationSystemCandidate] = []
            progress_points = intermediate_progress_points(system_count) | {system_count}
            highest_attempt = 1
            warning_seen = False
            for position, system in enumerate(context.systems, start=1):
                validator = ValidationSystemCandidateValidator(context=system)
                prompt_values = project_downstream_inputs(
                    "validation", cast(dict[str, Any], system.agent_context)
                )
                prompt_context = cast(
                    JsonValue,
                    {
                        "__gds_downstream_inputs__": "validation",
                        "values": prompt_values,
                    },
                )
                context_budget = self._context_policy.stage_max_context_bytes
                result_budget = None if context_budget is None else max(1, context_budget // 2)
                readers = build_downstream_readers(
                    "validation",
                    prompt_values,
                    max_result_bytes=None
                    if result_budget is None
                    else max(1, result_budget // stage_plan.selection.max_turns),
                    max_page_records=200,
                    max_cumulative_result_bytes=result_budget,
                )

                async def validate_complete_candidate(
                    value: JsonValue,
                    validator: ValidationSystemCandidateValidator = validator,
                    position: int = position,
                ) -> AgentCandidateValidation:
                    nonlocal rejected_changes, rejected_issues
                    try:
                        candidate_changes = reconcile_validation_candidates(
                            context=context.model_copy(
                                update={"systems": context.systems[:position]}
                            ),
                            candidates=(*candidates, validator.parse_validated(value)),
                        )
                        validate_project_stage_changes(list(candidate_changes))
                    except InvalidRequestError, ValidationError:
                        return AgentCandidateValidation(
                            issues=(
                                AgentValidationIssue(
                                    code="candidate.change_set_bounds",
                                    path=(),
                                    message=(
                                        "Combined Validation exceeds Project Change Set limits. "
                                        "Reduce redundant checks while preserving System coverage."
                                    ),
                                ),
                            )
                        )
                    checked = validate_future_graph(
                        snapshot=snapshot,
                        physical_scope=physical_scope,
                        staged_documents={c.dataset: c.records for c in candidate_changes},
                    )
                    if checked.issues and position == system_count:
                        rejected_changes, rejected_issues = candidate_changes, checked.issues
                    return AgentCandidateValidation(
                        issues=project_validation_issues(checked.issues)
                    )

                outcome = await self._stage_runner.run(
                    plan=stage_plan,
                    stage_code="validation_generation",
                    resolver_values={
                        "workflow.validation.common.validation_context": (
                            _system_context_manifest(system.system_ref, system.agent_context)
                        ),
                        "workflow.validation_failures": [],
                    },
                    context=prompt_context,
                    output_schema=validator.output_schema(),
                    allowed_tool_names=readers.allowed_tool_names,
                    local_tool_catalog=readers,
                    validator=validator,
                    final_validation=validate_complete_candidate,
                )
                candidates.append(validator.parse_validated(outcome.candidate))
                highest_attempt = max(highest_attempt, outcome.attempt_count)
                warning_seen = warning_seen or bool(outcome.was_repaired or outcome.warning_codes)
                if position in progress_points:
                    message = (
                        f"Validation generation validated {position} of {system_count} Systems."
                    )
                    if warning_seen:
                        message += " One or more candidates required repair."
                    await progress.append(
                        attempt=highest_attempt,
                        stage="validation.validation_generation",
                        status="warning" if warning_seen else "running",
                        message=message,
                        current=position,
                        total=system_count,
                        finding_count=0,
                    )

            changes = reconcile_validation_candidates(
                context=context,
                candidates=tuple(candidates),
            )
            if not changes:
                finalization_attempted = True
                return await self._no_op.complete(
                    principal,
                    tenant_id=tenant_id,
                    project_id=project_id,
                    workflow_run_id=workflow_run_id,
                    workflow_run_claim_token=workflow_run_claim_token,
                    request=AuthoringNoOpRequest(
                        expected_workflow="validation",
                        expected_execution_mode=None,
                        expected_correlation_id=plan.correlation_id,
                        expected_project_revision=expected_project_revision,
                        candidate_digest=authoring_no_op_candidate_digest(plan),
                        final_event=progress.event(
                            attempt=highest_attempt,
                            stage="validation.backend_validation",
                            status="warning" if warning_seen else "running",
                            message="Validation authoring completed with no effective change.",
                            current=1,
                            total=1,
                            finding_count=0,
                        ),
                    ),
                )

            staged_record_count = sum(len(change.records) for change in changes)
            finalization_attempted = True
            finalized = await self._handoff.finalize(
                principal,
                tenant_id=tenant_id,
                project_id=project_id,
                workflow_run_id=workflow_run_id,
                expected_workflow="validation",
                expected_project_revision=expected_project_revision,
                workflow_run_claim_token=workflow_run_claim_token,
                changes=changes,
                final_event=progress.event(
                    attempt=highest_attempt,
                    stage="validation.backend_validation",
                    status="warning" if warning_seen else "running",
                    message="Validation candidate is ready in a validated draft.",
                    current=1,
                    total=1,
                    finding_count=staged_record_count,
                ),
            )
            return finalized.handoff
        except Exception as error:
            retention_issues = (
                error.issues if isinstance(error, WorkflowChangeSetValidationError) else ()
            )
            if isinstance(error, AgentCandidateValidationError) and rejected_changes:
                changes, retention_issues = rejected_changes, rejected_issues
            if retention_issues and changes and isinstance(error, AtlasError):
                try:
                    await self._handoff.retain_failed_candidate(
                        principal,
                        tenant_id=tenant_id,
                        project_id=project_id,
                        workflow_run_id=workflow_run_id,
                        expected_workflow="validation",
                        expected_project_revision=expected_project_revision,
                        workflow_run_claim_token=workflow_run_claim_token,
                        changes=changes,
                        issues=retention_issues,
                        failure_code=error.code,
                        safe_failure_message=(
                            "Validation failed. A rejected draft was retained for review."
                        ),
                    )
                except Exception as retention_error:
                    _logger.warning(
                        "Rejected Workflow draft retention remains pending.",
                        extra={"workflow_run_id": workflow_run_id, "project_id": project_id},
                    )
                    raise _safe_execution_error(
                        retention_error,
                        finalization_attempted=True,
                    ) from None
                raise error from None
            safe_error = _safe_execution_error(
                error,
                finalization_attempted=finalization_attempted,
            )
            if finalization_attempted:
                _logger.warning(
                    "Validation Workflow Run finalization remains pending.",
                    extra={
                        "workflow_run_id": workflow_run_id,
                        "project_id": project_id,
                        "failure_code": safe_error.code[:100],
                    },
                )
                raise safe_error from None
            try:
                await self._lifecycle.fail(
                    principal,
                    workflow_run_id=workflow_run_id,
                    expected_project_revision=expected_project_revision,
                    workflow_run_claim_token=workflow_run_claim_token,
                    failure_code=safe_error.code[:100],
                    safe_failure_message=safe_error.message[:2000],
                )
            except Exception as persistence_error:
                _logger.warning(
                    "Validation failure state could not be persisted.",
                    extra={
                        "workflow_run_id": workflow_run_id,
                        "project_id": project_id,
                        "failure_code": safe_error.code[:100],
                    },
                )
                raise _safe_execution_error(
                    persistence_error,
                    finalization_attempted=False,
                ) from None
            raise safe_error from None

    @staticmethod
    def _validate_plan(
        plan: AgentRunPlan,
        *,
        project_id: int,
        workflow_run_id: int,
        expected_project_revision: int,
    ) -> None:
        if (
            plan.project_id != project_id
            or plan.workflow_run_id != workflow_run_id
            or plan.project_revision != expected_project_revision
            or plan.project_workflow != "validation"
            or plan.workflow_execution_mode is not None
            or plan.selected_object_ids
            or plan.selected_entity_ids
            or not plan.selected_system_codes
            or len(plan.stages) != 1
            or plan.stages[0].stage_code != "validation_generation"
        ):
            raise InvalidRequestError("The Validation run does not use the fixed execution path.")


def _system_context_manifest(system_ref: str, context: JsonValue) -> JsonValue:
    encoded = json.dumps(
        context,
        ensure_ascii=False,
        allow_nan=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")
    return cast(
        JsonValue,
        {
            "system_ref": system_ref,
            "system_context_delivery": "workflow_variables_and_optional_readers",
            "system_context_sha256": sha256(encoded).hexdigest(),
            "system_context_byte_count": len(encoded),
        },
    )


def _safe_execution_error(
    error: Exception,
    *,
    finalization_attempted: bool,
) -> AtlasError:
    if isinstance(error, AtlasError):
        return error
    if finalization_attempted:
        return ValidationFinalizationFailedError()
    return ValidationExecutionFailedError()
