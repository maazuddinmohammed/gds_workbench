"""Validate and reconcile complete per-System Validation candidates."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Annotated, Literal, cast

import sqlglot
from atlas_mcp.application.change_sets.project import StageProjectChange
from atlas_mcp.domain.databricks_sql import validate_databricks_sql
from atlas_mcp.domain.errors import InvalidRequestError
from atlas_mcp.domain.modeling_records import (
    ValidationCheckRecord,
    ValidationGroupRecord,
    normalize_project_key_value,
)
from pydantic import BaseModel, ConfigDict, Field, JsonValue, ValidationError
from sqlglot import expressions as exp

from atlas_platform.features.workflows.authoring.repair import (
    AgentCandidateValidation,
    AgentValidationIssue,
    pydantic_validation_issues,
)

from .context import ValidationExecutionContext, ValidationSystemAuthoringContext

_MAX_GROUPS_PER_SYSTEM = 500
_MAX_CHECKS_PER_GROUP = 1_000
_MAX_CHECKS_PER_SYSTEM = 10_000
_MAX_CANDIDATE_BYTES = 16 * 1024 * 1024

type ValidationLiteral = bool | int | float | str
type ValidationLiteralList = Annotated[
    list[ValidationLiteral],
    Field(min_length=1, max_length=10_000),
]


class _AgentValidationCheck(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    validation_check_name: str = Field(
        min_length=1,
        max_length=200,
        pattern=r"\S",
        description="Stable name unique within the owning Validation Group.",
    )
    validation_check_description: str | None = Field(
        default=None,
        min_length=1,
        description="Optional intent and failure meaning; use null when unnecessary.",
    )
    validation_category_code: str = Field(
        pattern=r"^[a-z][a-z0-9_.-]{0,99}$",
        description=(
            "Stable lower-case category such as technical.execution or business.reconciliation."
        ),
    )
    validation_severity: Literal["blocking", "warning", "informational"] = Field(
        description="Operational importance when this assertion fails."
    )
    validation_query_sql: str = Field(
        min_length=1,
        description=(
            "Query A using governed Databricks SQL. Every physical relation must be fully "
            "qualified as catalog.schema.table; only an unqualified temporary view or table "
            "declared earlier in this same SQL batch may be referenced unqualified. Except "
            "for executes_successfully, its final result must be exactly one row and one "
            "column at runtime; any other cardinality is a query-contract execution error, "
            "not an assertion failure."
        ),
    )
    validation_comparison_query_sql: str | None = Field(
        default=None,
        min_length=1,
        description=(
            "Query B, populated only when comparison_value_type is query. Every physical "
            "relation must be fully qualified as catalog.schema.table; only an unqualified "
            "temporary object declared earlier in this same SQL batch may be referenced "
            "unqualified. Its final result must be exactly one row and one column at runtime."
        ),
    )
    validation_result_data_type: (
        Literal["boolean", "integer", "decimal", "text", "date", "timestamp"] | None
    ) = Field(
        description=(
            "Type of the single Query A cell and query-valued Query B cell; null only for "
            "executes_successfully, whose result shape is ignored."
        )
    )
    validation_comparison_operator: Literal[
        "executes_successfully",
        "is_null",
        "is_not_null",
        "is_true",
        "is_false",
        "equal",
        "not_equal",
        "greater_than",
        "greater_than_or_equal",
        "less_than",
        "less_than_or_equal",
        "in",
        "not_in",
    ] = Field(
        description=(
            "Assertion over Query A. executes_successfully uses result type null/value type "
            "none; is_null/is_not_null use a declared result type and none; is_true/is_false "
            "use boolean and none; equal/not_equal use literal or query; ordered comparisons "
            "use integer, decimal, date, or timestamp with literal or query; in/not_in use "
            "literal_list."
        )
    )
    validation_comparison_value_type: Literal[
        "none",
        "literal",
        "literal_list",
        "query",
    ] = Field(
        description=(
            "Comparison operand source. query requires Query B and a null comparison value; "
            "literal/literal_list require a value and no Query B; none requires both absent."
        )
    )
    validation_comparison_value: ValidationLiteral | ValidationLiteralList | None = Field(
        description=(
            "Typed literal operand, or a non-empty homogeneous list for in/not_in. Values "
            "must match validation_result_data_type; otherwise use null."
        )
    )


class _RetainedValidationCheck(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    keep_existing_check: str = Field(
        min_length=1,
        max_length=200,
        pattern=r"\S",
        description="Keep the named active Check unchanged in this existing active Group.",
    )


class _AgentValidationGroup(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    validation_group_name: str = Field(
        min_length=1,
        max_length=200,
        pattern=r"\S",
        description="Stable name unique within this System and shared by its Checks.",
    )
    validation_group_description: str | None = Field(
        default=None,
        min_length=1,
        description="Optional purpose and Validation coverage; use null when unnecessary.",
    )
    validation_checks: list[_AgentValidationCheck | _RetainedValidationCheck] = Field(
        min_length=1,
        max_length=_MAX_CHECKS_PER_GROUP,
        description="Complete desired active Check list for this Group.",
    )


class _AgentValidationSystemCandidate(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    system_ref: str = Field(
        pattern=r"^system_[1-9][0-9]*$",
        description="Copy the exact opaque System reference supplied in frozen context.",
    )
    validation_groups: list[_AgentValidationGroup] = Field(
        min_length=1,
        max_length=_MAX_GROUPS_PER_SYSTEM,
        description=(
            "Complete desired active Validation Group ledger for this System; omission retires "
            "a previously applied Group or Check."
        ),
    )


@dataclass(frozen=True, slots=True)
class ValidatedValidationSystemCandidate:
    system_ref: str
    groups: tuple[ValidationGroupRecord, ...]
    checks: tuple[ValidationCheckRecord, ...]


class ValidationSystemCandidateValidator:
    def __init__(self, *, context: ValidationSystemAuthoringContext) -> None:
        self._context = context
        self._active_group_keys = {
            _group_key(row) for row in context.applied_groups if row.is_active
        }
        self._active_checks = {
            _check_key(row): row for row in context.applied_checks if row.is_active
        }

    def output_schema(self) -> dict[str, JsonValue]:
        return cast(dict[str, JsonValue], _AgentValidationSystemCandidate.model_json_schema())

    async def validate(self, candidate: JsonValue) -> AgentCandidateValidation:
        try:
            self.parse_validated(candidate)
        except _CandidateIssueError as error:
            return AgentCandidateValidation(issues=(error.issue,))
        except ValidationError as error:
            return AgentCandidateValidation(issues=pydantic_validation_issues(error))
        except InvalidRequestError, TypeError, ValueError:
            return AgentCandidateValidation(
                issues=(
                    AgentValidationIssue(
                        code="candidate.schema_invalid",
                        path=(),
                        message="The candidate does not match the required Validation schema.",
                    ),
                )
            )
        return AgentCandidateValidation(issues=())

    def parse_validated(self, candidate: JsonValue) -> ValidatedValidationSystemCandidate:
        try:
            encoded = json.dumps(
                candidate,
                ensure_ascii=False,
                allow_nan=False,
                separators=(",", ":"),
            ).encode("utf-8")
        except TypeError, ValueError:
            raise InvalidRequestError("The Validation candidate is invalid.") from None
        if len(encoded) > _MAX_CANDIDATE_BYTES:
            raise _CandidateIssueError(
                AgentValidationIssue(
                    code="candidate.too_large",
                    path=(),
                    message="The Validation candidate exceeds its bounded size.",
                )
            )
        parsed = _AgentValidationSystemCandidate.model_validate(candidate, strict=True)
        if parsed.system_ref != self._context.system_ref:
            raise _CandidateIssueError(
                AgentValidationIssue(
                    code="candidate.system_coverage",
                    path=("system_ref",),
                    message="The candidate must use the exact frozen System reference.",
                )
            )
        group_names: set[str] = set()
        check_count = sum(len(group.validation_checks) for group in parsed.validation_groups)
        if check_count > _MAX_CHECKS_PER_SYSTEM:
            raise _CandidateIssueError(
                AgentValidationIssue(
                    code="candidate.validation_check_limit",
                    path=("validation_groups",),
                    message="The Validation candidate contains too many Validation Checks.",
                )
            )

        groups: list[ValidationGroupRecord] = []
        checks: list[ValidationCheckRecord] = []
        for group_index, group in enumerate(parsed.validation_groups):
            group_name = group.validation_group_name
            if self._context.modeled_entity_type is not None:
                prefix = (
                    "Logical · "
                    if self._context.modeled_entity_type == "logical_entity"
                    else "Dimensional · "
                )
                if not group_name.startswith(prefix):
                    group_name = prefix + group_name
            normalized_name = normalize_project_key_value(group_name)
            if normalized_name in group_names:
                raise _CandidateIssueError(
                    AgentValidationIssue(
                        code="candidate.validation_group_duplicate",
                        path=("validation_groups", group_index),
                        message="Validation Group names must be unique for the System.",
                    )
                )
            group_names.add(normalized_name)
            if normalize_project_key_value(group_name) in {
                normalize_project_key_value(name) for name in self._context.reserved_group_names
            }:
                raise _CandidateIssueError(
                    AgentValidationIssue(
                        code="candidate.validation_group_scope",
                        path=("validation_groups", group_index),
                        message=(
                            "This Group belongs to a different layer or a shared Validation. "
                            "Choose a distinct name."
                        ),
                    )
                )
            check_names = [
                normalize_project_key_value(
                    check.keep_existing_check
                    if isinstance(check, _RetainedValidationCheck)
                    else check.validation_check_name
                )
                for check in group.validation_checks
            ]
            if len(check_names) != len(set(check_names)):
                raise _CandidateIssueError(
                    AgentValidationIssue(
                        code="candidate.validation_check_duplicate",
                        path=("validation_groups", group_index, "validation_checks"),
                        message="Validation Check names must be unique within their Group.",
                    )
                )
            contract_path: tuple[str | int, ...] = ("validation_groups", group_index)
            try:
                desired_group = ValidationGroupRecord(
                    is_locked=False,
                    tenant_code=self._context.tenant_code,
                    system_code=self._context.system_code,
                    validation_group_name=group_name,
                    validation_group_description=group.validation_group_description,
                    is_active=True,
                )
                groups.append(desired_group)
                parent_key = _group_key(desired_group)
                for check_index, entry in enumerate(group.validation_checks):
                    contract_path = (
                        "validation_groups",
                        group_index,
                        "validation_checks",
                        check_index,
                    )
                    if isinstance(entry, _RetainedValidationCheck):
                        key = (*parent_key, check_names[check_index])
                        check = self._active_checks.get(key)
                        if check is None or parent_key not in self._active_group_keys:
                            raise _CandidateIssueError(
                                AgentValidationIssue(
                                    code="candidate.validation_check_reference",
                                    path=(*contract_path, "keep_existing_check"),
                                    message=(
                                        "Only an active Check in this existing active Group "
                                        "can be retained."
                                    ),
                                )
                            )
                    else:
                        check = entry
                    _validate_query(
                        check.validation_query_sql,
                        must_return_rows=(
                            check.validation_comparison_operator != "executes_successfully"
                        ),
                        path=(*contract_path, "validation_query_sql"),
                    )
                    if check.validation_comparison_query_sql is not None:
                        _validate_query(
                            check.validation_comparison_query_sql,
                            must_return_rows=True,
                            path=(*contract_path, "validation_comparison_query_sql"),
                        )
                    _validate_check_quality(check, path=contract_path)
                    if isinstance(check, ValidationCheckRecord):
                        checks.append(check)
                        continue
                    comparison_value = check.validation_comparison_value
                    checks.append(
                        ValidationCheckRecord(
                            is_locked=False,
                            tenant_code=self._context.tenant_code,
                            system_code=self._context.system_code,
                            validation_group_name=group_name,
                            validation_check_name=check.validation_check_name,
                            validation_check_description=(check.validation_check_description),
                            validation_category_code=check.validation_category_code,
                            validation_severity=check.validation_severity,
                            validation_query_sql=check.validation_query_sql,
                            validation_comparison_query_sql=(check.validation_comparison_query_sql),
                            validation_result_data_type=(check.validation_result_data_type),
                            validation_comparison_operator=(check.validation_comparison_operator),
                            validation_comparison_value_type=(
                                check.validation_comparison_value_type
                            ),
                            validation_comparison_value=(
                                tuple(comparison_value)
                                if isinstance(comparison_value, list)
                                else comparison_value
                            ),
                            is_active=True,
                        )
                    )
            except _CandidateIssueError:
                raise
            except ValidationError as error:
                diagnostic = pydantic_validation_issues(
                    error,
                    path_prefix=contract_path,
                    maximum_issues=1,
                )[0]
                raise _CandidateIssueError(
                    AgentValidationIssue(
                        code="candidate.validation_contract_invalid",
                        path=diagnostic.path,
                        message=diagnostic.message,
                    )
                ) from None
            except TypeError, ValueError:
                raise _CandidateIssueError(
                    AgentValidationIssue(
                        code="candidate.validation_contract_invalid",
                        path=("validation_groups", group_index),
                        message=(
                            "The Validation Group or one of its Checks has an invalid "
                            "assertion contract."
                        ),
                    )
                ) from None
        return ValidatedValidationSystemCandidate(
            system_ref=parsed.system_ref,
            groups=tuple(groups),
            checks=tuple(checks),
        )


def reconcile_validation_candidates(
    *,
    context: ValidationExecutionContext,
    candidates: tuple[ValidatedValidationSystemCandidate, ...],
) -> tuple[StageProjectChange, ...]:
    systems_by_ref = {system.system_ref: system for system in context.systems}
    candidates_by_ref = {candidate.system_ref: candidate for candidate in candidates}
    if (
        len(systems_by_ref) != len(context.systems)
        or len(candidates_by_ref) != len(candidates)
        or set(candidates_by_ref) != set(systems_by_ref)
    ):
        raise InvalidRequestError("The Validation candidate and frozen System coverage differ.")

    changed_groups: list[ValidationGroupRecord] = []
    changed_checks: list[ValidationCheckRecord] = []
    for system_ref, system in systems_by_ref.items():
        candidate = candidates_by_ref[system_ref]
        applied_groups = {_group_key(group): group for group in system.applied_groups}
        applied_checks = {_check_key(check): check for check in system.applied_checks}
        desired_groups = {_group_key(group): group for group in candidate.groups}
        desired_checks = {_check_key(check): check for check in candidate.checks}
        locked_groups = {key for key, group in applied_groups.items() if group.is_locked}
        parents_of_locked_checks = {
            key[:3] for key, check in applied_checks.items() if check.is_locked and check.is_active
        }
        if (
            len(applied_groups) != len(system.applied_groups)
            or len(applied_checks) != len(system.applied_checks)
            or len(desired_groups) != len(candidate.groups)
            or len(desired_checks) != len(candidate.checks)
        ):
            raise InvalidRequestError("The Validation candidate context is ambiguous.")

        for key, desired in desired_groups.items():
            if key in applied_groups and applied_groups[key].is_locked:
                continue
            if desired != applied_groups.get(key) or key not in {
                (
                    normalize_project_key_value(system.tenant_code),
                    normalize_project_key_value(system.system_code),
                    normalize_project_key_value(name),
                )
                for name in system.current_group_names
            }:
                changed_groups.append(desired)
        for key, applied in applied_groups.items():
            if (
                key not in desired_groups
                and applied.is_active
                and not applied.is_locked
                and key not in parents_of_locked_checks
            ):
                changed_groups.append(applied.model_copy(update={"is_active": False}))

        for key, desired in desired_checks.items():
            if key[:3] in locked_groups or (
                key in applied_checks and applied_checks[key].is_locked
            ):
                continue
            if desired != applied_checks.get(key):
                changed_checks.append(desired)
        for key, applied in applied_checks.items():
            if (
                key not in desired_checks
                and applied.is_active
                and not applied.is_locked
                and key[:3] not in locked_groups
            ):
                changed_checks.append(applied.model_copy(update={"is_active": False}))

    changes: list[StageProjectChange] = []
    if changed_groups:
        changed_groups.sort(key=_group_key)
        changes.append(
            StageProjectChange(
                dataset="validation_group",
                records=[record.model_dump(mode="json") for record in changed_groups],
            )
        )
    if changed_checks:
        changed_checks.sort(key=_check_key)
        changes.append(
            StageProjectChange(
                dataset="validation_check",
                records=[record.model_dump(mode="json") for record in changed_checks],
            )
        )
    return tuple(changes)


class _CandidateIssueError(Exception):
    def __init__(self, issue: AgentValidationIssue) -> None:
        super().__init__(issue.code)
        self.issue = issue


def _validate_check_quality(
    check: _AgentValidationCheck | ValidationCheckRecord, *, path: tuple[str | int, ...]
) -> None:
    """Reject provably uninformative patterns; business coverage still needs review."""
    statements = [
        item
        for item in sqlglot.parse(check.validation_query_sql, read="databricks")
        if item is not None
    ]
    final = statements[-1]
    projection = (
        final.expressions[0].unalias()
        if isinstance(final, exp.Select) and len(final.expressions) == 1
        else None
    )
    constant_result = isinstance(projection, (exp.Literal, exp.Boolean, exp.Null)) and not any(
        final.find_all(exp.Table)
    )
    count_nonnegative = (
        isinstance(projection, exp.Count)
        and check.validation_comparison_operator == "greater_than_or_equal"
        and check.validation_comparison_value_type == "literal"
        and check.validation_comparison_value == 0
    )
    same_query = False
    if check.validation_comparison_query_sql:
        comparison = [
            item
            for item in sqlglot.parse(check.validation_comparison_query_sql, read="databricks")
            if item is not None
        ]
        same_query = [item.sql(normalize=True, comments=False) for item in statements] == [
            item.sql(normalize=True, comments=False) for item in comparison
        ]
    if constant_result or count_nonnegative or same_query:
        raise _CandidateIssueError(
            AgentValidationIssue(
                code="candidate.validation_check_tautological",
                path=path,
                message=(
                    "This Check cannot detect a meaningful data failure. Replace constant results, "
                    "COUNT >= 0, or identical Query A/B with an evidence-based assertion and "
                    "an independent expected result; otherwise omit the redundant Check."
                ),
            )
        )


def _validate_query(
    sql: str,
    *,
    must_return_rows: bool,
    path: tuple[str | int, ...],
) -> None:
    """Validate static SQL safety; deterministic orchestration enforces runtime cardinality."""
    try:
        validated = validate_databricks_sql(sql)
    except InvalidRequestError:
        raise _CandidateIssueError(
            AgentValidationIssue(
                code="candidate.validation_query_invalid",
                path=path,
                message=(
                    "Validation SQL must use governed read-only Databricks SQL, qualify every "
                    "physical relation as catalog.schema.table, and use only an unqualified "
                    "temporary object declared earlier in the same SQL batch."
                ),
            )
        ) from None
    if must_return_rows and not validated.final_returns_rows:
        raise _CandidateIssueError(
            AgentValidationIssue(
                code="candidate.validation_query_result_invalid",
                path=path,
                message="This Validation SQL must end with a row-returning statement.",
            )
        )


def _group_key(record: ValidationGroupRecord) -> tuple[str, str, str]:
    return (
        normalize_project_key_value(record.tenant_code),
        normalize_project_key_value(record.system_code),
        normalize_project_key_value(record.validation_group_name),
    )


def _check_key(record: ValidationCheckRecord) -> tuple[str, str, str, str]:
    return (
        normalize_project_key_value(record.tenant_code),
        normalize_project_key_value(record.system_code),
        normalize_project_key_value(record.validation_group_name),
        normalize_project_key_value(record.validation_check_name),
    )
