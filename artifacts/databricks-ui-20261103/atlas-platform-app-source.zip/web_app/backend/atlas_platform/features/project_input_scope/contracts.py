"""Active Project Input Scope read contracts."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from atlas_mcp.domain.errors import AtlasError
from atlas_mcp.domain.snapshots.metadata import (
    normalize_natural_key_value,
)
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    ValidationInfo,
    field_validator,
    model_validator,
)

from atlas_platform.features.metadata.contracts import ObjectAttribute

type ZoneCode = Literal["source", "bronze"]


class ScopeLocation(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    tenant_id: int
    tenant_code: str
    tenant_name: str
    system_code: str
    system_name: str
    zone_code: ZoneCode


class ScopeSearchOptions(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    project_revision: int
    locations: tuple[ScopeLocation, ...]


class ProjectInputScopeObject(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    project_input_scope_id: int = Field(gt=0)
    object_id: int = Field(gt=0)
    connection_id: int = Field(gt=0)
    system_id: int = Field(gt=0)
    system_code: str = Field(min_length=1, max_length=100)
    system_name: str = Field(min_length=1, max_length=200)
    source_tenant_id: int = Field(gt=0)
    source_tenant_code: str = Field(min_length=1, max_length=100)
    source_tenant_name: str = Field(min_length=1, max_length=200)
    object_schema: str = Field(min_length=1, max_length=400)
    object_name: str = Field(min_length=1, max_length=400)
    zone_code: ZoneCode
    object_description: str | None = Field(default=None, max_length=2000, repr=False)
    description_truncated: bool = False
    is_locked: bool = False
    review_revision: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    batch_attribute_name: str | None = Field(default=None, max_length=400)
    attribute_count: int = Field(ge=0)
    is_project_input_eligible: bool
    created_at: datetime
    updated_at: datetime


class ProjectInputScopePage(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    project_id: int = Field(gt=0)
    project_revision: int = Field(gt=0)
    items: tuple[ProjectInputScopeObject, ...] = Field(max_length=200)
    next_cursor: str | None = Field(default=None, max_length=2048)


class ProjectInputScopeCandidate(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    object_id: int = Field(gt=0)
    connection_id: int = Field(gt=0)
    system_id: int = Field(gt=0)
    system_code: str = Field(min_length=1, max_length=100)
    system_name: str = Field(min_length=1, max_length=200)
    source_tenant_id: int = Field(gt=0)
    source_tenant_code: str = Field(min_length=1, max_length=100)
    source_tenant_name: str = Field(min_length=1, max_length=200)
    object_schema: str = Field(min_length=1, max_length=400)
    object_name: str = Field(min_length=1, max_length=400)
    zone_code: ZoneCode
    batch_attribute_name: str | None = Field(default=None, max_length=400)
    attribute_count: int = Field(ge=0)
    is_in_active_scope: bool


class ProjectInputScopeCandidatePage(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    project_id: int = Field(gt=0)
    project_revision: int = Field(gt=0)
    items: tuple[ProjectInputScopeCandidate, ...] = Field(max_length=200)
    next_cursor: str | None = Field(default=None, max_length=2048)


class ProjectAttributeEnrichment(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)
    is_natural_key: bool | None = None
    is_primary_key: bool | None = None
    is_nullable: bool | None = None
    is_pii: bool | None = None


class ProjectInputScopeAttribute(ObjectAttribute):
    review_revision: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")
    enrichment: ProjectAttributeEnrichment | None = None
    profile: dict[str, object] | None = Field(default=None, repr=False)


class ProjectInputScopeDetail(ProjectInputScopeObject):
    attributes: tuple[ProjectInputScopeAttribute | ObjectAttribute, ...]
    total_attribute_count: int = Field(ge=0)

    @model_validator(mode="after")
    def validate_attribute_count(self) -> ProjectInputScopeDetail:
        if self.attribute_count != len(self.attributes):
            raise ValueError("attribute_count must match the returned Attributes")
        if self.total_attribute_count < self.attribute_count:
            raise ValueError("total_attribute_count must include every active Attribute")
        return self


class ProjectInputScopeObjectNotFoundError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="project_input_scope_object_not_found",
            message="The requested active Project Input Scope Object was not found.",
        )


class ProjectInputScopeQuery(BaseModel):
    model_config = ConfigDict(extra="forbid")

    zone: ZoneCode | None = None
    system_code: str | None = Field(default=None, max_length=100)
    source_tenant_code: str | None = Field(default=None, max_length=100)
    object_name: str | None = Field(default=None, max_length=400)
    page_size: int = Field(default=50, ge=1, le=200)
    cursor: str | None = Field(default=None, max_length=2048)

    @field_validator(
        "zone",
        "system_code",
        "source_tenant_code",
        "object_name",
        mode="before",
    )
    @classmethod
    def normalize_filter(cls, value: object, info: ValidationInfo) -> object:
        if not isinstance(value, str):
            return value
        if not isinstance(info.field_name, str):
            raise ValueError("filter field is invalid")
        field = "zone_code" if info.field_name == "zone" else info.field_name
        normalized = normalize_natural_key_value(field, value)
        if not isinstance(normalized, str) or not normalized:
            raise ValueError(f"{info.field_name} must be nonblank")
        return normalized
