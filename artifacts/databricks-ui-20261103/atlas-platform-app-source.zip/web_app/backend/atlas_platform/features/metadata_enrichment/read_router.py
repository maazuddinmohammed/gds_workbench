"""Read physical enrichment outcomes through the existing Run identity route."""

from typing import Annotated

from atlas_mcp.application.identity import IdentityProvider
from atlas_mcp.domain.authorization import RequestPrincipal
from fastapi import APIRouter, Depends, Path, Query

from atlas_platform.dependencies import principal_dependency

from .read_contracts import MetadataEnrichmentResultPage
from .read_service import MetadataEnrichmentReadService


def create_metadata_enrichment_read_router(
    *, identity_provider: IdentityProvider, service: MetadataEnrichmentReadService
) -> APIRouter:
    authenticate = principal_dependency(identity_provider)
    router = APIRouter(
        prefix="/api/v1/tenants/{tenant_id}/projects/{project_id}/runs",
        tags=["metadata-enrichment"],
    )

    async def read_results(
        tenant_id: Annotated[int, Path(gt=0)],
        project_id: Annotated[int, Path(gt=0)],
        workflow_run_id: Annotated[int, Path(gt=0)],
        limit: Annotated[int, Query(ge=1, le=200)] = 100,
        offset: Annotated[int, Query(ge=0, le=30200)] = 0,
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> MetadataEnrichmentResultPage:
        return await service.read_results(
            principal,
            tenant_id=tenant_id,
            project_id=project_id,
            workflow_run_id=workflow_run_id,
            limit=limit,
            offset=offset,
        )

    router.add_api_route(
        "/{workflow_run_id}/metadata-enrichment",
        read_results,
        methods=["GET"],
        response_model=MetadataEnrichmentResultPage,
    )
    return router
