"""Explicit deterministic Analysis validation Workflow Run route."""

from typing import Annotated, Protocol

from atlas_mcp.application.identity import IdentityProvider
from atlas_mcp.domain.authorization import RequestPrincipal
from fastapi import APIRouter, Depends, Path, Response, status
from pydantic import BaseModel, ConfigDict, Field

from atlas_platform.dependencies import principal_dependency
from atlas_platform.features.workflows.authoring.lifecycle import (
    AgentWorkflowRunStart,
)


class ExecuteAnalysisValidationRunRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    expected_project_revision: int = Field(gt=0)


class AnalysisValidationWorkflowService(Protocol):
    async def start(
        self,
        principal: RequestPrincipal,
        *,
        tenant_id: int,
        project_id: int,
        workflow_run_id: int,
        expected_project_revision: int,
    ) -> AgentWorkflowRunStart: ...


def create_analysis_validation_workflow_router(
    *,
    identity_provider: IdentityProvider,
    service: AnalysisValidationWorkflowService,
) -> APIRouter:
    authenticate = principal_dependency(identity_provider)
    router = APIRouter(
        prefix=("/api/v1/tenants/{tenant_id}/projects/{project_id}/analysis/validation-runs"),
        tags=["analysis"],
    )

    async def execute_run(
        response: Response,
        tenant_id: Annotated[int, Path(gt=0)],
        project_id: Annotated[int, Path(gt=0)],
        workflow_run_id: Annotated[int, Path(gt=0)],
        command: ExecuteAnalysisValidationRunRequest,
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> AgentWorkflowRunStart:
        result = await service.start(
            principal,
            tenant_id=tenant_id,
            project_id=project_id,
            workflow_run_id=workflow_run_id,
            expected_project_revision=command.expected_project_revision,
        )
        if result.changed and result.workflow_run_state == "running":
            response.status_code = status.HTTP_202_ACCEPTED
        else:
            response.status_code = status.HTTP_200_OK
        return result

    router.add_api_route(
        "/{workflow_run_id}/execute",
        execute_run,
        methods=["POST"],
        response_model=AgentWorkflowRunStart,
        status_code=status.HTTP_202_ACCEPTED,
    )
    return router


__all__ = [
    "AnalysisValidationWorkflowService",
    "ExecuteAnalysisValidationRunRequest",
    "create_analysis_validation_workflow_router",
]
