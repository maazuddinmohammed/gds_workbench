"""HTTP router for Analysis finding review."""

from typing import Annotated

from atlas_mcp.application.identity import IdentityProvider
from atlas_mcp.domain.authorization import RequestPrincipal
from fastapi import APIRouter, Depends, Path, Query, Response
from pydantic import BaseModel, ConfigDict, Field

from atlas_platform.dependencies import principal_dependency
from atlas_platform.features.analysis.read_contracts import (
    AnalysisFindingDetail,
    AnalysisFindingFilters,
    AnalysisFindingPage,
)
from atlas_platform.features.analysis.read_service import AnalysisReviewService
from atlas_platform.features.metadata.workbook import XLSX_MEDIA_TYPE


class AnalysisExportRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)
    expected_project_revision: int = Field(gt=0)
    filters: AnalysisFindingFilters = Field(default_factory=AnalysisFindingFilters)


def create_analysis_review_router(
    *,
    identity_provider: IdentityProvider,
    service: AnalysisReviewService,
) -> APIRouter:
    authenticate = principal_dependency(identity_provider)
    router = APIRouter(
        prefix="/api/v1/tenants/{tenant_id}/projects/{project_id}",
        tags=["analysis"],
    )

    async def list_analysis_findings(
        tenant_id: Annotated[int, Path(gt=0)],
        project_id: Annotated[int, Path(gt=0)],
        object_id: Annotated[int | None, Query(gt=0)] = None,
        from_object_id: Annotated[int | None, Query(gt=0)] = None,
        to_object_id: Annotated[int | None, Query(gt=0)] = None,
        validation_state: Annotated[str | None, Query(max_length=20)] = None,
        status: Annotated[str | None, Query(max_length=20)] = None,
        locked: Annotated[bool | None, Query()] = None,
        show_inactive: Annotated[bool, Query()] = False,
        page_size: Annotated[int, Query(ge=1, le=200)] = 50,
        cursor: Annotated[str | None, Query(max_length=2048)] = None,
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> AnalysisFindingPage:
        filters = AnalysisFindingFilters.model_validate(
            {
                "object_id": object_id,
                "from_object_id": from_object_id,
                "to_object_id": to_object_id,
                "validation_state": validation_state,
                "status": status,
                "locked": locked,
                "show_inactive": show_inactive,
            }
        )
        return await service.list_analysis_findings(
            principal,
            tenant_id=tenant_id,
            project_id=project_id,
            filters=filters,
            page_size=page_size,
            cursor=cursor,
        )

    router.add_api_route(
        "/analysis",
        list_analysis_findings,
        methods=["GET"],
        response_model=AnalysisFindingPage,
    )

    async def export_analysis_findings(
        tenant_id: Annotated[int, Path(gt=0)],
        project_id: Annotated[int, Path(gt=0)],
        command: AnalysisExportRequest,
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> Response:
        result = await service.export_analysis_findings(
            principal,
            tenant_id=tenant_id,
            project_id=project_id,
            filters=command.filters,
            expected_project_revision=command.expected_project_revision,
        )
        return Response(
            content=result.content,
            media_type=XLSX_MEDIA_TYPE,
            headers={
                "Content-Disposition": f'attachment; filename="{result.filename}"',
                "Cache-Control": "no-store",
                "X-Content-Type-Options": "nosniff",
            },
        )

    router.add_api_route("/analysis/export", export_analysis_findings, methods=["POST"])

    async def read_analysis_finding(
        tenant_id: Annotated[int, Path(gt=0)],
        project_id: Annotated[int, Path(gt=0)],
        analysis_result_id: Annotated[int, Path(gt=0)],
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> AnalysisFindingDetail:
        return await service.read_analysis_finding(
            principal,
            tenant_id=tenant_id,
            project_id=project_id,
            analysis_result_id=analysis_result_id,
        )

    router.add_api_route(
        "/analysis/{analysis_result_id}",
        read_analysis_finding,
        methods=["GET"],
        response_model=AnalysisFindingDetail,
    )

    return router
