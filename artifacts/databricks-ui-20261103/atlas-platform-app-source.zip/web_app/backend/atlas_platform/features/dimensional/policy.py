"""Deterministic first-stage Gold technical and audit policy projection."""

from __future__ import annotations

import json
import re
from typing import Literal, cast

from atlas_mcp.application.change_sets.project import StageProjectChange
from atlas_mcp.application.change_sets.project_validation import validate_staged_records
from atlas_mcp.domain.errors import InvalidRequestError
from atlas_mcp.domain.modeling_policy import (
    GoldAuditPolicy,
    GoldPolicyColumn,
    GoldTechnicalPolicy,
)
from atlas_mcp.domain.modeling_records import (
    DimensionalAttributeRecord,
    DimensionalEntityRecord,
    DimensionalRelationshipRecord,
    normalize_project_key_value,
)
from atlas_mcp.domain.snapshots.project import (
    CHANGE_SET_DATASETS_BY_NAME,
    DimensionalSection,
)
from pydantic import BaseModel, ValidationError


class DimensionalProjectionConflictError(InvalidRequestError):
    """Candidate semantics conflict with the frozen Gold policy; safe to repair."""


def validate_dimensional_gold_policy(
    *,
    naming_instructions: str | None,
    raw_technical_template: dict[str, object] | None,
    raw_audit_template: dict[str, object] | None,
) -> None:
    """Require and parse the complete Gold policy group before agent work."""

    if naming_instructions is None or raw_technical_template is None or raw_audit_template is None:
        raise InvalidRequestError("Dimensional authoring requires the complete Gold policy group.")
    _parse_technical_policy(raw_technical_template)
    _parse_audit_policy(raw_audit_template)


def project_dimensional_gold_policy(
    *,
    changes: tuple[StageProjectChange, ...],
    applied: DimensionalSection | None,
    raw_technical_template: dict[str, object] | None,
    raw_audit_template: dict[str, object] | None,
    scd_type: Literal["type_1", "type_2"] | None = None,
) -> tuple[StageProjectChange, ...]:
    """Project Entity-local surrogate, Type 2, and audit Attributes.

    Relationship-derived Fact/Bridge foreign keys are applied separately after
    Relationships settle by ``project_dimensional_foreign_key_policy``.
    """

    if raw_technical_template is None and raw_audit_template is None:
        return changes
    if raw_technical_template is None or raw_audit_template is None:
        raise InvalidRequestError("The Gold policy template group is incomplete.")
    technical = _parse_technical_policy(raw_technical_template)
    audit = _parse_audit_policy(raw_audit_template)
    baseline = applied or DimensionalSection(entities=(), attributes=(), relationships=())
    changes_by_dataset = {change.dataset: change for change in changes}
    if len(changes_by_dataset) != len(changes) or any(
        not change.dataset.startswith("dimensional_") for change in changes
    ):
        raise InvalidRequestError("Dimensional policy projection received invalid input.")

    changed_entities = _parse_records(
        changes_by_dataset.get("dimensional_entity"),
        dataset="dimensional_entity",
        record_type=DimensionalEntityRecord,
    )
    changed_attributes = _parse_records(
        changes_by_dataset.get("dimensional_attribute"),
        dataset="dimensional_attribute",
        record_type=DimensionalAttributeRecord,
    )
    entities = {_entity_key(record): record for record in baseline.entities}
    entities.update({_entity_key(record): record for record in changed_entities})
    attributes = {_attribute_key(record): record for record in baseline.attributes}
    attributes.update({_attribute_key(record): record for record in changed_attributes})
    relationships = {
        dimensional_relationship_key(record): record for record in baseline.relationships
    }
    relationships.update(
        {
            dimensional_relationship_key(record): record
            for record in _parse_records(
                changes_by_dataset.get("dimensional_relationship"),
                dataset="dimensional_relationship",
                record_type=DimensionalRelationshipRecord,
            )
        }
    )
    foreign_keys = dimensional_policy_attribute_keys(
        entities=tuple(entities.values()),
        relationships=tuple(relationships.values()),
        technical=technical,
        audit=None,
        foreign_only=True,
        applied=baseline,
    )

    projected: list[DimensionalAttributeRecord] = []
    for entity_key, entity in sorted(entities.items()):
        if not entity.dimensional_entity_is_active:
            continue
        entity_attributes = [record for key, record in attributes.items() if key[:2] == entity_key]
        is_new_entity = entity_key not in {_entity_key(row) for row in baseline.entities}
        if is_new_entity or any(
            row.dimensional_attribute_is_surrogate_key
            and row.dimensional_attribute_ordinal_position == 1
            for row in entity_attributes
        ):
            # Reserve ordinal 1 for the own key; retain business relative order.
            business = sorted(
                (
                    row
                    for row in entity_attributes
                    if not row.dimensional_attribute_is_surrogate_key
                ),
                key=lambda row: (row.dimensional_attribute_ordinal_position, _attribute_key(row)),
            )
            for ordinal, row in enumerate(business, start=2):
                desired = row.model_copy(update={"dimensional_attribute_ordinal_position": ordinal})
                attributes[_attribute_key(desired)] = desired
                projected.append(desired)
            entity_attributes = [row for key, row in attributes.items() if key[:2] == entity_key]
        business_ordinal = max(
            (
                record.dimensional_attribute_ordinal_position
                for record in entity_attributes
                if not record.dimensional_attribute_is_audit_column
                and not record.dimensional_attribute_is_surrogate_key
                and _attribute_key(record) not in foreign_keys
            ),
            default=0,
        )
        policy_ordinal_base = business_ordinal
        if entity.dimensional_entity_type in ("fact", "bridge"):
            policy_ordinal_base += sum(
                _attribute_key(record) in foreign_keys and record.dimensional_attribute_is_active
                for record in entity_attributes
            )
        specifications: list[tuple[GoldPolicyColumn, Literal["technical", "audit"], str]] = []
        history: list[GoldPolicyColumn] = []
        if entity.dimensional_entity_type == "dimension" or is_new_entity:
            # A saved Entity keeps its surrogate's name, such as a DimCustomerKey saved
            # before generated keys dropped the Dim prefix.
            saved_surrogate = None
            if not is_new_entity:
                saved_surrogate = next(
                    (
                        row.dimensional_attribute_name
                        for row in entity_attributes
                        if row.dimensional_attribute_is_surrogate_key
                        and row.dimensional_attribute_is_active
                    ),
                    None,
                )
            try:
                surrogate = GoldPolicyColumn(
                    semantic_name=saved_surrogate
                    or technical.dimension_surrogate_key.semantic_name_template.format(
                        entity_name=_key_name(entity)
                    ),
                    data_type=technical.dimension_surrogate_key.data_type,
                    nullable=False,
                    definition=technical.dimension_surrogate_key.definition_template.format(
                        entity_name=entity.dimensional_entity_name
                    ),
                )
            except ValidationError:
                raise DimensionalProjectionConflictError(
                    "The Gold surrogate-key template produced an invalid column. Shorten the "
                    "Entity name so the configured key name fits 255 characters and its "
                    "definition fits 2000 characters. Preserve the frozen policy."
                ) from None
            specifications.append((surrogate, "technical", "surrogate"))
            if entity.dimensional_entity_type == "dimension" and scd_type == "type_2":
                history.extend(
                    (
                        technical.type_2.is_current,
                        technical.type_2.effective_from,
                        technical.type_2.effective_to,
                    )
                )
        # History belongs to the audit group, immediately after SourceSystemID.
        # With a custom audit list lacking that anchor, history starts the group.
        audit_columns = list(audit.columns)
        history_position = next(
            (
                index + 1
                for index, column in enumerate(audit_columns)
                if normalize_project_key_value(column.semantic_name) == "sourcesystemid"
            ),
            0,
        )
        audit_columns[history_position:history_position] = history
        specifications.extend((column, "audit", "none") for column in audit_columns)
        normalized_names = [
            normalize_project_key_value(column.semantic_name) for column, _, _ in specifications
        ]
        if len(normalized_names) != len(set(normalized_names)):
            raise DimensionalProjectionConflictError(
                "Gold policy columns collide after normalization."
            )

        for offset, (column, role, key_role) in enumerate(specifications, start=1):
            key = (*entity_key, normalize_project_key_value(column.semantic_name))
            existing = attributes.get(key)
            if key_role == "surrogate":
                ordinal = (
                    1
                    if is_new_entity
                    else (
                        existing.dimensional_attribute_ordinal_position
                        if existing is not None
                        else policy_ordinal_base + 1
                    )
                )
            else:
                ordinal = (
                    policy_ordinal_base + offset - (1 if specifications[0][2] == "surrogate" else 0)
                )
            desired = _policy_attribute(
                entity=entity,
                column=column,
                role=role,
                key_role=key_role,
                ordinal=ordinal,
                existing=existing,
            )
            if existing != desired:
                projected.append(desired)
            attributes[key] = desired
            if key_role == "surrogate":
                policy_ordinal_base = max(
                    policy_ordinal_base, desired.dimensional_attribute_ordinal_position
                )

    changed_attribute_by_key = {_attribute_key(record): record for record in changed_attributes}
    for record in projected:
        changed_attribute_by_key[_attribute_key(record)] = record
    applied_attributes = {_attribute_key(record): record for record in baseline.attributes}
    changed_attribute_by_key = {
        key: record
        for key, record in changed_attribute_by_key.items()
        if applied_attributes.get(key) != record
    }

    output: list[StageProjectChange] = []
    for dataset in ("dimensional_entity", "dimensional_attribute", "dimensional_relationship"):
        if dataset == "dimensional_attribute":
            records = [
                record.model_dump(mode="json")
                for record in sorted(
                    changed_attribute_by_key.values(),
                    key=lambda item: (
                        normalize_project_key_value(item.dimensional_entity_name),
                        item.dimensional_attribute_ordinal_position,
                        normalize_project_key_value(item.dimensional_attribute_name),
                    ),
                )
            ]
        else:
            change = changes_by_dataset.get(dataset)
            records = [] if change is None else change.records
        if records:
            output.append(StageProjectChange(dataset=dataset, records=records))
    return tuple(output)


def project_dimensional_foreign_key_policy(
    *,
    changes: tuple[StageProjectChange, ...],
    applied: DimensionalSection | None,
    raw_technical_template: dict[str, object] | None,
) -> tuple[StageProjectChange, ...]:
    """Project Fact/Bridge foreign keys and bind their final Relationships."""

    if raw_technical_template is None:
        return changes
    technical = _parse_technical_policy(raw_technical_template)
    baseline = applied or DimensionalSection(entities=(), attributes=(), relationships=())
    changes_by_dataset = {change.dataset: change for change in changes}
    if len(changes_by_dataset) != len(changes) or any(
        not change.dataset.startswith("dimensional_") for change in changes
    ):
        raise InvalidRequestError("Dimensional policy projection received invalid input.")

    changed_entities = _parse_records(
        changes_by_dataset.get("dimensional_entity"),
        dataset="dimensional_entity",
        record_type=DimensionalEntityRecord,
    )
    changed_attributes = _parse_records(
        changes_by_dataset.get("dimensional_attribute"),
        dataset="dimensional_attribute",
        record_type=DimensionalAttributeRecord,
    )
    changed_relationships = _parse_records(
        changes_by_dataset.get("dimensional_relationship"),
        dataset="dimensional_relationship",
        record_type=DimensionalRelationshipRecord,
    )
    entities = {_entity_key(record): record for record in baseline.entities}
    entities.update({_entity_key(record): record for record in changed_entities})
    attributes = {_attribute_key(record): record for record in baseline.attributes}
    attributes.update({_attribute_key(record): record for record in changed_attributes})
    relationships = {
        dimensional_relationship_key(record): record for record in baseline.relationships
    }
    relationships.update(
        {dimensional_relationship_key(record): record for record in changed_relationships}
    )
    foreign_keys = dimensional_policy_attribute_keys(
        entities=tuple(entities.values()),
        relationships=tuple(relationships.values()),
        technical=technical,
        audit=None,
        foreign_only=True,
        applied=baseline,
    )
    owned_foreign_keys = dimensional_policy_attribute_keys(
        entities=tuple(entities.values()),
        relationships=(),
        applied=baseline,
        technical=technical,
        audit=None,
        foreign_only=True,
    )
    applied_attributes = {_attribute_key(record): record for record in baseline.attributes}

    projected_relationships: list[DimensionalRelationshipRecord] = []
    projected_attributes: dict[tuple[str, str, str], DimensionalAttributeRecord] = {}
    projected_fk_keys: set[tuple[str, str, str]] = set()
    affected_entity_keys: set[tuple[str, str]] = set()
    for relationship in changed_relationships:
        if not relationship.dimensional_relationship_is_active:
            projected_relationships.append(relationship)
            continue
        from_key = (
            normalize_project_key_value(relationship.from_dimensional_entity_schema_name),
            normalize_project_key_value(relationship.from_dimensional_entity_name),
        )
        to_key = (
            normalize_project_key_value(relationship.to_dimensional_entity_schema_name),
            normalize_project_key_value(relationship.to_dimensional_entity_name),
        )
        from_entity = entities.get(from_key)
        to_entity = entities.get(to_key)
        if from_entity is None or to_entity is None:
            raise DimensionalProjectionConflictError(
                "A Dimensional Relationship references an unknown Entity."
            )

        if from_entity.dimensional_entity_type in ("fact", "bridge"):
            if to_entity.dimensional_entity_type != "dimension":
                raise DimensionalProjectionConflictError(
                    "Fact and Bridge Relationships must point to a Dimension."
                )
            surrogate_candidates = [
                attribute
                for attribute in attributes.values()
                if _entity_key_from_attribute(attribute) == to_key
                and attribute.dimensional_attribute_is_surrogate_key
                and attribute.dimensional_attribute_is_active
            ]
            if len(surrogate_candidates) != 1:
                raise DimensionalProjectionConflictError(
                    "A referenced Dimension must have exactly one effective surrogate key."
                )
            surrogate = surrogate_candidates[0]
            role_name = relationship.dimensional_relationship_role_name
            # A reference is optional when its business foreign-key column may be null.
            business_key = attributes.get(
                (
                    *from_key,
                    normalize_project_key_value(relationship.from_dimensional_attribute_name),
                )
            )
            optional = business_key is None or business_key.dimensional_attribute_is_nullable
            try:
                semantic_name = (
                    technical.fact_bridge_foreign_key.with_role_semantic_name_template.format(
                        role_name=role_name
                    )
                    if role_name is not None
                    else (
                        technical.fact_bridge_foreign_key.without_role_semantic_name_template.format(
                            entity_name=_key_name(to_entity)
                        )
                    )
                )
                definition = technical.fact_bridge_foreign_key.definition_template.format(
                    entity_name=to_entity.dimensional_entity_name,
                    role_name=(role_name or to_entity.dimensional_entity_name),
                )
                column = GoldPolicyColumn(
                    semantic_name=semantic_name,
                    data_type=surrogate.dimensional_attribute_data_type,
                    nullable=optional,
                    definition=definition,
                )
            except KeyError, ValidationError:
                raise DimensionalProjectionConflictError(
                    "The Gold foreign-key template produced an invalid column. Shorten the "
                    "Entity or role name so the configured column name fits 255 characters "
                    "and its definition fits 2000 characters. Preserve the frozen policy."
                ) from None
            attribute_key = (
                *from_key,
                normalize_project_key_value(column.semantic_name),
            )
            if attribute_key in projected_fk_keys:
                raise DimensionalProjectionConflictError(
                    "Two Dimensional Relationships project the same foreign-key name."
                )
            projected_fk_keys.add(attribute_key)
            existing = attributes.get(attribute_key)
            if existing is not None and attribute_key not in owned_foreign_keys:
                raise DimensionalProjectionConflictError(
                    "A projected foreign-key name conflicts with an existing business Attribute."
                )
            desired = _policy_attribute(
                entity=from_entity,
                column=column,
                role="technical",
                key_role="foreign",
                ordinal=1,
                existing=existing,
            )
            attributes[attribute_key] = desired
            projected_attributes[attribute_key] = desired
            affected_entity_keys.add(from_key)
            projected_relationships.append(
                relationship.model_copy(
                    update={
                        "from_dimensional_attribute_name": desired.dimensional_attribute_name,
                        "to_dimensional_attribute_name": (surrogate.dimensional_attribute_name),
                    }
                )
            )
        elif to_entity.dimensional_entity_type in ("fact", "bridge"):
            raise DimensionalProjectionConflictError(
                "Fact and Bridge Relationships must use the from endpoint."
            )
        else:
            projected_relationships.append(relationship)

    for entity_key in sorted(affected_entity_keys):
        entity_attributes = [
            record
            for record in attributes.values()
            if _entity_key_from_attribute(record) == entity_key
        ]
        business = [
            record
            for record in entity_attributes
            if not record.dimensional_attribute_is_audit_column
            and not record.dimensional_attribute_is_surrogate_key
            and _attribute_key(record) not in foreign_keys
        ]
        technical_attributes = sorted(
            (
                record
                for record in entity_attributes
                if record.dimensional_attribute_is_surrogate_key
                or _attribute_key(record) in foreign_keys
            ),
            key=lambda item: (
                0 if item.dimensional_attribute_is_surrogate_key else 1,
                normalize_project_key_value(item.dimensional_attribute_name),
            ),
        )
        audit_attributes = sorted(
            (
                record
                for record in entity_attributes
                if record.dimensional_attribute_is_audit_column
            ),
            key=lambda item: (
                item.dimensional_attribute_ordinal_position,
                normalize_project_key_value(item.dimensional_attribute_name),
            ),
        )
        next_ordinal = max(
            (item.dimensional_attribute_ordinal_position for item in business),
            default=0,
        )
        for offset, record in enumerate(
            (*technical_attributes, *audit_attributes),
            start=1,
        ):
            reordered = record.model_copy(
                update={
                    "dimensional_attribute_ordinal_position": (
                        record.dimensional_attribute_ordinal_position
                        if record.dimensional_attribute_is_surrogate_key
                        else next_ordinal
                        + offset
                        - sum(
                            item.dimensional_attribute_is_surrogate_key
                            for item in technical_attributes
                        )
                    )
                }
            )
            key = _attribute_key(reordered)
            applied_record = applied_attributes.get(key)
            if (
                applied_record is not None
                and applied_record.dimensional_attribute_is_locked
                and applied_record != reordered
            ):
                raise DimensionalProjectionConflictError(
                    "A locked Gold policy column cannot be projected."
                )
            attributes[key] = reordered
            if applied_record != reordered:
                projected_attributes[key] = reordered

    changed_attribute_by_key = {_attribute_key(record): record for record in changed_attributes}
    changed_attribute_by_key.update(projected_attributes)
    output: list[StageProjectChange] = []
    for dataset in ("dimensional_entity", "dimensional_attribute", "dimensional_relationship"):
        if dataset == "dimensional_attribute":
            records = [
                record.model_dump(mode="json")
                for record in sorted(
                    changed_attribute_by_key.values(),
                    key=lambda item: (
                        _entity_key_from_attribute(item),
                        item.dimensional_attribute_ordinal_position,
                        normalize_project_key_value(item.dimensional_attribute_name),
                    ),
                )
            ]
        elif dataset == "dimensional_relationship":
            records = [record.model_dump(mode="json") for record in projected_relationships]
        else:
            change = changes_by_dataset.get(dataset)
            records = [] if change is None else change.records
        if records:
            output.append(StageProjectChange(dataset=dataset, records=records))
    return tuple(output)


def dimensional_relationship_key(record: DimensionalRelationshipRecord) -> tuple[str, ...]:
    """A Relationship is its child foreign-key Attribute."""
    return tuple(
        normalize_project_key_value(str(getattr(record, field) or ""))
        for field in CHANGE_SET_DATASETS_BY_NAME["dimensional_relationship"].canonical_key
    )


def dimensional_policy_attribute_keys(
    *,
    entities: tuple[DimensionalEntityRecord, ...],
    relationships: tuple[DimensionalRelationshipRecord, ...],
    technical: GoldTechnicalPolicy,
    audit: GoldAuditPolicy | None,
    foreign_only: bool = False,
    applied: DimensionalSection | None = None,
) -> set[tuple[str, str, str]]:
    """Resolve framework-owned column identities from configuration and the graph."""
    entities_by_key = {_entity_key(entity): entity for entity in entities}
    applied_entities = (
        {_entity_key(entity): entity for entity in applied.entities} if applied else {}
    )
    keys: set[tuple[str, str, str]] = set()
    if not foreign_only:
        for entity_key, entity in entities_by_key.items():
            names = [
                technical.dimension_surrogate_key.semantic_name_template.format(
                    entity_name=_key_name(entity)
                )
            ]
            names.extend(
                column.semantic_name
                for column in (
                    technical.type_2.is_current,
                    technical.type_2.effective_from,
                    technical.type_2.effective_to,
                )
            )
            if audit is not None:
                names.extend(column.semantic_name for column in audit.columns)
            keys.update((*entity_key, normalize_project_key_value(name)) for name in names)
    for relationship, existing in (
        *((record, False) for record in relationships),
        *((record, True) for record in (applied.relationships if applied else ())),
    ):
        if not existing and not relationship.dimensional_relationship_is_active:
            continue
        from_key = (
            normalize_project_key_value(relationship.from_dimensional_entity_schema_name),
            normalize_project_key_value(relationship.from_dimensional_entity_name),
        )
        to_key = (
            normalize_project_key_value(relationship.to_dimensional_entity_schema_name),
            normalize_project_key_value(relationship.to_dimensional_entity_name),
        )
        graph_entities = applied_entities if existing else entities_by_key
        source, target = graph_entities.get(from_key), graph_entities.get(to_key)
        if (
            source is None
            or target is None
            or source.dimensional_entity_type not in ("fact", "bridge")
            or target.dimensional_entity_type != "dimension"
        ):
            continue
        if existing:
            keys.add(
                (
                    *from_key,
                    normalize_project_key_value(relationship.from_dimensional_attribute_name),
                )
            )
            continue
        role = relationship.dimensional_relationship_role_name
        name = (
            technical.fact_bridge_foreign_key.with_role_semantic_name_template.format(
                role_name=role
            )
            if role is not None
            else technical.fact_bridge_foreign_key.without_role_semantic_name_template.format(
                entity_name=_key_name(target)
            )
        )
        keys.add((*from_key, normalize_project_key_value(name)))
    return keys


def _parse_technical_policy(raw_template: dict[str, object]) -> GoldTechnicalPolicy:
    try:
        return GoldTechnicalPolicy.model_validate_json(
            json.dumps(raw_template, ensure_ascii=False, allow_nan=False, separators=(",", ":")),
            strict=True,
        )
    except TypeError, ValueError, ValidationError:
        raise InvalidRequestError("The Gold technical-column template is invalid.") from None


def _parse_audit_policy(raw_template: dict[str, object]) -> GoldAuditPolicy:
    try:
        return GoldAuditPolicy.model_validate_json(
            json.dumps(raw_template, ensure_ascii=False, allow_nan=False, separators=(",", ":")),
            strict=True,
        )
    except TypeError, ValueError, ValidationError:
        raise InvalidRequestError("The Gold audit-column template is invalid.") from None


def _parse_records[T: BaseModel](
    change: StageProjectChange | None,
    *,
    dataset: Literal[
        "dimensional_entity",
        "dimensional_attribute",
        "dimensional_relationship",
    ],
    record_type: type[T],
) -> tuple[T, ...]:
    if change is None:
        return ()
    records, issues = validate_staged_records(dataset, change.records)
    if issues:
        raise InvalidRequestError("Dimensional policy projection received invalid input.")
    return tuple(cast(T, record) for record in records if isinstance(record, record_type))


def _policy_attribute(
    *,
    entity: DimensionalEntityRecord,
    column: GoldPolicyColumn,
    role: Literal["technical", "audit"],
    key_role: str,
    ordinal: int,
    existing: DimensionalAttributeRecord | None,
) -> DimensionalAttributeRecord:
    if existing is not None and (
        existing.dimensional_attribute_is_audit_column != (role == "audit")
        or existing.dimensional_attribute_is_natural_key
        or normalize_project_key_value(existing.dimensional_attribute_data_type)
        != normalize_project_key_value(column.data_type)
        or existing.dimensional_attribute_is_nullable != column.nullable
        or existing.dimensional_attribute_is_surrogate_key != (key_role == "surrogate")
        or (
            existing.sources
            and normalize_project_key_value(column.semantic_name) != "sourcesystemid"
        )
    ):
        raise DimensionalProjectionConflictError(
            "A configured Gold policy column conflicts with an existing Attribute."
        )
    desired = DimensionalAttributeRecord(
        dimensional_entity_schema_name=entity.dimensional_entity_schema_name,
        dimensional_entity_name=entity.dimensional_entity_name,
        dimensional_attribute_name=column.semantic_name,
        dimensional_attribute_definition=column.definition or column.semantic_name,
        dimensional_attribute_data_type=column.data_type,
        dimensional_attribute_is_nullable=column.nullable,
        dimensional_attribute_ordinal_position=ordinal,
        dimensional_attribute_is_natural_key=False,
        dimensional_attribute_is_surrogate_key=key_role == "surrogate",
        dimensional_attribute_is_audit_column=role == "audit",
        dimensional_attribute_is_active=True,
        dimensional_attribute_is_locked=(
            existing.dimensional_attribute_is_locked if existing is not None else False
        ),
        sources=(existing.sources if existing is not None else ()),
    )
    if existing is not None and existing.dimensional_attribute_is_locked and existing != desired:
        raise DimensionalProjectionConflictError("A locked Gold policy column cannot be projected.")
    return desired


def _key_name(entity: DimensionalEntityRecord) -> str:
    """Generated key names drop a Dimension's Dim prefix: DimCustomer gets CustomerKey."""
    name = entity.dimensional_entity_name
    if entity.dimensional_entity_type == "dimension" and re.match(r"Dim[A-Z]", name):
        return name[3:]
    return name


def _entity_key(record: DimensionalEntityRecord) -> tuple[str, str]:
    return (
        normalize_project_key_value(record.dimensional_entity_schema_name),
        normalize_project_key_value(record.dimensional_entity_name),
    )


def _attribute_key(record: DimensionalAttributeRecord) -> tuple[str, str, str]:
    return (
        normalize_project_key_value(record.dimensional_entity_schema_name),
        normalize_project_key_value(record.dimensional_entity_name),
        normalize_project_key_value(record.dimensional_attribute_name),
    )


def _entity_key_from_attribute(record: DimensionalAttributeRecord) -> tuple[str, str]:
    return _attribute_key(record)[:2]


__all__ = [
    "GoldAuditPolicy",
    "GoldPolicyColumn",
    "GoldTechnicalPolicy",
    "project_dimensional_foreign_key_policy",
    "project_dimensional_gold_policy",
    "validate_dimensional_gold_policy",
]
