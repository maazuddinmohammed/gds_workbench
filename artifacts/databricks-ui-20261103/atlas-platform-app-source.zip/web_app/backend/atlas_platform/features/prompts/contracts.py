"""Governed Prompt Library contracts."""

from datetime import datetime
from typing import Literal, Self

from atlas_mcp.domain.errors import AtlasError
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    JsonValue,
    field_validator,
    model_validator,
)

from atlas_platform.features.workflows.authoring.agent_execution import LocalAgentToolDefinition
from atlas_platform.features.workflows.authoring.tool_configuration import AgentToolName

type ProjectWorkflow = Literal[
    "profiling",
    "analysis",
    "subject_area",
    "logical",
    "dimensional",
    "mapping",
    "code_generation",
    "validation",
    "metadata_enrichment",
    "metadata_enrichment_object",
    "metadata_enrichment_attribute",
]
type WorkflowExecutionMode = Literal[
    "one_shot",
    "tool_assisted",
]
type PromptVariableDataType = Literal[
    "text",
    "integer",
    "number",
    "boolean",
    "json",
]
type PromptOwnershipScope = Literal["global", "tenant"]
type PromptVersionStatus = Literal["draft", "published", "retired"]
type PromptAssignmentScope = Literal["global_default", "project_default"]
type EffectivePromptSource = Literal["global_default", "project_default", "none"]


class PromptContract(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)


class PromptStageVariable(PromptContract):
    name: str = Field(min_length=1, max_length=100)
    resolver_key: str = Field(min_length=1, max_length=200)
    data_type: PromptVariableDataType
    is_required: bool
    description: str = Field(min_length=1, max_length=2000)
    example: JsonValue | None = None
    order: int = Field(gt=0)
    value_schema: dict[str, JsonValue] | None = None
    source: str | None = Field(default=None, min_length=1, max_length=500)
    availability: str | None = Field(default=None, min_length=1, max_length=500)
    delivery: Literal["inline_value", "structured_context", "tool_dataset"] | None = None
    context_path: str | None = Field(default=None, min_length=1, max_length=200)


class PromptStage(PromptContract):
    workflow_stage_id: int = Field(gt=0)
    project_workflow: ProjectWorkflow
    workflow_execution_mode: WorkflowExecutionMode | None = None
    workflow_stage_code: str = Field(min_length=1, max_length=100)
    workflow_stage_name: str = Field(min_length=1, max_length=200)
    workflow_stage_description: str | None = Field(default=None, max_length=2000)
    workflow_stage_order: int = Field(gt=0)
    allowed_variables: tuple[PromptStageVariable, ...] = Field(max_length=100)


class PromptStageCatalog(PromptContract):
    tenant_id: int = Field(gt=0)
    items: tuple[PromptStage, ...] = Field(max_length=200)


class PromptTemplateFilters(PromptContract):
    project_workflow: ProjectWorkflow | None = None
    workflow_execution_mode: WorkflowExecutionMode | None = None
    workflow_stage_code: str | None = Field(
        default=None,
        min_length=1,
        max_length=100,
        pattern=r"^[a-z][a-z0-9_]{0,99}$",
    )
    version_status: PromptVersionStatus | None = None

    @field_validator("workflow_stage_code", mode="before")
    @classmethod
    def normalize_stage_code(cls, value: object) -> object:
        return value.strip().lower() if isinstance(value, str) else value


class PromptTemplateSummary(PromptContract):
    prompt_template_id: int = Field(gt=0)
    workflow_stage_id: int = Field(gt=0)
    project_workflow: ProjectWorkflow
    workflow_execution_mode: WorkflowExecutionMode | None = None
    workflow_stage_code: str = Field(min_length=1, max_length=100)
    workflow_stage_name: str = Field(min_length=1, max_length=200)
    prompt_template_ownership_scope: PromptOwnershipScope
    owner_tenant_id: int | None = Field(default=None, gt=0)
    prompt_template_code: str = Field(min_length=1, max_length=100)
    prompt_template_name: str = Field(min_length=1, max_length=200)
    prompt_template_description: str | None = Field(default=None, max_length=2000)
    is_active: bool
    latest_version_id: int | None = Field(default=None, gt=0)
    latest_version_number: int | None = Field(default=None, gt=0)
    latest_version_status: PromptVersionStatus | None = None
    latest_version_digest: str | None = Field(
        default=None,
        min_length=64,
        max_length=64,
        pattern=r"^[0-9a-f]{64}$",
    )
    latest_version_updated_at: datetime | None = None
    updated_at: datetime

    @model_validator(mode="after")
    def validate_ownership_and_version_shape(self) -> Self:
        if (self.prompt_template_ownership_scope == "global") != (self.owner_tenant_id is None):
            raise ValueError("Prompt Template ownership is inconsistent")
        latest = (
            self.latest_version_id,
            self.latest_version_number,
            self.latest_version_status,
            self.latest_version_digest,
            self.latest_version_updated_at,
        )
        if any(value is None for value in latest) and not all(value is None for value in latest):
            raise ValueError("latest Prompt Template version fields are incomplete")
        return self


class PromptTemplatePage(PromptContract):
    tenant_id: int = Field(gt=0)
    items: tuple[PromptTemplateSummary, ...] = Field(max_length=200)
    next_cursor: str | None = Field(default=None, max_length=2048)


class PromptTemplateVersion(PromptContract):
    prompt_template_version_id: int = Field(gt=0)
    prompt_template_id: int = Field(gt=0)
    workflow_stage_id: int = Field(gt=0)
    prompt_template_version_number: int = Field(gt=0)
    agent_tool_names: list[AgentToolName] | None = Field(default=None, max_length=100)

    @field_validator("agent_tool_names")
    @classmethod
    def validate_tool_selection(
        cls, value: list[AgentToolName] | None
    ) -> list[AgentToolName] | None:
        if value is not None and len(value) != len(set(value)):
            raise ValueError("Prompt tool names must be unique")
        return sorted(value) if value is not None else None

    system_prompt_template: str = Field(min_length=1)
    instruction_prompt_template: str = Field(min_length=1)
    tool_instruction_prompt_template: str | None = Field(
        default=None,
        min_length=1,
    )
    prompt_template_digest: str = Field(
        min_length=64,
        max_length=64,
        pattern=r"^[0-9a-f]{64}$",
    )
    prompt_template_version_status: PromptVersionStatus
    published_at: datetime | None = None
    retired_at: datetime | None = None
    created_at: datetime
    updated_at: datetime


class PromptTemplateDetail(PromptContract):
    tenant_id: int = Field(gt=0)
    template: PromptTemplateSummary
    allowed_variables: tuple[PromptStageVariable, ...] = Field(max_length=100)
    versions: tuple[PromptTemplateVersion, ...] = Field(max_length=200)
    available_tools: tuple[LocalAgentToolDefinition, ...] = Field(default=(), max_length=100)


class PromptTemplateNotFoundError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="prompt_template_not_found",
            message="The requested Prompt Template was not found.",
        )


class PromptConflictError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="prompt_conflict",
            message=(
                "Prompt Library state changed or is still in use; inspect the current "
                "state before retrying."
            ),
        )


class PromptAssignmentConflictError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="prompt_assignment_conflict",
            message=("Prompt assignment state changed or the selected version is unavailable."),
        )


class PromptRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class CreatePromptTemplateRequest(PromptRequest):
    workflow_stage_id: int = Field(gt=0)
    prompt_template_ownership_scope: PromptOwnershipScope
    prompt_template_code: str = Field(
        min_length=1,
        max_length=100,
        pattern=r"^[a-z][a-z0-9_.-]{0,99}$",
    )
    prompt_template_name: str = Field(min_length=1, max_length=200)
    prompt_template_description: str | None = Field(default=None, max_length=2000)
    is_active: bool = True

    @field_validator("prompt_template_code", mode="before")
    @classmethod
    def normalize_template_code(cls, value: object) -> object:
        return value.strip().lower() if isinstance(value, str) else value

    @field_validator("prompt_template_name", "prompt_template_description", mode="before")
    @classmethod
    def normalize_bounded_text(cls, value: object) -> object:
        if not isinstance(value, str):
            return value
        normalized = value.strip()
        if not normalized:
            raise ValueError("Prompt Template text must be nonblank")
        return normalized


class UpdatePromptTemplateRequest(PromptRequest):
    prompt_template_name: str = Field(min_length=1, max_length=200)
    prompt_template_description: str | None = Field(default=None, max_length=2000)
    is_active: bool
    expected_updated_at: datetime

    @field_validator("prompt_template_name", "prompt_template_description", mode="before")
    @classmethod
    def normalize_bounded_text(cls, value: object) -> object:
        if not isinstance(value, str):
            return value
        normalized = value.strip()
        if not normalized:
            raise ValueError("Prompt Template text must be nonblank")
        return normalized


class SavePromptDraftRequest(PromptRequest):
    expected_prompt_template_version_id: int | None = Field(default=None, gt=0)
    expected_updated_at: datetime | None = None
    agent_tool_names: list[AgentToolName] | None = Field(default=None, max_length=100)

    @field_validator("agent_tool_names")
    @classmethod
    def validate_tool_selection(
        cls, value: list[AgentToolName] | None
    ) -> list[AgentToolName] | None:
        if value is not None and len(value) != len(set(value)):
            raise ValueError("Prompt tool names must be unique")
        return sorted(value) if value is not None else None

    system_prompt_template: str = Field(min_length=1)
    instruction_prompt_template: str = Field(min_length=1)
    tool_instruction_prompt_template: str | None = Field(
        default=None,
        min_length=1,
    )

    @field_validator(
        "system_prompt_template",
        "instruction_prompt_template",
        "tool_instruction_prompt_template",
    )
    @classmethod
    def validate_prompt_body(cls, value: str | None) -> str | None:
        if value is None:
            return None
        if not value.strip():
            raise ValueError("Prompt Template body must be nonblank")
        return value

    @model_validator(mode="after")
    def validate_fence_pair(self) -> Self:
        if (self.expected_prompt_template_version_id is None) != (self.expected_updated_at is None):
            raise ValueError("Draft version and timestamp fences must be supplied together")
        return self


class PromptPreview(PromptContract):
    rendered_system_prompt: str = Field(repr=False)
    rendered_instruction_prompt: str = Field(repr=False)
    rendered_tool_instruction_prompt: str | None = Field(default=None, repr=False)


class SetProjectPromptAssignmentRequest(PromptRequest):
    prompt_template_version_id: int | None = Field(gt=0)
    expected_prompt_assignment_id: int | None = Field(default=None, gt=0)


class PromptTemplateHeader(PromptContract):
    prompt_template_id: int = Field(gt=0)
    workflow_stage_id: int = Field(gt=0)
    prompt_template_ownership_scope: PromptOwnershipScope
    owner_tenant_id: int | None = Field(default=None, gt=0)
    prompt_template_code: str = Field(min_length=1, max_length=100)
    prompt_template_name: str = Field(min_length=1, max_length=200)
    prompt_template_description: str | None = Field(default=None, max_length=2000)
    is_active: bool
    created_at: datetime
    updated_at: datetime

    @model_validator(mode="after")
    def validate_ownership(self) -> Self:
        if (self.prompt_template_ownership_scope == "global") != (self.owner_tenant_id is None):
            raise ValueError("Prompt Template ownership is inconsistent")
        return self


class PromptAssignmentTarget(PromptContract):
    prompt_assignment_id: int = Field(gt=0)
    prompt_assignment_scope: PromptAssignmentScope
    prompt_template_version_id: int = Field(gt=0)
    prompt_template_version_number: int = Field(gt=0)
    prompt_template_digest: str = Field(
        min_length=64,
        max_length=64,
        pattern=r"^[0-9a-f]{64}$",
    )
    prompt_template_id: int = Field(gt=0)
    prompt_template_ownership_scope: PromptOwnershipScope
    owner_tenant_id: int | None = Field(default=None, gt=0)
    prompt_template_code: str = Field(min_length=1, max_length=100)
    prompt_template_name: str = Field(min_length=1, max_length=200)
    assigned_at: datetime

    @model_validator(mode="after")
    def validate_ownership(self) -> Self:
        if (self.prompt_template_ownership_scope == "global") != (self.owner_tenant_id is None):
            raise ValueError("Prompt assignment ownership is inconsistent")
        return self


class ProjectPromptAssignmentState(PromptContract):
    workflow_stage_id: int = Field(gt=0)
    project_workflow: ProjectWorkflow
    workflow_execution_mode: WorkflowExecutionMode | None = None
    workflow_stage_code: str = Field(min_length=1, max_length=100)
    workflow_stage_name: str = Field(min_length=1, max_length=200)
    workflow_stage_order: int = Field(gt=0)
    project_assignment: PromptAssignmentTarget | None = None
    global_assignment: PromptAssignmentTarget | None = None
    effective_source: EffectivePromptSource
    effective_assignment: PromptAssignmentTarget | None = None

    @model_validator(mode="after")
    def validate_effective_assignment(self) -> Self:
        expected = (
            self.project_assignment
            if self.effective_source == "project_default"
            else self.global_assignment
            if self.effective_source == "global_default"
            else None
        )
        if self.effective_assignment != expected:
            raise ValueError("effective Prompt assignment is inconsistent")
        return self


class ProjectPromptAssignments(PromptContract):
    tenant_id: int = Field(gt=0)
    project_id: int = Field(gt=0)
    items: tuple[ProjectPromptAssignmentState, ...] = Field(max_length=200)


class PromptProjectNotFoundError(AtlasError):
    def __init__(self) -> None:
        super().__init__(
            code="project_not_found",
            message="The requested Project was not found.",
        )


class PromptTemplateMutationContext(PromptContract):
    prompt_template_id: int = Field(gt=0)
    workflow_stage_id: int = Field(gt=0)
    prompt_template_ownership_scope: PromptOwnershipScope
    owner_tenant_id: int | None = Field(default=None, gt=0)
    prompt_template_code: str = Field(min_length=1, max_length=100)
