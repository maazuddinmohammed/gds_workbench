"""Governed Prompt Library HTTP routes."""

from typing import Annotated

from atlas_mcp.application.identity import IdentityProvider
from atlas_mcp.domain.authorization import RequestPrincipal
from fastapi import APIRouter, Depends, Path, Query, Response

from atlas_platform.dependencies import principal_dependency
from atlas_platform.features.prompts.contracts import (
    CreatePromptTemplateRequest,
    ProjectPromptAssignments,
    ProjectPromptAssignmentState,
    ProjectWorkflow,
    PromptPreview,
    PromptStageCatalog,
    PromptTemplateDetail,
    PromptTemplateFilters,
    PromptTemplateHeader,
    PromptTemplatePage,
    PromptTemplateVersion,
    PromptVersionStatus,
    SavePromptDraftRequest,
    SetProjectPromptAssignmentRequest,
    UpdatePromptTemplateRequest,
    WorkflowExecutionMode,
)
from atlas_platform.features.prompts.service import PromptService
from atlas_platform.prompt_rendering import (
    PromptComponentTemplates,
    PromptVariableDefinition,
    render_prompt,
)


def create_prompts_router(
    *,
    identity_provider: IdentityProvider,
    service: PromptService,
) -> APIRouter:
    authenticate = principal_dependency(identity_provider)
    router = APIRouter(
        prefix="/api/v1/tenants/{tenant_id}/prompts",
        tags=["prompts"],
    )
    tenant_path = Path(gt=0)
    id_path = Path(gt=0)

    async def list_stages(
        tenant_id: Annotated[int, tenant_path],
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> PromptStageCatalog:
        return await service.list_stages(principal, tenant_id=tenant_id)

    async def list_templates(
        tenant_id: Annotated[int, tenant_path],
        workflow: ProjectWorkflow | None = None,
        mode: WorkflowExecutionMode | None = None,
        stage_code: Annotated[
            str | None, Query(min_length=1, max_length=100, pattern="^[a-z][a-z0-9_]{0,99}$")
        ] = None,
        status: PromptVersionStatus | None = None,
        page_size: Annotated[int, Query(ge=1, le=200)] = 50,
        cursor: Annotated[str | None, Query(max_length=2048)] = None,
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> PromptTemplatePage:
        return await service.list_templates(
            principal,
            tenant_id=tenant_id,
            filters=PromptTemplateFilters(
                project_workflow=workflow,
                workflow_execution_mode=mode,
                workflow_stage_code=stage_code,
                version_status=status,
            ),
            page_size=page_size,
            cursor=cursor,
        )

    async def read_template(
        tenant_id: Annotated[int, tenant_path],
        prompt_template_id: Annotated[int, id_path],
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> PromptTemplateDetail:
        return await service.read_template(
            principal,
            tenant_id=tenant_id,
            prompt_template_id=prompt_template_id,
        )

    async def create_template(
        tenant_id: Annotated[int, tenant_path],
        body: CreatePromptTemplateRequest,
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> PromptTemplateHeader:
        return await service.create_template(
            principal,
            tenant_id=tenant_id,
            body=body,
        )

    async def update_template(
        tenant_id: Annotated[int, tenant_path],
        prompt_template_id: Annotated[int, id_path],
        body: UpdatePromptTemplateRequest,
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> PromptTemplateHeader:
        return await service.update_template(
            principal,
            tenant_id=tenant_id,
            prompt_template_id=prompt_template_id,
            body=body,
        )

    async def save_draft(
        tenant_id: Annotated[int, tenant_path],
        prompt_template_id: Annotated[int, id_path],
        body: SavePromptDraftRequest,
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> PromptTemplateVersion:
        return await service.save_draft(
            principal,
            tenant_id=tenant_id,
            prompt_template_id=prompt_template_id,
            body=body,
        )

    async def preview_prompt(
        response: Response,
        tenant_id: Annotated[int, tenant_path],
        prompt_template_id: Annotated[int, id_path],
        body: SavePromptDraftRequest,
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> PromptPreview:
        detail = await service.read_template(
            principal, tenant_id=tenant_id, prompt_template_id=prompt_template_id
        )
        response.headers["Cache-Control"] = "no-store"
        rendered = render_prompt(
            templates=PromptComponentTemplates(
                system=body.system_prompt_template,
                instruction=body.instruction_prompt_template,
                tool_instruction=body.tool_instruction_prompt_template,
            ),
            variables=tuple(
                PromptVariableDefinition(
                    name=v.name,
                    resolver_key=v.resolver_key,
                    data_type=v.data_type,
                    is_required=False,
                )
                for v in detail.allowed_variables
            ),
            resolver_values={v.resolver_key: v.example for v in detail.allowed_variables},
        )
        return PromptPreview(
            rendered_system_prompt=rendered.system,
            rendered_instruction_prompt=rendered.instruction,
            rendered_tool_instruction_prompt=rendered.tool_instruction,
        )

    async def publish_version(
        tenant_id: Annotated[int, tenant_path],
        prompt_template_id: Annotated[int, id_path],
        prompt_template_version_id: Annotated[int, id_path],
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> PromptTemplateVersion:
        return await service.publish_version(
            principal,
            tenant_id=tenant_id,
            prompt_template_id=prompt_template_id,
            prompt_template_version_id=prompt_template_version_id,
        )

    async def retire_version(
        tenant_id: Annotated[int, tenant_path],
        prompt_template_id: Annotated[int, id_path],
        prompt_template_version_id: Annotated[int, id_path],
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> PromptTemplateVersion:
        return await service.retire_version(
            principal,
            tenant_id=tenant_id,
            prompt_template_id=prompt_template_id,
            prompt_template_version_id=prompt_template_version_id,
        )

    async def list_project_assignments(
        tenant_id: Annotated[int, tenant_path],
        project_id: Annotated[int, id_path],
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> ProjectPromptAssignments:
        return await service.list_project_assignments(
            principal,
            tenant_id=tenant_id,
            project_id=project_id,
        )

    async def set_project_assignment(
        tenant_id: Annotated[int, tenant_path],
        project_id: Annotated[int, id_path],
        workflow_stage_id: Annotated[int, id_path],
        body: SetProjectPromptAssignmentRequest,
        *,
        principal: RequestPrincipal = Depends(authenticate),
    ) -> ProjectPromptAssignmentState:
        return await service.set_project_assignment(
            principal,
            tenant_id=tenant_id,
            project_id=project_id,
            workflow_stage_id=workflow_stage_id,
            body=body,
        )

    router.add_api_route(
        "/stages",
        list_stages,
        methods=["GET"],
        response_model=PromptStageCatalog,
    )
    router.add_api_route(
        "/templates",
        list_templates,
        methods=["GET"],
        response_model=PromptTemplatePage,
    )
    router.add_api_route(
        "/templates",
        create_template,
        methods=["POST"],
        response_model=PromptTemplateHeader,
        status_code=201,
    )
    router.add_api_route(
        "/templates/{prompt_template_id}",
        read_template,
        methods=["GET"],
        response_model=PromptTemplateDetail,
    )
    router.add_api_route(
        "/templates/{prompt_template_id}",
        update_template,
        methods=["PUT"],
        response_model=PromptTemplateHeader,
    )
    router.add_api_route(
        "/templates/{prompt_template_id}/preview",
        preview_prompt,
        methods=["POST"],
        response_model=PromptPreview,
    )
    router.add_api_route(
        "/templates/{prompt_template_id}/draft",
        save_draft,
        methods=["PUT"],
        response_model=PromptTemplateVersion,
    )
    router.add_api_route(
        "/templates/{prompt_template_id}/versions/{prompt_template_version_id}/publish",
        publish_version,
        methods=["POST"],
        response_model=PromptTemplateVersion,
    )
    router.add_api_route(
        "/templates/{prompt_template_id}/versions/{prompt_template_version_id}/retire",
        retire_version,
        methods=["POST"],
        response_model=PromptTemplateVersion,
    )
    router.add_api_route(
        "/projects/{project_id}/assignments",
        list_project_assignments,
        methods=["GET"],
        response_model=ProjectPromptAssignments,
    )
    router.add_api_route(
        "/projects/{project_id}/assignments/{workflow_stage_id}",
        set_project_assignment,
        methods=["PUT"],
        response_model=ProjectPromptAssignmentState,
    )
    return router
