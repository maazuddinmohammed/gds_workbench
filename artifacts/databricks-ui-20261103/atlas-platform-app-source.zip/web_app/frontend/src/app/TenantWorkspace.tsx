import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";

import type { ProjectDetail } from "../features/projects/api";
import type { TenantHomeRecord } from "../features/tenants/api";
import { roleLabel } from "../features/tenants/presentation";
import {
  Avatar,
  Brand,
  DatabaseIcon,
  HomeIcon,
  ProjectIcon,
  PanelToggleIcon,
  PromptsIcon,
} from "../shared/ui";
import { useStoredBoolean } from "../shared/useStoredBoolean";

export type WorkspaceNavigation =
  | "home"
  | "metadata"
  | "projects"
  | "mapping"
  | "code-generation"
  | "validation"
  | "prompts";

export function TenantWorkspace({
  home,
  activeNav,
  project,
  children,
}: {
  home: TenantHomeRecord;
  activeNav: WorkspaceNavigation;
  project?: ProjectDetail;
  children: ReactNode;
}) {
  const tenantId = String(home.tenant.tenant_id);
  const [globalNavigationCollapsed, setGlobalNavigationCollapsed] = useStoredBoolean(
    "gds-workbench:workspace-navigation-collapsed",
  );
  const globalNavigationAction = globalNavigationCollapsed
    ? "Expand workspace navigation"
    : "Collapse workspace navigation";

  return (
    <div className={`app-shell page-enter${globalNavigationCollapsed ? " is-global-nav-collapsed" : ""}`}>
      <header className="topbar">
        <Brand compact />
        <dl className="tenant-context" aria-label="Current workspace">
          <div className="tenant-context-item">
            <dt>Tenant</dt>
            <dd><strong className="tenant-context-name" title={home.tenant.tenant_name}>{home.tenant.tenant_name}</strong></dd>
          </div>
          {project ? (
            <div className="tenant-context-item project-context">
              <dt>Project</dt>
              <dd>
                <strong className="project-context-name" title={project.project_name}>{project.project_name}</strong>
                <span className="tenant-code-badge" aria-label={`Revision ${project.project_revision}`}>r{project.project_revision}</span>
              </dd>
            </div>
          ) : null}
        </dl>
        <div className="topbar-actions">
          <button
            aria-controls="workspace-navigation-links"
            aria-expanded={!globalNavigationCollapsed}
            aria-label={globalNavigationAction}
            className="mobile-sidebar-toggle"
            onClick={() => setGlobalNavigationCollapsed((collapsed) => !collapsed)}
            title={globalNavigationAction}
            type="button"
          >
            <PanelToggleIcon collapsed={globalNavigationCollapsed} />
          </button>
          <Link className="button button-secondary switch-tenant" to="/">
            Switch Tenant
          </Link>
          <span className="role-badge">{roleLabel(home.tenant.effective_role)}</span>
          <Avatar name={home.tenant.tenant_name} />
        </div>
      </header>

      <aside
        className="sidebar"
        aria-label="Workspace navigation"
        data-collapsed={globalNavigationCollapsed}
      >
        <div className="sidebar-header">
          <button
            aria-controls="workspace-navigation-links"
            aria-expanded={!globalNavigationCollapsed}
            aria-label={globalNavigationAction}
            className="sidebar-toggle"
            onClick={() => setGlobalNavigationCollapsed((collapsed) => !collapsed)}
            title={globalNavigationAction}
            type="button"
          >
            <PanelToggleIcon collapsed={globalNavigationCollapsed} />
            <span>{globalNavigationCollapsed ? "Show" : "Hide"}</span>
          </button>
        </div>
        <nav id="workspace-navigation-links">
          <Link
            aria-label="Home"
            className={`nav-item${activeNav === "home" ? " is-active" : ""}`}
            data-short-label="Home"
            to="/tenants/$tenantId"
            params={{ tenantId }}
            activeOptions={{ exact: true }}
            title="Home"
          >
            <HomeIcon /><span className="nav-item-label">Home</span>
          </Link>
          <Link
            aria-label="Metadata"
            className={`nav-item${activeNav === "metadata" ? " is-active" : ""}`}
            data-short-label="Metadata"
            to="/tenants/$tenantId/metadata"
            params={{ tenantId }}
            title="Metadata"
          >
            <DatabaseIcon /><span className="nav-item-label">Metadata</span>
          </Link>
          <Link
            aria-label="Projects"
            className={`nav-item${["projects", "mapping", "code-generation", "validation"].includes(activeNav) ? " is-active" : ""}`}
            data-short-label="Projects"
            to="/tenants/$tenantId/projects"
            params={{ tenantId }}
            title="Projects"
          >
            <ProjectIcon /><span className="nav-item-label">Projects</span>
          </Link>
          <Link
            aria-label="Prompts"
            className={`nav-item${activeNav === "prompts" ? " is-active" : ""}`}
            data-short-label="Prompts"
            to="/tenants/$tenantId/prompts"
            params={{ tenantId }}
            title="Prompts"
          >
            <PromptsIcon /><span className="nav-item-label">Prompts</span>
          </Link>
        </nav>
        {project ? (
          <div className="open-project">
            <small>Open Project</small>
            <strong>{project.project_name}</strong>
            <Link
              to="/tenants/$tenantId/projects/$projectId"
              params={{ tenantId, projectId: String(project.project_id) }}
              activeOptions={{ exact: true }}
            >
              Project overview →
            </Link>
          </div>
        ) : null}
      </aside>
      {children}
    </div>
  );
}
