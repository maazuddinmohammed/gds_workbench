import { WorkflowCommandCenter, WorkflowCommandTools, WorkflowFilters, WorkflowMenu } from "../workflows/WorkflowCommandCenter";
import { MultiSelectField } from "../../shared/MultiSelectField";
import { ProjectLayerTabs, type ProjectLayer } from "../../shared/ProjectLayerTabs";
import type { MappingEntityType } from "../mapping/api";
import { ProjectRecordReview } from "../project_record_review/ProjectRecordReview";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";

import { ApiError } from "../../core/http";
import { archiveDownloadError, saveArchiveDownload } from "../../shared/archiveDownload";
import type { ProjectDetail } from "../projects/api";
import { WorkflowRunMonitor } from "../workflows/WorkflowRunMonitor";
import { validationQueryKeys, type ValidationApi } from "./api";
import { ValidationLedger } from "./ValidationLedger";
import { ValidationRunDialog } from "./ValidationRunDialog";
import { ValidationInspector } from "./ValidationInspector";
import { RefreshButton } from "../../shared/ui";

export function ValidationScreen({
  api,
  tenantId,
  project,
  hasTenantLock,
  hasAppPermission,
  layer,
  groupId,
  checkId,
}: {
  layer: ProjectLayer;
  api: ValidationApi;
  tenantId: number;
  project: ProjectDetail;
  hasTenantLock: boolean;
  hasAppPermission: boolean;
  groupId?: number | undefined;
  checkId?: number | undefined;
}) {
  const queryClient = useQueryClient();
  const entityType: MappingEntityType = layer === "logical" ? "logical_entity" : "dimensional_entity";
  const reviewDataset = groupId === undefined ? "validation_group" : "validation_check";
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [inspected, setInspected] = useState<{ groupId: number; checkId: number; returnFocus: HTMLElement | null } | null>(null);
  const [systemFilter, setSystemFilter] = useState<string[]>([]);
  const [statusFilter, setStatusFilter] = useState("");
  const [lockFilter, setLockFilter] = useState("");
  const [runDialogOpen, setRunDialogOpen] = useState(false);
  const [startedRunId, setStartedRunId] = useState<number | null>(null);
  const download = useMutation({
    mutationFn: async () => saveArchiveDownload(await api.exportAllValidations(tenantId, project.project_id, {
      entity_type: entityType,
      expected_project_revision: project.project_revision,
    })),
  });
  const systemsQuery = useQuery({
    queryKey: validationQueryKeys.systems(tenantId, project.project_id, entityType),
    queryFn: () => api.listValidationEligibleSystems(tenantId, project.project_id, entityType),
  });
  const ledgerQuery = useQuery({
    queryKey: validationQueryKeys.ledger(tenantId, project.project_id, entityType),
    queryFn: () => api.readValidationLedger(tenantId, project.project_id, entityType),
  });
  const canAuthor = hasTenantLock && hasAppPermission;
  const systemsRevisionMismatch = systemsQuery.data !== undefined
    && systemsQuery.data.project_revision !== project.project_revision;
  const canOpenRun = canAuthor
    && !systemsQuery.isPending
    && !systemsQuery.isError
    && !systemsRevisionMismatch
    && Boolean(systemsQuery.data?.items.length);
  const permissionLabel = !hasAppPermission
    ? "Architect permission required to run Validation"
    : !hasTenantLock
      ? "Tenant Lock required to run Validation"
      : systemsQuery.isPending
        ? "Loading eligible Validation Systems"
        : systemsQuery.isError
          ? "Eligible Validation Systems are unavailable; refresh to try again"
          : systemsRevisionMismatch
            ? "The Project changed; refresh before running Validation"
            : !systemsQuery.data?.items.length
              ? "No eligible Systems are available for Validation"
              : "Tenant Lock held · ready to run Validation";
  const invalidateValidation = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ["validation-systems", tenantId, project.project_id] }),
      queryClient.invalidateQueries({ queryKey: ["validation-ledger", tenantId, project.project_id] }),
      queryClient.invalidateQueries({ queryKey: ["project", tenantId, project.project_id] }),
      queryClient.invalidateQueries({ queryKey: ["tenant-home", tenantId] }),
    ]);
  };
  const refresh = async () => {
    setSelectedIds(new Set());
    await invalidateValidation();
  };

  return (
    <WorkflowCommandCenter filterCount={Number(systemFilter.length > 0) + Number(Boolean(statusFilter)) + Number(Boolean(lockFilter))} className="mapping-workspace validation-workspace page-enter">
      <header className="workflow-commandbar validation-commandbar project-section-toolbar">
        <div className="workflow-command-context validation-command-context">
          <ProjectLayerTabs tenantId={tenantId} projectId={project.project_id} layer={layer} workflow="validation" title="Validation" />
          {checkId !== undefined && groupId !== undefined ? <Link
            className="text-action"
            search={{ layer }}
            aria-label="Back to Checks"
            to="/tenants/$tenantId/validation/projects/$projectId/groups/$groupId"
            params={{ tenantId: String(tenantId), projectId: String(project.project_id), groupId: String(groupId) }}
          >← Back to Checks</Link> : groupId !== undefined ? <Link
            className="text-action"
            search={{ layer }}
            aria-label="Back to Groups"
            to="/tenants/$tenantId/validation/projects/$projectId"
            params={{ tenantId: String(tenantId), projectId: String(project.project_id) }}
          >← Back to Groups</Link> : null}
          <span className={canAuthor ? "lock-context is-held" : "lock-context"}>
            {permissionLabel}
          </span>
        </div>
        <div className="workflow-command-actions">
          <WorkflowCommandTools filters={groupId === undefined} />
          <WorkflowMenu>
            <button type="button" className="button button-secondary button-small"
              disabled={download.isPending} onClick={() => download.mutate()}
              title="All active validation checks for this layer and shared groups, including stale checks, SQL and criteria; ignores table filters."
            >{download.isPending ? "Preparing validation export…" : "Export all validations"}</button>
          </WorkflowMenu>
          <RefreshButton
            refreshing={systemsQuery.isFetching || ledgerQuery.isFetching}
            onClick={() => void refresh()}
          />
          {groupId === undefined ? <button
            className="button button-primary button-small"
            type="button"
            disabled={!canOpenRun}
            title={permissionLabel}
            onClick={() => setRunDialogOpen(true)}
          >
            Run Validation
          </button> : null}
        </div>
      </header>
      {download.isPending ? <p role="status">Preparing all active validation checks for this layer and shared groups…</p> : null}
      {download.isError ? <p className="inline-error" role="alert">
        {archiveDownloadError(download.error, "validation")}{" "}
        <button type="button" className="text-action" onClick={() => download.mutate()}>Retry export</button>
      </p> : null}
      {systemsQuery.error instanceof ApiError && systemsQuery.error.status === 403 ? (
        <p className="inline-error validation-system-error" role="alert">
          You do not have permission to load eligible Validation Systems.
        </p>
      ) : systemsQuery.isError ? (
        <p className="inline-error validation-system-error" role="alert">
          Eligible Validation Systems could not be loaded. Refresh to try again.
        </p>
      ) : systemsRevisionMismatch ? (
        <p className="inline-error validation-system-error" role="alert">
          The Project changed while eligible Validation Systems were loading. Refresh before starting a run.
        </p>
      ) : systemsQuery.data?.is_truncated ? (
        <p className="code-generation-run-notice" role="status">
          The eligible Validation System register is truncated to its safe server bound.
        </p>
      ) : null}
      {startedRunId ? (
        <p className="code-generation-run-notice" role="status">
          Validation run {startedRunId} started. Refresh runs to review the draft, then Apply the validated draft.
        </p>
      ) : null}
      {groupId === undefined ? <WorkflowRunMonitor
        api={api}
        tenantId={tenantId}
        projectId={project.project_id}
        projectRevision={project.project_revision}
        workflow="validation"
        hasTenantLock={canAuthor}
        focusRunId={startedRunId}
        onApplied={invalidateValidation}
      /> : null}
      {checkId === undefined ? <ProjectRecordReview
        api={api} tenantId={tenantId} projectId={project.project_id} projectRevision={project.project_revision}
        dataset={reviewDataset} selectedIds={selectedIds} hasTenantLock={canAuthor}
        disabled={ledgerQuery.isPending || ledgerQuery.isError || ledgerQuery.data?.project_revision !== project.project_revision}
        onApplied={async () => { setSelectedIds(new Set()); await queryClient.invalidateQueries({ predicate: (query) => query.queryKey[1] === tenantId }); }}
      /> : null}
      {groupId === undefined ? <WorkflowFilters><div className="workflow-filterbar validation-filterbar">
        <MultiSelectField label="Systems" emptyLabel="All Systems" value={systemFilter} onChange={(value) => { setSystemFilter(value); setSelectedIds(new Set()); }}
          options={[...new Set((ledgerQuery.data?.groups ?? []).map((group) => group.system_code))].map((code) => [code, code])} />
        <label><span>Status</span><select aria-label="Status" value={statusFilter} onChange={(event) => { setStatusFilter(event.target.value); setSelectedIds(new Set()); }}>
          <option value="">All statuses</option><option value="current">Current</option><option value="stale">Stale</option>
        </select></label>
        <label><span>Lock</span><select aria-label="Lock" value={lockFilter} onChange={(event) => { setLockFilter(event.target.value); setSelectedIds(new Set()); }}>
          <option value="">All lock states</option><option value="unlocked">Unlocked</option><option value="locked">Locked</option>
        </select></label>
        <button className="button button-secondary button-small" type="button" onClick={() => { setSystemFilter([]); setStatusFilter(""); setLockFilter(""); setSelectedIds(new Set()); }}>Clear</button>
      </div></WorkflowFilters> : null}
      <ValidationLedger
        tenantId={tenantId}
        projectId={project.project_id}
        layer={layer}
        isFiltered={Boolean(systemFilter.length || statusFilter || lockFilter)}
        groupId={groupId}
        checkId={checkId}
        onShowDetails={groupId === undefined ? undefined : (nextGroupId, nextCheckId) => {
          if (nextCheckId === undefined) return;
          setInspected({ groupId: nextGroupId, checkId: nextCheckId,
            returnFocus: document.activeElement instanceof HTMLElement ? document.activeElement : null });
        }}
        selection={{ dataset: reviewDataset, selectedIds, onSelectionChange: setSelectedIds }}
        groups={(ledgerQuery.data?.groups ?? []).filter((group) => groupId !== undefined || (
          (!systemFilter.length || systemFilter.includes(group.system_code))
          && (!statusFilter || group.validation_group_is_current === (statusFilter === "current"))
          && (!lockFilter || group.is_locked === (lockFilter === "locked"))
        ))}
        projectRevision={project.project_revision}
        loadedProjectRevision={ledgerQuery.data?.project_revision}
        isLoading={ledgerQuery.isPending}
        error={ledgerQuery.error}
      />
      {inspected ? <ValidationInspector returnFocus={inspected.returnFocus} onClose={() => setInspected(null)}>
        <ValidationLedger tenantId={tenantId} projectId={project.project_id} layer={layer}
          groupId={inspected.groupId} checkId={inspected.checkId}
          groups={ledgerQuery.data?.groups ?? []} projectRevision={project.project_revision}
          loadedProjectRevision={ledgerQuery.data?.project_revision} isLoading={ledgerQuery.isPending} error={ledgerQuery.error} />
      </ValidationInspector> : null}
      {runDialogOpen && systemsQuery.data ? (
        <ValidationRunDialog
          api={api}
          tenantId={tenantId}
          project={project}
          entityType={entityType}
          systems={systemsQuery.data.items}
          systemsTruncated={systemsQuery.data.is_truncated}
          onClose={() => setRunDialogOpen(false)}
          onStarted={async (workflowRunId) => {
            setStartedRunId(workflowRunId);
            await invalidateValidation();
          }}
        />
      ) : null}
    </WorkflowCommandCenter>
  );
}
