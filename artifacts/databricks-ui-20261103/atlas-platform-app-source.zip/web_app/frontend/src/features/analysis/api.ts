import { ApiError, type HttpRequest } from "../../core/http";
import { METADATA_XLSX_MEDIA_TYPE } from "../metadata/api";
import type { ReviewStatus } from "../../shared/contracts";
import type { ProjectInputScopeApi } from "../project_input_scope/api";
import type { WorkflowsApi } from "../workflows/api";

export type AnalysisValidationState = "validated" | "unvalidated";
export type AnalysisValidationResult = "supported" | "inconclusive" | "unsupported";
export type AnalysisReviewAction = "lock" | "unlock" | "deactivate" | "reactivate";

export interface AnalysisReviewCommand {
  record_ids: number[];
  action: AnalysisReviewAction;
  expected_project_revision: number;
}

export interface AnalysisReviewResult {
  project_id: number;
  project_change_set_id: string;
  project_revision: number;
  action_count: number;
}

export interface AnalysisFilters {
  objectId?: number;
  validationState?: AnalysisValidationState;
  status?: ReviewStatus;
  locked?: boolean;
  showInactive?: boolean;
}

export interface AnalysisEndpoint {
  object_id: number;
  attribute_id: number;
  source_tenant_id: number;
  source_tenant_code: string;
  source_tenant_name: string;
  system_id: number;
  system_code: string;
  system_name: string;
  connection_id: number;
  connection_code: string;
  object_schema: string;
  object_name: string;
  attribute_name: string;
  attribute_data_type: string;
}

export interface AnalysisFinding {
  analysis_result_id: number;
  from_endpoint: AnalysisEndpoint;
  to_endpoint: AnalysisEndpoint;
  relationship_kind: string;
  validation_state: AnalysisValidationState;
  validation_result: AnalysisValidationResult | null;
  inferred_cardinality: "one_to_one" | "one_to_many" | "many_to_one" | "many_to_many" | "unknown";
  cardinality_mismatch: boolean;
  from_row_count: number | null;
  to_row_count: number | null;
  source_missing_target_count: number | null;
  unused_target_count: number | null;
  source_missing_target_percent: number | null;
  unused_target_percent: number | null;
  observed_cardinality: "one_to_one" | "one_to_many" | "many_to_one" | "many_to_many" | null;
  status: ReviewStatus;
  is_locked: boolean;
  updated_at: string;
}

export interface AnalysisFindingPage {
  project_id: number;
  project_revision: number;
  items: AnalysisFinding[];
  next_cursor: string | null;
}

export interface AnalysisEvidence {
  validation_policy_version: string;
  validation_policy_digest: string;
  result: AnalysisValidationResult;
  source_non_null_count: number;
  source_distinct_count: number;
  target_non_null_count: number;
  target_distinct_count: number;
  source_missing_target_count: number;
  unused_target_count: number;
  duplicate_target_key_count: number;
}

export interface AnalysisFindingDetail extends AnalysisFinding {
  evidence: AnalysisEvidence | null;
  provenance: {
    agent_run_id: string | null;
    inference_workflow_run_id: number | null;
    validation_workflow_run_id: number | null;
  };
  created_at: string;
}

export interface AnalysisTransport {
  exportAnalysis: (tenantId: number, projectId: number, revision: number, filters: AnalysisFilters) => Promise<{ blob: Blob; filename: string }>;
  listAnalysisFindings: (
    tenantId: number,
    projectId: number,
    filters?: AnalysisFilters,
    pageSize?: number,
    cursor?: string,
  ) => Promise<AnalysisFindingPage>;
  readAnalysisFinding: (
    tenantId: number,
    projectId: number,
    analysisResultId: number,
  ) => Promise<AnalysisFindingDetail>;
  reviewAnalysisFindings: (
    tenantId: number,
    projectId: number,
    command: AnalysisReviewCommand,
    idempotencyKey: string,
  ) => Promise<AnalysisReviewResult>;
}

export type AnalysisApi = AnalysisTransport
  & Pick<
    WorkflowsApi,
    | "applyWorkflowDraft"
  | "cancelWorkflowRun"
    | "createWorkflowRun"
    | "executeAnalysisInferenceRun"
    | "executeAnalysisValidationRun"
    | "listWorkflowRunEvents"
    | "listWorkflowRuns"
    | "readAgentCapabilities"
    | "readWorkflowDraftReview"
    | "readWorkflowRun"
  >
  & Pick<ProjectInputScopeApi, "listProjectInputScope">;

export function createAnalysisApi(request: HttpRequest): AnalysisTransport {
  return {
    exportAnalysis: (tenantId, projectId, revision, filters) => request(`/api/v1/tenants/${tenantId}/projects/${projectId}/analysis/export`, {
      method: "POST", headers: { "content-type": "application/json", accept: METADATA_XLSX_MEDIA_TYPE },
      body: JSON.stringify({ expected_project_revision: revision, filters: {
        object_id: filters.objectId, validation_state: filters.validationState, status: filters.status,
        locked: filters.locked, show_inactive: filters.showInactive ?? false,
      } }),
    }, async (response) => {
      if (response.headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase() !== METADATA_XLSX_MEDIA_TYPE) throw new ApiError(502, "invalid_response", null);
      return { blob: await response.blob(), filename: /filename="([A-Za-z0-9._-]{1,180}\.xlsx)"/.exec(response.headers.get("content-disposition") ?? "")?.[1] ?? "Analysis.xlsx" };
    }),
    listAnalysisFindings: (tenantId, projectId, filters = {}, pageSize = 200, cursor) => {
      const query = new URLSearchParams();
      if (filters.objectId) query.set("object_id", String(filters.objectId));
      if (filters.validationState) query.set("validation_state", filters.validationState);
      if (filters.status) query.set("status", filters.status);
      if (filters.locked !== undefined) query.set("locked", String(filters.locked));
      if (filters.showInactive) query.set("show_inactive", "true");
      query.set("page_size", String(pageSize));
      if (cursor) query.set("cursor", cursor);
      return request<AnalysisFindingPage>(
        `/api/v1/tenants/${tenantId}/projects/${projectId}/analysis?${query}`,
      );
    },
    readAnalysisFinding: (tenantId, projectId, analysisResultId) =>
      request<AnalysisFindingDetail>(
        `/api/v1/tenants/${tenantId}/projects/${projectId}/analysis/${analysisResultId}`,
      ),
    reviewAnalysisFindings: (tenantId, projectId, command, idempotencyKey) =>
      request<AnalysisReviewResult>(
        `/api/v1/tenants/${tenantId}/projects/${projectId}/change-sets/review`,
        {
          method: "POST",
          headers: { "content-type": "application/json", "Idempotency-Key": idempotencyKey },
          body: JSON.stringify({ dataset: "analysis_result", ...command }),
        },
      ),
  };
}

export const analysisQueryKeys = {
  findings: (tenantId: number, projectId: number, filters: unknown) => (
    ["analysis-findings", tenantId, projectId, filters] as const
  ),
  runs: (tenantId: number, projectId: number, state: string) => (
    ["analysis-runs", tenantId, projectId, state] as const
  ),
  endpointOptions: (tenantId: number, projectId: number) => (
    ["analysis-endpoint-options", tenantId, projectId] as const
  ),
};
