import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { useQuery } from "@tanstack/react-query";

import { ApiError } from "../../core/http";
import { trapDialogFocus, useDialogFocus } from "../../shared/dialog";
import { SelectField } from "../../shared/ui";
import type { ProjectDetail } from "../projects/api";
import { useWorkflowRunSubmission } from "../workflows/useWorkflowRunSubmission";
import {
  findAgentExecutionProfile,
  listCompatibleExecutionModes,
  reasoningEffortDisplayName,
  resolveAgentProfileSelection,
  resolveDefaultAgent,
  WORKFLOW_EXECUTION_MODE_NAMES,
  workflowCreationQueryKeys,
  type CreateWorkflowRunCommand,
} from "../workflows/api";
import { isTenantWorkflowConflict, TENANT_WORKFLOW_CONFLICT_MESSAGE } from "../workflows/presentation";
import {
  loadActiveMappingOutputTemplates,
  loadMappingGenerationTargets,
  mappingQueryKeys,
  type MappingApi,
  type MappingEntityType,
  type MappingGenerationTarget,
} from "./api";
import { MappingOutputTemplateSelection } from "./MappingOutputTemplateSelection";

type ExecutionMode = NonNullable<CreateWorkflowRunCommand["workflow_execution_mode"]>;
const targetKey = (target: MappingGenerationTarget) => `${target.entity_id}:${target.source_system.system_id}`;

export function MappingRunDialog({ api, tenantId, project, entityType, initialSystemCode, onClose, onCompleted }: {
  api: MappingApi;
  tenantId: number;
  project: ProjectDetail;
  entityType: MappingEntityType;
  /** The Mapping screen's System tab; the dialog starts filtered to it. */
  initialSystemCode?: string | undefined;
  onClose: () => void;
  onCompleted: (workflowRunId: number) => Promise<void>;
}) {
  const closeButton = useRef<HTMLButtonElement>(null);
  const attributeHeading = useRef<HTMLHeadingElement>(null);
  const returnToObject = useRef<string | null>(null);
  useDialogFocus(closeButton);
  const [scopeMode, setScopeMode] = useState<"all" | "selected">("all");
  const [system, setSystem] = useState(initialSystemCode ?? "");
  const [search, setSearch] = useState("");
  const [excluded, setExcluded] = useState<Set<string>>(new Set());
  const [attributes, setAttributes] = useState<Record<string, number[]>>({});
  const [viewedKey, setViewedKey] = useState<string | null>(null);
  const [attributePage, setAttributePage] = useState(0);
  const [executionMode, setExecutionMode] = useState<ExecutionMode>("tool_assisted");
  const [modelCode, setModelCode] = useState(project.default_agent_model_code ?? "");
  const [reasoningCode, setReasoningCode] = useState(project.default_reasoning_effort_code ?? "");
  const [objectTemplate, setObjectTemplate] = useState("");
  const [attributeTemplate, setAttributeTemplate] = useState("");
  const capabilities = useQuery({
    queryKey: workflowCreationQueryKeys.capabilities,
    queryFn: api.readAgentCapabilities,
  });
  const targets = useQuery({
    queryKey: ["mapping-generation-targets", tenantId, project.project_id, entityType],
    queryFn: () => loadMappingGenerationTargets(api, tenantId, project.project_id, entityType),
  });
  const templates = useQuery({
    queryKey: mappingQueryKeys.outputTemplates(tenantId, project.project_id, entityType),
    queryFn: () => loadActiveMappingOutputTemplates(api, tenantId, entityType),
  });
  const rows = useMemo(() => targets.data?.items ?? [], [targets.data?.items]);
  const systems = [...new Map(rows.map((row) => [row.source_system.system_code.toLowerCase(), row.source_system])).values()];
  // A tab's System may source nothing in this layer (only older saved Mappings); keep it
  // selected, with nothing to map, rather than widen the run to every System.
  const selectedSystem = systems.find((item) => item.system_code.toLowerCase() === system.toLowerCase())?.system_code ?? system;
  const systemOptions: [string, string][] = [["", "All Systems"], ...systems.map((item): [string, string] => [item.system_code, item.system_code])];
  if (selectedSystem && !systems.some((item) => item.system_code === selectedSystem)) systemOptions.push([selectedSystem, selectedSystem]);
  const scoped = rows.filter((row) => !selectedSystem || row.source_system.system_code === selectedSystem);
  const unsupplied = targets.data?.unsuppliedEntityCount ?? 0;
  // Search only narrows the list; it never silently removes a selected target from the run.
  const visible = scoped.filter((row) => `${row.entity_schema_name}.${row.entity_name} ${row.entity_name}`
    .toLowerCase().includes(search.trim().toLowerCase()));
  const eligible = scoped.filter((row) => !row.is_locked && row.attributes.length > 0);
  const eligibleKeys = new Set(eligible.map(targetKey));
  const selected = eligible.filter((row) => scopeMode === "all" || !excluded.has(targetKey(row)));
  const selectedKeys = new Set(selected.map(targetKey));
  const selectedAttributes = (row: MappingGenerationTarget) => attributes[targetKey(row)]
    ?? row.attributes.filter((attribute) => !attribute.is_locked).map((attribute) => attribute.attribute_id);
  const attributeCount = selected.reduce((count, row) => count + selectedAttributes(row).length, 0);
  const preservedCount = selected.reduce((count, row) => count + row.attributes.length - selectedAttributes(row).length, 0);
  const viewed = rows.find((row) => targetKey(row) === viewedKey);
  const viewedAttributes = viewed ? selectedAttributes(viewed) : [];
  const revisionChanged = targets.data !== undefined && targets.data.projectRevision !== project.project_revision;
  const models = capabilities.data?.models.filter((item) => findAgentExecutionProfile(item, executionMode)) ?? [];
  const profile = models.find((item) => item.code === modelCode);
  const efforts = capabilities.data?.reasoning_efforts.filter((item) => profile
    && findAgentExecutionProfile(profile, executionMode)?.reasoning_effort_codes.includes(item.code)) ?? [];
  const agent = capabilities.data ? resolveDefaultAgent(capabilities.data, executionMode, {
    modelCode,
    reasoningEffortCode: reasoningCode,
    maxTurns: project.default_max_turns,
    validationRetryCount: project.default_validation_retry_count,
  }) : null;
  const agentValid = agent !== null && agent.model_code === modelCode && agent.reasoning_effort_code === reasoningCode;

  useEffect(() => {
    if (!capabilities.data) return;
    const resolved = resolveAgentProfileSelection(capabilities.data, executionMode, { modelCode, reasoningEffortCode: reasoningCode });
    if (!resolved) return;
    setExecutionMode(resolved.executionMode);
    setModelCode(resolved.modelCode);
    setReasoningCode(resolved.reasoningEffortCode);
  }, [capabilities.data, executionMode, modelCode, reasoningCode]);
  useEffect(() => {
    setAttributePage(0);
    if (viewedKey !== null) attributeHeading.current?.focus();
    else if (returnToObject.current !== null) document.getElementById(`mapping-choose-${returnToObject.current}`)?.focus();
  }, [viewedKey]);

  const { mutation, pendingRunId } = useWorkflowRunSubmission({
    api,
    tenantId,
    projectId: project.project_id,
    execute: (id, command) => api.executeMappingRun(
      tenantId, project.project_id, id, command.workflow_execution_mode!, command.expected_project_revision,
    ),
    onSuccess: async (id) => { await onCompleted(id); onClose(); },
  });
  const frozen = mutation.isPending || pendingRunId !== null;
  const selectionUnavailable = frozen || targets.isPending || targets.isError || revisionChanged;
  const viewedSelected = viewedKey !== null && selectedKeys.has(viewedKey);

  function submit(event: FormEvent) {
    event.preventDefault();
    if (mutation.isPending) return;
    if (pendingRunId !== null) { mutation.mutate(undefined); return; }
    if (selectionUnavailable || !selected.length || !agentValid) return;
    mutation.mutate({
      expected_project_revision: project.project_revision,
      project_workflow: "mapping",
      workflow_execution_mode: executionMode,
      selected_object_ids: [],
      selected_entity_ids: [...new Set(selected.map((row) => row.entity_id))],
      modeled_entity_type: entityType,
      requested_batch_id: null,
      agent,
      prompt_overrides: {},
      mapping_operation: "generate",
      mapping_coverage_mode: "selected_targets",
      mapping_targets: selected.map((row) => ({
        modeled_entity_id: row.entity_id,
        source_system_id: row.source_system.system_id,
        selected_attribute_ids: selectedAttributes(row),
      })),
      mapping_object_output_template_id: objectTemplate ? Number(objectTemplate) : null,
      mapping_attribute_output_template_id: attributeTemplate ? Number(attributeTemplate) : null,
    });
  }

  return <div className="dialog-scrim" role="presentation">
    <section
      className="run-configuration-dialog mapping-run-dialog"
      role="dialog" aria-modal="true" aria-labelledby="mapping-run-heading"
      onKeyDown={(event) => {
        trapDialogFocus(event);
        if (event.key === "Escape" && !mutation.isPending) onClose();
      }}
    >
      <header className="drawer-header">
        <div>
          <h2 id="mapping-run-heading">Generate mappings</h2>
          <p>{entityType === "logical_entity" ? "Logical Entities" : "Dimensional Entities"}</p>
        </div>
        <button ref={closeButton} className="panel-close" type="button" aria-label="Close Generate mappings"
          disabled={mutation.isPending} onClick={onClose}>×</button>
      </header>
      <form onSubmit={submit}>
        <fieldset className="agent-run-grid" disabled={frozen}>
          <legend className="sr-only">Agent configuration</legend>
          <SelectField label="Execution mode" value={executionMode}
            options={capabilities.data ? listCompatibleExecutionModes(capabilities.data).map((mode) => [mode, WORKFLOW_EXECUTION_MODE_NAMES[mode]]) : []}
            onChange={(value) => setExecutionMode(value as ExecutionMode)} />
          <SelectField label="Model" value={modelCode} options={models.map((item) => [item.code, item.name])} onChange={setModelCode} />
          <SelectField label="Reasoning effort" value={reasoningCode}
            options={efforts.map((item) => [item.code, reasoningEffortDisplayName(item)])} onChange={setReasoningCode} />
        </fieldset>
        <fieldset className="mapping-target-selection" disabled={selectionUnavailable}>
          <legend className="sr-only">Mapping selection</legend>
          {!viewed ? <div className="agent-run-grid mapping-scope-controls">
            <SelectField label="Source System" value={selectedSystem} options={systemOptions} onChange={setSystem} />
          </div> : null}
          <fieldset className="scope-mode-options">
            <legend>Entities</legend>
            <label><input type="radio" name="mapping-object-scope" checked={scopeMode === "all"}
              onChange={() => setScopeMode("all")} /><span><strong>All unlocked Entities</strong></span></label>
            <label><input type="radio" name="mapping-object-scope" checked={scopeMode === "selected"}
              onChange={() => setScopeMode("selected")} /><span><strong>Selected Entities</strong></span></label>
          </fieldset>
          <div className="enrichment-selection-summary" aria-live="polite">
            <strong>{selected.length} Entity–System mappings · {attributeCount} Attributes to generate</strong>
            <span>{preservedCount} Attributes preserved. Locked and unselected mappings stay unchanged.</span>
          </div>
          <p className="field-help">{entityType === "logical_entity"
            ? "Each Entity is mapped only from the Systems its source tables come from."
            : "Each Entity is mapped only from the Systems its Logical sources are mapped from."} Available transformations are retained; missing selected transformations stay blank. Locked and unselected mappings are preserved.</p>
          {unsupplied ? <p className="field-help">{unsupplied} {entityType === "logical_entity"
            ? `Logical ${unsupplied === 1 ? "Entity has" : "Entities have"} no source System`
            : `Dimensional ${unsupplied === 1 ? "Entity has" : "Entities have"} no Logical source with complete Mapping yet`}, so {unsupplied === 1 ? "it is" : "they are"} not listed.</p> : null}
          {targets.isPending ? <div className="surface-state" aria-busy="true">Loading all Mapping targets and Attributes…</div>
            : targets.isError ? <p className="inline-error" role="alert">Targets could not be fully loaded.</p>
            : revisionChanged ? <p className="inline-error" role="alert">The Project changed. Close this dialog and refresh.</p>
            : viewed ? <section aria-label="Choose Entity Attributes">
              <button className="text-action" type="button" onClick={() => setViewedKey(null)}>Back to Entities</button>
              <header className="enrichment-selection-header">
                <div>
                  <small>{viewed.entity_schema_name} · {viewed.source_system.system_code}</small>
                  <h3 ref={attributeHeading} tabIndex={-1}>{viewed.entity_name}</h3>
                </div>
                <span>{viewedSelected ? viewedAttributes.length : 0} selected · {viewed.attributes.length - (viewedSelected ? viewedAttributes.length : 0)} unselected · {viewed.attributes.filter((item) => item.is_locked).length} locked</span>
              </header>
              <div className="enrichment-selection-actions">
                <button type="button" className="button button-secondary button-small" disabled={!viewedSelected}
                  onClick={() => setAttributes((previous) => ({ ...previous, [targetKey(viewed)]: viewed.attributes.filter((item) => !item.is_locked).map((item) => item.attribute_id) }))}>
                  Select all unlocked Attributes
                </button>
                <button type="button" className="button button-secondary button-small" disabled={!viewedSelected}
                  onClick={() => setAttributes((previous) => ({ ...previous, [targetKey(viewed)]: [] }))}>
                  Clear Attribute selection
                </button>
              </div>
              <div className="workflow-table-scroll table-scroll">
                <table className="enrichment-selection-table" aria-label={`Attributes for ${viewed.entity_name} from ${viewed.source_system.system_code}`}>
                  <thead><tr><th className="selection-cell"><span className="sr-only">Selected</span></th><th>Attribute</th><th>Mapping</th></tr></thead>
                  <tbody>{viewed.attributes.slice(attributePage * 50, (attributePage + 1) * 50).map((attribute) => <tr key={attribute.attribute_id}>
                    <td className="selection-cell"><input type="checkbox"
                      aria-label={`Generate ${viewed.entity_name}.${attribute.attribute_name} from ${viewed.source_system.system_code}`}
                      disabled={!viewedSelected || attribute.is_locked}
                      checked={viewedSelected && !attribute.is_locked && viewedAttributes.includes(attribute.attribute_id)}
                      onChange={(event) => setAttributes((previous) => ({
                        ...previous,
                        [targetKey(viewed)]: event.target.checked
                          ? [...viewedAttributes, attribute.attribute_id]
                          : viewedAttributes.filter((id) => id !== attribute.attribute_id),
                      }))} /></td>
                    <td>{attribute.attribute_name}</td>
                    <td>{attribute.is_locked ? "Locked · preserved" : attribute.is_authored ? "Existing" : "Missing"}</td>
                  </tr>)}</tbody>
                </table>
              </div>
              {viewed.attributes.length > 50 ? <div className="enrichment-pagination">
                <span>{attributePage * 50 + 1}–{Math.min((attributePage + 1) * 50, viewed.attributes.length)} of {viewed.attributes.length}</span>
                <button className="button button-secondary button-small" type="button" disabled={attributePage === 0}
                  onClick={() => setAttributePage((page) => page - 1)}>Previous Attributes</button>
                <button className="button button-secondary button-small" type="button" disabled={(attributePage + 1) * 50 >= viewed.attributes.length}
                  onClick={() => setAttributePage((page) => page + 1)}>Next Attributes</button>
              </div> : null}
            </section> : <>
              <div className="agent-run-grid mapping-scope-controls">
                <label><span>Find Entities</span><input type="search" value={search} placeholder="Schema or Entity"
                  onChange={(event) => setSearch(event.target.value)} /></label>
              </div>
              {scopeMode === "selected" ? <div className="enrichment-selection-actions">
                <button type="button" className="button button-secondary button-small" disabled={!visible.some((row) => eligibleKeys.has(targetKey(row)))}
                  onClick={() => setExcluded((previous) => {
                    const next = new Set(previous);
                    for (const row of visible) if (eligibleKeys.has(targetKey(row))) next.delete(targetKey(row));
                    return next;
                  })}>Select all shown Entities</button>
                <button type="button" className="button button-secondary button-small" disabled={!selected.length}
                  onClick={() => setExcluded((previous) => new Set([...previous, ...eligibleKeys]))}>Clear Entity selection</button>
              </div> : null}
              {search.trim() ? <p className="field-help">Showing {visible.length} of {scoped.length} mappings.</p> : null}
              <div className="workflow-table-scroll table-scroll">
                <table className="enrichment-selection-table" aria-label="Entities for Mapping">
                  <thead><tr><th className="selection-cell"><span className="sr-only">Selected</span></th><th>Schema</th><th>Entity</th><th>Source System</th><th>Attributes</th><th>Locks</th></tr></thead>
                  <tbody>{visible.map((row) => {
                    const key = targetKey(row);
                    const checked = selectedKeys.has(key);
                    const chosenCount = checked ? selectedAttributes(row).length : 0;
                    return <tr key={key}>
                      <td className="selection-cell"><input type="checkbox"
                        aria-label={`Generate ${row.entity_schema_name}.${row.entity_name} from ${row.source_system.system_code}`}
                        checked={checked} disabled={scopeMode === "all" || !eligibleKeys.has(key)}
                        onChange={(event) => setExcluded((previous) => {
                          const next = new Set(previous);
                          if (event.target.checked) next.delete(key); else next.add(key);
                          return next;
                        })} /></td>
                      <td>{row.entity_schema_name}</td>
                      <td><button type="button" className="text-action" id={`mapping-choose-${key}`}
                        aria-label={`Choose Attributes for ${row.entity_name} from ${row.source_system.system_code}`}
                        disabled={!checked} onClick={() => { returnToObject.current = key; setViewedKey(key); }}>
                        {row.entity_name}
                      </button></td>
                      <td>{row.source_system.system_code}</td>
                      <td>{chosenCount} selected · {row.attributes.length - chosenCount} unselected</td>
                      <td>{row.is_locked ? "Entity locked" : `${row.attributes.filter((item) => item.is_locked).length} locked`}</td>
                    </tr>;
                  })}</tbody>
                </table>
                {!visible.length ? <p className="empty-state compact">{selectedSystem && !scoped.length
                  ? `No Entity has ${selectedSystem} as a source System in this layer.`
                  : "No targets match. Each Entity needs an active source table in Project Input Scope (Dimensional: a Logical source with complete Mapping)."}</p> : null}
              </div>
            </>}
        </fieldset>
        {targets.isError ? <button type="button" className="text-action" disabled={frozen} onClick={() => void targets.refetch()}>Retry loading targets</button> : null}
        <details className="mapping-advanced"><summary>Advanced settings</summary>
          <MappingOutputTemplateSelection entityType={entityType}
            mappingObjects={templates.data?.mappingObjects ?? []} mappingAttributes={templates.data?.mappingAttributes ?? []}
            objectValue={objectTemplate} attributeValue={attributeTemplate} disabled={frozen || templates.isPending || templates.isError}
            onObjectChange={setObjectTemplate} onAttributeChange={setAttributeTemplate} />
        </details>
        {capabilities.isError || (capabilities.data && !agentValid) ? <p className="inline-error" role="alert">No compatible agent configuration is available. Refresh and check Project settings.</p> : null}
        {templates.isError ? <p className="field-help">Custom templates could not be loaded. Global defaults remain available.</p> : null}
        {mutation.isError ? <p className="inline-error" role="alert">{mappingRunError(mutation.error, pendingRunId !== null)}</p> : null}
        <footer className="dialog-actions">
          <button className="button button-secondary" type="button" disabled={mutation.isPending} onClick={onClose}>Cancel</button>
          <button className="button button-primary" type="submit"
            disabled={mutation.isPending || (pendingRunId === null && (selectionUnavailable || !selected.length || !agentValid))}>
            {mutation.isPending ? "Starting…" : pendingRunId !== null ? "Retry start" : "Generate mappings"}
          </button>
        </footer>
      </form>
    </section>
  </div>;
}

function mappingRunError(error: Error, runWasCreated: boolean): string {
  if (runWasCreated && isTenantWorkflowConflict(error)) return TENANT_WORKFLOW_CONFLICT_MESSAGE;
  if (runWasCreated) return "The Mapping run remains queued because it could not be started.";
  if (error instanceof ApiError && error.status === 403) return "You no longer have permission or the required Tenant Lock to run Mapping.";
  if (error instanceof ApiError && error.status === 409) return "The Project or Mapping state changed. Refresh before creating another run.";
  return "The Mapping run could not be created or started.";
}
