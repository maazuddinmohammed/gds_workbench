# Model Binding

Run only after target Metadata Apply succeeds and a fresh Metadata Snapshot confirms every target Object and Attribute.

Once those prerequisites are present, derive and author the bindings directly from the applied Logical/Dimensional records and registered target Metadata. Do not add an optional design-confirmation pause. Stop only when a required target is missing or more than one compatible match exists.

- `model_object_binding` binds one Logical Entity to one Silver Object or one Dimensional Entity to one Gold Object.
- `model_attribute_binding` binds each modeled Attribute to one Attribute under that Object Binding.
- Bind every modeled and physical target Attribute exactly once, including audit, technical, and constant-valued Attributes.
- Derive Model, Object, and Entity type from the parent binding instead of repeating them in Attribute Binding.
- Current server eligibility requires a target Object's `source_tenant_id` to equal the Model Tenant. Report a mismatch as a workflow limitation; never rewrite registered ownership to pass it. Physical Tenant/System/Connection still come from the GDS Connection.

Missing or ambiguous metadata blocks. Apply Binding through a Model Change Set, refresh the Model Snapshot, and stop before Mapping. Mapping never establishes Binding.
