# Server handoff

Load only after a positive acknowledgement of the exact local digest. Use the correct area tools dynamically; never invent tool names, IDs or revisions.

1. Check the Tenant Lock. The acknowledgement authorizes ordinary acquisition when unlocked. Another owner stops; override requires separate explicit authorization and a reason.
2. For Model work, re-read authoritative revision. On mismatch, follow `workflows/revision-recovery.md` **before** creating/caching a draft. Metadata has no tenant-wide revision: require a non-stale Snapshot and lock. Metadata Enrichment also rechecks its scope Model revision.
3. Inspect existing cache/proof **first**. If proof matches an active/validated staged draft, skip Stage and resume validation/Apply; never reset its status. For a failed-draft retry, retain its cached failure marker and old digest until the runner returns the newer Stage revision. Otherwise get/create the task's correct Metadata or Model Change Set, then bind its authoritative ID/revision with `draft-cache --session <session> --area metadata|model --id <UUID> --revision <n> --status active`. Never create a draft merely to inspect. For summary-only reads omit `dataset`.
4. Read `staging.md`. Run `prepare-stage-request` once, invoke `gds_stageApprovedManifest` using the exact field translation, and save the bounded proof described there. Cache the receipt's resulting revision as `active`; mark `task-state --task <ID> --state staged`.
5. Validate that exact server revision. Cache the returned revision/status as `validated` only on success. On `valid=false`, cache the active revision with `--validation-failed true`; repair locally, revalidate, notify, and obtain acknowledgement. Only this task's failed draft may be replaced; never substitute unrelated pending content.
6. Show bounded authoritative `action_review`; ask separately for Apply approval. Compare the current local digest and server ID/revision/fingerprint with the Stage proof before Apply; changed or missing proof stops handoff.
7. Apply once. On confirmed success run `task-state --task <ID> --state applied` (marks the area stale), release a lock acquired here, and install the required fresh Snapshot before dependent work. Uncertain Apply results require a summary read; never retry blindly.

Metadata Change Sets carry Metadata only; Model Change Sets carry Model records. Archive only on an explicit request. Do not manipulate task state or clear a cached draft to bypass a conflict.
