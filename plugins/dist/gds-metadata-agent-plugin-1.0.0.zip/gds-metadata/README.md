# GDS Metadata Agent Plugin

Portable Agent Plugin 1.0 for VS Code. It connects to the GDS Workbench MCP
server and teaches an agent the safe metadata read/change workflow.

## Install from this folder

1. Open VS Code Settings (JSON).
2. Enable Agent Plugins and register the extracted plugin directory:

   ```json
   {
     "chat.plugins.enabled": true,
     "chat.pluginLocations": {
       "/absolute/path/to/gds-metadata": true
     }
   }
   ```

3. Run `Developer: Reload Window`.
4. Run `Chat: Open Customizations` and confirm `gds-metadata` appears.
5. Run `MCP: List Servers`, start `gds-workbench`, and complete the Entra
   browser sign-in if VS Code requests it.
6. Run `Chat: Configure Skills` and confirm `manage-gds-metadata` appears.
7. In Agent chat, invoke `/gds-metadata:manage-gds-metadata`, or ask to inspect
   or change GDS metadata.

If this workspace already registers the remote server directly or through a
bridge in `.vscode/mcp.json`, disable those registrations while using the
plugin connection. Multiple registrations expose duplicate tool names.

## What is packaged

```text
gds-metadata/
├── plugin.json
├── mcp.json
├── README.md
└── skills/manage-gds-metadata/
    ├── SKILL.md
    ├── references/
    └── scripts/local_draft.py
```

`mcp.json` contains only the HTTPS endpoint. It contains no token, client
secret, password, or authorization header. VS Code owns client authentication;
the MCP server derives the Principal and Tenant authorization server-side.

## Quick smoke test

Ask the agent:

```text
List the GDS Tenants I can access. Do not make any changes.
```

Then confirm it uses `list_tenants` without acquiring a lock. For a change
request, confirm it checks/acquires the Tenant Lock and stops before Apply for
explicit approval.
