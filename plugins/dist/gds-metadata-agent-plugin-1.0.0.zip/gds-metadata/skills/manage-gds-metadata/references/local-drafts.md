# Local drafts

The local draft is the agent's working copy. It is separate from the immutable
snapshot and from the server-side Metadata Change Set.

Use the bundled `scripts/local_draft.py`. Resolve the script relative to this
`SKILL.md`, then run it with Python 3. It performs no network or MCP calls and
never prints record contents.

## Layout

```text
.gds-metadata/
├── .gitignore
├── snapshots/<snapshot-id>/metadata-snapshot/...
└── tenant-<tenant-id>/changes/<change-set-id>/
    ├── state.json
    └── datasets/<dataset>.json
```

Each dataset file is the complete local pending JSON array for one eligible
dataset. `state.json` stores control state, counts, and hashes—not a SAS URL.
The root `.gitignore` excludes everything except itself.

## Commands

Set `SCRIPT` to the absolute path of `scripts/local_draft.py` and use explicit,
resolved paths.

```bash
python "$SCRIPT" init-root --root .gds-metadata

python "$SCRIPT" new \
  --root .gds-metadata \
  --snapshot-dir .gds-metadata/snapshots/<snapshot-id>/metadata-snapshot \
  --tenant-id <tenant-id> \
  --change-set-id <uuid> \
  --draft-revision <revision>

python "$SCRIPT" upsert \
  --change-dir .gds-metadata/tenant-<tenant-id>/changes/<uuid> \
  --dataset <dataset> \
  --records <temporary-json-array-file>

python "$SCRIPT" status --change-dir <change-dir>
```

`upsert` validates full records against the matching snapshot schema, merges by
the schema's canonical key, checks local unique constraints, and writes
atomically. Text keys compare after trimming and case-folding. It never patches
individual fields.

After a successful Stage call, save the returned revision and staged hash:

```bash
python "$SCRIPT" mark-staged \
  --change-dir <change-dir> \
  --dataset <dataset> \
  --draft-revision <returned-revision>
```

After fetching a newer server revision during reconciliation:

```bash
python "$SCRIPT" set-revision \
  --change-dir <change-dir> \
  --draft-revision <server-revision>
```

Remove a record from the local pending list by supplying its complete canonical
key in a temporary JSON file. Do not place real metadata values directly in a
shell command:

```bash
python "$SCRIPT" remove \
  --change-dir <change-dir> \
  --dataset <dataset> \
  --key-json <canonical-key-json-file>
```

This removal affects the pending list only. It does not delete or deactivate a
database row. To deactivate an applied record, `upsert` its complete row with
`is_active: false`.

Before validation or Apply, check local/server synchronization:

```bash
python "$SCRIPT" status --change-dir <change-dir> --require-clean
```

`--require-clean` fails if a dataset changed after its last successful Stage or
if its staged revision became stale.

## Safe handling

- Create the ignored root before copying any snapshot or record into it.
- Never put records, SAS URLs, credentials, or raw tool output in command-line
  arguments. `--records` accepts a file; delete temporary inputs after merging.
- Do not edit snapshot files. Copy full rows into dataset draft files and edit
  the copies.
- Do not trust local validation as server validation. Always call
  `validate_metadata_change_set`, then Apply only after user confirmation.
