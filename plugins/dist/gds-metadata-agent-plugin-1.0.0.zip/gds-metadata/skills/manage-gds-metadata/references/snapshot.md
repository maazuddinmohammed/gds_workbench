# Metadata snapshot

Use a snapshot for broad metadata discovery or as the base for a change. It is
an immutable, ID-free view; it is not the Change Set.

## Download safely

1. Call `get_metadata_snapshot(tenant_id, schema_version="2.0")`.
2. Do not repeat its `download_url`. The full SAS query string is a temporary
   read credential for one private Blob.
3. Use a client-provided download action that does not expose the URL in logs or
   shell history. Otherwise ask the user to click the original link.
4. Put the extracted archive under the ignored local workspace described in
   `local-drafts.md`, never in a tracked source directory.
5. Verify ZIP byte count and SHA-256 against the tool result before trusting it.
6. Extract safely: reject absolute paths, `..`, links, and entries outside the
   destination.

The SAS expiry limits downloading. The extracted snapshot remains useful as a
local baseline, but obtain a fresh snapshot after acquiring the lock for a new
change workflow.

## Archive shape

```text
metadata-snapshot/
├── manifest.json
├── catalog.json
├── schemas/<dataset>.schema.json
└── data/
    ├── foundational/<dataset>/rows.jsonl
    ├── reference/<dataset>/rows.jsonl
    └── operational/<dataset>/{rows.jsonl,lookup.jsonl}
```

There are 29 logical datasets: 5 foundational, 8 reference, and 16
operational. Only the operational datasets are Change Set eligible.

## Read without filling context

1. Read `catalog.json` only.
2. Pick the exact dataset from its canonical key and search fields.
3. Search the catalog-provided `search_file` with an exact natural-key value.
4. For a wide dataset, `lookup.jsonl` returns compact fields plus a one-based
   `line`; read only that line from `rows.jsonl`.
5. For a compact dataset, the search file is already `rows.jsonl`.
6. Read `schemas/<dataset>.schema.json` only when constructing or checking a
   record.
7. Use `manifest.json` for integrity checks, not normal navigation.

Never recursively read or paste all JSONL files. Use filesystem search and
line-bounded reads. Keep only the chosen natural keys, counts, and file paths in
chat context.

## Schema meaning

The JSON Schema contains normal field validation plus:

- `x-gds-change-set-eligible`: whether it may be staged.
- `x-gds-canonical-key`: fields that identify one record.
- `x-gds-unique-constraints`: uniqueness groups to check locally.
- `x-gds-references`: natural-key foreign references.
- `x-gds-fixed-values`: values fixed by the logical dataset, such as Zone.

Rows are flat and ID-free. Foreign references use the target's natural-key
columns. Key comparisons trim text and compare it case-insensitively.

