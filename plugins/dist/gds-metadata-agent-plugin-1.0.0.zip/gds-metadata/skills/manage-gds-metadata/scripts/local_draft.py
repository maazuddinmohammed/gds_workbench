#!/usr/bin/env python3
"""Safely maintain local, ID-free GDS Metadata Change Set drafts."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import sys
from datetime import date, datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, cast
from uuid import UUID, uuid4


ROOT_NAME = ".gds-metadata"
GITIGNORE = b"*\n!.gitignore\n"
MAX_JSON_BYTES = 16_777_216
MAX_STATE_BYTES = 2_097_152
MAX_SNAPSHOT_MEMBER_BYTES = 268_435_456
DATASET_NAME = re.compile(r"^[a-z][a-z0-9_]*$")
SHA256 = re.compile(r"^[0-9a-f]{64}$")
SAS_SIGNATURE = re.compile(r"(?:^|[?&])sig=", re.IGNORECASE)
STATUSES = {"active", "validated", "applied", "expired", "archived", "superseded"}


class DraftError(Exception):
    """A bounded local-draft failure safe to print."""


def _absolute(path: Path) -> Path:
    return Path(os.path.abspath(os.fspath(path)))


def _assert_no_symlink_components(path: Path, *, allow_missing: bool = False) -> None:
    """Reject every existing symlink component without resolving through it."""
    absolute = _absolute(path)
    current = Path(absolute.anchor)
    missing = False
    for part in absolute.parts[1:]:
        current /= part
        if missing:
            continue
        try:
            item_stat = os.lstat(current)
        except FileNotFoundError:
            if allow_missing:
                missing = True
                continue
            raise DraftError("Required local path does not exist.") from None
        if stat.S_ISLNK(item_stat.st_mode):
            raise DraftError("Symbolic links are not allowed in local draft paths.")


def _require_directory(path: Path) -> None:
    _assert_no_symlink_components(path)
    try:
        item_stat = os.stat(path, follow_symlinks=False)
    except OSError:
        raise DraftError("Required local directory is unavailable.") from None
    if not stat.S_ISDIR(item_stat.st_mode):
        raise DraftError("Required local path is not a directory.")


def _require_descendant(path: Path, parent: Path) -> None:
    absolute_path = _absolute(path)
    absolute_parent = _absolute(parent)
    try:
        common = Path(os.path.commonpath((absolute_path, absolute_parent)))
    except ValueError:
        raise DraftError("Local path is outside the managed metadata root.") from None
    if common != absolute_parent or absolute_path == absolute_parent:
        raise DraftError("Local path is outside the managed metadata root.")


def _safe_relative_path(value: object, *, label: str) -> PurePosixPath:
    if not isinstance(value, str) or not value or "\\" in value:
        raise DraftError(f"{label} path is invalid.")
    relative = PurePosixPath(value)
    if relative.is_absolute() or any(
        part in {"", ".", ".."} for part in relative.parts
    ):
        raise DraftError(f"{label} path is invalid.")
    return relative


def _open_regular_file(path: Path) -> int:
    _assert_no_symlink_components(path)
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    try:
        descriptor = os.open(path, flags)
    except OSError:
        raise DraftError("Required local file is unavailable.") from None
    item_stat = os.fstat(descriptor)
    if not stat.S_ISREG(item_stat.st_mode):
        os.close(descriptor)
        raise DraftError("Required local path is not a regular file.")
    return descriptor


def _read_bytes(path: Path, *, max_bytes: int) -> bytes:
    descriptor = _open_regular_file(path)
    try:
        item_stat = os.fstat(descriptor)
        if item_stat.st_size > max_bytes:
            raise DraftError("Local JSON file exceeds its allowed size.")
        with os.fdopen(descriptor, "rb", closefd=False) as stream:
            payload = stream.read(max_bytes + 1)
        if len(payload) > max_bytes:
            raise DraftError("Local JSON file exceeds its allowed size.")
        return payload
    finally:
        os.close(descriptor)


def _read_json(path: Path, *, max_bytes: int = MAX_JSON_BYTES) -> Any:
    try:
        return json.loads(_read_bytes(path, max_bytes=max_bytes))
    except DraftError:
        raise
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise DraftError("Local JSON is invalid.") from None


def _read_json_input(value: str) -> Any:
    if value == "-":
        payload = sys.stdin.buffer.read(MAX_JSON_BYTES + 1)
        if len(payload) > MAX_JSON_BYTES:
            raise DraftError("Input JSON exceeds 16 MiB.")
        try:
            return json.loads(payload)
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise DraftError("Input JSON is invalid.") from None
    return _read_json(Path(value))


def _sha256_file(
    path: Path, *, max_bytes: int = MAX_SNAPSHOT_MEMBER_BYTES
) -> tuple[str, int]:
    descriptor = _open_regular_file(path)
    digest = hashlib.sha256()
    total = 0
    try:
        with os.fdopen(descriptor, "rb", closefd=False) as stream:
            while chunk := stream.read(1024 * 1024):
                total += len(chunk)
                if total > max_bytes:
                    raise DraftError("Snapshot member exceeds its allowed size.")
                digest.update(chunk)
    finally:
        os.close(descriptor)
    return digest.hexdigest(), total


def _contains_sas(value: object) -> bool:
    if isinstance(value, str):
        return SAS_SIGNATURE.search(value) is not None
    if isinstance(value, list):
        return any(_contains_sas(item) for item in value)
    if isinstance(value, dict):
        return any(
            _contains_sas(key) or _contains_sas(item) for key, item in value.items()
        )
    return False


def _atomic_write_bytes(path: Path, payload: bytes, *, mode: int = 0o600) -> None:
    parent = path.parent
    _require_directory(parent)
    if path.exists() or path.is_symlink():
        _assert_no_symlink_components(path)
        try:
            existing_stat = os.stat(path, follow_symlinks=False)
        except OSError:
            raise DraftError("Local output file is unavailable.") from None
        if not stat.S_ISREG(existing_stat.st_mode):
            raise DraftError("Local output target is not a regular file.")

    temporary = parent / f".{path.name}.tmp-{uuid4()}"
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    descriptor: int | None = None
    try:
        descriptor = os.open(temporary, flags, mode)
        with os.fdopen(descriptor, "wb", closefd=False) as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(descriptor)
        os.close(descriptor)
        descriptor = None
        os.replace(temporary, path)
        os.chmod(path, mode, follow_symlinks=False)
        directory_flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
        directory_descriptor = os.open(parent, directory_flags)
        try:
            os.fsync(directory_descriptor)
        finally:
            os.close(directory_descriptor)
    except DraftError:
        raise
    except OSError:
        raise DraftError("Atomic local write failed.") from None
    finally:
        if descriptor is not None:
            os.close(descriptor)
        try:
            os.unlink(temporary)
        except FileNotFoundError:
            pass


def _atomic_write_json(path: Path, value: object, *, max_bytes: int) -> str:
    if _contains_sas(value):
        raise DraftError("Refusing to persist an Azure SAS credential.")
    payload = (
        json.dumps(
            value,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            separators=(",", ": "),
        ).encode("utf-8")
        + b"\n"
    )
    if len(payload) > max_bytes:
        raise DraftError("Local JSON exceeds its allowed size.")
    _atomic_write_bytes(path, payload)
    return hashlib.sha256(payload).hexdigest()


def _mkdir(path: Path) -> None:
    _assert_no_symlink_components(path.parent)
    try:
        os.mkdir(path, 0o700)
    except FileExistsError:
        _require_directory(path)
    except OSError:
        raise DraftError("Could not create the managed local directory.") from None


def _root_path(raw_root: str) -> Path:
    root = _absolute(Path(raw_root))
    if root.name != ROOT_NAME:
        raise DraftError(f"Managed root must be named {ROOT_NAME}.")
    return root


def _initialize_root(raw_root: str) -> Path:
    root = _root_path(raw_root)
    _require_directory(root.parent)
    _mkdir(root)
    _mkdir(root / "snapshots")
    _atomic_write_bytes(root / ".gitignore", GITIGNORE)
    return root


def _load_root(raw_root: str) -> Path:
    root = _root_path(raw_root)
    _require_directory(root)
    _require_directory(root / "snapshots")
    _atomic_write_bytes(root / ".gitignore", GITIGNORE)
    return root


def _positive_integer(value: str) -> int:
    try:
        parsed = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError("must be a positive integer") from None
    if parsed <= 0 or parsed > 9_223_372_036_854_775_807:
        raise argparse.ArgumentTypeError("must be a positive PostgreSQL BIGINT")
    return parsed


def _positive_revision(value: str) -> int:
    try:
        parsed = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError("must be a positive integer") from None
    if parsed <= 0:
        raise argparse.ArgumentTypeError("must be a positive integer")
    return parsed


def _change_set_uuid(value: str) -> str:
    try:
        return str(UUID(value))
    except ValueError:
        raise argparse.ArgumentTypeError("must be a UUID") from None


def _snapshot_sha(value: str) -> str:
    normalized = value.strip().lower()
    if SHA256.fullmatch(normalized) is None:
        raise argparse.ArgumentTypeError("must be a lowercase SHA-256 digest")
    return normalized


def _json_type_matches(value: object, expected: str) -> bool:
    return {
        "null": value is None,
        "boolean": type(value) is bool,
        "integer": type(value) is int,
        "number": type(value) in {int, float},
        "string": isinstance(value, str),
        "array": isinstance(value, list),
        "object": isinstance(value, dict),
    }.get(expected, False)


def _validate_format(value: str, expected_format: str, field: str) -> None:
    try:
        if expected_format == "date":
            date.fromisoformat(value)
        elif expected_format == "date-time":
            datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        raise DraftError(
            f"Field {field} has an invalid {expected_format} value."
        ) from None


def _validate_schema_value(
    value: object, schema: dict[str, object], field: str
) -> None:
    alternatives = schema.get("anyOf", schema.get("oneOf"))
    if alternatives is not None:
        if not isinstance(alternatives, list):
            raise DraftError(f"Schema for field {field} is invalid.")
        for alternative in alternatives:
            if not isinstance(alternative, dict):
                continue
            try:
                _validate_schema_value(value, alternative, field)
                return
            except DraftError:
                continue
        raise DraftError(f"Field {field} does not match its allowed type.")

    if "const" in schema and value != schema["const"]:
        raise DraftError(f"Field {field} does not match its fixed value.")
    enum = schema.get("enum")
    if enum is not None:
        if not isinstance(enum, list) or value not in enum:
            raise DraftError(f"Field {field} is outside its allowed values.")

    expected_type = schema.get("type")
    if isinstance(expected_type, list):
        if not all(isinstance(item, str) for item in expected_type) or not any(
            _json_type_matches(value, item) for item in expected_type
        ):
            raise DraftError(f"Field {field} does not match its required type.")
    elif isinstance(expected_type, str):
        if not _json_type_matches(value, expected_type):
            raise DraftError(f"Field {field} does not match its required type.")
    elif expected_type is not None:
        raise DraftError(f"Schema for field {field} is invalid.")

    if isinstance(value, str):
        minimum_length = schema.get("minLength")
        maximum_length = schema.get("maxLength")
        if isinstance(minimum_length, int) and len(value) < minimum_length:
            raise DraftError(f"Field {field} is shorter than allowed.")
        if isinstance(maximum_length, int) and len(value) > maximum_length:
            raise DraftError(f"Field {field} is longer than allowed.")
        pattern = schema.get("pattern")
        if pattern is not None:
            if not isinstance(pattern, str):
                raise DraftError(f"Schema for field {field} is invalid.")
            try:
                matched = re.search(pattern, value) is not None
            except re.error:
                raise DraftError(
                    f"Schema pattern for field {field} is invalid."
                ) from None
            if not matched:
                raise DraftError(f"Field {field} does not match its required pattern.")
        expected_format = schema.get("format")
        if isinstance(expected_format, str):
            _validate_format(value, expected_format, field)

    if type(value) in {int, float}:
        checks = (
            ("minimum", lambda item, bound: item >= bound),
            ("maximum", lambda item, bound: item <= bound),
            ("exclusiveMinimum", lambda item, bound: item > bound),
            ("exclusiveMaximum", lambda item, bound: item < bound),
        )
        for keyword, check in checks:
            bound = schema.get(keyword)
            if type(bound) in {int, float} and not check(value, bound):
                raise DraftError(f"Field {field} is outside its allowed range.")

    if isinstance(value, list):
        minimum_items = schema.get("minItems")
        maximum_items = schema.get("maxItems")
        if isinstance(minimum_items, int) and len(value) < minimum_items:
            raise DraftError(f"Field {field} has too few items.")
        if isinstance(maximum_items, int) and len(value) > maximum_items:
            raise DraftError(f"Field {field} has too many items.")
        item_schema = schema.get("items")
        if isinstance(item_schema, dict):
            for item in value:
                _validate_schema_value(item, item_schema, field)

    if isinstance(value, dict):
        properties = schema.get("properties")
        if isinstance(properties, dict):
            required = schema.get("required", [])
            if not isinstance(required, list) or not all(
                isinstance(item, str) for item in required
            ):
                raise DraftError(f"Schema for field {field} is invalid.")
            missing = [item for item in required if item not in value]
            if missing:
                raise DraftError(f"Field {field} is missing required nested fields.")
            if schema.get("additionalProperties") is False:
                unknown = set(value).difference(properties)
                if unknown:
                    raise DraftError(f"Field {field} contains unknown nested fields.")
            for key, item in value.items():
                property_schema = properties.get(key)
                if isinstance(property_schema, dict):
                    _validate_schema_value(item, property_schema, f"{field}.{key}")


def _schema_contract(
    schema: object, *, expected_dataset: str, expected_path: str
) -> dict[str, object]:
    if not isinstance(schema, dict):
        raise DraftError("Dataset schema is invalid.")
    if schema.get("x-gds-dataset") != expected_dataset:
        raise DraftError("Dataset schema identity does not match its catalog entry.")
    if schema.get("$id") != expected_path:
        raise DraftError("Dataset schema path does not match its catalog entry.")
    if (
        schema.get("type") != "object"
        or schema.get("additionalProperties") is not False
    ):
        raise DraftError("Dataset schema must be a closed object schema.")
    properties = schema.get("properties")
    required = schema.get("required")
    canonical_key = schema.get("x-gds-canonical-key")
    unique_constraints = schema.get("x-gds-unique-constraints")
    if not isinstance(properties, dict) or not all(
        isinstance(name, str) and isinstance(definition, dict)
        for name, definition in properties.items()
    ):
        raise DraftError("Dataset schema properties are invalid.")
    if not isinstance(required, list) or not all(
        isinstance(name, str) and name in properties for name in required
    ):
        raise DraftError("Dataset schema required fields are invalid.")
    if (
        not isinstance(canonical_key, list)
        or not canonical_key
        or not all(
            isinstance(name, str) and name in properties for name in canonical_key
        )
    ):
        raise DraftError("Dataset canonical key is invalid.")
    if not isinstance(unique_constraints, list) or not unique_constraints:
        raise DraftError("Dataset unique constraints are invalid.")
    for constraint in unique_constraints:
        if (
            not isinstance(constraint, list)
            or not constraint
            or not all(
                isinstance(name, str) and name in properties for name in constraint
            )
        ):
            raise DraftError("Dataset unique constraint is invalid.")
    return schema


def _validate_record(
    record: object, schema: dict[str, object], dataset: str
) -> dict[str, object]:
    if not isinstance(record, dict) or not all(isinstance(key, str) for key in record):
        raise DraftError(f"Dataset {dataset} record must be a JSON object.")
    if _contains_sas(record):
        raise DraftError("Refusing to persist an Azure SAS credential.")
    properties = schema["properties"]
    required = schema["required"]
    assert isinstance(properties, dict)
    assert isinstance(required, list)
    missing = [name for name in required if name not in record]
    if missing:
        raise DraftError(f"Dataset {dataset} record is missing required fields.")
    unknown = set(record).difference(properties)
    if unknown:
        if any(name == "id" or name.endswith("_id") for name in unknown):
            raise DraftError(
                f"Dataset {dataset} record contains a forbidden database ID field."
            )
        raise DraftError(f"Dataset {dataset} record contains an unknown field.")
    for name, value in record.items():
        field_schema = properties[name]
        assert isinstance(field_schema, dict)
        _validate_schema_value(value, field_schema, name)
    return dict(record)


def _normalized_key(record: dict[str, object], fields: list[str]) -> tuple[object, ...]:
    values: list[object] = []
    for field in fields:
        value = record[field]
        values.append(value.strip().casefold() if isinstance(value, str) else value)
    return tuple(values)


def _validate_unique_constraints(
    records: list[dict[str, object]], schema: dict[str, object], dataset: str
) -> None:
    constraints = schema["x-gds-unique-constraints"]
    assert isinstance(constraints, list)
    for raw_constraint in constraints:
        assert isinstance(raw_constraint, list)
        constraint = [str(field) for field in raw_constraint]
        seen: set[tuple[object, ...]] = set()
        for record in records:
            key = _normalized_key(record, constraint)
            if key in seen:
                raise DraftError(
                    f"Dataset {dataset} contains a duplicate unique constraint."
                )
            seen.add(key)


def _snapshot_contract(
    snapshot_root: Path, *, verify_members: bool
) -> dict[str, object]:
    _require_directory(snapshot_root)
    if snapshot_root.name != "metadata-snapshot":
        raise DraftError(
            "Snapshot directory must be the extracted metadata-snapshot directory."
        )

    manifest_path = snapshot_root / "manifest.json"
    manifest = _read_json(manifest_path, max_bytes=MAX_STATE_BYTES)
    if not isinstance(manifest, dict):
        raise DraftError("Snapshot manifest is invalid.")
    if (
        manifest.get("schema_version") != "2.0"
        or manifest.get("snapshot_kind") != "metadata"
        or manifest.get("database_ids_included") is not False
    ):
        raise DraftError("Snapshot manifest is not an ID-free metadata snapshot.")
    try:
        snapshot_id = str(UUID(str(manifest["snapshot_id"])))
    except (KeyError, ValueError):
        raise DraftError("Snapshot manifest ID is invalid.") from None
    if snapshot_root.parent.name != snapshot_id:
        raise DraftError("Snapshot directory does not match its manifest ID.")

    manifest_sha, _ = _sha256_file(manifest_path, max_bytes=MAX_STATE_BYTES)
    members = manifest.get("members")
    if not isinstance(members, list):
        raise DraftError("Snapshot manifest members are invalid.")
    member_by_path: dict[str, dict[str, object]] = {}
    for member in members:
        if not isinstance(member, dict):
            raise DraftError("Snapshot manifest member is invalid.")
        relative = _safe_relative_path(member.get("path"), label="Snapshot member")
        member_path = relative.as_posix()
        digest = member.get("sha256")
        size_bytes = member.get("size_bytes")
        if (
            member_path in member_by_path
            or not isinstance(digest, str)
            or SHA256.fullmatch(digest) is None
            or type(size_bytes) is not int
            or size_bytes < 0
            or size_bytes > MAX_SNAPSHOT_MEMBER_BYTES
        ):
            raise DraftError("Snapshot manifest member metadata is invalid.")
        member_by_path[member_path] = member
        if verify_members:
            physical_path = snapshot_root.joinpath(*relative.parts)
            _require_descendant(physical_path, snapshot_root)
            actual_digest, actual_size = _sha256_file(physical_path)
            if actual_digest != digest or actual_size != size_bytes:
                raise DraftError("Snapshot member integrity check failed.")

    catalog_metadata = manifest.get("catalog")
    if not isinstance(catalog_metadata, dict):
        raise DraftError("Snapshot catalog metadata is invalid.")
    catalog_relative = _safe_relative_path(
        catalog_metadata.get("path"), label="Catalog"
    )
    catalog_path = snapshot_root.joinpath(*catalog_relative.parts)
    catalog_digest, _ = _sha256_file(catalog_path, max_bytes=MAX_STATE_BYTES)
    if catalog_metadata.get("sha256") != catalog_digest:
        raise DraftError("Snapshot catalog integrity check failed.")
    catalog = _read_json(catalog_path, max_bytes=MAX_STATE_BYTES)
    if not isinstance(catalog, dict) or catalog.get("schema_version") != "2.0":
        raise DraftError("Snapshot catalog is invalid.")

    sections = catalog.get("sections")
    if not isinstance(sections, list):
        raise DraftError("Snapshot catalog sections are invalid.")
    schemas: dict[str, dict[str, object]] = {}
    for section in sections:
        if not isinstance(section, dict) or not isinstance(
            section.get("datasets"), list
        ):
            raise DraftError("Snapshot catalog section is invalid.")
        for entry in section["datasets"]:
            if not isinstance(entry, dict):
                raise DraftError("Snapshot catalog dataset is invalid.")
            dataset = entry.get("name")
            schema_value = entry.get("schema_file")
            if (
                not isinstance(dataset, str)
                or DATASET_NAME.fullmatch(dataset) is None
                or not isinstance(schema_value, str)
            ):
                raise DraftError("Snapshot catalog dataset identity is invalid.")
            schema_relative = _safe_relative_path(schema_value, label="Schema")
            schema_path = snapshot_root.joinpath(*schema_relative.parts)
            _require_descendant(schema_path, snapshot_root)
            schema_digest, _ = _sha256_file(schema_path, max_bytes=MAX_STATE_BYTES)
            member = member_by_path.get(schema_relative.as_posix())
            if member is None or member.get("sha256") != schema_digest:
                raise DraftError("Snapshot schema integrity check failed.")
            schema = _schema_contract(
                _read_json(schema_path, max_bytes=MAX_STATE_BYTES),
                expected_dataset=dataset,
                expected_path=schema_relative.as_posix(),
            )
            if schema.get("x-gds-change-set-eligible") is True:
                schemas[dataset] = {
                    "path": schema_relative.as_posix(),
                    "sha256": schema_digest,
                    "schema": schema,
                }
    if not schemas:
        raise DraftError("Snapshot has no change-set-eligible datasets.")
    return {
        "snapshot_id": snapshot_id,
        "manifest_sha256": manifest_sha,
        "catalog_sha256": catalog_digest,
        "schemas": schemas,
    }


def _tenant_directory(root: Path, tenant_id: int) -> Path:
    return root / f"tenant-{tenant_id}"


def _draft_directory(root: Path, tenant_id: int, change_set_id: str) -> Path:
    return _tenant_directory(root, tenant_id) / "changes" / change_set_id


def _prepare_tenant_directories(root: Path, tenant_id: int) -> Path:
    tenant = _tenant_directory(root, tenant_id)
    _mkdir(tenant)
    changes = tenant / "changes"
    _mkdir(changes)
    return changes


def _state_path(draft: Path) -> Path:
    return draft / "state.json"


def _dataset_path(draft: Path, dataset: str) -> Path:
    if DATASET_NAME.fullmatch(dataset) is None:
        raise DraftError("Dataset name is invalid.")
    return draft / "datasets" / f"{dataset}.json"


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _public_schema_metadata(schemas: dict[str, dict[str, object]]) -> dict[str, object]:
    return {
        dataset: {"path": details["path"], "sha256": details["sha256"]}
        for dataset, details in sorted(schemas.items())
    }


def _load_draft(
    root: Path, tenant_id: int, change_set_id: str
) -> tuple[
    Path,
    dict[str, object],
    dict[str, dict[str, object]],
    dict[str, list[dict[str, object]]],
]:
    draft = _draft_directory(root, tenant_id, change_set_id)
    _require_directory(draft)
    _require_directory(draft / "datasets")
    state = _read_json(_state_path(draft), max_bytes=MAX_STATE_BYTES)
    if not isinstance(state, dict) or _contains_sas(state):
        raise DraftError("Local draft state is invalid.")
    if (
        state.get("format_version") != "1.0"
        or state.get("tenant_id") != tenant_id
        or state.get("metadata_change_set_id") != change_set_id
        or state.get("status") not in STATUSES
        or type(state.get("draft_revision")) is not int
        or int(state["draft_revision"]) <= 0
    ):
        raise DraftError("Local draft state does not match the requested Change Set.")

    snapshot_state = state.get("snapshot")
    if not isinstance(snapshot_state, dict):
        raise DraftError("Local draft snapshot state is invalid.")
    snapshot_path_value = snapshot_state.get("resolved_path")
    if not isinstance(snapshot_path_value, str) or SAS_SIGNATURE.search(
        snapshot_path_value
    ):
        raise DraftError("Local draft snapshot path is invalid.")
    snapshot_path = _absolute(Path(snapshot_path_value))
    _require_descendant(snapshot_path, root / "snapshots")
    contract = _snapshot_contract(snapshot_path, verify_members=False)
    raw_schemas = contract["schemas"]
    if not isinstance(raw_schemas, dict):
        raise DraftError("Snapshot schema registry is invalid.")
    schemas = cast(dict[str, dict[str, object]], raw_schemas)
    if (
        snapshot_state.get("snapshot_id") != contract["snapshot_id"]
        or snapshot_state.get("manifest_sha256") != contract["manifest_sha256"]
        or snapshot_state.get("catalog_sha256") != contract["catalog_sha256"]
        or snapshot_state.get("schemas") != _public_schema_metadata(schemas)
    ):
        raise DraftError("Snapshot contract changed after the local draft was created.")

    raw_datasets = state.get("datasets")
    if not isinstance(raw_datasets, dict):
        raise DraftError("Local draft dataset state is invalid.")
    rows_by_dataset: dict[str, list[dict[str, object]]] = {}
    for dataset, metadata in raw_datasets.items():
        if dataset not in schemas or not isinstance(metadata, dict):
            raise DraftError("Local draft references an ineligible dataset.")
        rows = _read_json(_dataset_path(draft, dataset))
        if not isinstance(rows, list):
            raise DraftError(f"Dataset {dataset} must contain a JSON array.")
        schema = schemas[dataset]["schema"]
        assert isinstance(schema, dict)
        validated = [_validate_record(record, schema, dataset) for record in rows]
        _validate_unique_constraints(validated, schema, dataset)
        digest, _ = _sha256_file(_dataset_path(draft, dataset))
        if (
            metadata.get("record_count") != len(validated)
            or metadata.get("sha256") != digest
            or type(metadata.get("dirty")) is not bool
        ):
            raise DraftError("Local dataset changed outside the safe draft helper.")
        rows_by_dataset[dataset] = validated
    return draft, state, schemas, rows_by_dataset


def _write_state(draft: Path, state: dict[str, object]) -> None:
    state["updated_at"] = _utc_now()
    _atomic_write_json(_state_path(draft), state, max_bytes=MAX_STATE_BYTES)


def _write_dataset(
    draft: Path,
    state: dict[str, object],
    dataset: str,
    records: list[dict[str, object]],
    *,
    dirty: bool,
) -> None:
    digest = _atomic_write_json(
        _dataset_path(draft, dataset), records, max_bytes=MAX_JSON_BYTES
    )
    datasets = state["datasets"]
    assert isinstance(datasets, dict)
    previous = datasets.get(dataset)
    last_staged_revision = (
        previous.get("last_staged_revision") if isinstance(previous, dict) else None
    )
    staged_sha256 = (
        previous.get("staged_sha256") if isinstance(previous, dict) else None
    )
    datasets[dataset] = {
        "record_count": len(records),
        "sha256": digest,
        "dirty": dirty,
        "last_staged_revision": last_staged_revision,
        "staged_sha256": staged_sha256,
    }
    _write_state(draft, state)


def _summary(
    state: dict[str, object], schemas: dict[str, dict[str, object]], *, operation: str
) -> dict[str, object]:
    raw_datasets = state["datasets"]
    assert isinstance(raw_datasets, dict)
    counts = {}
    dataset_states: dict[str, dict[str, object]] = {}
    for dataset in sorted(schemas):
        metadata = raw_datasets.get(dataset, {})
        assert isinstance(metadata, dict)
        record_count = int(metadata.get("record_count", 0))
        counts[dataset] = record_count
        dataset_states[dataset] = {
            "record_count": record_count,
            "dirty": bool(metadata.get("dirty", False)),
            "staged_revision": metadata.get("last_staged_revision"),
        }
    staged: dict[str, dict[str, int]] = {}
    dirty: list[str] = []
    for dataset, metadata in sorted(raw_datasets.items()):
        assert isinstance(metadata, dict)
        if metadata["dirty"]:
            dirty.append(dataset)
        revision = metadata.get("last_staged_revision")
        if type(revision) is int:
            staged[dataset] = {
                "record_count": int(metadata["record_count"]),
                "revision": revision,
            }
    snapshot = state["snapshot"]
    assert isinstance(snapshot, dict)
    return {
        "ok": True,
        "operation": operation,
        "tenant_id": state["tenant_id"],
        "metadata_change_set_id": state["metadata_change_set_id"],
        "snapshot_id": snapshot["snapshot_id"],
        "draft_revision": state["draft_revision"],
        "status": state["status"],
        "eligible_dataset_count": len(schemas),
        "total_record_count": sum(counts.values()),
        "dataset_counts": counts,
        "datasets": dataset_states,
        "dirty_datasets": dirty,
        "staged_datasets": staged,
    }


def _command_init_root(arguments: argparse.Namespace) -> dict[str, object]:
    root = _initialize_root(arguments.root)
    snapshot_count = sum(
        1
        for child in (root / "snapshots").iterdir()
        if child.is_dir() and not child.is_symlink()
    )
    tenant_count = sum(
        1
        for child in root.iterdir()
        if child.is_dir()
        and not child.is_symlink()
        and child.name.startswith("tenant-")
    )
    return {
        "ok": True,
        "operation": "init-root",
        "initialized": True,
        "snapshot_count": snapshot_count,
        "tenant_count": tenant_count,
    }


def _command_new(arguments: argparse.Namespace) -> dict[str, object]:
    root = _load_root(arguments.root)
    snapshot_root = _absolute(Path(arguments.snapshot_dir))
    _require_descendant(snapshot_root, root / "snapshots")
    contract = _snapshot_contract(snapshot_root, verify_members=True)
    snapshot_id = contract["snapshot_id"]
    if (
        snapshot_root.parent.parent != root / "snapshots"
        or snapshot_root.parent.name != snapshot_id
    ):
        raise DraftError(
            "Snapshot must be under snapshots/<snapshot-id>/metadata-snapshot."
        )
    changes = _prepare_tenant_directories(root, arguments.tenant_id)
    draft = changes / arguments.change_set_id
    if draft.exists() or draft.is_symlink():
        raise DraftError("Local draft already exists.")
    try:
        os.mkdir(draft, 0o700)
        os.mkdir(draft / "datasets", 0o700)
    except OSError:
        raise DraftError("Could not create the local draft.") from None

    schemas = contract["schemas"]
    assert isinstance(schemas, dict)
    state: dict[str, object] = {
        "format_version": "1.0",
        "tenant_id": arguments.tenant_id,
        "metadata_change_set_id": arguments.change_set_id,
        "draft_revision": arguments.draft_revision,
        "status": "active",
        "snapshot": {
            "resolved_path": str(snapshot_root),
            "snapshot_id": snapshot_id,
            **(
                {"zip_sha256": arguments.snapshot_sha256}
                if arguments.snapshot_sha256 is not None
                else {}
            ),
            "manifest_sha256": contract["manifest_sha256"],
            "catalog_sha256": contract["catalog_sha256"],
            "schemas": _public_schema_metadata(schemas),
        },
        "datasets": {},
        "created_at": _utc_now(),
        "updated_at": _utc_now(),
    }
    _write_state(draft, state)
    result = _summary(state, schemas, operation="new")
    result["change_dir"] = str(draft)
    return result


def _load_change_directory(
    raw_change_directory: str,
) -> tuple[
    Path,
    dict[str, object],
    dict[str, dict[str, object]],
    dict[str, list[dict[str, object]]],
]:
    draft = _absolute(Path(raw_change_directory))
    _require_directory(draft)
    if draft.parent.name != "changes" or not draft.parent.parent.name.startswith(
        "tenant-"
    ):
        raise DraftError("Change directory does not match the managed draft layout.")
    try:
        tenant_id = _positive_integer(draft.parent.parent.name.removeprefix("tenant-"))
        change_set_id = _change_set_uuid(draft.name)
    except argparse.ArgumentTypeError:
        raise DraftError("Change directory identity is invalid.") from None
    root = draft.parent.parent.parent
    if root.name != ROOT_NAME:
        raise DraftError(f"Managed root must be named {ROOT_NAME}.")
    loaded_root = _load_root(str(root))
    loaded = _load_draft(loaded_root, tenant_id, change_set_id)
    if loaded[0] != draft:
        raise DraftError("Change directory does not match its local state.")
    return loaded


def _command_upsert(arguments: argparse.Namespace) -> dict[str, object]:
    draft, state, schemas, rows_by_dataset = _load_change_directory(
        arguments.change_dir
    )
    if state["status"] not in {"active", "validated"}:
        raise DraftError("Terminal Change Set drafts cannot be edited.")
    if arguments.dataset not in schemas:
        raise DraftError("Dataset is not change-set eligible.")
    schema = schemas[arguments.dataset]["schema"]
    assert isinstance(schema, dict)
    incoming = _read_json_input(arguments.records)
    if not isinstance(incoming, list):
        raise DraftError("Upsert input must be a JSON array of full records.")
    incoming_records = [
        _validate_record(record, schema, arguments.dataset) for record in incoming
    ]
    records = list(rows_by_dataset.get(arguments.dataset, []))
    canonical_key = schema["x-gds-canonical-key"]
    assert isinstance(canonical_key, list)
    key_fields = [str(field) for field in canonical_key]
    inserted_count = 0
    replaced_count = 0
    for record in incoming_records:
        wanted = _normalized_key(record, key_fields)
        replaced = False
        for index, existing in enumerate(records):
            if _normalized_key(existing, key_fields) == wanted:
                records[index] = record
                replaced = True
                replaced_count += 1
                break
        if not replaced:
            records.append(record)
            inserted_count += 1
    _validate_unique_constraints(records, schema, arguments.dataset)
    state["status"] = "active"
    _write_dataset(draft, state, arguments.dataset, records, dirty=True)
    result = _summary(state, schemas, operation="upsert")
    result.update(
        {
            "dataset": arguments.dataset,
            "record_count": len(records),
            "inserted_count": inserted_count,
            "replaced_count": replaced_count,
        }
    )
    return result


def _command_remove(arguments: argparse.Namespace) -> dict[str, object]:
    draft, state, schemas, rows_by_dataset = _load_change_directory(
        arguments.change_dir
    )
    if state["status"] not in {"active", "validated"}:
        raise DraftError("Terminal Change Set drafts cannot be edited.")
    if arguments.dataset not in schemas:
        raise DraftError("Dataset is not change-set eligible.")
    schema = schemas[arguments.dataset]["schema"]
    assert isinstance(schema, dict)
    raw_key = arguments.key_json
    if raw_key.lstrip().startswith("{"):
        try:
            key_input = json.loads(raw_key)
        except json.JSONDecodeError:
            raise DraftError("Remove key JSON is invalid.") from None
    else:
        key_input = _read_json_input(raw_key)
    canonical_key = schema["x-gds-canonical-key"]
    properties = schema["properties"]
    assert isinstance(canonical_key, list)
    assert isinstance(properties, dict)
    key_fields = [str(field) for field in canonical_key]
    if not isinstance(key_input, dict) or set(key_input) != set(key_fields):
        raise DraftError("Remove key must contain exactly the canonical-key fields.")
    for field in key_fields:
        field_schema = properties[field]
        assert isinstance(field_schema, dict)
        _validate_schema_value(key_input[field], field_schema, field)
    if _contains_sas(key_input):
        raise DraftError("Refusing to persist an Azure SAS credential.")
    wanted = _normalized_key(key_input, key_fields)
    existing = rows_by_dataset.get(arguments.dataset, [])
    records = [
        record for record in existing if _normalized_key(record, key_fields) != wanted
    ]
    removed_count = len(existing) - len(records)
    if removed_count:
        state["status"] = "active"
        _write_dataset(draft, state, arguments.dataset, records, dirty=True)
    result = _summary(state, schemas, operation="remove")
    result.update(
        {
            "dataset": arguments.dataset,
            "record_count": len(records),
            "removed_count": removed_count,
        }
    )
    return result


def _command_mark_staged(arguments: argparse.Namespace) -> dict[str, object]:
    draft, state, schemas, rows_by_dataset = _load_change_directory(
        arguments.change_dir
    )
    if arguments.dataset not in schemas:
        raise DraftError("Dataset is not change-set eligible.")
    records = rows_by_dataset.get(arguments.dataset, [])
    server_record_count = (
        len(records) if arguments.record_count is None else arguments.record_count
    )
    if len(records) != server_record_count:
        raise DraftError("Server staged count does not match the local dataset count.")
    current_revision = state["draft_revision"]
    assert type(current_revision) is int
    datasets = state["datasets"]
    assert isinstance(datasets, dict)
    metadata = datasets.get(arguments.dataset)
    if not isinstance(metadata, dict):
        if server_record_count != 0:
            raise DraftError("Local staged dataset state is missing.")
        _write_dataset(draft, state, arguments.dataset, [], dirty=True)
        datasets = state["datasets"]
        assert isinstance(datasets, dict)
        metadata = datasets[arguments.dataset]
        assert isinstance(metadata, dict)

    if arguments.draft_revision < current_revision:
        raise DraftError("Cannot move the local draft revision backwards.")
    if arguments.draft_revision == current_revision:
        if metadata.get(
            "last_staged_revision"
        ) != arguments.draft_revision or metadata.get("staged_sha256") != metadata.get(
            "sha256"
        ):
            raise DraftError(
                "Staged revision does not advance the current local revision."
            )
    elif arguments.draft_revision == current_revision + 1:
        state["draft_revision"] = arguments.draft_revision
        state["status"] = "active"
        metadata["dirty"] = False
        metadata["last_staged_revision"] = arguments.draft_revision
        metadata["staged_sha256"] = metadata["sha256"]
        _write_state(draft, state)
    else:
        raise DraftError(
            "A Stage response must advance the local draft revision by exactly one."
        )
    return _summary(state, schemas, operation="mark-staged")


def _command_set_revision(arguments: argparse.Namespace) -> dict[str, object]:
    draft, state, schemas, _rows = _load_change_directory(arguments.change_dir)
    current_revision = state["draft_revision"]
    assert type(current_revision) is int
    if arguments.draft_revision < current_revision:
        raise DraftError("Cannot move the local draft revision backwards.")
    if arguments.draft_revision > current_revision:
        datasets = state["datasets"]
        assert isinstance(datasets, dict)
        for metadata in datasets.values():
            assert isinstance(metadata, dict)
            metadata["dirty"] = True
        state["status"] = "active"
    state["draft_revision"] = arguments.draft_revision
    if arguments.status is not None:
        state["status"] = arguments.status
    _write_state(draft, state)
    return _summary(state, schemas, operation="set-revision")


def _command_status(arguments: argparse.Namespace) -> dict[str, object]:
    _draft, state, schemas, _rows = _load_change_directory(arguments.change_dir)
    result = _summary(state, schemas, operation="status")
    if arguments.require_clean and result["dirty_datasets"]:
        raise DraftError("Local draft has datasets that have not been staged.")
    return result


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Maintain safe local GDS Metadata Change Set draft files."
    )
    commands = parser.add_subparsers(dest="command", required=True)

    def common(command: argparse.ArgumentParser) -> None:
        command.add_argument(
            "--root",
            default=ROOT_NAME,
            help=f"Managed local root; final directory name must be {ROOT_NAME}.",
        )

    init_root = commands.add_parser(
        "init-root", help="Create and protect the local root."
    )
    common(init_root)
    init_root.set_defaults(handler=_command_init_root)

    new = commands.add_parser(
        "new", help="Create a draft bound to an extracted snapshot."
    )
    common(new)
    new.add_argument("--tenant-id", required=True, type=_positive_integer)
    new.add_argument("--change-set-id", required=True, type=_change_set_uuid)
    new.add_argument("--snapshot-dir", required=True)
    new.add_argument("--snapshot-sha256", type=_snapshot_sha)
    new.add_argument("--draft-revision", type=_positive_revision, default=1)
    new.set_defaults(handler=_command_new)

    def draft(command: argparse.ArgumentParser) -> None:
        command.add_argument("--change-dir", required=True)

    upsert = commands.add_parser(
        "upsert", help="Insert or fully replace one keyed record."
    )
    draft(upsert)
    upsert.add_argument("--dataset", required=True)
    upsert.add_argument(
        "--records", required=True, help="JSON array file, or - for stdin."
    )
    upsert.set_defaults(handler=_command_upsert)

    remove = commands.add_parser(
        "remove", help="Remove one record from the local pending list."
    )
    draft(remove)
    remove.add_argument("--dataset", required=True)
    remove.add_argument(
        "--key-json",
        required=True,
        help="Inline canonical-key JSON object or a JSON file path.",
    )
    remove.set_defaults(handler=_command_remove)

    mark_staged = commands.add_parser(
        "mark-staged", help="Record a successful stage_metadata_change_set response."
    )
    draft(mark_staged)
    mark_staged.add_argument("--dataset", required=True)
    mark_staged.add_argument("--draft-revision", required=True, type=_positive_revision)
    mark_staged.add_argument("--record-count", type=int)
    mark_staged.set_defaults(handler=_command_mark_staged)

    set_revision = commands.add_parser(
        "set-revision", help="Reconcile local revision/status with server state."
    )
    draft(set_revision)
    set_revision.add_argument(
        "--draft-revision", required=True, type=_positive_revision
    )
    set_revision.add_argument("--status", choices=sorted(STATUSES))
    set_revision.set_defaults(handler=_command_set_revision)

    status = commands.add_parser("status", help="Print counts and safe state only.")
    draft(status)
    status.add_argument("--require-clean", action="store_true")
    status.set_defaults(handler=_command_status)
    return parser


def main() -> int:
    arguments = _parser().parse_args()
    try:
        if (
            arguments.command == "mark-staged"
            and arguments.record_count is not None
            and arguments.record_count < 0
        ):
            raise DraftError("Record count cannot be negative.")
        result = arguments.handler(arguments)
        print(json.dumps(result, separators=(",", ":"), sort_keys=True))
        return 0
    except DraftError as error:
        print(
            json.dumps(
                {"ok": False, "error": str(error)},
                separators=(",", ":"),
                sort_keys=True,
            ),
            file=sys.stderr,
        )
        return 2
    except Exception:
        print(
            '{"error":"Unexpected local helper failure.","ok":false}', file=sys.stderr
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
