---
name: manage-gds-metadata
description: Inspect or change GDS Tenant metadata through the GDS Workbench MCP server. Use for metadata snapshots, Objects and Attributes, mappings, Copy Groups and Copies, Process Groups and Processes, Tenant Locks, or Metadata Change Sets.
---

# Manage GDS metadata

Use only the governed `gds-workbench` MCP tools. Never use direct SQL, direct
table writes, foundational/reference mutation, arbitrary CRUD, or lock-table
updates.

## Choose the path

- For a small read, use the bounded Tenant/Object/Copy Group/Process Group read
  tools. Do not create a lock or Change Set.
- For broad discovery, use a metadata snapshot and read it selectively.
- For any metadata change, follow the complete workflow below.

Read [references/tools.md](references/tools.md) before constructing unfamiliar
tool calls. Read [references/snapshot.md](references/snapshot.md) before using a
snapshot. Read [references/change-sets.md](references/change-sets.md) before
staging, validating, applying, or archiving.

## Change workflow

1. Identify the exact Tenant with `list_tenants` or `get_tenant_details`.
   Never infer a Tenant from a name fragment.
2. Call `check_tenant_lock`.
   - Unlocked: call `acquire_tenant_lock` for the current user.
   - Owned by the current user: continue; renew before it expires.
   - Owned by another Principal: stop and tell the user who owns it. Do not
     override automatically.
3. Call `get_metadata_snapshot` after owning the lock. Treat its complete SAS
   URL as a temporary credential. Do not print, log, save, or commit it. Ask the
   user to download/extract it when the client cannot do so safely. Verify the
   downloaded byte count and SHA-256.
4. Read only `catalog.json` first. Search only the affected dataset search
   files. Load an exact full row and its schema only when required. Never load
   the whole archive into chat.
5. Restate the requested change in concrete records and natural keys. Ask only
   questions whose answers change the records. Metadata rows must be ID-free;
   Tenant ID and Change Set ID remain valid tool control inputs.
6. Call `create_metadata_change_set`. It may create a draft or return the
   caller's existing active draft. Keep the returned Change Set ID and
   `draft_revision`. If `created` is false, immediately get its summary and
   fetch each dataset you will edit before building locally; otherwise a Stage
   call could replace pending work you have not seen.
7. Create a local draft outside the immutable snapshot. Use
   [references/local-drafts.md](references/local-drafts.md) and the bundled
   `scripts/local_draft.py`. Keep one JSON array per affected dataset.
8. Build every item as a complete record using the live
   `stage_metadata_change_set` input schema and the snapshot dataset schema.
   Do not invent fields or database IDs. Preserve unchanged fields when
   updating or deactivating an existing record.
9. Stage one affected dataset at a time in dependency order. Send the complete
   accumulated local list for that dataset, not a patch or one new item. Pass
   the latest global `draft_revision` and replace it with the returned revision
   after every successful call.
10. Call `get_metadata_change_set` without a dataset to compare counts. Request
    one dataset only when reconciling a conflict or uncertain server state.
11. Call `validate_metadata_change_set` with the latest revision. It reports the
    first failed phase. Fix locally, restage the complete affected dataset,
    update the revision, and validate again. Any restage invalidates the prior
    validation.
12. Show the user a compact review: Tenant, Change Set ID, datasets/counts,
    natural keys, intended insert/update/deactivation results, and validation
    status. Obtain explicit confirmation immediately before
    `apply_metadata_change_set`.
13. Apply with the latest revision. Apply revalidates and commits all datasets
    atomically. Report the server result; do not claim success from local state.
14. Verify the Change Set status, then release the Tenant Lock. If work is
    abandoned, confirm when needed, archive the draft, and release the lock.

## Hard safety rules

- Require explicit user direction and a reason immediately before
  `override_tenant_lock`. Override only releases the old lock; recheck and
  acquire separately.
- Require explicit user confirmation immediately before Apply.
- Never apply on a revision conflict. Fetch, reconcile, then ask for review
  again if the intended result changed.
- Never restage an existing or conflicted dataset until its current server list
  has been fetched and merged into the complete local list.
- Never delete applied metadata. An empty staged list clears only that pending
  dataset. To deactivate, stage the complete record with `is_active: false`.
- Existing natural key means update; a new natural key means insert.
- A locked Object blocks changes to it and its Attributes. Let validation and
  Apply enforce the server rule.
- Never commit snapshots, local drafts, SAS URLs, credentials, raw tool output,
  or raw physical rows.
- Do not paste large tool or file output into chat. Summarize counts and natural
  keys instead.

## Context limits

- Keep `catalog.json`, not the entire snapshot, as navigation context.
- Use lookup lines for wide datasets; read the pointed `rows.jsonl` line only.
- Read schemas only for datasets currently being edited.
- Request only one staged dataset when record-level reconciliation is needed.
- Keep full working records in local JSON files, not repeated chat messages.
