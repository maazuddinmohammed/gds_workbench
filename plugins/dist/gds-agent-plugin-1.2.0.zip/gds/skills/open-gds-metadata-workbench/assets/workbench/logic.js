(function (root) {
  "use strict";

  const ELIGIBLE_DATASETS = Object.freeze([
    "source_object", "source_attribute", "bronze_object", "bronze_attribute",
    "silver_object", "silver_attribute", "gold_object", "gold_attribute",
    "ingestion_object_mapping", "ingestion_attribute_mapping", "copy_group",
    "member_group", "copy_group_control", "copy", "process_group", "process"
  ]);
  const MAX_DATASET_RECORDS = 50000;
  const MAX_DATASET_BYTES = 16777216;
  const eligible = new Set(ELIGIBLE_DATASETS);

  function clone(value) {
    return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
  }

  function safePathParts(path) {
    if (typeof path !== "string" || !path || path.includes("\\") || path.startsWith("/")) {
      throw new Error("Snapshot contains an unsafe file path.");
    }
    const parts = path.split("/");
    if (parts.some((part) => !part || part === "." || part === ".." || part.includes(":"))) {
      throw new Error("Snapshot contains an unsafe file path.");
    }
    return parts;
  }

  function parseJson(text, label) {
    try {
      return JSON.parse(String(text).replace(/^\uFEFF/, ""));
    } catch (error) {
      throw new Error(`${label} is not valid JSON (${error.message}).`);
    }
  }

  function parseRows(text, path) {
    const value = String(text).replace(/^\uFEFF/, "");
    if (/\.(jsonl|ndjson)$/i.test(path)) {
      const rows = [];
      value.split(/\r?\n/).forEach((line, index) => {
        if (!line.trim()) return;
        const row = parseJson(line, `${path} line ${index + 1}`);
        if (!isObject(row)) throw new Error(`${path} line ${index + 1} must be a JSON object.`);
        rows.push(row);
      });
      return rows;
    }
    const parsed = parseJson(value, path);
    if (!Array.isArray(parsed) || parsed.some((row) => !isObject(row))) {
      throw new Error(`${path} must contain one JSON array of objects.`);
    }
    return parsed;
  }

  function isObject(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
  }

  function keyNormalization(schema) {
    const value = schema?.["x-gds-key-normalization"];
    if (!isObject(value) || value.version !== "1.0" ||
        value.string_field_suffixes?.join("\u001f") !== "_code\u001f_name\u001f_schema" ||
        value.trim_code_points?.join("\u001f") !== "U+0020" ||
        value.case !== "unicode-lowercase" || value.unicode_normalization !== "none" ||
        value.other_values !== "identity") {
      throw new Error("Dataset schema has no valid GDS key-normalization contract.");
    }
    return value;
  }

  function normalizeKeyValue(column, value, schema) {
    const normalization = keyNormalization(schema);
    if (typeof value === "string" && normalization.string_field_suffixes.some((suffix) => column.endsWith(suffix))) {
      return value.replace(/^ +| +$/g, "").toLowerCase();
    }
    if (typeof value === "string") return value;
    if (value === null) return "null";
    return JSON.stringify(value);
  }

  function keyFor(record, columns, schema) {
    return JSON.stringify(columns.map((column) => {
      const value = record[column];
      return [value === null ? "null" : typeof value, normalizeKeyValue(column, value, schema)];
    }));
  }

  function canonicalColumns(schema) {
    const columns = schema && schema["x-gds-canonical-key"];
    if (!Array.isArray(columns) || !columns.length || columns.some((name) => typeof name !== "string" || !name)) {
      throw new Error("Dataset schema has no valid GDS canonical key.");
    }
    return columns;
  }

  function assertEligibleSchema(dataset, schema) {
    if (!eligible.has(dataset) || schema?.["x-gds-dataset"] !== dataset || schema?.["x-gds-change-set-eligible"] !== true) {
      throw new Error(`${dataset} is not Change Set eligible.`);
    }
    keyNormalization(schema);
  }

  function candidateSchemas(property) {
    if (Array.isArray(property?.anyOf)) return property.anyOf;
    return [property || {}];
  }

  function validDate(value) {
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
    if (!match) return false;
    const year = Number(match[1]);
    const month = Number(match[2]);
    const day = Number(match[3]);
    const date = new Date(Date.UTC(year, month - 1, day));
    return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
  }

  function validDateTime(value) {
    return /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.test(value) && !Number.isNaN(Date.parse(value));
  }

  function typeMatches(value, type) {
    if (!type) return true;
    if (type === "null") return value === null;
    if (type === "string") return typeof value === "string";
    if (type === "boolean") return typeof value === "boolean";
    if (type === "integer") return Number.isInteger(value);
    if (type === "number") return typeof value === "number" && Number.isFinite(value);
    if (type === "array") return Array.isArray(value);
    if (type === "object") return isObject(value);
    return true;
  }

  function scalarIssue(value, property) {
    const candidates = candidateSchemas(property);
    const candidate = candidates.find((item) => typeMatches(value, item.type));
    if (!candidate) {
      const expected = candidates.map((item) => item.type).filter(Boolean).join(" or ");
      return `Expected ${expected || "the schema type"}.`;
    }
    const rules = { ...property, ...candidate };
    if (Object.prototype.hasOwnProperty.call(rules, "const") && value !== rules.const) {
      return `Must equal ${JSON.stringify(rules.const)}.`;
    }
    if (Array.isArray(rules.enum) && !rules.enum.some((item) => item === value)) {
      return `Must be one of ${rules.enum.map((item) => JSON.stringify(item)).join(", ")}.`;
    }
    if (typeof value === "string") {
      if (Number.isInteger(rules.minLength) && value.length < rules.minLength) return `Must contain at least ${rules.minLength} characters.`;
      if (Number.isInteger(rules.maxLength) && value.length > rules.maxLength) return `Must contain at most ${rules.maxLength} characters.`;
      if (typeof rules.pattern === "string") {
        try {
          if (!new RegExp(rules.pattern, "u").test(value)) return "Does not match the required text pattern.";
        } catch (_) {
          return "The Snapshot schema contains an invalid text pattern.";
        }
      }
      if (rules.format === "date" && !validDate(value)) return "Must be a valid YYYY-MM-DD date.";
      if (rules.format === "date-time" && !validDateTime(value)) return "Must be a valid ISO 8601 date-time with a timezone.";
    }
    if (typeof value === "number") {
      if (typeof rules.minimum === "number" && value < rules.minimum) return `Must be at least ${rules.minimum}.`;
      if (typeof rules.maximum === "number" && value > rules.maximum) return `Must be at most ${rules.maximum}.`;
      if (typeof rules.exclusiveMinimum === "number" && value <= rules.exclusiveMinimum) return `Must be greater than ${rules.exclusiveMinimum}.`;
      if (typeof rules.exclusiveMaximum === "number" && value >= rules.exclusiveMaximum) return `Must be less than ${rules.exclusiveMaximum}.`;
    }
    return "";
  }

  function validateSchema(schema, dataset, requireEligible = false) {
    if (!isObject(schema) || schema.type !== "object" || schema.additionalProperties !== false ||
        !isObject(schema.properties) || !Array.isArray(schema.required) ||
        schema["x-gds-dataset"] !== dataset || !Array.isArray(schema["x-gds-canonical-key"]) ||
        !Array.isArray(schema["x-gds-unique-constraints"]) ||
        (requireEligible && schema["x-gds-change-set-eligible"] !== true)) {
      throw new Error("Snapshot dataset schema contract is invalid.");
    }
    keyNormalization(schema);
    canonicalColumns(schema);
    return schema;
  }

  function validateRecord(record, schema) {
    const errors = [];
    if (!isObject(record)) return [{ field: "$", message: "Record must be a JSON object." }];
    const properties = isObject(schema?.properties) ? schema.properties : {};
    const required = Array.isArray(schema?.required) ? schema.required : [];
    for (const field of required) {
      if (!Object.prototype.hasOwnProperty.call(record, field)) errors.push({ field, message: "Required field is missing." });
    }
    for (const field of Object.keys(record)) {
      const normalized = field.toLocaleLowerCase("en-US");
      if (normalized === "id" || normalized.endsWith("_id")) {
        errors.push({ field, message: "Database IDs are forbidden." });
        continue;
      }
      if (!Object.prototype.hasOwnProperty.call(properties, field)) {
        errors.push({ field, message: "Unknown fields and database IDs are not allowed." });
        continue;
      }
      const issue = scalarIssue(record[field], properties[field]);
      if (issue) errors.push({ field, message: issue });
    }
    for (const field of canonicalColumns(schema)) {
      if (!Object.prototype.hasOwnProperty.call(record, field) || record[field] === null || (typeof record[field] === "string" && !record[field].trim())) {
        errors.push({ field, message: "Canonical-key value is required." });
      }
    }
    return errors;
  }

  function uniqueConstraints(schema) {
    const declared = Array.isArray(schema?.["x-gds-unique-constraints"])
      ? schema["x-gds-unique-constraints"].filter((group) => Array.isArray(group) && group.length)
      : [];
    const canonical = canonicalColumns(schema);
    return declared.length ? declared : [canonical];
  }

  function validateDataset(rows, schema) {
    if (!Array.isArray(rows)) return [{ row: null, field: "$", message: "Dataset must be one JSON array." }];
    const errors = [];
    if (rows.length > MAX_DATASET_RECORDS) {
      errors.push({ row: null, field: "$", message: `Dataset exceeds ${MAX_DATASET_RECORDS.toLocaleString("en-US")} records.` });
      return errors;
    }
    rows.forEach((row, index) => {
      validateRecord(row, schema).forEach((issue) => errors.push({ row: index, ...issue }));
    });
    for (const columns of uniqueConstraints(schema)) {
      const seen = new Map();
      rows.forEach((row, index) => {
        if (!isObject(row) || columns.some((field) => row[field] === undefined)) return;
        const key = keyFor(row, columns, schema);
        if (seen.has(key)) {
          const other = seen.get(key);
          const message = `Duplicates row ${other + 1} for ${columns.join(", ")}.`;
          columns.forEach((field) => errors.push({ row: index, field, message }));
        } else {
          seen.set(key, index);
        }
      });
    }
    return errors;
  }

  function serializeDataset(rows) {
    const content = JSON.stringify(rows, null, 2) + "\n";
    const bytes = new TextEncoder().encode(content).byteLength;
    if (bytes > MAX_DATASET_BYTES) throw new Error("Dataset exceeds the 16 MiB Stage limit.");
    return { content, bytes };
  }

  function mergeRecord(rows, record, schema, dataset) {
    assertEligibleSchema(dataset, schema);
    const recordErrors = validateRecord(record, schema);
    if (recordErrors.length) return { rows: clone(rows), action: "rejected", index: -1, errors: recordErrors };
    const columns = canonicalColumns(schema);
    const wanted = keyFor(record, columns, schema);
    const next = clone(rows);
    const index = next.findIndex((item) => keyFor(item, columns, schema) === wanted);
    const action = index < 0 ? "inserted" : "replaced";
    if (index < 0) next.push(clone(record)); else next[index] = clone(record);
    const errors = validateDataset(next, schema);
    return errors.length ? { rows: clone(rows), action: "rejected", index, errors } : { rows: next, action, index: index < 0 ? next.length - 1 : index, errors: [] };
  }

  function mergeRecords(rows, records, schema, dataset) {
    assertEligibleSchema(dataset, schema);
    if (!Array.isArray(records) || !records.length) {
      return { rows: clone(rows), action: "rejected", indexes: [], errors: [{ field: "$", message: "Choose at least one record." }] };
    }
    const columns = canonicalColumns(schema);
    const next = clone(rows);
    const indexByKey = new Map(next.map((item, index) => [keyFor(item, columns, schema), index]));
    const indexes = [];
    for (const record of records) {
      const recordErrors = validateRecord(record, schema);
      if (recordErrors.length) return { rows: clone(rows), action: "rejected", indexes: [], errors: recordErrors };
      const wanted = keyFor(record, columns, schema);
      let index = indexByKey.get(wanted);
      if (index === undefined) {
        index = next.length;
        next.push(clone(record));
        indexByKey.set(wanted, index);
      } else {
        next[index] = clone(record);
      }
      indexes.push(index);
    }
    const errors = validateDataset(next, schema);
    return errors.length
      ? { rows: clone(rows), action: "rejected", indexes: [], errors }
      : { rows: next, action: "merged", indexes, errors: [] };
  }

  function removeRecord(rows, keyRecord, schema, dataset) {
    assertEligibleSchema(dataset, schema);
    const columns = canonicalColumns(schema);
    const provided = Object.keys(keyRecord || {}).sort();
    if (provided.join("\u001f") !== [...columns].sort().join("\u001f")) throw new Error("Removal key must contain exactly the canonical-key fields.");
    const wanted = keyFor(keyRecord, columns, schema);
    const index = rows.findIndex((item) => keyFor(item, columns, schema) === wanted);
    if (index < 0) throw new Error("No matching local Change Set record was found.");
    const next = clone(rows);
    next.splice(index, 1);
    return next;
  }

  function createLocalState(manifest) {
    if (!manifest || manifest.schema_version !== "2.0" || manifest.snapshot_kind !== "metadata" || typeof manifest.tenant_code !== "string" || typeof manifest.snapshot_id !== "string") {
      throw new Error("Snapshot manifest cannot initialize a local Change Set.");
    }
    return {
      format_version: "1.0",
      tenant: { tenant_id: null, tenant_code: manifest.tenant_code },
      snapshot: {
        snapshot_id: manifest.snapshot_id,
        path: "../metadata-snapshot",
        usage: "local",
        outdated_snapshot_warning_acknowledged: false
      },
      server_change_set: {
        metadata_change_set_id: null,
        draft_revision: null,
        status: "local"
      },
      datasets: {}
    };
  }

  function sameRecord(left, right, schema) {
    const fields = Object.keys(schema?.properties || {});
    return fields.every((field) => JSON.stringify(left?.[field]) === JSON.stringify(right?.[field]));
  }

  function classifyRecord(record, snapshotRows, schema) {
    const columns = canonicalColumns(schema);
    const wanted = keyFor(record, columns, schema);
    const base = snapshotRows.find((item) => keyFor(item, columns, schema) === wanted);
    if (!base) return "insert";
    if (sameRecord(record, base, schema)) return "no_change";
    if (base.is_active === true && record.is_active === false) return "deactivate";
    if (base.is_active === false && record.is_active === true) return "reactivate";
    return "update";
  }

  function diffRecord(record, baseline, schema) {
    const fields = Object.keys(schema?.properties || {});
    const changes = fields.filter((field) => JSON.stringify(record?.[field]) !== JSON.stringify(baseline?.[field]));
    let action = "insert";
    if (baseline) {
      if (!changes.length) action = "no_change";
      else if (baseline.is_active === true && record?.is_active === false) action = "deactivate";
      else if (baseline.is_active === false && record?.is_active === true) action = "reactivate";
      else action = "update";
    }
    return {
      action,
      changes: changes.map((field) => ({ field, before: baseline?.[field], after: record?.[field] }))
    };
  }

  root.GdsWorkbenchLogic = Object.freeze({
    ELIGIBLE_DATASETS,
    MAX_DATASET_RECORDS,
    MAX_DATASET_BYTES,
    safePathParts,
    parseJson,
    parseRows,
    normalizeKeyValue,
    canonicalColumns,
    validateSchema,
    validateRecord,
    validateDataset,
    serializeDataset,
    mergeRecord,
    mergeRecords,
    removeRecord,
    createLocalState,
    classifyRecord,
    diffRecord,
    clone,
    isObject
  });
})(typeof globalThis === "undefined" ? window : globalThis);
