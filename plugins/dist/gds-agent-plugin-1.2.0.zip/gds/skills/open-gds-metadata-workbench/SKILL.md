---
name: open-gds-metadata-workbench
description: Launch the bundled local GDS Metadata Workbench in a browser. Use only when the user explicitly asks to open the local table utility or manually browse or edit downloaded GDS Snapshot or Change Set files; do not use for MCP metadata reads or server Change Set operations.
---

# Open GDS Metadata Workbench

Open the bundled static utility in the default browser. It has no server,
Python, Node, network, or MCP dependency.

## Launch

Use this skill directory as the process working directory. On Windows
PowerShell 5.1:

```powershell
powershell.exe -NoProfile -File ".\scripts\open-gds-metadata-workbench.ps1"
```

On macOS:

```sh
"./scripts/open-gds-metadata-workbench.sh"
```

Require `ok=true` and `opened=true`. The utility opens the default browser.
Direct folder editing requires current Chrome or Edge. If the default browser
does not support it, ask the user to open the same bundled
`assets/workbench/index.html` in Chrome or Edge.

## Hand control to the user

1. Ask the user to choose either the current project folder or its exact `GDS`
   folder. Browser permission is always explicit.
2. Require `GDS/metadata-snapshot`. The utility reads `manifest.json` and
   `catalog.json`, then verifies each opened Snapshot member before displaying
   it.
3. Explain that Snapshot rows are immutable. Only the 16 operational datasets
   expose **Create change**.
4. The utility reuses `GDS/change-set` or creates an unbound local draft when it
   is absent. No Tenant Lock is needed for local drafting.
5. Ask the user to save inside the utility and tell you when finished. Do not
   assume that an interaction occurred or inspect all local rows afterward.

## Boundary

The utility only reads local Snapshot files and writes complete arrays to
`GDS/change-set/datasets/<dataset>.json`. It never calls MCP, acquires a Tenant
Lock, Stages, validates on the server, Applies, or changes PostgreSQL.

When the user wants to continue to Stage or Apply, switch to the
`manage-gds-metadata` skill. That workflow must obtain approval for the Tenant
Lock, create or resume the server Change Set, bind an unbound local draft, run
local review, ask before Stage, validate on the server, and ask separately
before Apply.

Never claim that locally saved records are authorized, Staged, validated, or
applied.
