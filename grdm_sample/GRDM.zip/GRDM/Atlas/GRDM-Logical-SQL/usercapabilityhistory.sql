SELECT
    h.tracking_system_user_id AS SourceTrackingSystemUserID,
    h.capability_name AS CapabilityName,
    h.last_change_time AS LastChangeTime,
    CAST(NULL AS BIGINT) AS OwningUserID,
    h.is_granted AS IsGranted,
    h.status AS Status,
    h.created_by_tracking_system_user_id AS SourceCreatorTrackingSystemUserID,
    CAST(NULL AS BIGINT) AS CreatorUserID,
    h.current_assigned_compliance_region_id AS SourceCurrentAssignedComplianceRegionID,
    CAST(NULL AS BIGINT) AS CurrentAssignedComplianceRegionID,
    h.current_secondary_compliance_region_id AS SourceCurrentSecondaryComplianceRegionID,
    CAST(NULL AS BIGINT) AS CurrentSecondaryComplianceRegionID,
    h.last_change_user AS SourceLastChangeLoginUserID,
    CAST(NULL AS BIGINT) AS LastChangeUserID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_user_capability_history AS h;