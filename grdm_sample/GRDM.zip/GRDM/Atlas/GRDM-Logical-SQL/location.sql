SELECT
    l.location_id AS SourceLocationID,
    l.office_number AS OfficeNumber,
    l.street1 AS StreetLine1,
    l.street2 AS StreetLine2,
    l.city AS City,
    l.country AS Country,
    l.state_or_province AS StateOrProvince,
    l.postal AS PostalCode,
    l.status AS Status,
    l.override_auto_self_clear_configuration AS OverrideAutoSelfClearConfiguration,
    l.compliance_region_id AS SourceComplianceRegionID,
    CAST(NULL AS BIGINT) AS ComplianceRegionID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_location_v1 AS l;