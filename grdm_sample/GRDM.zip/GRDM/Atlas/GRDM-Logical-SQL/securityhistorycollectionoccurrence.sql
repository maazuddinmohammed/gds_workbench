CREATE OR REPLACE TEMPORARY VIEW temp_security_history_collection_occurrence_kics_unpivoted AS
SELECT
    h.security_id AS SourceSecurityID,
    h.last_change_time AS LastChangeTime,
    c.CollectionName,
    c.encoding
FROM gds_grdm_raw.kics_security_history_v1 AS h
LATERAL VIEW STACK(
    9,
    'symbol_exchange_array', h.symbol_exchange_array,
    'cusip_array', h.cusip_array,
    'isin_array', h.isin_array,
    'sedol_array', h.sedol_array,
    'alias_value_array', h.alias_value_array,
    'parent_entity_security_name_array', h.parent_entity_security_name_array,
    'parent_entity_security_type_array', h.parent_entity_security_type_array,
    'relationship_type_array', h.relationship_type_array,
    'is_restriction_flow_down_array', h.is_restriction_flow_down_array
) c AS CollectionName, encoding;

CREATE OR REPLACE TEMPORARY VIEW temp_security_history_collection_occurrence_kics_parsed AS
SELECT
    SourceSecurityID,
    LastChangeTime,
    CollectionName,
    encoding,
    TRY_PARSE_JSON(encoding) AS parsed_encoding
FROM temp_security_history_collection_occurrence_kics_unpivoted;

CREATE OR REPLACE TEMPORARY VIEW temp_security_history_collection_occurrence_kics_classified AS
SELECT
    SourceSecurityID,
    LastChangeTime,
    CollectionName,
    encoding,
    parsed_encoding,
    CASE
        WHEN encoding IS NULL THEN 'Null'
        WHEN SCHEMA_OF_VARIANT(parsed_encoding) LIKE 'ARRAY<%' THEN
            CASE
                WHEN VARIANT_GET(parsed_encoding, '$[0]') IS NULL THEN 'Empty'
                ELSE 'Array'
            END
        ELSE 'Undecoded'
    END AS CollectionState
FROM temp_security_history_collection_occurrence_kics_parsed;

CREATE OR REPLACE TEMPORARY VIEW temp_security_history_collection_occurrence_kics_rows AS
SELECT
    SourceSecurityID,
    LastChangeTime,
    CollectionName,
    CAST(0 AS BIGINT) AS OccurrencePosition,
    CollectionState,
    CASE
        WHEN CollectionState = 'Undecoded' THEN encoding
        ELSE CAST(NULL AS STRING)
    END AS `Value`
FROM temp_security_history_collection_occurrence_kics_classified
UNION ALL
SELECT
    c.SourceSecurityID,
    c.LastChangeTime,
    c.CollectionName,
    CAST(e.pos AS BIGINT) + CAST(1 AS BIGINT) AS OccurrencePosition,
    c.CollectionState,
    CASE
        WHEN IS_VARIANT_NULL(e.value) THEN CAST(NULL AS STRING)
        WHEN SCHEMA_OF_VARIANT(e.value) = 'STRING' THEN CAST(e.value AS STRING)
        ELSE TO_JSON(e.value)
    END AS `Value`
FROM temp_security_history_collection_occurrence_kics_classified AS c,
LATERAL VARIANT_EXPLODE(
    CASE
        WHEN c.CollectionState = 'Array' THEN c.parsed_encoding
        ELSE PARSE_JSON('[]')
    END
) AS e;

SELECT
    SourceSecurityID,
    LastChangeTime,
    CollectionName,
    OccurrencePosition,
    CollectionState,
    `Value`,
    CAST(NULL AS BIGINT) AS SecurityHistoryID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM temp_security_history_collection_occurrence_kics_rows;