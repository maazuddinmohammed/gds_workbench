CREATE OR REPLACE TEMPORARY VIEW temp_questionset_kics_identities AS
SELECT q.`question_set_id` AS `SourceQuestionSetID`
FROM `gds_grdm_raw`.`kics_question_group_question_v1` AS q
UNION
SELECT a.`question_set_id` AS `SourceQuestionSetID`
FROM `gds_grdm_raw`.`kics_question_group_to_question_bridge_v1` AS a;

SELECT
    s.`SourceQuestionSetID` AS `SourceQuestionSetID`,
    CAST(NULL AS STRING) AS `Name`,
    CAST(NULL AS STRING) AS `QuestionSetIdentifierID`,
    CAST(NULL AS STRING) AS `Text`,
    CAST(NULL AS STRING) AS `SetType`,
    CAST(NULL AS STRING) AS `Status`,
    CAST(NULL AS STRING) AS `ModificationNumber`,
    CAST(NULL AS STRING) AS `SourceLanguageID`,
    CAST(NULL AS BIGINT) AS `LanguageID`,
    CAST(NULL AS STRING) AS `SourceMoveToProductionUserID`,
    CAST(NULL AS STRING) AS `MoveToProductionTime`,
    CAST(NULL AS STRING) AS `SourceMoveToArchiveUserID`,
    CAST(NULL AS STRING) AS `MoveToArchiveTime`,
    CAST(NULL AS STRING) AS `IsCommentRequired`,
    CAST(NULL AS STRING) AS `SourceComplianceRegionID`,
    CAST(NULL AS BIGINT) AS `ComplianceRegionID`,
    CAST(NULL AS BIGINT) AS `MoveToProductionUserID`,
    CAST(NULL AS BIGINT) AS `MoveToArchiveUserID`,
    CAST(2 AS BIGINT) AS `SourceSystemID`
FROM temp_questionset_kics_identities AS s;