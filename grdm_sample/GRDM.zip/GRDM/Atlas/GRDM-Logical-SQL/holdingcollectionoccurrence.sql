CREATE OR REPLACE TEMPORARY VIEW temp_holding_collection_occurrence_kics_collections AS
SELECT h.case_id AS SourceHoldingCaseID, c.CollectionName, c.RawValue
FROM gds_grdm_raw.kics_holding_v1 AS h
LATERAL VIEW STACK(7,
  'holding_attachment_filename_array', h.holding_attachment_filename_array,
  'holding_attachment_add_date_array', h.holding_attachment_add_date_array,
  'holding_attachment_service_center_provided_array', h.holding_attachment_service_center_provided_array,
  'is_third_party_user_update_attachment_array', h.is_third_party_user_update_attachment_array,
  'brokerage_authorization_submission_attachment_filename_array', h.brokerage_authorization_submission_attachment_filename_array,
  'brokerage_authorization_submission_attachment_add_date_array', h.brokerage_authorization_submission_attachment_add_date_array,
  'brokerage_authorization_submission_attachment_service_center_provided_array', h.brokerage_authorization_submission_attachment_service_center_provided_array
) c AS CollectionName, RawValue;

CREATE OR REPLACE TEMPORARY VIEW temp_holding_collection_occurrence_kics_parsed AS
SELECT SourceHoldingCaseID, CollectionName, RawValue,
  try_parse_json(RawValue) AS JsonValue
FROM temp_holding_collection_occurrence_kics_collections;

CREATE OR REPLACE TEMPORARY VIEW temp_holding_collection_occurrence_kics_classified AS
SELECT SourceHoldingCaseID, CollectionName, RawValue, JsonValue,
  CASE
    WHEN RawValue IS NULL THEN 'Null'
    WHEN schema_of_variant(JsonValue) LIKE 'ARRAY<%' THEN
      CASE WHEN json_array_length(to_json(JsonValue)) = 0 THEN 'Empty' ELSE 'Array' END
    ELSE 'Undecoded'
  END AS CollectionState
FROM temp_holding_collection_occurrence_kics_parsed;

CREATE OR REPLACE TEMPORARY VIEW temp_holding_collection_occurrence_kics_decoded AS
SELECT s.SourceHoldingCaseID, s.CollectionName,
  CAST(e.pos + 1 AS BIGINT) AS OccurrencePosition,
  s.CollectionState,
  CASE
    WHEN schema_of_variant(e.value) = 'STRING' THEN CAST(e.value AS STRING)
    ELSE to_json(e.value)
  END AS `Value`
FROM temp_holding_collection_occurrence_kics_classified AS s,
LATERAL variant_explode(
  CASE WHEN s.CollectionState = 'Array' THEN s.JsonValue ELSE parse_json('[]') END
) AS e
WHERE s.CollectionState = 'Array';

CREATE OR REPLACE TEMPORARY VIEW temp_holding_collection_occurrence_kics_occurrences AS
SELECT SourceHoldingCaseID, CollectionName,
  CAST(0 AS BIGINT) AS OccurrencePosition,
  CollectionState,
  CASE WHEN CollectionState = 'Undecoded' THEN RawValue ELSE CAST(NULL AS STRING) END AS `Value`
FROM temp_holding_collection_occurrence_kics_classified
UNION ALL
SELECT SourceHoldingCaseID, CollectionName, OccurrencePosition, CollectionState, `Value`
FROM temp_holding_collection_occurrence_kics_decoded;

SELECT SourceHoldingCaseID, CollectionName, OccurrencePosition, CollectionState, `Value`,
  CAST(NULL AS BIGINT) AS HoldingCaseID,
  CAST(2 AS BIGINT) AS SourceSystemID
FROM temp_holding_collection_occurrence_kics_occurrences;