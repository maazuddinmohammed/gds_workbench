CREATE OR REPLACE TEMPORARY VIEW temp_reason_kics_identities AS
SELECT DISTINCT r.reason_id AS SourceReasonID
FROM gds_grdm_raw.kics_reason_v1 AS r;

SELECT
    SourceReasonID,
    CAST(NULL AS STRING) AS ReasonIdentifierID,
    CAST(NULL AS STRING) AS ReasonType,
    CAST(NULL AS STRING) AS DefaultDayCountUntilExpiration,
    CAST(NULL AS STRING) AS MaxDayCountUntilExpiration,
    CAST(NULL AS STRING) AS Status,
    CAST(NULL AS STRING) AS SourceComplianceRegionID,
    CAST(NULL AS BIGINT) AS ComplianceRegionID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM temp_reason_kics_identities;