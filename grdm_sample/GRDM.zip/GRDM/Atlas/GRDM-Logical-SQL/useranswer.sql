CREATE OR REPLACE TEMPORARY VIEW temp_user_answer_kics_regular AS
SELECT
    'Regular' AS ResponseKind,
    t13.user_answer_id AS SourceUserAnswerID,
    t13.user_answer_text AS AnswerText,
    t13.reviewer_comment_on_user_answer AS ReviewerComment,
    t13.answer_choice_and_decision_tree_id AS SourceDecisionTreeAnswerID,
    CAST(NULL AS BIGINT) AS DecisionTreeAnswerID,
    t13.review_time AS ReviewTime,
    t13.user_question_id AS SourceUserQuestionID,
    CAST(NULL AS BIGINT) AS UserQuestionInstanceID,
    t13.response_type AS ResponseType,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_question_group_user_response_v1 AS t13;

CREATE OR REPLACE TEMPORARY VIEW temp_user_answer_kics_supplemental AS
SELECT
    'Supplemental' AS ResponseKind,
    t11.user_answer_id AS SourceUserAnswerID,
    t11.user_answer_text AS AnswerText,
    t11.reviewer_comment_on_user_answer AS ReviewerComment,
    t11.answer_choice_and_decision_tree_id AS SourceDecisionTreeAnswerID,
    CAST(NULL AS BIGINT) AS DecisionTreeAnswerID,
    t11.review_time AS ReviewTime,
    t11.user_question_id AS SourceUserQuestionID,
    CAST(NULL AS BIGINT) AS UserQuestionInstanceID,
    t11.response_type AS ResponseType,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_question_group_user_response_for_supplemental_data_v1 AS t11;

SELECT
    ResponseKind,
    SourceUserAnswerID,
    AnswerText,
    ReviewerComment,
    SourceDecisionTreeAnswerID,
    DecisionTreeAnswerID,
    ReviewTime,
    SourceUserQuestionID,
    UserQuestionInstanceID,
    ResponseType,
    SourceSystemID
FROM temp_user_answer_kics_regular
UNION ALL
SELECT
    ResponseKind,
    SourceUserAnswerID,
    AnswerText,
    ReviewerComment,
    SourceDecisionTreeAnswerID,
    DecisionTreeAnswerID,
    ReviewTime,
    SourceUserQuestionID,
    UserQuestionInstanceID,
    ResponseType,
    SourceSystemID
FROM temp_user_answer_kics_supplemental;