CREATE OR REPLACE TEMPORARY VIEW temp_business_entity_collection_occurrence_kics_collections AS
SELECT e.entity_id AS SourceBusinessEntityID, u.CollectionName, u.encoding
FROM gds_grdm_raw.kics_entity_v1 AS e
LATERAL VIEW STACK(9,
  'sic_array', e.sic_array,
  'icusip_array', e.icusip_array,
  'refinitiv_identifier_array', e.refinitiv_identifier_array,
  'nmls_array', e.nmls_array,
  'alias_value_array', e.alias_value_array,
  'child_entity_security_type_array', e.child_entity_security_type_array,
  'child_entity_security_name_array', e.child_entity_security_name_array,
  'relationship_type_array', e.relationship_type_array,
  'is_restriction_flow_down_array', e.is_restriction_flow_down_array
) u AS CollectionName, encoding;

CREATE OR REPLACE TEMPORARY VIEW temp_business_entity_collection_occurrence_kics_parsed AS
SELECT SourceBusinessEntityID, CollectionName, encoding, TRY_PARSE_JSON(encoding) AS json_value
FROM temp_business_entity_collection_occurrence_kics_collections;

CREATE OR REPLACE TEMPORARY VIEW temp_business_entity_collection_occurrence_kics_classified AS
SELECT SourceBusinessEntityID, CollectionName, encoding, json_value,
  CASE
    WHEN encoding IS NULL THEN 'Null'
    WHEN SCHEMA_OF_VARIANT(json_value) LIKE 'ARRAY<%' THEN
      CASE WHEN JSON_ARRAY_LENGTH(TO_JSON(json_value)) = 0 THEN 'Empty' ELSE 'Array' END
    ELSE 'Undecoded'
  END AS CollectionState
FROM temp_business_entity_collection_occurrence_kics_parsed;

CREATE OR REPLACE TEMPORARY VIEW temp_business_entity_collection_occurrence_kics_occurrences AS
SELECT c.SourceBusinessEntityID, c.CollectionName,
  CAST(0 AS BIGINT) AS OccurrencePosition, c.CollectionState,
  CASE WHEN c.CollectionState = 'Undecoded' THEN c.encoding ELSE CAST(NULL AS STRING) END AS `Value`
FROM temp_business_entity_collection_occurrence_kics_classified AS c
UNION ALL
SELECT c.SourceBusinessEntityID, c.CollectionName,
  CAST(v.pos + 1 AS BIGINT) AS OccurrencePosition, c.CollectionState,
  CASE WHEN SCHEMA_OF_VARIANT(v.value) = 'STRING' THEN CAST(v.value AS STRING) ELSE TO_JSON(v.value) END AS `Value`
FROM temp_business_entity_collection_occurrence_kics_classified AS c,
  LATERAL VARIANT_EXPLODE(CASE WHEN c.CollectionState = 'Array' THEN c.json_value ELSE PARSE_JSON('[]') END) AS v;

SELECT SourceBusinessEntityID, CollectionName, OccurrencePosition, CollectionState, `Value`,
  CAST(NULL AS BIGINT) AS BusinessEntityID,
  CAST(2 AS BIGINT) AS SourceSystemID
FROM temp_business_entity_collection_occurrence_kics_occurrences;