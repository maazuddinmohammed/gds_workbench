SELECT
    uc.user_capability_id AS SourceUserCapabilityID,
    uc.tracking_system_user_id AS SourceTrackingSystemUserID,
    CAST(NULL AS BIGINT) AS OwningUserID,
    uc.capability_name AS CapabilityName,
    uc.is_granted AS IsGranted,
    uc.status AS Status,
    uc.created_by_tracking_system_user_id AS SourceCreatorTrackingSystemUserID,
    CAST(NULL AS BIGINT) AS CreatorUserID,
    uc.current_assigned_compliance_region_id AS SourceCurrentAssignedComplianceRegionID,
    CAST(NULL AS BIGINT) AS CurrentAssignedComplianceRegionID,
    uc.current_secondary_compliance_region_id AS SourceCurrentSecondaryComplianceRegionID,
    CAST(NULL AS BIGINT) AS CurrentSecondaryComplianceRegionID,
    uc.last_change_time AS LastChangeTime,
    uc.last_change_user AS SourceLastChangeLoginUserID,
    CAST(NULL AS BIGINT) AS LastChangeUserID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_user_capability AS uc;