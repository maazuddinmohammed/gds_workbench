SELECT
    a.acknowledgement_text_assignment_id AS SourceAcknowledgementTextAssignmentID,
    a.entity_id AS SourceBusinessEntityID,
    CAST(NULL AS BIGINT) AS BusinessEntityID,
    a.compliance_region_id AS SourceComplianceRegionID,
    CAST(NULL AS BIGINT) AS ComplianceRegionID,
    a.language_id AS SourceLanguageID,
    CAST(NULL AS BIGINT) AS LanguageID,
    a.status AS Status,
    a.acknowledgement_heading AS AcknowledgementHeading,
    a.acknowledgement_text AS AcknowledgementText,
    a.acknowledgement_name AS AcknowledgementName,
    a.brokerage_instruction AS BrokerageInstruction,
    a.example_account_identifier AS ExampleAccountID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_acknowledgement_text_assignment_v1 AS a;