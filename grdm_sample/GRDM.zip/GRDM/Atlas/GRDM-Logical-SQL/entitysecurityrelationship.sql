SELECT
    b.child_to_parent_bridge_id AS SourceEntitySecurityRelationshipID,
    b.child_entity_security_id AS SourceChildEntitySecurityID,
    b.parent_entity_security_id AS SourceParentEntitySecurityID,
    b.relationship_type AS RelationshipType,
    b.relationship_status AS RelationshipStatus,
    b.is_restriction_flow_down AS IsRestrictionFlowDown,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_child_to_parent_bridge_v1 AS b;