SELECT
    a.location_engagement_assignment_case_id AS SourceLocationEngagementAssignmentCaseID,
    a.assignment_status AS AssignmentStatus,
    a.location_id AS SourceLocationID,
    CAST(NULL AS BIGINT) AS LocationID,
    a.engagement_location_type AS EngagementLocationType,
    a.entity_security_id AS SourceEntitySecurityID,
    a.entity_security_type AS EntitySecurityType,
    a.engagement_comments AS EngagementComments,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_location_engagement_assignment_v1 AS a;