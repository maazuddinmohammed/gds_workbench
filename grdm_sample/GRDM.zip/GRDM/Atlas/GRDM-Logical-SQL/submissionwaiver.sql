CREATE OR REPLACE TEMPORARY VIEW temp_submission_waiver_kics_input AS
SELECT
    q.question_group_submission_case_id,
    q.waiver_case_id,
    q.waiver_expiration_time,
    q.waiver_comments,
    q.waiver_state,
    q.waiver_email_time,
    q.waiver_last_change_user_id,
    q.waiver_reason_id
FROM gds_grdm_raw.kics_question_group_submission_v1 AS q
WHERE q.waiver_case_id IS NOT NULL
   OR q.waiver_expiration_time IS NOT NULL
   OR q.waiver_comments IS NOT NULL
   OR q.waiver_state IS NOT NULL
   OR q.waiver_email_time IS NOT NULL
   OR q.waiver_last_change_user_id IS NOT NULL
   OR q.waiver_reason_id IS NOT NULL;

SELECT
    q.question_group_submission_case_id AS SourceQuestionGroupSubmissionCaseID,
    CAST(NULL AS BIGINT) AS QuestionGroupSubmissionCaseID,
    q.waiver_case_id AS SourceWaiverCaseID,
    q.waiver_expiration_time AS ExpirationTime,
    q.waiver_comments AS Comments,
    q.waiver_state AS State,
    q.waiver_email_time AS EmailTime,
    q.waiver_last_change_user_id AS SourceLastChangeUserID,
    CAST(NULL AS BIGINT) AS LastChangeUserID,
    q.waiver_reason_id AS SourceReasonID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM temp_submission_waiver_kics_input AS q;