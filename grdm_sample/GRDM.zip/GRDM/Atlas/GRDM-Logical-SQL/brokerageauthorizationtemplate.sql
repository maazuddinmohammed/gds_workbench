SELECT
    t.brokerage_authorization_template_id AS SourceBrokerageAuthorizationTemplateID,
    t.brokerage_authorization_template_name AS Name,
    t.entity_id AS SourceBusinessEntityID,
    CAST(NULL AS BIGINT) AS BusinessEntityID,
    t.language_id AS SourceLanguageID,
    CAST(NULL AS BIGINT) AS LanguageID,
    t.status AS Status,
    t.move_to_production_time AS MoveToProductionTime,
    t.move_to_production_user_id AS SourceMoveToProductionUserID,
    CAST(NULL AS BIGINT) AS MoveToProductionUserID,
    t.archived_time AS ArchivedTime,
    t.archived_user AS ArchivedUser,
    t.brokerage_authorization_template_attachment_filename AS AttachmentFilename,
    t.brokerage_authorization_template_attachment_add_time AS AttachmentAddTime,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_brokerage_authorization_template_v1 AS t;