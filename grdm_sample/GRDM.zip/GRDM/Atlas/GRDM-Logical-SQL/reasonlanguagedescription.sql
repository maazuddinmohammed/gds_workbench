SELECT
    r.`reason_language_description_id` AS `SourceReasonLanguageDescriptionID`,
    r.`reason_id` AS `SourceReasonID`,
    CAST(NULL AS BIGINT) AS `ReasonID`,
    r.`language_id` AS `SourceLanguageID`,
    CAST(NULL AS BIGINT) AS `LanguageID`,
    r.`reason_language_description` AS `Description`,
    r.`reason_language_description_comment` AS `Comment`,
    r.`is_default_language` AS `IsDefaultLanguage`,
    r.`reason_language_description_status` AS `Status`,
    CAST(2 AS BIGINT) AS `SourceSystemID`
FROM `gds_grdm_raw`.`kics_reason_v1` AS r;