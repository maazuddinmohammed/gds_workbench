SELECT
    COALESCE(to_json(array(sr.security_restriction_id)), '[null]') AS RestrictionIdentity,
    sr.security_restriction_id AS SourceSecurityRestrictionID,
    sr.restricted_compliance_region_id AS SourceRestrictedComplianceRegionID,
    sr.security_id AS SourceSecurityID,
    CAST(NULL AS BIGINT) AS SecurityID,
    CAST(NULL AS BIGINT) AS RestrictedComplianceRegionID,
    sr.security_type AS RecordedSecurityType,
    sr.restriction_type AS RestrictionType,
    sr.restriction_state AS RestrictionState,
    sr.restriction_reason AS RestrictionReason,
    sr.restriction_applied AS RestrictionApplied,
    sr.is_restricted AS IsRestricted,
    sr.is_applicable AS IsApplicable,
    sr.inherited_from_parent_compliance_region_id AS SourceInheritedFromParentComplianceRegionID,
    CAST(NULL AS BIGINT) AS InheritedFromParentComplianceRegionID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_security_restriction_v1 AS sr;