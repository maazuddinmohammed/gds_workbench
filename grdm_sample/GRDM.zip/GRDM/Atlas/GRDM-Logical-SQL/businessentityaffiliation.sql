CREATE OR REPLACE TEMPORARY VIEW temp_business_entity_affiliation_sntl_input AS
SELECT
    entity_id,
    parent_entity_id,
    gup_entity_id,
    affiliate_type_code,
    relation_code
FROM gds_grdm_raw.sntl_x_tree;

CREATE OR REPLACE TEMPORARY VIEW temp_business_entity_affiliation_sntl_joined AS
SELECT
    t.entity_id AS SourceBusinessEntityID,
    t.parent_entity_id AS SourceParentBusinessEntityID,
    t.gup_entity_id AS SourceGupBusinessEntityID,
    t.affiliate_type_code AS AffiliateTypeCode,
    CASE WHEN t.relation_code IS NULL THEN 'N' ELSE CONCAT('V', t.relation_code) END AS RelationIdentity,
    t.relation_code AS SourceRelationCode,
    rd.RelationDefinitionID AS RelationDefinitionID
FROM temp_business_entity_affiliation_sntl_input AS t
LEFT JOIN gds_grdm_int.RelationDefinition AS rd
    ON rd.SourceSystemID = CAST(3 AS BIGINT)
    AND rd.RelationCode = t.relation_code;

SELECT
    SourceBusinessEntityID,
    SourceParentBusinessEntityID,
    SourceGupBusinessEntityID,
    AffiliateTypeCode,
    RelationIdentity,
    SourceRelationCode,
    RelationDefinitionID,
    CAST(NULL AS BIGINT) AS BusinessEntityID,
    CAST(NULL AS BIGINT) AS ParentBusinessEntityID,
    CAST(NULL AS BIGINT) AS GupBusinessEntityID,
    CAST(3 AS BIGINT) AS SourceSystemID
FROM temp_business_entity_affiliation_sntl_joined;