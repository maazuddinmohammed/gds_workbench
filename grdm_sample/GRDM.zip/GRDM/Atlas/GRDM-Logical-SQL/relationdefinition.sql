SELECT
    r.`relation_code` AS `RelationCode`,
    r.`relation_abbreviation` AS `Abbreviation`,
    r.`relation_description` AS `Description`,
    CAST(3 AS BIGINT) AS `SourceSystemID`
FROM `gds_grdm_raw`.`sntl_x_relationcode` AS r;