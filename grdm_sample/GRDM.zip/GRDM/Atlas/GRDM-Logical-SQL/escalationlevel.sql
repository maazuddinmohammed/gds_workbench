SELECT
    e.escalation_level_id AS SourceEscalationLevelID,
    e.level_description AS Description,
    e.level_number AS LevelNumber,
    e.level_type AS LevelType,
    e.status AS Status,
    e.compliance_region_id AS SourceComplianceRegionID,
    CAST(NULL AS BIGINT) AS ComplianceRegionID,
    e.next_escalation_level_id AS SourceNextEscalationLevelID,
    CAST(NULL AS BIGINT) AS NextEscalationLevelID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_escalation_level_v1 AS e;