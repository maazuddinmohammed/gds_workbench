CREATE OR REPLACE TEMPORARY VIEW temp_submission_history_initial_delivery_question_type_kics_parsed AS
SELECT
    h.question_group_submission_id,
    h.last_change_time,
    h.initial_delivery_question_types,
    try_parse_json(h.initial_delivery_question_types) AS decoded
FROM gds_grdm_raw.kics_question_group_submission_history_v1 AS h;

CREATE OR REPLACE TEMPORARY VIEW temp_submission_history_initial_delivery_question_type_kics_classified AS
SELECT
    p.question_group_submission_id,
    p.last_change_time,
    p.initial_delivery_question_types,
    p.decoded,
    CASE
        WHEN p.initial_delivery_question_types IS NULL THEN 'Null'
        WHEN schema_of_variant(p.decoded) LIKE 'ARRAY<%'
            AND size(variant_get(p.decoded, '$', 'ARRAY<VARIANT>')) = 0 THEN 'Empty'
        WHEN schema_of_variant(p.decoded) LIKE 'ARRAY<%' THEN 'Array'
        ELSE 'Undecoded'
    END AS collection_state
FROM temp_submission_history_initial_delivery_question_type_kics_parsed AS p;

CREATE OR REPLACE TEMPORARY VIEW temp_submission_history_initial_delivery_question_type_kics_occurrences AS
SELECT
    c.question_group_submission_id,
    c.last_change_time,
    CAST(0 AS BIGINT) AS occurrence_position,
    c.collection_state,
    CASE
        WHEN c.collection_state = 'Undecoded' THEN c.initial_delivery_question_types
        ELSE CAST(NULL AS STRING)
    END AS occurrence_value
FROM temp_submission_history_initial_delivery_question_type_kics_classified AS c
UNION ALL
SELECT
    c.question_group_submission_id,
    c.last_change_time,
    CAST(e.pos AS BIGINT) + CAST(1 AS BIGINT) AS occurrence_position,
    c.collection_state,
    CASE
        WHEN schema_of_variant(e.value) = 'STRING' THEN CAST(e.value AS STRING)
        ELSE to_json(e.value)
    END AS occurrence_value
FROM temp_submission_history_initial_delivery_question_type_kics_classified AS c,
LATERAL variant_explode(
    CASE
        WHEN c.collection_state IN ('Empty', 'Array') THEN c.decoded
        ELSE parse_json('[]')
    END
) AS e;

SELECT
    o.question_group_submission_id AS SourceQuestionGroupSubmissionID,
    o.last_change_time AS LastChangeTime,
    o.occurrence_position AS OccurrencePosition,
    o.collection_state AS CollectionState,
    o.occurrence_value AS `Value`,
    CAST(NULL AS BIGINT) AS QuestionGroupSubmissionHistoryID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM temp_submission_history_initial_delivery_question_type_kics_occurrences AS o;