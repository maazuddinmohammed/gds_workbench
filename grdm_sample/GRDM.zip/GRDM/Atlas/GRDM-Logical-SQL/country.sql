SELECT
    c.`CountryID` AS `SourceCountryID`,
    c.`Country` AS `Name`,
    c.`IsoCountryCode` AS `IsoCountryCode`,
    c.`UnCountryCode` AS `UnCountryCode`,
    c.`IsActive` AS `SourceActiveIndicator`,
    CAST(3 AS BIGINT) AS `SourceSystemID`
FROM `gds_grdm_raw`.`sntl_x_country` AS c;