SELECT
    m.entity_security_merge_record_id AS SourceEntitySecurityMergeID,
    m.entity_security_replaced_id AS SourceReplacedEntitySecurityID,
    m.entity_security_replaced_type AS ReplacedEntitySecurityType,
    m.entity_security_retained_id AS SourceRetainedEntitySecurityID,
    m.entity_security_retained_type AS RetainedEntitySecurityType,
    m.merge_time AS MergeTime,
    m.merge_comment AS MergeComment,
    m.is_confirmation_required AS IsConfirmationRequired,
    m.is_send_notification_selected AS IsSendNotificationSelected,
    m.retained_security_acquisition_date_source AS RetainedSecurityAcquisitionDateSource,
    m.selected_acquisition_date AS SelectedAcquisitionDate,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_entity_security_merge_record_v1 AS m;