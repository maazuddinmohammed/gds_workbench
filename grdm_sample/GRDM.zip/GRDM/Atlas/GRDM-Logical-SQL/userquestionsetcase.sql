CREATE OR REPLACE TEMPORARY VIEW temp_user_question_set_case_kics_regular AS
SELECT
    'Regular' AS ResponseKind,
    t13.user_question_set_case_id AS SourceUserQuestionSetCaseID,
    t13.question_set_id AS SourceQuestionSetID,
    t13.holding_case_id AS SourceHoldingCaseID,
    CAST(NULL AS BIGINT) AS HoldingCaseID,
    t13.self_clear_attempt_count AS SelfClearAttemptCount,
    t13.first_user_question_in_question_set AS SourceFirstUserQuestionID,
    t13.is_question_set_skipped AS IsQuestionSetSkipped,
    t13.question_set_question_type AS QuestionSetQuestionType,
    t13.question_group_submission_case_id AS SourceQuestionGroupSubmissionCaseID,
    CAST(NULL AS BIGINT) AS QuestionGroupSubmissionCaseID,
    t13.tracking_system_user_id AS SourceTrackingSystemUserID,
    CAST(NULL AS BIGINT) AS TrackingUserID,
    t13.current_secondary_compliance_region_id AS SourceCurrentSecondaryComplianceRegionID,
    CAST(NULL AS BIGINT) AS CurrentSecondaryComplianceRegionID,
    t13.current_assigned_compliance_region_id AS SourceCurrentAssignedComplianceRegionID,
    CAST(NULL AS BIGINT) AS CurrentAssignedComplianceRegionID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_question_group_user_response_v1 AS t13
WHERE t13.user_question_set_case_id IS NOT NULL;

CREATE OR REPLACE TEMPORARY VIEW temp_user_question_set_case_kics_supplemental AS
SELECT
    'Supplemental' AS ResponseKind,
    t11.user_question_set_case_id AS SourceUserQuestionSetCaseID,
    t11.question_set_id AS SourceQuestionSetID,
    t11.holding_case_id AS SourceHoldingCaseID,
    CAST(NULL AS BIGINT) AS HoldingCaseID,
    t11.self_clear_attempt_count AS SelfClearAttemptCount,
    t11.first_user_question_in_question_set AS SourceFirstUserQuestionID,
    t11.is_question_set_skipped AS IsQuestionSetSkipped,
    t11.question_set_question_type AS QuestionSetQuestionType,
    t11.question_group_submission_case_id AS SourceQuestionGroupSubmissionCaseID,
    CAST(NULL AS BIGINT) AS QuestionGroupSubmissionCaseID,
    t11.tracking_system_user_id AS SourceTrackingSystemUserID,
    CAST(NULL AS BIGINT) AS TrackingUserID,
    t11.current_secondary_compliance_region_id AS SourceCurrentSecondaryComplianceRegionID,
    CAST(NULL AS BIGINT) AS CurrentSecondaryComplianceRegionID,
    t11.current_assigned_compliance_region_id AS SourceCurrentAssignedComplianceRegionID,
    CAST(NULL AS BIGINT) AS CurrentAssignedComplianceRegionID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_question_group_user_response_for_supplemental_data_v1 AS t11
WHERE t11.user_question_set_case_id IS NOT NULL;

SELECT
    CAST(NULL AS STRING) AS ResponseKind,
    CAST(NULL AS STRING) AS SourceUserQuestionSetCaseID,
    CAST(NULL AS STRING) AS SourceQuestionSetID,
    CAST(NULL AS STRING) AS SourceHoldingCaseID,
    CAST(NULL AS BIGINT) AS HoldingCaseID,
    CAST(NULL AS STRING) AS SelfClearAttemptCount,
    CAST(NULL AS STRING) AS SourceFirstUserQuestionID,
    CAST(NULL AS STRING) AS IsQuestionSetSkipped,
    CAST(NULL AS STRING) AS QuestionSetQuestionType,
    CAST(NULL AS STRING) AS SourceQuestionGroupSubmissionCaseID,
    CAST(NULL AS BIGINT) AS QuestionGroupSubmissionCaseID,
    CAST(NULL AS STRING) AS SourceTrackingSystemUserID,
    CAST(NULL AS BIGINT) AS TrackingUserID,
    CAST(NULL AS STRING) AS SourceCurrentSecondaryComplianceRegionID,
    CAST(NULL AS BIGINT) AS CurrentSecondaryComplianceRegionID,
    CAST(NULL AS STRING) AS SourceCurrentAssignedComplianceRegionID,
    CAST(NULL AS BIGINT) AS CurrentAssignedComplianceRegionID,
    CAST(2 AS BIGINT) AS SourceSystemID
WHERE FALSE;