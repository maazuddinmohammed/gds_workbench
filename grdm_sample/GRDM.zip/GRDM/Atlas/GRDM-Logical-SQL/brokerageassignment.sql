SELECT
    ba.brokerage_assignment_id AS SourceBrokerageAssignmentID,
    ba.entity_id AS SourceBusinessEntityID,
    CAST(NULL AS BIGINT) AS BusinessEntityID,
    ba.compliance_region_id AS SourceComplianceRegionID,
    CAST(NULL AS BIGINT) AS ComplianceRegionID,
    ba.is_bdi_enable AS IsBdiEnabled,
    ba.is_bdi_exempt AS IsBdiExempt,
    ba.bdi_action_authorized_compliance_region_id AS SourceBdiActionAuthorizedComplianceRegionID,
    CAST(NULL AS BIGINT) AS BdiActionAuthorizedComplianceRegionID,
    ba.bdi_exempt_status_change_time AS BdiExemptStatusChangeTime,
    ba.bdi_enable_status_change_time AS BdiEnableStatusChangeTime,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_brokerage_assignment_v1 AS ba;