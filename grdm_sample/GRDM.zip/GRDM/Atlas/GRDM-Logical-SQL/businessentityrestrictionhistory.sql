SELECT
    COALESCE(to_json(array(h.entity_restriction_id)), '[null]') AS RestrictionIdentity,
    h.entity_restriction_id AS SourceEntityRestrictionID,
    h.restricted_compliance_region_id AS SourceRestrictedComplianceRegionID,
    h.last_change_time AS LastChangeTime,
    h.entity_id AS SourceBusinessEntityID,
    CAST(NULL AS BIGINT) AS BusinessEntityID,
    CAST(NULL AS BIGINT) AS RestrictedComplianceRegionID,
    h.entity_type AS RecordedEntityType,
    h.restriction_type AS RestrictionType,
    h.restriction_state AS RestrictionState,
    h.restriction_reason AS RestrictionReason,
    h.restriction_applied AS RestrictionApplied,
    h.is_restricted AS IsRestricted,
    h.is_applicable AS IsApplicable,
    h.inherited_from_parent_compliance_region_id AS SourceInheritedFromParentComplianceRegionID,
    CAST(NULL AS BIGINT) AS InheritedFromParentComplianceRegionID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_entity_restriction_history_v1 AS h;