SELECT
    h.child_to_parent_bridge_id AS SourceEntitySecurityRelationshipID,
    h.last_change_time AS LastChangeTime,
    CAST(NULL AS BIGINT) AS EntitySecurityRelationshipID,
    h.child_entity_security_id AS SourceChildEntitySecurityID,
    h.parent_entity_security_id AS SourceParentEntitySecurityID,
    CAST(NULL AS BIGINT) AS ChildSecurityID,
    CAST(NULL AS BIGINT) AS ParentSecurityID,
    h.relationship_type AS RelationshipType,
    h.relationship_status AS RelationshipStatus,
    h.is_restriction_flow_down AS IsRestrictionFlowDown,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_child_to_parent_bridge_history_v1 AS h;