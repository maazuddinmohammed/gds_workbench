SELECT
    a.location_engagement_by_firm_action_id AS SourceLocationEngagementFirmActionID,
    a.firm_action_case_id AS SourceFirmActionCaseID,
    CAST(NULL AS BIGINT) AS FirmActionCaseID,
    a.location_engagement_assignment_case_id AS SourceLocationEngagementAssignmentCaseID,
    CAST(NULL AS BIGINT) AS LocationEngagementAssignmentID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_location_engagement_by_firm_action_v1 AS a;