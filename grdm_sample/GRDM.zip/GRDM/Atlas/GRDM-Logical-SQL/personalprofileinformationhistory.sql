SELECT
    h.personal_profile_information_id AS SourcePersonalProfileInformationID,
    h.last_change_time AS LastChangeTime,
    CAST(NULL AS BIGINT) AS PersonalProfileInformationID,
    h.tracking_system_user_id AS SourceTrackingSystemUserID,
    CAST(NULL AS BIGINT) AS OwningUserID,
    h.personal_profile_information_type AS InformationType,
    h.personal_profile_information_attribute AS AttributeName,
    h.personal_profile_information_text AS TextValue,
    h.personal_profile_information_long AS LongValue,
    h.last_change_user AS LastChangeLoginUserID,
    CAST(NULL AS BIGINT) AS LastChangeUserID,
    h.current_assigned_compliance_region_id AS SourceCapturedAssignedComplianceRegionID,
    CAST(NULL AS BIGINT) AS CapturedAssignedComplianceRegionID,
    h.current_secondary_compliance_region_id AS SourceCapturedSecondaryComplianceRegionID,
    CAST(NULL AS BIGINT) AS CapturedSecondaryComplianceRegionID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_personal_profile_information_history_v1 AS h;