SELECT
    r.from_entity_perm_id AS SourceFromEntityID,
    r.relationship_type_code AS RelationshipTypeCode,
    r.to_entity_perm_id AS SourceToEntityID,
    r.fund_holding_weight AS FundHoldingWeight,
    CAST(4 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.rft_gmf_entity_relation_initial_globalfunds AS r;