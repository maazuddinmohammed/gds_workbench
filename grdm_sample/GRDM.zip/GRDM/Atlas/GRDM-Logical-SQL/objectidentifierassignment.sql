SELECT
    x.perm_id AS SourceObjectID,
    x.object_type_code AS ObjectTypeCode,
    x.identifier_type_code AS IdentifierTypeCode,
    x.identifier_value AS IdentifierValue,
    x.current_flag AS CurrentFlag,
    CAST(4 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.rft_gmf_symbol_cross_ref_initial AS x;