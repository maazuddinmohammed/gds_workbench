SELECT
    h.user_device_information_id AS SourceUserDeviceID,
    h.last_change_time AS LastChangeTime,
    CAST(NULL AS BIGINT) AS CurrentUserDeviceID,
    h.tracking_system_user_id AS SourceTrackingSystemUserID,
    CAST(NULL AS BIGINT) AS OwningUserID,
    h.last_access_time AS LastAccessTime,
    h.notification_platform AS NotificationPlatform,
    h.installed_app_version AS InstalledAppVersion,
    h.status AS Status,
    h.record_type AS RecordType,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_user_device_history_v1 AS h;