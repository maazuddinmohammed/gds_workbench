SELECT
    o.entity_organization_code AS OrganizationCode,
    o.entity_organization_desc AS Description,
    CAST(3 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.sntl_x_entityorganization AS o;