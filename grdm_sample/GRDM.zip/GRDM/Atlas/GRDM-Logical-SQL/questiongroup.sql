SELECT
    q.question_group_id AS SourceQuestionGroupID,
    q.status AS Status,
    q.move_to_production_time AS MoveToProductionTime,
    q.archive_time AS ArchiveTime,
    q.sec_role AS SecurityRole,
    q.holding_type AS HoldingType,
    q.entity_security_id AS SourceEntitySecurityID,
    q.holding_type_scope AS HoldingTypeScope,
    q.new_question_group_id AS SourceNewQuestionGroupID,
    CAST(NULL AS BIGINT) AS NewQuestionGroupID,
    q.financial_interest_sub_type_list_code_id AS SourceFinancialInterestSubtypeListCodeID,
    CAST(NULL AS BIGINT) AS FinancialInterestSubtypeListCodeID,
    q.restriction_type AS RestrictionType,
    q.stock_type AS StockType,
    q.compliance_region_id AS SourceComplianceRegionID,
    CAST(NULL AS BIGINT) AS ComplianceRegionID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_question_group_v1 AS q;