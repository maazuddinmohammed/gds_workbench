CREATE OR REPLACE TEMPORARY VIEW temp_user_question_instance_kics_regular AS
SELECT
    'Regular' AS ResponseKind,
    t13.user_question_id AS SourceUserQuestionID
FROM gds_grdm_raw.kics_question_group_user_response_v1 AS t13
WHERE t13.user_question_id IS NOT NULL;

CREATE OR REPLACE TEMPORARY VIEW temp_user_question_instance_kics_supplemental AS
SELECT
    'Supplemental' AS ResponseKind,
    t11.user_question_id AS SourceUserQuestionID
FROM gds_grdm_raw.kics_question_group_user_response_for_supplemental_data_v1 AS t11
WHERE t11.user_question_id IS NOT NULL;

CREATE OR REPLACE TEMPORARY VIEW temp_user_question_instance_kics_combined AS
SELECT ResponseKind, SourceUserQuestionID
FROM temp_user_question_instance_kics_regular
UNION ALL
SELECT ResponseKind, SourceUserQuestionID
FROM temp_user_question_instance_kics_supplemental;

CREATE OR REPLACE TEMPORARY VIEW temp_user_question_instance_kics_identities AS
SELECT ResponseKind, SourceUserQuestionID
FROM temp_user_question_instance_kics_combined
GROUP BY ResponseKind, SourceUserQuestionID;

SELECT
    ResponseKind,
    SourceUserQuestionID,
    CAST(NULL AS STRING) AS SourceQuestionID,
    CAST(NULL AS BIGINT) AS QuestionID,
    CAST(NULL AS STRING) AS SourceNextUserQuestionID,
    CAST(NULL AS STRING) AS SourceUserQuestionSetCaseID,
    CAST(NULL AS BIGINT) AS UserQuestionSetCaseID,
    CAST(NULL AS STRING) AS SourceSupplementalDataQuestionSetCaseID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM temp_user_question_instance_kics_identities;