CREATE OR REPLACE TEMPORARY VIEW temp_submission_initial_delivery_question_type_occurrence_kics_parsed AS
SELECT
    o.question_group_submission_case_id AS case_id,
    o.initial_delivery_question_types AS raw_value,
    try_parse_json(o.initial_delivery_question_types) AS j
FROM gds_grdm_raw.kics_question_group_submission_v1 AS o;

CREATE OR REPLACE TEMPORARY VIEW temp_submission_initial_delivery_question_type_occurrence_kics_classified AS
SELECT
    p.case_id,
    p.raw_value,
    p.j,
    CASE
        WHEN p.raw_value IS NULL THEN 'Null'
        WHEN schema_of_variant(p.j) LIKE 'ARRAY<%' THEN
            CASE WHEN size(CAST(p.j AS ARRAY<VARIANT>)) = 0 THEN 'Empty' ELSE 'Array' END
        ELSE 'Undecoded'
    END AS collection_state
FROM temp_submission_initial_delivery_question_type_occurrence_kics_parsed AS p;

CREATE OR REPLACE TEMPORARY VIEW temp_submission_initial_delivery_question_type_occurrence_kics_occurrences AS
SELECT
    c.case_id,
    CAST(0 AS BIGINT) AS occurrence_position,
    c.collection_state,
    CASE
        WHEN c.collection_state = 'Undecoded' THEN c.raw_value
        ELSE CAST(NULL AS STRING)
    END AS occurrence_value
FROM temp_submission_initial_delivery_question_type_occurrence_kics_classified AS c
UNION ALL
SELECT
    c.case_id,
    CAST(e.pos AS BIGINT) + CAST(1 AS BIGINT) AS occurrence_position,
    c.collection_state,
    CASE
        WHEN schema_of_variant(e.value) = 'STRING' THEN CAST(e.value AS STRING)
        ELSE to_json(e.value)
    END AS occurrence_value
FROM temp_submission_initial_delivery_question_type_occurrence_kics_classified AS c,
LATERAL variant_explode(
    CASE
        WHEN c.collection_state IN ('Empty', 'Array') THEN c.j
        ELSE parse_json('[]')
    END
) AS e;

SELECT
    r.case_id AS SourceQuestionGroupSubmissionCaseID,
    r.occurrence_position AS OccurrencePosition,
    r.collection_state AS CollectionState,
    r.occurrence_value AS `Value`,
    CAST(NULL AS BIGINT) AS QuestionGroupSubmissionCaseID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM temp_submission_initial_delivery_question_type_occurrence_kics_occurrences AS r;