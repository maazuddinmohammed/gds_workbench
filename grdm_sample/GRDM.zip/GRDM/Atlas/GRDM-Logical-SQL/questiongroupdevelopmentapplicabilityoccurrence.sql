CREATE OR REPLACE TEMPORARY VIEW temp_question_group_dev_app_kics_collections AS
SELECT
    q.question_group_id AS SourceQuestionGroupID,
    c.kind AS ApplicabilityKind,
    c.raw_value
FROM gds_grdm_raw.kics_question_group_v1 AS q
LATERAL VIEW STACK(
    3,
    'SecurityRole', q.development_question_group_sec_role_array,
    'HoldingType', q.development_question_group_holding_type_array,
    'RestrictionType', q.development_question_group_restriction_type_array
) c AS kind, raw_value;

CREATE OR REPLACE TEMPORARY VIEW temp_question_group_dev_app_kics_decoded AS
SELECT
    SourceQuestionGroupID,
    ApplicabilityKind,
    raw_value,
    TRY_VARIANT_GET(TRY_PARSE_JSON(raw_value), '$', 'ARRAY<VARIANT>') AS elements
FROM temp_question_group_dev_app_kics_collections;

CREATE OR REPLACE TEMPORARY VIEW temp_question_group_dev_app_kics_classified AS
SELECT
    SourceQuestionGroupID,
    ApplicabilityKind,
    raw_value,
    elements,
    CASE
        WHEN raw_value IS NULL THEN 'Null'
        WHEN elements IS NULL THEN 'Undecoded'
        WHEN SIZE(elements) = 0 THEN 'Empty'
        ELSE 'Array'
    END AS CollectionState
FROM temp_question_group_dev_app_kics_decoded;

CREATE OR REPLACE TEMPORARY VIEW temp_question_group_dev_app_kics_occurrences AS
SELECT
    d.SourceQuestionGroupID,
    d.ApplicabilityKind,
    CAST(0 AS BIGINT) AS OccurrencePosition,
    d.CollectionState,
    CASE
        WHEN d.CollectionState = 'Undecoded' THEN d.raw_value
        ELSE CAST(NULL AS STRING)
    END AS `Value`
FROM temp_question_group_dev_app_kics_classified AS d
UNION ALL
SELECT
    d.SourceQuestionGroupID,
    d.ApplicabilityKind,
    CAST(e.pos + 1 AS BIGINT) AS OccurrencePosition,
    d.CollectionState,
    CASE
        WHEN SCHEMA_OF_VARIANT(e.element) = 'STRING' THEN CAST(e.element AS STRING)
        ELSE TO_JSON(e.element)
    END AS `Value`
FROM temp_question_group_dev_app_kics_classified AS d
LATERAL VIEW POSEXPLODE(d.elements) e AS pos, element;

SELECT
    SourceQuestionGroupID,
    ApplicabilityKind,
    OccurrencePosition,
    CollectionState,
    `Value`,
    CAST(NULL AS BIGINT) AS QuestionGroupID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM temp_question_group_dev_app_kics_occurrences;