CREATE OR REPLACE TEMPORARY VIEW temp_security_collection_occurrence_kics_collections AS
SELECT s.security_id AS SourceSecurityID, c.CollectionName, c.RawValue
FROM gds_grdm_raw.kics_security_v1 AS s
LATERAL VIEW STACK(9,
  'parent_entity_security_name_array', s.parent_entity_security_name_array,
  'parent_entity_security_type_array', s.parent_entity_security_type_array,
  'relationship_type_array', s.relationship_type_array,
  'symbol_exchange_array', s.symbol_exchange_array,
  'cusip_array', s.cusip_array,
  'isin_array', s.isin_array,
  'sedol_array', s.sedol_array,
  'alias_value_array', s.alias_value_array,
  'is_restriction_flow_down_array', s.is_restriction_flow_down_array
) c AS CollectionName, RawValue;

CREATE OR REPLACE TEMPORARY VIEW temp_security_collection_occurrence_kics_parsed AS
SELECT SourceSecurityID, CollectionName, RawValue,
  TRY_PARSE_JSON(RawValue) AS ParsedValue
FROM temp_security_collection_occurrence_kics_collections;

CREATE OR REPLACE TEMPORARY VIEW temp_security_collection_occurrence_kics_classified AS
SELECT SourceSecurityID, CollectionName, RawValue, ParsedValue,
  CASE
    WHEN RawValue IS NULL THEN 'Null'
    WHEN SCHEMA_OF_VARIANT(ParsedValue) LIKE 'ARRAY<%' AND TO_JSON(ParsedValue) = '[]' THEN 'Empty'
    WHEN SCHEMA_OF_VARIANT(ParsedValue) LIKE 'ARRAY<%' THEN 'Array'
    ELSE 'Undecoded'
  END AS CollectionState
FROM temp_security_collection_occurrence_kics_parsed;

CREATE OR REPLACE TEMPORARY VIEW temp_security_collection_occurrence_kics_occurrences AS
SELECT c.SourceSecurityID, c.CollectionName,
  CAST(0 AS BIGINT) AS OccurrencePosition, c.CollectionState,
  CASE WHEN c.CollectionState = 'Undecoded' THEN c.RawValue ELSE CAST(NULL AS STRING) END AS `Value`
FROM temp_security_collection_occurrence_kics_classified AS c
UNION ALL
SELECT c.SourceSecurityID, c.CollectionName,
  CAST(e.pos + 1 AS BIGINT) AS OccurrencePosition, c.CollectionState,
  CASE WHEN SCHEMA_OF_VARIANT(e.value) = 'STRING' THEN CAST(e.value AS STRING) ELSE TO_JSON(e.value) END AS `Value`
FROM temp_security_collection_occurrence_kics_classified AS c,
LATERAL VARIANT_EXPLODE(CASE WHEN c.CollectionState = 'Array' THEN c.ParsedValue ELSE PARSE_JSON('[]') END) AS e
WHERE c.CollectionState = 'Array';

SELECT SourceSecurityID, CollectionName, OccurrencePosition, CollectionState, `Value`,
  CAST(NULL AS BIGINT) AS SecurityID,
  CAST(2 AS BIGINT) AS SourceSystemID
FROM temp_security_collection_occurrence_kics_occurrences;