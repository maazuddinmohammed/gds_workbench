CREATE OR REPLACE TEMPORARY VIEW temp_question_system_query_configuration_kics_input AS
SELECT
    q.question_id,
    q.system_query_identifier,
    q.system_query_name,
    q.system_query_description,
    q.system_query_compliance_region_id,
    q.system_query_action,
    q.system_query_condition,
    q.system_query_source_field,
    q.system_query_target_field,
    q.system_query_compared_value,
    q.system_query_status,
    q.system_query_move_to_production_user_id,
    q.system_query_move_to_production_time,
    q.system_query_move_to_archive_user_id,
    q.system_query_move_to_archive_time,
    q.system_query_source_category
FROM gds_grdm_raw.kics_question_group_question_v1 AS q
WHERE q.system_query_identifier IS NOT NULL
   OR q.system_query_name IS NOT NULL
   OR q.system_query_description IS NOT NULL
   OR q.system_query_compliance_region_id IS NOT NULL
   OR q.system_query_action IS NOT NULL
   OR q.system_query_condition IS NOT NULL
   OR q.system_query_source_field IS NOT NULL
   OR q.system_query_target_field IS NOT NULL
   OR q.system_query_compared_value IS NOT NULL
   OR q.system_query_status IS NOT NULL
   OR q.system_query_move_to_production_user_id IS NOT NULL
   OR q.system_query_move_to_production_time IS NOT NULL
   OR q.system_query_move_to_archive_user_id IS NOT NULL
   OR q.system_query_move_to_archive_time IS NOT NULL
   OR q.system_query_source_category IS NOT NULL;

SELECT
    q.question_id AS SourceQuestionID,
    CAST(NULL AS BIGINT) AS QuestionID,
    q.system_query_identifier AS SystemQueryIdentifierID,
    q.system_query_name AS Name,
    q.system_query_description AS Description,
    q.system_query_compliance_region_id AS SourceComplianceRegionID,
    CAST(NULL AS BIGINT) AS ComplianceRegionID,
    q.system_query_action AS `Action`,
    q.system_query_condition AS `Condition`,
    q.system_query_source_field AS SourceField,
    q.system_query_target_field AS TargetField,
    q.system_query_compared_value AS ComparedValue,
    q.system_query_status AS Status,
    q.system_query_move_to_production_user_id AS SourceMoveToProductionUserID,
    q.system_query_move_to_production_time AS MoveToProductionTime,
    q.system_query_move_to_archive_user_id AS SourceMoveToArchiveUserID,
    q.system_query_move_to_archive_time AS MoveToArchiveTime,
    q.system_query_source_category AS SourceCategory,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM temp_question_system_query_configuration_kics_input AS q;