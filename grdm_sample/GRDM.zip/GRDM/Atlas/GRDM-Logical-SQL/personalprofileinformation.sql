SELECT
    p.personal_profile_information_id AS SourcePersonalProfileInformationID,
    p.tracking_system_user_id AS SourceTrackingSystemUserID,
    CAST(NULL AS BIGINT) AS OwningUserID,
    p.personal_profile_information_type AS InformationType,
    p.personal_profile_information_attribute AS AttributeName,
    p.personal_profile_information_text AS TextValue,
    p.personal_profile_information_long AS LongValue,
    p.current_assigned_compliance_region_id AS SourceCurrentAssignedComplianceRegionID,
    CAST(NULL AS BIGINT) AS CurrentAssignedComplianceRegionID,
    p.current_secondary_compliance_region_id AS SourceCurrentSecondaryComplianceRegionID,
    CAST(NULL AS BIGINT) AS CurrentSecondaryComplianceRegionID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_personal_profile_information_v1 AS p;