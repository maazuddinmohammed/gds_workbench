SELECT
    h.compliance_region_id AS SourceComplianceRegionID,
    h.capability_name AS CapabilityName,
    h.last_change_time AS LastChangeTime,
    CAST(NULL AS BIGINT) AS ComplianceRegionID,
    h.is_admin_enabled AS IsAdminEnabled,
    h.is_compliance_officer_enabled AS IsComplianceOfficerEnabled,
    h.is_reviewer_enabled AS IsReviewerEnabled,
    h.is_superuser_enabled AS IsSuperuserEnabled,
    h.last_change_user AS SourceLastChangeLoginUserID,
    CAST(NULL AS BIGINT) AS LastChangeUserID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_compliance_region_capability_history AS h;