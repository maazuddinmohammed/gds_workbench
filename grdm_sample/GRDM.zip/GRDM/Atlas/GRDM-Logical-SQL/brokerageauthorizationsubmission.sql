CREATE OR REPLACE TEMPORARY VIEW temp_brokerage_authorization_submission_kics_input AS
SELECT
    h.case_id AS SourceHoldingCaseID,
    h.brokerage_authorization_submission_state AS State,
    h.brokerage_authorization_submission_submit_time AS SubmitTime,
    h.brokerage_authorization_submission_reviewer_comment AS ReviewerComment,
    h.brokerage_authorization_submission_user_submit_comment AS UserSubmitComment,
    h.brokerage_authorization_submission_approved_time AS ApprovedTime,
    h.brokerage_authorization_submission_submitted_to_broker_time AS SubmittedToBrokerTime
FROM gds_grdm_raw.kics_holding_v1 AS h
WHERE h.brokerage_authorization_submission_state IS NOT NULL
   OR h.brokerage_authorization_submission_submit_time IS NOT NULL
   OR h.brokerage_authorization_submission_reviewer_comment IS NOT NULL
   OR h.brokerage_authorization_submission_user_submit_comment IS NOT NULL
   OR h.brokerage_authorization_submission_approved_time IS NOT NULL
   OR h.brokerage_authorization_submission_submitted_to_broker_time IS NOT NULL
   OR h.brokerage_authorization_submission_attachment_filename_array IS NOT NULL
   OR h.brokerage_authorization_submission_attachment_add_date_array IS NOT NULL
   OR h.brokerage_authorization_submission_attachment_service_center_provided_array IS NOT NULL;

SELECT
    SourceHoldingCaseID,
    CAST(NULL AS BIGINT) AS HoldingCaseID,
    State,
    SubmitTime,
    ReviewerComment,
    UserSubmitComment,
    ApprovedTime,
    SubmittedToBrokerTime,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM temp_brokerage_authorization_submission_kics_input;