CREATE OR REPLACE TEMPORARY VIEW temp_notice_type_occurrence_kics_parsed AS
SELECT
    n.entity_security_notice_id,
    n.notice_types,
    try_parse_json(n.notice_types) AS parsed_json
FROM gds_grdm_raw.kics_entity_security_notice_v1 AS n;

CREATE OR REPLACE TEMPORARY VIEW temp_notice_type_occurrence_kics_arrays AS
SELECT
    p.entity_security_notice_id,
    p.notice_types,
    try_variant_get(p.parsed_json, '$', 'ARRAY<VARIANT>') AS elements
FROM temp_notice_type_occurrence_kics_parsed AS p;

CREATE OR REPLACE TEMPORARY VIEW temp_notice_type_occurrence_kics_classified AS
SELECT
    a.entity_security_notice_id,
    a.notice_types,
    a.elements,
    CASE
        WHEN a.notice_types IS NULL THEN 'Null'
        WHEN a.elements IS NULL THEN 'Undecoded'
        WHEN size(a.elements) = 0 THEN 'Empty'
        ELSE 'Array'
    END AS collection_state
FROM temp_notice_type_occurrence_kics_arrays AS a;

CREATE OR REPLACE TEMPORARY VIEW temp_notice_type_occurrence_kics_rows AS
SELECT
    c.entity_security_notice_id,
    CAST(0 AS BIGINT) AS occurrence_position,
    c.collection_state,
    CASE
        WHEN c.collection_state = 'Undecoded' THEN c.notice_types
        ELSE CAST(NULL AS STRING)
    END AS occurrence_value
FROM temp_notice_type_occurrence_kics_classified AS c
UNION ALL
SELECT
    c.entity_security_notice_id,
    CAST(e.pos AS BIGINT) + CAST(1 AS BIGINT) AS occurrence_position,
    c.collection_state,
    CASE
        WHEN schema_of_variant(e.element) = 'STRING' THEN variant_get(e.element, '$', 'STRING')
        ELSE to_json(e.element)
    END AS occurrence_value
FROM temp_notice_type_occurrence_kics_classified AS c
LATERAL VIEW posexplode(c.elements) e AS pos, element
WHERE c.collection_state = 'Array';

SELECT
    o.entity_security_notice_id AS SourceEntitySecurityNoticeID,
    o.occurrence_position AS OccurrencePosition,
    o.collection_state AS CollectionState,
    o.occurrence_value AS `Value`,
    CAST(NULL AS BIGINT) AS EntitySecurityNoticeID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM temp_notice_type_occurrence_kics_rows AS o;