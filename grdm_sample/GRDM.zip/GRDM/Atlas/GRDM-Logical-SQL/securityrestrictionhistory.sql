SELECT
    COALESCE(to_json(array(h.security_restriction_id)), '[null]') AS RestrictionIdentity,
    h.security_restriction_id AS SourceSecurityRestrictionID,
    h.restricted_compliance_region_id AS SourceRestrictedComplianceRegionID,
    h.last_change_time AS LastChangeTime,
    h.security_id AS SourceSecurityID,
    CAST(NULL AS BIGINT) AS SecurityID,
    CAST(NULL AS BIGINT) AS RestrictedComplianceRegionID,
    h.security_type AS RecordedSecurityType,
    h.restriction_type AS RestrictionType,
    h.restriction_state AS RestrictionState,
    h.restriction_reason AS RestrictionReason,
    h.restriction_applied AS RestrictionApplied,
    h.is_restricted AS IsRestricted,
    h.is_applicable AS IsApplicable,
    h.inherited_from_parent_compliance_region_id AS SourceInheritedFromParentComplianceRegionID,
    CAST(NULL AS BIGINT) AS InheritedFromParentComplianceRegionID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_security_restriction_history_v1 AS h;