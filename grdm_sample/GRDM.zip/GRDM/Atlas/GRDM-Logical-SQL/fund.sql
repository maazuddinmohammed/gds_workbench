SELECT
    f.entity_perm_id AS SourceFundID,
    f.official_name AS OfficialName,
    f.domicile AS Domicile,
    f.ndf AS Ndf,
    f.fund_marketing_group_name AS MarketingGroupName,
    CAST(4 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.rft_gmf_entity_detail_initial_globalfunds AS f;