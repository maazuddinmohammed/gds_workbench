SELECT
    d.user_device_information_id AS SourceUserDeviceID,
    d.tracking_system_user_id AS SourceTrackingSystemUserID,
    CAST(NULL AS BIGINT) AS OwningUserID,
    d.last_access_time AS LastAccessTime,
    d.notification_platform AS NotificationPlatform,
    d.installed_app_version AS InstalledAppVersion,
    d.status AS Status,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_user_device_v1 AS d;