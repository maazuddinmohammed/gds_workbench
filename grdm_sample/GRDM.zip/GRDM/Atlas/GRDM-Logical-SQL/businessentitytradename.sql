CREATE OR REPLACE TEMPORARY VIEW temp_business_entity_trade_name_sntl_input AS
SELECT
    e.entity_id,
    e.trade_style,
    e.second_trade_style
FROM gds_grdm_raw.sntl_x_entity AS e;

CREATE OR REPLACE TEMPORARY VIEW temp_business_entity_trade_name_sntl_slots AS
SELECT
    e.entity_id AS SourceBusinessEntityID,
    CAST(1 AS BIGINT) AS TradeNamePosition,
    e.trade_style AS TradeName
FROM temp_business_entity_trade_name_sntl_input AS e
UNION ALL
SELECT
    e.entity_id AS SourceBusinessEntityID,
    CAST(2 AS BIGINT) AS TradeNamePosition,
    e.second_trade_style AS TradeName
FROM temp_business_entity_trade_name_sntl_input AS e;

SELECT
    n.SourceBusinessEntityID AS SourceBusinessEntityID,
    n.TradeNamePosition AS TradeNamePosition,
    n.TradeName AS TradeName,
    CAST(NULL AS BIGINT) AS BusinessEntityID,
    CAST(3 AS BIGINT) AS SourceSystemID
FROM temp_business_entity_trade_name_sntl_slots AS n;