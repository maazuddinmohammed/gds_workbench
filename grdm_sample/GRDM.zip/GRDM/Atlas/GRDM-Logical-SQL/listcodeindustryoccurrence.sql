CREATE OR REPLACE TEMPORARY VIEW temp_list_code_industry_occurrence_kics_parsed AS
SELECT
    lc.list_code_id,
    lc.sic_codes,
    TRY_CAST(TRY_PARSE_JSON(lc.sic_codes) AS ARRAY<VARIANT>) AS codes
FROM gds_grdm_raw.kics_list_code_v1 AS lc;

CREATE OR REPLACE TEMPORARY VIEW temp_list_code_industry_occurrence_kics_classified AS
SELECT
    p.list_code_id,
    p.sic_codes,
    p.codes,
    CASE
        WHEN p.sic_codes IS NULL THEN 'Null'
        WHEN SIZE(p.codes) = 0 THEN 'Empty'
        WHEN p.codes IS NOT NULL THEN 'Array'
        ELSE 'Undecoded'
    END AS encoding_state
FROM temp_list_code_industry_occurrence_kics_parsed AS p;

CREATE OR REPLACE TEMPORARY VIEW temp_list_code_industry_occurrence_kics_occurrences AS
SELECT
    c.list_code_id,
    CAST(0 AS BIGINT) AS occurrence_position,
    c.encoding_state,
    CASE
        WHEN c.encoding_state = 'Undecoded' THEN c.sic_codes
        ELSE CAST(NULL AS STRING)
    END AS industry_code_value
FROM temp_list_code_industry_occurrence_kics_classified AS c
UNION ALL
SELECT
    c.list_code_id,
    CAST(e.pos AS BIGINT) + CAST(1 AS BIGINT) AS occurrence_position,
    c.encoding_state,
    CASE
        WHEN IS_VARIANT_NULL(e.element) THEN CAST(NULL AS STRING)
        WHEN SCHEMA_OF_VARIANT(e.element) = 'STRING' THEN VARIANT_GET(e.element, '$', 'STRING')
        ELSE TO_JSON(e.element)
    END AS industry_code_value
FROM temp_list_code_industry_occurrence_kics_classified AS c
LATERAL VIEW POSEXPLODE(c.codes) e AS pos, element;

SELECT
    o.list_code_id AS SourceListCodeID,
    o.occurrence_position AS OccurrencePosition,
    o.encoding_state AS EncodingState,
    o.industry_code_value AS IndustryCodeValue,
    CAST(NULL AS BIGINT) AS ListCodeID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM temp_list_code_industry_occurrence_kics_occurrences AS o;