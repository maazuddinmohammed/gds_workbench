SELECT
    a.`AffiliateTypeID` AS `SourceAffiliateTypeID`,
    a.`AffiliateTypeCode` AS `AffiliateTypeCode`,
    a.`AffiliateTypeName` AS `Name`,
    a.`DisplayCode` AS `DisplayCode`,
    a.`IsActive` AS `SourceActiveIndicator`,
    a.`DisplayOrder` AS `DisplayOrder`,
    a.`AffiliateTypeRank` AS `AffiliateTypeRank`,
    a.`AffiliateTypeAliasCode` AS `AffiliateTypeAliasCode`,
    a.`OrganizationType` AS `OrganizationType`,
    a.`Description` AS `Description`,
    a.`LongDescription` AS `LongDescription`,
    CAST(3 AS BIGINT) AS `SourceSystemID`
FROM `gds_grdm_raw`.`sntl_x_affiliatetype` AS a;