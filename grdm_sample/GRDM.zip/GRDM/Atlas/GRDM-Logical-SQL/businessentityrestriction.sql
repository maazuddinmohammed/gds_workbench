SELECT
    COALESCE(to_json(array(t3.entity_restriction_id)), '[null]') AS RestrictionIdentity,
    t3.entity_restriction_id AS SourceEntityRestrictionID,
    t3.restricted_compliance_region_id AS SourceRestrictedComplianceRegionID,
    t3.entity_id AS SourceBusinessEntityID,
    CAST(NULL AS BIGINT) AS BusinessEntityID,
    CAST(NULL AS BIGINT) AS RestrictedComplianceRegionID,
    t3.entity_type AS RecordedEntityType,
    t3.restriction_type AS RestrictionType,
    t3.restriction_state AS RestrictionState,
    t3.restriction_reason AS RestrictionReason,
    t3.restriction_applied AS RestrictionApplied,
    t3.is_restricted AS IsRestricted,
    t3.is_applicable AS IsApplicable,
    t3.inherited_from_parent_compliance_region_id AS SourceInheritedFromParentComplianceRegionID,
    CAST(NULL AS BIGINT) AS InheritedFromParentComplianceRegionID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_entity_restriction_v1 AS t3;