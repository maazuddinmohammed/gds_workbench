SELECT
    a.decision_tree_answer_id AS SourceDecisionTreeAnswerID,
    a.decision_tree_answer_identifier AS DecisionTreeAnswerIdentifierID,
    a.question_id AS SourceQuestionID,
    CAST(NULL AS BIGINT) AS QuestionID,
    a.action_if_chosen AS ActionIfChosen,
    a.next_question_id AS SourceNextQuestionID,
    CAST(NULL AS BIGINT) AS NextQuestionID,
    a.skip_to_question_set_id AS SourceSkipToQuestionSetID,
    a.is_supplemental_data_enabled AS IsSupplementalDataEnabled,
    a.supplemental_data_section_id AS SourceSupplementalDataSectionID,
    a.answer_choice_type AS AnswerChoiceType,
    a.answer_choice_number AS AnswerChoiceNumber,
    a.answer_choice_text AS AnswerChoiceText,
    a.is_system_query_comparison_enabled AS IsSystemQueryComparisonEnabled,
    a.answer_description_id AS SourceAnswerDescriptionID,
    CAST(NULL AS BIGINT) AS AnswerDescriptionID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_question_group_answer_choice_and_decision_tree_v1 AS a;