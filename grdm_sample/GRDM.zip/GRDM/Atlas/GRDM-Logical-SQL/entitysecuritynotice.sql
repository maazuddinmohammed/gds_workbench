SELECT
    n.entity_security_notice_id AS SourceEntitySecurityNoticeID,
    n.operator_user_id AS SourceOperatorUserID,
    CAST(NULL AS BIGINT) AS OperatorApplicationUserID,
    n.operator_authorized_compliance_region AS SourceOperatorAuthorizedComplianceRegionID,
    CAST(NULL AS BIGINT) AS OperatorAuthorizedComplianceRegionID,
    n.entity_security_type AS EntitySecurityType,
    n.entity_security_id AS SourceEntitySecurityID,
    n.notice_created_time AS NoticeCreatedTime,
    n.notice_reason AS NoticeReason,
    n.state AS State,
    n.comments AS Comments,
    n.operation_process_type AS OperationProcessType,
    n.compliance_region_id AS SourceComplianceRegionID,
    CAST(NULL AS BIGINT) AS ComplianceRegionID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_entity_security_notice_v1 AS n;