SELECT
    g.firm_action_group_id AS SourceFirmActionGroupID,
    g.firm_action_group_state AS State,
    g.firm_action_group_current_action AS CurrentAction,
    g.is_action_group_retroactive AS IsRetroactive,
    g.auto_process_to AS AutoProcessTo,
    g.auto_process AS AutoProcess,
    g.review_comments AS ReviewComments,
    g.compliance_region_id AS SourceComplianceRegionID,
    CAST(NULL AS BIGINT) AS ComplianceRegionID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_firm_action_group_v1 AS g;