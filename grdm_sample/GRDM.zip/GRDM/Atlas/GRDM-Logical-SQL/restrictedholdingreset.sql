SELECT
    r.reset_restricted_holding_by_firm_action_id AS SourceRestrictedHoldingResetID,
    r.firm_action_case_id AS SourceFirmActionCaseID,
    CAST(NULL AS BIGINT) AS FirmActionCaseID,
    r.holding_case_id AS SourceHoldingCaseID,
    CAST(NULL AS BIGINT) AS HoldingCaseID,
    r.holding_type AS HoldingType,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_reset_restricted_holding_by_firm_action_v1 AS r;