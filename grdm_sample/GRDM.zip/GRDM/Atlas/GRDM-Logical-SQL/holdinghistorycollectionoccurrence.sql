CREATE OR REPLACE TEMPORARY VIEW temp_holding_history_collection_occurrence_kics_unpivoted AS
SELECT
    h.holding_history_id AS SourceHoldingHistoryID,
    h.last_change_time AS LastChangeTime,
    c.CollectionName,
    c.RawValue
FROM gds_grdm_raw.kics_holding_history_v1 AS h
LATERAL VIEW STACK(
    7,
    'holding_attachment_filename_array', h.holding_attachment_filename_array,
    'holding_attachment_add_date_array', h.holding_attachment_add_date_array,
    'holding_attachment_service_center_provided_array', h.holding_attachment_service_center_provided_array,
    'is_third_party_user_update_attachment_array', h.is_third_party_user_update_attachment_array,
    'brokerage_authorization_submission_attachment_filename_array', h.brokerage_authorization_submission_attachment_filename_array,
    'brokerage_authorization_submission_attachment_add_date_array', h.brokerage_authorization_submission_attachment_add_date_array,
    'brokerage_authorization_submission_attachment_service_center_provided_array', h.brokerage_authorization_submission_attachment_service_center_provided_array
) c AS CollectionName, RawValue;

CREATE OR REPLACE TEMPORARY VIEW temp_holding_history_collection_occurrence_kics_parsed AS
SELECT
    SourceHoldingHistoryID,
    LastChangeTime,
    CollectionName,
    RawValue,
    TRY_PARSE_JSON(RawValue) AS ParsedValue
FROM temp_holding_history_collection_occurrence_kics_unpivoted;

CREATE OR REPLACE TEMPORARY VIEW temp_holding_history_collection_occurrence_kics_arrays AS
SELECT
    SourceHoldingHistoryID,
    LastChangeTime,
    CollectionName,
    RawValue,
    CASE
        WHEN SCHEMA_OF_VARIANT(ParsedValue) LIKE 'ARRAY<%'
        THEN VARIANT_GET(ParsedValue, '$', 'ARRAY<VARIANT>')
        ELSE CAST(NULL AS ARRAY<VARIANT>)
    END AS Elements
FROM temp_holding_history_collection_occurrence_kics_parsed;

CREATE OR REPLACE TEMPORARY VIEW temp_holding_history_collection_occurrence_kics_classified AS
SELECT
    SourceHoldingHistoryID,
    LastChangeTime,
    CollectionName,
    RawValue,
    Elements,
    CASE
        WHEN RawValue IS NULL THEN 'Null'
        WHEN Elements IS NULL THEN 'Undecoded'
        WHEN SIZE(Elements) = 0 THEN 'Empty'
        ELSE 'Array'
    END AS CollectionState
FROM temp_holding_history_collection_occurrence_kics_arrays;

CREATE OR REPLACE TEMPORARY VIEW temp_holding_history_collection_occurrence_kics_occurrences AS
SELECT
    SourceHoldingHistoryID,
    LastChangeTime,
    CollectionName,
    CAST(0 AS BIGINT) AS OccurrencePosition,
    CollectionState,
    CASE
        WHEN CollectionState = 'Undecoded' THEN RawValue
        ELSE CAST(NULL AS STRING)
    END AS Value
FROM temp_holding_history_collection_occurrence_kics_classified
UNION ALL
SELECT
    c.SourceHoldingHistoryID,
    c.LastChangeTime,
    c.CollectionName,
    CAST(e.element_index + 1 AS BIGINT) AS OccurrencePosition,
    c.CollectionState,
    CASE
        WHEN IS_VARIANT_NULL(e.element_value) THEN CAST(NULL AS STRING)
        WHEN SCHEMA_OF_VARIANT(e.element_value) = 'STRING' THEN CAST(e.element_value AS STRING)
        ELSE TO_JSON(e.element_value)
    END AS Value
FROM temp_holding_history_collection_occurrence_kics_classified AS c
LATERAL VIEW POSEXPLODE(c.Elements) e AS element_index, element_value;

SELECT
    SourceHoldingHistoryID,
    LastChangeTime,
    CollectionName,
    OccurrencePosition,
    CollectionState,
    Value,
    CAST(NULL AS BIGINT) AS HoldingHistoryID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM temp_holding_history_collection_occurrence_kics_occurrences;