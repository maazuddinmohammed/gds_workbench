CREATE OR REPLACE TEMPORARY VIEW temp_securityquote_rft_continenteq AS
SELECT
    eq.quote_perm_id AS SourceSecurityQuoteID,
    eq.issue_perm_id AS SourceSecurityID,
    CAST(NULL AS BIGINT) AS SecurityID,
    eq.ticker AS Ticker,
    eq.mic AS MarketIdentifierCode,
    CAST(NULL AS STRING) AS OperatingMarketIdentifierCode,
    CAST(NULL AS STRING) AS MarketSegmentIdentifierCode,
    CAST(NULL AS STRING) AS ExchangeCode,
    CAST(4 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.rft_gmf_reference_initial_continenteq AS eq;

CREATE OR REPLACE TEMPORARY VIEW temp_securityquote_rft_continentfd AS
SELECT
    fd.quote_perm_id AS SourceSecurityQuoteID,
    fd.issue_perm_id AS SourceSecurityID,
    CAST(NULL AS BIGINT) AS SecurityID,
    fd.ticker AS Ticker,
    fd.mic AS MarketIdentifierCode,
    fd.operating_mic AS OperatingMarketIdentifierCode,
    fd.market_segment_mic AS MarketSegmentIdentifierCode,
    fd.exchange_code AS ExchangeCode,
    CAST(4 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.rft_gmf_reference_initial_continentfd AS fd;

SELECT
    SourceSecurityQuoteID,
    SourceSecurityID,
    SecurityID,
    Ticker,
    MarketIdentifierCode,
    OperatingMarketIdentifierCode,
    MarketSegmentIdentifierCode,
    ExchangeCode,
    SourceSystemID
FROM temp_securityquote_rft_continenteq
UNION ALL
SELECT
    SourceSecurityQuoteID,
    SourceSecurityID,
    SecurityID,
    Ticker,
    MarketIdentifierCode,
    OperatingMarketIdentifierCode,
    MarketSegmentIdentifierCode,
    ExchangeCode,
    SourceSystemID
FROM temp_securityquote_rft_continentfd;