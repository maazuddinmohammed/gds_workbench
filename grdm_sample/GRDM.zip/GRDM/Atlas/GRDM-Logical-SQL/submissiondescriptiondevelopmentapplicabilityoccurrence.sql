CREATE OR REPLACE TEMPORARY VIEW temp_submission_description_development_kics_collections AS
SELECT
    o.question_group_submission_description_id AS SourceQuestionGroupSubmissionDescriptionID,
    c.kind AS ApplicabilityKind,
    c.raw AS RawValue
FROM gds_grdm_raw.kics_question_group_submission_description_v1 AS o
LATERAL VIEW STACK(
    3,
    'SecurityRole', o.development_description_sec_role_array,
    'HoldingType', o.development_description_holding_type_array,
    'RestrictionType', o.development_description_restriction_type_array
) c AS kind, raw;

CREATE OR REPLACE TEMPORARY VIEW temp_submission_description_development_kics_parsed AS
SELECT
    SourceQuestionGroupSubmissionDescriptionID,
    ApplicabilityKind,
    RawValue,
    TRY_PARSE_JSON(RawValue) AS JsonValue
FROM temp_submission_description_development_kics_collections;

CREATE OR REPLACE TEMPORARY VIEW temp_submission_description_development_kics_decoded AS
SELECT
    SourceQuestionGroupSubmissionDescriptionID,
    ApplicabilityKind,
    RawValue,
    TRY_VARIANT_GET(JsonValue, '$', 'ARRAY<VARIANT>') AS Elements
FROM temp_submission_description_development_kics_parsed;

CREATE OR REPLACE TEMPORARY VIEW temp_submission_description_development_kics_classified AS
SELECT
    SourceQuestionGroupSubmissionDescriptionID,
    ApplicabilityKind,
    RawValue,
    Elements,
    CASE
        WHEN RawValue IS NULL THEN 'Null'
        WHEN Elements IS NULL THEN 'Undecoded'
        WHEN SIZE(Elements) = 0 THEN 'Empty'
        ELSE 'Array'
    END AS CollectionState
FROM temp_submission_description_development_kics_decoded;

CREATE OR REPLACE TEMPORARY VIEW temp_submission_description_development_kics_occurrences AS
SELECT
    c.SourceQuestionGroupSubmissionDescriptionID,
    c.ApplicabilityKind,
    CAST(0 AS BIGINT) AS OccurrencePosition,
    c.CollectionState,
    CASE
        WHEN c.CollectionState = 'Undecoded' THEN c.RawValue
        ELSE CAST(NULL AS STRING)
    END AS `Value`
FROM temp_submission_description_development_kics_classified AS c
UNION ALL
SELECT
    c.SourceQuestionGroupSubmissionDescriptionID,
    c.ApplicabilityKind,
    CAST(e.pos + 1 AS BIGINT) AS OccurrencePosition,
    c.CollectionState,
    CASE
        WHEN SCHEMA_OF_VARIANT(e.element) = 'STRING'
            THEN VARIANT_GET(e.element, '$', 'STRING')
        ELSE TO_JSON(e.element)
    END AS `Value`
FROM temp_submission_description_development_kics_classified AS c
LATERAL VIEW POSEXPLODE(c.Elements) e AS pos, element;

SELECT
    r.SourceQuestionGroupSubmissionDescriptionID AS SourceQuestionGroupSubmissionDescriptionID,
    r.ApplicabilityKind AS ApplicabilityKind,
    r.OccurrencePosition AS OccurrencePosition,
    r.CollectionState AS CollectionState,
    r.`Value` AS `Value`,
    CAST(NULL AS BIGINT) AS QuestionGroupSubmissionDescriptionID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM temp_submission_description_development_kics_occurrences AS r;