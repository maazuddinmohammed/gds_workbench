SELECT
    p.profile_id AS SourceIndividualProfileID,
    p.tracking_system_user_id AS SourceTrackingSystemUserID,
    CAST(NULL AS BIGINT) AS OwningUserID,
    p.first_name AS FirstName,
    p.middle_name AS MiddleName,
    p.last_name AS LastName,
    p.ssn AS SocialSecurityNumber,
    p.profile_type AS ProfileType,
    p.profile_status AS Status,
    p.current_assigned_compliance_region_id AS SourceCurrentAssignedComplianceRegionID,
    CAST(NULL AS BIGINT) AS CurrentAssignedComplianceRegionID,
    p.current_secondary_compliance_region_id AS SourceCurrentSecondaryComplianceRegionID,
    CAST(NULL AS BIGINT) AS CurrentSecondaryComplianceRegionID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_profile_v1 AS p;