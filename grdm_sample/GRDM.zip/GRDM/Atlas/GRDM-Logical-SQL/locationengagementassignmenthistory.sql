SELECT
    h.location_engagement_assignment_case_id AS SourceLocationEngagementAssignmentCaseID,
    h.last_change_time AS LastChangeTime,
    CAST(NULL AS BIGINT) AS LocationEngagementAssignmentID,
    h.assignment_status AS AssignmentStatus,
    h.location_id AS SourceLocationID,
    CAST(NULL AS BIGINT) AS LocationID,
    h.engagement_location_type AS EngagementLocationType,
    h.entity_security_id AS SourceEntitySecurityID,
    h.entity_security_type AS EntitySecurityType,
    h.engagement_comments AS EngagementComments,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_location_engagement_assignment_history_v1 AS h;