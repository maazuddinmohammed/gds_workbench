SELECT
    a.question_set_assignment_id AS SourceQuestionSetAssignmentID,
    a.question_group_id AS SourceQuestionGroupID,
    CAST(NULL AS BIGINT) AS QuestionGroupID,
    a.question_set_id AS SourceQuestionSetID,
    CAST(NULL AS BIGINT) AS QuestionSetID,
    a.question_set_assignment_status AS Status,
    a.question_set_question_type AS QuestionType,
    a.is_default_question_set AS IsDefaultQuestionSet,
    a.question_set_number AS QuestionSetNumber,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_question_group_to_question_bridge_v1 AS a;