SELECT
    dc.default_capability_id AS SourceDefaultCapabilityID,
    dc.capability_name AS CapabilityName,
    dc.is_admin_enabled AS IsAdminEnabled,
    dc.is_compliance_officer_enabled AS IsComplianceOfficerEnabled,
    dc.is_reviewer_enabled AS IsReviewerEnabled,
    dc.is_superuser_enabled AS IsSuperuserEnabled,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_default_capability AS dc;