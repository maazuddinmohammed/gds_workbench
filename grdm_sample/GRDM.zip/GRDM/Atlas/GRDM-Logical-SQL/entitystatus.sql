SELECT
    s.entity_status_code AS StatusCode,
    s.entity_status_description AS Description,
    s.is_entity_active AS IsEntityActive,
    CAST(3 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.sntl_x_entitystatus AS s;