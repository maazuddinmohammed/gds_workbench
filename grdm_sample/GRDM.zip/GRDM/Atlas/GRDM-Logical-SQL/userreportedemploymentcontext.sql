SELECT
    u.tracking_system_user_id AS SourceTrackingSystemUserID,
    CAST(NULL AS BIGINT) AS OwningUserID,
    u.department_number AS DepartmentNumber,
    u.department_code AS DepartmentCode,
    u.department_name AS DepartmentName,
    u.cost_center AS CostCenter,
    u.cost_center_description AS CostCenterDescription,
    u.supervisor_employee_identifier AS SupervisorEmployeeID,
    u.supervisor_first_name AS SupervisorFirstName,
    u.supervisor_last_name AS SupervisorLastName,
    u.supervisor_email_address AS SupervisorEmailAddress,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_user_info_v1 AS u;