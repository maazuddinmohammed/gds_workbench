SELECT
    q.question_id AS SourceQuestionID,
    q.question_number AS QuestionNumber,
    q.question_text AS `Text`,
    q.question_status AS Status,
    q.question_set_id AS SourceQuestionSetID,
    CAST(NULL AS BIGINT) AS QuestionSetID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_question_group_question_v1 AS q;