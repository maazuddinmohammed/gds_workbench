CREATE OR REPLACE TEMPORARY VIEW temp_restriction_collection_occurrence_kics_origins AS
SELECT
  'BusinessEntity' AS RestrictionKind,
  'History' AS LifecycleKind,
  TO_JSON(ARRAY(o.entity_restriction_id)) AS RestrictionIdentity,
  o.restricted_compliance_region_id AS SourceRestrictedComplianceRegionID,
  TO_JSON(ARRAY(o.last_change_time)) AS VersionIdentity,
  o.engagement_partner_assignment_array AS engagement_encoding,
  o.covered_person_restriction_attribute_array AS covered_encoding
FROM gds_grdm_raw.kics_entity_restriction_history_v1 AS o
UNION ALL
SELECT
  'BusinessEntity' AS RestrictionKind,
  'Current' AS LifecycleKind,
  TO_JSON(ARRAY(o.entity_restriction_id)) AS RestrictionIdentity,
  o.restricted_compliance_region_id AS SourceRestrictedComplianceRegionID,
  'Current' AS VersionIdentity,
  o.engagement_partner_assignment_array AS engagement_encoding,
  o.covered_person_restriction_attribute_array AS covered_encoding
FROM gds_grdm_raw.kics_entity_restriction_v1 AS o
UNION ALL
SELECT
  'Security' AS RestrictionKind,
  'History' AS LifecycleKind,
  TO_JSON(ARRAY(o.security_restriction_id)) AS RestrictionIdentity,
  o.restricted_compliance_region_id AS SourceRestrictedComplianceRegionID,
  TO_JSON(ARRAY(o.last_change_time)) AS VersionIdentity,
  o.engagement_partner_assignment_array AS engagement_encoding,
  o.covered_person_restriction_attribute_array AS covered_encoding
FROM gds_grdm_raw.kics_security_restriction_history_v1 AS o
UNION ALL
SELECT
  'Security' AS RestrictionKind,
  'Current' AS LifecycleKind,
  TO_JSON(ARRAY(o.security_restriction_id)) AS RestrictionIdentity,
  o.restricted_compliance_region_id AS SourceRestrictedComplianceRegionID,
  'Current' AS VersionIdentity,
  o.engagement_partner_assignment_array AS engagement_encoding,
  o.covered_person_restriction_attribute_array AS covered_encoding
FROM gds_grdm_raw.kics_security_restriction_v1 AS o;

CREATE OR REPLACE TEMPORARY VIEW temp_restriction_collection_occurrence_kics_collections AS
SELECT
  RestrictionKind,
  LifecycleKind,
  RestrictionIdentity,
  SourceRestrictedComplianceRegionID,
  VersionIdentity,
  'engagement_partner_assignment_array' AS CollectionName,
  engagement_encoding AS raw_encoding
FROM temp_restriction_collection_occurrence_kics_origins
UNION ALL
SELECT
  RestrictionKind,
  LifecycleKind,
  RestrictionIdentity,
  SourceRestrictedComplianceRegionID,
  VersionIdentity,
  'covered_person_restriction_attribute_array' AS CollectionName,
  covered_encoding AS raw_encoding
FROM temp_restriction_collection_occurrence_kics_origins;

CREATE OR REPLACE TEMPORARY VIEW temp_restriction_collection_occurrence_kics_parsed AS
SELECT
  RestrictionKind,
  LifecycleKind,
  RestrictionIdentity,
  SourceRestrictedComplianceRegionID,
  VersionIdentity,
  CollectionName,
  raw_encoding,
  TRY_PARSE_JSON(raw_encoding) AS parsed_encoding
FROM temp_restriction_collection_occurrence_kics_collections;

CREATE OR REPLACE TEMPORARY VIEW temp_restriction_collection_occurrence_kics_arrays AS
SELECT
  RestrictionKind,
  LifecycleKind,
  RestrictionIdentity,
  SourceRestrictedComplianceRegionID,
  VersionIdentity,
  CollectionName,
  raw_encoding,
  CASE
    WHEN SCHEMA_OF_VARIANT(parsed_encoding) LIKE 'ARRAY<%'
    THEN TRY_VARIANT_GET(parsed_encoding, '$', 'ARRAY<VARIANT>')
    ELSE CAST(NULL AS ARRAY<VARIANT>)
  END AS decoded_elements
FROM temp_restriction_collection_occurrence_kics_parsed;

CREATE OR REPLACE TEMPORARY VIEW temp_restriction_collection_occurrence_kics_states AS
SELECT
  RestrictionKind,
  LifecycleKind,
  RestrictionIdentity,
  SourceRestrictedComplianceRegionID,
  VersionIdentity,
  CollectionName,
  raw_encoding,
  decoded_elements,
  CASE
    WHEN raw_encoding IS NULL THEN 'Null'
    WHEN SIZE(decoded_elements) = 0 THEN 'Empty'
    WHEN SIZE(decoded_elements) > 0 THEN 'Array'
    ELSE 'Undecoded'
  END AS CollectionState
FROM temp_restriction_collection_occurrence_kics_arrays;

CREATE OR REPLACE TEMPORARY VIEW temp_restriction_collection_occurrence_kics_rows AS
SELECT
  RestrictionKind,
  LifecycleKind,
  RestrictionIdentity,
  SourceRestrictedComplianceRegionID,
  VersionIdentity,
  CollectionName,
  CAST(0 AS BIGINT) AS OccurrencePosition,
  CollectionState,
  CASE WHEN CollectionState = 'Undecoded' THEN raw_encoding ELSE CAST(NULL AS STRING) END AS `Value`
FROM temp_restriction_collection_occurrence_kics_states
UNION ALL
SELECT
  s.RestrictionKind,
  s.LifecycleKind,
  s.RestrictionIdentity,
  s.SourceRestrictedComplianceRegionID,
  s.VersionIdentity,
  s.CollectionName,
  CAST(e.element_index + 1 AS BIGINT) AS OccurrencePosition,
  s.CollectionState,
  CASE
    WHEN IS_VARIANT_NULL(e.element_value) THEN 'null'
    WHEN SCHEMA_OF_VARIANT(e.element_value) = 'STRING' THEN CAST(e.element_value AS STRING)
    ELSE TO_JSON(e.element_value)
  END AS `Value`
FROM temp_restriction_collection_occurrence_kics_states AS s
LATERAL VIEW POSEXPLODE(s.decoded_elements) e AS element_index, element_value;

SELECT
  RestrictionKind,
  LifecycleKind,
  RestrictionIdentity,
  SourceRestrictedComplianceRegionID,
  VersionIdentity,
  CollectionName,
  OccurrencePosition,
  CollectionState,
  `Value`,
  CAST(NULL AS BIGINT) AS BusinessEntityRestrictionID,
  CAST(NULL AS BIGINT) AS BusinessEntityRestrictionHistoryID,
  CAST(NULL AS BIGINT) AS SecurityRestrictionID,
  CAST(NULL AS BIGINT) AS SecurityRestrictionHistoryID,
  CAST(2 AS BIGINT) AS SourceSystemID
FROM temp_restriction_collection_occurrence_kics_rows;