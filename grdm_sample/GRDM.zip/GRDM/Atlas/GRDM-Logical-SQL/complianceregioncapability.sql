SELECT
    c.compliance_region_capability_id AS SourceComplianceRegionCapabilityID,
    c.capability_name AS CapabilityName,
    c.compliance_region_id AS SourceComplianceRegionID,
    CAST(NULL AS BIGINT) AS ComplianceRegionID,
    c.is_admin_enabled AS IsAdminEnabled,
    c.is_compliance_officer_enabled AS IsComplianceOfficerEnabled,
    c.is_reviewer_enabled AS IsReviewerEnabled,
    c.is_superuser_enabled AS IsSuperuserEnabled,
    c.last_change_time AS LastChangeTime,
    c.last_change_user AS SourceLastChangeUserID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM gds_grdm_raw.kics_compliance_region_capability AS c;