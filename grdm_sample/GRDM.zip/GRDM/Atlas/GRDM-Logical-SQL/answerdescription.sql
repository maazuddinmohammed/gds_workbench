CREATE OR REPLACE TEMPORARY VIEW temp_answer_description_kics_identities AS
SELECT d.answer_description_id AS SourceAnswerDescriptionID
FROM gds_grdm_raw.kics_question_group_answer_description_v1 AS d
UNION ALL
SELECT t.answer_description_id AS SourceAnswerDescriptionID
FROM gds_grdm_raw.kics_question_group_answer_choice_and_decision_tree_v1 AS t
UNION ALL
SELECT c.answer_description_id AS SourceAnswerDescriptionID
FROM gds_grdm_raw.kics_question_group_answer_choice_v1 AS c;

CREATE OR REPLACE TEMPORARY VIEW temp_answer_description_kics_distinct_identities AS
SELECT DISTINCT SourceAnswerDescriptionID
FROM temp_answer_description_kics_identities;

SELECT
    SourceAnswerDescriptionID,
    CAST(NULL AS STRING) AS Name,
    CAST(NULL AS STRING) AS AnswerDescriptionIdentifierID,
    CAST(NULL AS STRING) AS Style,
    CAST(NULL AS STRING) AS Status,
    CAST(NULL AS STRING) AS ModificationNumber,
    CAST(NULL AS STRING) AS SourceLanguageID,
    CAST(NULL AS BIGINT) AS LanguageID,
    CAST(NULL AS STRING) AS MoveToProductionTime,
    CAST(NULL AS STRING) AS SourceMoveToProductionUserID,
    CAST(NULL AS STRING) AS MoveToArchiveTime,
    CAST(NULL AS STRING) AS SourceMoveToArchiveUserID,
    CAST(NULL AS STRING) AS SourceComplianceRegionID,
    CAST(NULL AS BIGINT) AS ComplianceRegionID,
    CAST(NULL AS BIGINT) AS MoveToProductionUserID,
    CAST(NULL AS BIGINT) AS MoveToArchiveUserID,
    CAST(2 AS BIGINT) AS SourceSystemID
FROM temp_answer_description_kics_distinct_identities;