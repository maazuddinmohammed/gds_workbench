# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Bronze to Silver Notebook - ComplianceRegionHierarchy
# MAGIC ---
# MAGIC
# MAGIC ###### The purpose of this template is to transfer data from Bronze to Silver zone.
# MAGIC
# MAGIC **The Pre-requisites for this template are:**
# MAGIC * Source and Target delta tables should be created.
# MAGIC * This Databricks notebook should be integrated to ADF.
# MAGIC * ADF should pass the widget values to this notebook.
# MAGIC * The Configuration section should be updated.

# COMMAND ----------

dbutils.widgets.text("TargetTable", "", "TargetTable")
dbutils.widgets.text("GDSBatchID", "", "GDSBatchID")
dbutils.widgets.text("PipelineID", "", "PipelineID")
dbutils.widgets.text("PipelineRunID", "", "PipelineRunID")
dbutils.widgets.text("GDSCatalog", "", "GDSCatalog")
dbutils.widgets.text("ProcessID", "", "ProcessID")
dbutils.widgets.text("TenantName", "", "TenantName")  

# Capturing the Logging Parameter
wid_target_table_name = dbutils.widgets.get("TargetTable")
wid_GDSBatchID = dbutils.widgets.get("GDSBatchID")
wid_PipelineID = dbutils.widgets.get("PipelineID")
wid_PipelineRunID = dbutils.widgets.get("PipelineRunID")
wid_catalog = dbutils.widgets.get("GDSCatalog")
wid_ProcessID = dbutils.widgets.get("ProcessID")
wid_TenantName = dbutils.widgets.get("TenantName")

# COMMAND ----------

from datetime import datetime
import pandas as pd
import sys

# COMMAND ----------

from datetime import datetime

current_year = datetime.now().year
current_month = datetime.now().month

if current_month >= 10:
    current_year_2 = current_year + 1
else:
    current_year_2 = current_year

end_date = f'{current_year_2}-09-30'

print(end_date)

# COMMAND ----------

set_context = spark.sql(f'USE CATALOG {wid_catalog};')
common_functions_notebook_path = spark.sql(f"SELECT TenantCommonFunctionsNotebookPath FROM meta.tenant WHERE TenantName = '{wid_TenantName}';").collect()[0][0]
var_ObjectID = spark.sql(f"select ObjectID FROM meta.process where ProcessID = '{wid_ProcessID}' and isActive = True").collect()[0][0]

print(f'-> Importing Common Functions Notebook From: {common_functions_notebook_path}')
sys.path.insert(0, common_functions_notebook_path) 
from GDS import put_ProcessLog_entry

# COMMAND ----------



# COMMAND ----------

try:
    val_RecordsRead = 0
    val_RecordsInserted = 0
    val_RecordsUpdated = 0
    val_RecordsRejected = 0

    val_StartDate = datetime.now()
    set_context = spark.sql(f'USE CATALOG {wid_catalog};')

    # -------------------------------------------------------
    # Refresh ComplianceRegionHierarchy
    # -------------------------------------------------------

    spark.sql("TRUNCATE TABLE gds_grdm_int.ComplianceRegionHierarchy")

    query = f"""
    WITH RECURSIVE ComplianceRegionHierarchy AS
    (
      SELECT  
          cr.ComplianceRegionID,
          cr.ComplianceRegionName,
          cr.ComplianceRegionIdentifier, 
          cr.ParentComplianceRegionID,
          pcr.ComplianceRegionName as ParentComplianceRegionName,
          pcr.ComplianceRegionIdentifier as ParentComplianceRegionIdentifier,
          cr.SourceCreatedDate,
          cr.SourceUpdatedDate,
          cr.SourceCreatedBy,
          cr.SourceUpdatedBy,
          ms.SourceSystemID 
        FROM gds_grdm_int.ComplianceRegion cr
        LEFT JOIN gds_grdm_int.ComplianceRegion pcr ON
          pcr.ComplianceRegionID = cr.ParentComplianceRegionID
        LEFT JOIN meta.MetaSourceSystem ms ON 
          ms.SourceSystemName = 'KICS'
      UNION ALL
      SELECT  
          cr.ComplianceRegionID, 
          cr.ComplianceRegionName,
          cr.ComplianceRegionIdentifier, 
          cr.ParentComplianceRegionID,
          pcr.ComplianceRegionName as ParentComplianceRegionName,
          pcr.ComplianceRegionIdentifier as ParentComplianceRegionIdentifier,
          cr.SourceCreatedDate,
          cr.SourceUpdatedDate,
          cr.SourceCreatedBy,
          cr.SourceUpdatedBy,
          ms.SourceSystemID
        FROM gds_grdm_int.ComplianceRegion cr
        LEFT JOIN gds_grdm_int.ComplianceRegion pcr ON
          pcr.ComplianceRegionID = cr.ParentComplianceRegionID
        LEFT JOIN meta.MetaSourceSystem ms ON 
          ms.SourceSystemName = 'KICS'
      INNER JOIN ComplianceRegionHierarchy crh ON
        cr.ParentComplianceRegionID = crh.ComplianceRegionID
    ) SELECT *,
    True AS IsDataValid,
    md5(concat_ws('',FiscalYearName,FiscalPeriodName,FiscalQuarterName)) AS HashKey,
    True AS IsActive,
    cast('{wid_GDSBatchID}' as int) AS GDSBatchID,
    '{wid_PipelineRunID}' AS PipelineRunID,
    current_timestamp() AS CreatedDate,
    current_timestamp() AS UpdatedDate,
    current_user() AS CreatedBy,
    current_user() AS UpdatedBy FROM ComplianceRegionHierarchy
    """

    df_AuditParams = spark.sql(query)
    display(df_AuditParams)

    val_RecordsInserted = df_AuditParams.collect()[0][1]
    val_RecordsUpdated = 0
    val_RecordsRejected = 0
    print(f'Row Count: {val_RecordsRead} | Row Inserted: {val_RecordsInserted} | Row Updated: {val_RecordsUpdated} | Row Deleted: {val_RecordsRejected} ')

    # Calling the Logging Framework - Success Path
    LoggingParameters = {
        "ProcessID": wid_ProcessID,
        "ObjectID": var_ObjectID,
        "StartDate": val_StartDate,
        "PipelineID": wid_PipelineID,
        "PipelineRunId": wid_PipelineRunID,
        'BatchId': wid_GDSBatchID,
        "RecordsRead": val_RecordsRead,
        "RecordsInserted": val_RecordsInserted,
        "RecordsUpdated": val_RecordsUpdated,
        "RecordsRejected": val_RecordsRejected,
        "Status": "Completed",
    }
    logStatus = put_ProcessLog_entry(LoggingParameters)
    print(logStatus)

except Exception as val_StatusMessage:

    # Calling the Logging Framework - Failure Path
    LoggingParameters = {
        "ProcessID": wid_ProcessID,
        "ObjectID": var_ObjectID,
        "StartDate": val_StartDate,
        "PipelineID": wid_PipelineID,
        "PipelineRunId": wid_PipelineRunID,
        'BatchId': wid_GDSBatchID,
        "RecordsRead": val_RecordsRead,
        "RecordsInserted": val_RecordsInserted,
        "RecordsUpdated": val_RecordsUpdated,
        "RecordsRejected": val_RecordsRejected,
        "StatusMessage": str(val_StatusMessage),
        "Status": "Failed",
    }
    logStatus = put_ProcessLog_entry(LoggingParameters)
    print(logStatus)

    raise Exception(str(val_StatusMessage))