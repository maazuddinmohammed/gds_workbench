SELECT 
    TRIM(u.userID) AS UserID,
    TRIM(us.UserID) AS CreatedByUserID,
    TRIM(uch.status) AS UserCapabilityStatus,
    TRIM(uch.is_granted) AS IsUserCapabilityGranted,
    TRIM(c.CapabilityID) AS CapabilityID,
    TRIM(cr1.ComplianceRegionID) AS CurrentAssignedComplianceRegionID,
    TRIM(cr2.ComplianceRegionID) AS CurrentSecondaryComplianceRegionID,
    null AS SourceCreatedDate,
    TRIM(uch.last_change_time) AS SourceUpdatedDate,
    TRIM(uch.last_change_user) AS SourceCreatedBy,   
    TRIM(uch.last_change_user) AS SourceUpdatedBy,  
    TRIM(ms.SourceSystemID) as SourceSystemID
    FROM
    gds_grdm_raw.kics_user_capability_history uch
    LEFT JOIN gds_grdm_int.User u
       ON TRIM(LOWER(uch.tracking_system_user_id)) = TRIM(LOWER(u.UserNumber))
        LEFT JOIN gds_grdm_int.User us
       ON TRIM(LOWER(uch.created_by_tracking_system_user_id)) = TRIM(LOWER(us.UserNumber))
    LEFT JOIN gds_grdm_int.capability c
       ON TRIM(LOWER(uch.capability_name)) = TRIM(LOWER(c.CapabilityName))
    LEFT JOIN gds_grdm_int.ComplianceRegion cr1
       ON TRIM(LOWER(uch.current_assigned_compliance_region_id))  = TRIM(LOWER(cr1.ComplianceRegionNumber))
    LEFT JOIN gds_grdm_int.ComplianceRegion cr2
       ON TRIM(LOWER(uch.current_secondary_compliance_region_id)) = TRIM(LOWER(cr2.ComplianceRegionNumber))
   LEFT JOIN
       meta.MetaSourceSystem ms 
       ON ms.SourceSystemName = 'KICS'
    WHERE
       uch.gds_batch_id = wid_GDSBatchID