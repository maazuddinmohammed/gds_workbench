SELECT
   TRIM(rrhfa.reset_restricted_holding_by_firm_action_id) AS FirmActionHoldingResetNumber,
    fa.FirmActionID AS FirmActionID,
    h.HoldingID AS HoldingID,
    NULL AS SourceCreatedDate,
    rrhfa.last_change_time AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    s.SourceSystemID AS SourceSystemID
  FROM
    gds_grdm_raw.kics_reset_restricted_holding_by_firm_action_v1 rrhfa
  LEFT JOIN
    gds_grdm_int.FirmAction fa
    ON TRIM(LOWER(fa.FirmActionNumber)) = TRIM(LOWER(rrhfa.firm_action_case_id))
  LEFT JOIN
    gds_grdm_int.Holding h
    ON TRIM(LOWER(h.HoldingNumber)) = TRIM(LOWER(rrhfa.holding_case_id))
  LEFT JOIN
    gds.MetaSourceSystem s
    ON s.SourceSystemName = 'KICS'
  WHERE
    rrhfa.gds_batch_id = wid_GDSBatchID