SELECT
    coalesce(qg.QuestionGroupID, -1) AS QuestionGroupID,
    coalesce(ht.HoldingTypeID, -1) AS HoldingTypeID,
    NULL AS SourceCreatedDate,
    NULL AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    s.SourceSystemID AS SourceSystemID
  FROM gds_grdm_raw.kics_question_group_v1 q
  LEFT JOIN gds_grdm_int.QuestionGroup qg 
    ON trim(lower(qg.QuestionGroupNumber)) = trim(lower(q.question_group_id))
  LEFT JOIN gds_grdm_int.HoldingType ht 
    ON trim(lower(ht.HoldingTypeNumber)) = trim(lower(q.holding_type))
  LEFT JOIN gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
  WHERE q.gds_batch_id = wid_GDSBatchID