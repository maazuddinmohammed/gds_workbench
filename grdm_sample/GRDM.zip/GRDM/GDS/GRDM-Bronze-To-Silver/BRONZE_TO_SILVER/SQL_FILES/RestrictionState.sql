SELECT
    src.RestrictionStateNumber,
    src.RestrictionStateName,
    coalesce(rs.RestrictionStateBusinessName, TRIM(src.RestrictionStateName)) as RestrictionStateBusinessName,
    src.RestrictionStateDescription,
    NULL as SourceCreatedDate,
    NULL as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    ms.SourceSystemID as SourceSystemID
FROM
(
SELECT DISTINCT
    coalesce(TRIM(er.restriction_state), 'N/A') as RestrictionStateNumber,
    coalesce(TRIM(er.restriction_state), 'N/A') as RestrictionStateName,
    TRIM(er.restriction_state) as RestrictionStateDescription
FROM 
    gds_grdm_raw.v_kics_entity_restriction_v1 er
WHERE er.gds_batch_id = wid_GDSBatchID
UNION
SELECT DISTINCT
    coalesce(TRIM(er.restriction_state), 'N/A') as RestrictionStateNumber,
    coalesce(TRIM(er.restriction_state), 'N/A') as RestrictionStateName,
    TRIM(er.restriction_state) as RestrictionStateDescription
FROM 
    gds_grdm_raw.v_kics_entity_restriction_history_v1 er
WHERE er.gds_batch_id = wid_GDSBatchID
UNION  
SELECT DISTINCT
    COALESCE(TRIM(sr.restriction_state), 'N/A') as RestrictionStateNumber,
    COALESCE(TRIM(sr.restriction_state), 'N/A') as RestrictionStateName,
    TRIM(sr.restriction_state) as RestrictionStateDescription
FROM 
    gds_grdm_raw.v_kics_security_restriction_v1 sr
WHERE sr.gds_batch_id = wid_GDSBatchID
UNION
SELECT DISTINCT
    COALESCE(TRIM(sr.restriction_state), 'N/A') as RestrictionStateNumber,
    COALESCE(TRIM(sr.restriction_state), 'N/A') as RestrictionStateName,
    TRIM(sr.restriction_state) as RestrictionStateDescription
FROM 
    gds_grdm_raw.v_kics_security_restriction_history_v1 sr
WHERE sr.gds_batch_id = wid_GDSBatchID
) src
LEFT JOIN
    gds_grdm_int.RestrictionState rs 
    ON TRIM(LOWER(rs.RestrictionStateNumber)) = TRIM(LOWER(src.RestrictionStateNumber))
LEFT JOIN
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
