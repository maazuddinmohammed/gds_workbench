SELECT 
  trim(lc.list_code_id) as PolicyTypeNumber,
  trim(lc.short_name) as PolicyTypeName,
  coalesce(pt.PolicyTypeBusinessName, trim(lc.short_name)) as PolicyTypeBusinessName,
  trim(lc.description) as PolicyTypeDescription,
  cr.ComplianceRegionID as ComplianceRegionID,
	lc.start_effective_date AS	PolicyTypeEffectiveStartDate,
	lc.end_effective_date AS PolicyTypeEffectiveEndDate,
	lc.identifier AS PolicyTypeIdentifier,
	lc.parent_list_code_id AS ParentPolicyTypeListCodeNumber,
	lc.associated_security_type AS	PolicyTypeAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS PolicyTypeIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	PolicyTypeSICCode,
	lc.show_acknowledgement_checkbox AS	PolicyTypeShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS PolicyTypeRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS PolicyTypeFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	PolicyTypeIsAccountTypeEligibleForBrokerageImport,  
  NULL as SourceCreatedDate,
  lc.last_change_time as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  sys.SourceSystemID as SourceSystemID
FROM 
  gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
  gds_grdm_int.PolicyType pt 
  ON lc.list_code_id = pt.PolicyTypeNumber
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON LOWER(TRIM(lc.compliance_region_id)) = LOWER(TRIM(cr.ComplianceRegionNumber))
LEFT JOIN 
  gds.MetaSourceSystem sys 
  ON sys.SourceSystemName = 'KICS'
WHERE 
  lc.gds_batch_id = wid_GDSBatchID
  AND lc.list_code_type = 'Type of Policy'