
SELECT
    PhoneType.PhoneTypeName AS PhoneTypeName,
    NULL AS SourceCreatedDate,
    NULL AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy ,              
    s.SourceSystemID AS SourceSystemID                
                       
FROM
  (   
    SELECT "Phone" AS PhoneTypeName   
    UNION ALL
    SELECT "Mobile" AS PhoneTypeName
    UNION ALL
    SELECT "Fax" AS PhoneTypeName
    UNION ALL
    SELECT "Work" AS PhoneTypeName
    UNION ALL
    SELECT "Personal" AS PhoneTypeName 
    ) AS PhoneType
LEFT JOIN
    gds.MetaSourceSystem s ON s.SourceSystemCode = 'SNTL'