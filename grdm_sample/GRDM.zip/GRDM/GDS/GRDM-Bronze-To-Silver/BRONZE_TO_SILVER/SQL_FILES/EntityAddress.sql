SELECT 
  e.EntityID as EntityID,
  at.AddressTypeID as AddressTypeID,
  trim(ke.street_address_line_1) as EntityAddressLine1,
  trim(ke.street_address_line_2) as EntityAddressLine2,
  trim(ke.city) as EntityAddressCity,
  trim(ke.state_or_province) as EntityAddressState,
  trim(ke.postal_code) as EntityAddressPostalCode,
  NULL as CountryID,
  NULL as SourceCreatedDate,
  NULL as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  ms.SourceSystemID as SourceSystemID
FROM 
 gds_grdm_raw.kics_entity_v1 ke
 LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
LEFT JOIN 
 gds_ref_int.Entity e 
  ON LOWER(TRIM(ke.entity_id)) = LOWER(TRIM(e.EntityNumber)) AND e.SourceSystemID = ms.SourceSystemID
LEFT JOIN 
 gds_ref_int.AddressType at 
  ON at.AddressTypeName = 'Primary'
WHERE 
  ke.gds_batch_id = wid_GDSBatchID
  and (ke.city IS NOT NULL AND ke.city <> '') --country detail is not present in kics so keeping it as city

UNION ALL

 SELECT 
  e1.EntityID as EntityID,
  at.AddressTypeID as AddressTypeID,
  trim(ev.physical_street_address) as EntityAddressLine1,
  trim(ev.second_address_line) as EntityAddressLine2,
  trim(ev.physical_city) as EntityAddressCity,
  trim(ev.state) as EntityAddressState,
  NULL as EntityAddressPostalCode,
  c2.CountryID as CountryID,
  NULL as SourceCreatedDate,
  NULL as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  sys.SourceSystemID as SourceSystemID
FROM 
  gds_grdm_raw.sntl_x_entity ev
LEFT JOIN 
  gds.MetaSourceSystem sys 
  ON sys.SourceSystemCode = 'SNTL'
LEFT JOIN 
  gds_ref_int.Entity e1 
  ON LOWER(TRIM(e1.EntityNumber)) = LOWER(TRIM(ev.Entity_ID)) AND e1.SourceSystemID = sys.SourceSystemID
LEFT JOIN 
  gds_ref_int.AddressType at 
  ON at.AddressTypeName = 'Primary'
LEFT JOIN 
  gds_grdm_raw.sntl_x_country c 
  ON c.UNCountryCode = ev.country_code AND ev.gds_batch_id= c.gds_batch_id
LEFT JOIN 
  gds_ref_int.Country c2 
  ON LOWER(TRIM(c2.CountryISOCode)) = LOWER(TRIM(c.isocountrycode))
WHERE 
  ev.gds_batch_id = wid_GDSBatchID  
  and (ev.country_code IS NOT NULL AND ev.country_code <> '')   
  AND e1.EntityID IS NOT NULL ----> 1 record coming as NULL