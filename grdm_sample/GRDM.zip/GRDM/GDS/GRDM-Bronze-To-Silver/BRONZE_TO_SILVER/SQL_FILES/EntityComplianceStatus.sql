SELECT 
    DISTINCT
    trim(le.status) as EntityComplianceStatusNumber,
    trim(le.status) as EntityComplianceStatusName,
    coalesce(ecs.EntityComplianceStatusBusinessName, le.status) as EntityComplianceStatusBusinessName,
    trim(le.status) as EntityComplianceStatusDescription,
    NULL as SourceCreatedDate,
    NULL as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(s.SourceSystemID, -1) as SourceSystemID
FROM  gds_grdm_raw.kics_entity_v1 le
LEFT JOIN 
    gds_grdm_int.EntityComplianceStatus ecs 
    ON trim(lower(le.status)) = trim(lower(ecs.EntityComplianceStatusNumber))
LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
WHERE 
    le.gds_batch_id = wid_GDSBatchID