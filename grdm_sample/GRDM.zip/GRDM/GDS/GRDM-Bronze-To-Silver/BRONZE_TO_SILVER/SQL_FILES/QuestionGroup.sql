SELECT 
    cr.ComplianceRegionID as ComplianceRegionID,
    TRIM(qg.question_group_id) as QuestionGroupNumber,
    TRIM(qg.status) as QuestionGroupStatus,
    sec.SecurityID as SecurityID,
    ec.EntityComplianceID as EntityComplianceID,
    ht.HoldingTypeID as HoldingTypeID,
    rt.RestrictionTypeID as RestrictionTypeID,
    sr.SECRoleID as SECRoleID,
    qg.development_question_group_holding_type_array as QuestionGroupHoldingTypeArray,
    qg.development_question_group_restriction_type_array as QuestionGroupRestrictionTypeArray,
    qg.development_question_group_sec_role_array as QuestionGroupSECRoleArray ,  
    fis.FinancialInterestSubTypeID as FinancialInterestSubTypeID,
    TRIM(qg.holding_type_scope) as QuestionGroupHoldingTypeScope,
    qg.move_to_production_time  as QuestionGroupProductionTime,
    qg.archive_time  as QuestionGroupArchiveTime,  
    qg.new_question_group_id AS NewQuestionGroupID,
    NULL as SourceCreatedDate,
    qg.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(ms.SourceSystemID, -1) as SourceSystemID
FROM
    gds_grdm_raw.kics_question_group_v1 qg
LEFT JOIN
    gds.MetaSourceSystem ms
    ON ms.SourceSystemName = 'KICS' 
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr
    ON LOWER(TRIM(qg.compliance_region_id)) = LOWER(TRIM(cr.ComplianceRegionNumber))
LEFT JOIN
    gds_grdm_int.Security sec
    ON LOWER(TRIM(qg.entity_security_id)) = LOWER(TRIM(sec.SecurityNumber))
LEFT JOIN gds_ref_int.Entity e 
    ON LOWER(TRIM(e.EntityNumber)) = LOWER(TRIM(qg.entity_security_id)) AND e.SourceSystemID = ms.SourceSystemID
LEFT JOIN
    gds_grdm_int.EntityCompliance ec
    ON LOWER(TRIM(e.EntityID)) = LOWER(TRIM(ec.EntityID))
LEFT JOIN
    gds_grdm_int.FinancialInterestSubType fis
    ON LOWER(TRIM(qg.financial_interest_sub_type_list_code_id)) = LOWER(TRIM(fis.FinancialInterestSubTypeNumber))
LEFT JOIN
    gds_grdm_int.StockType st
    ON LOWER(TRIM(qg.stock_type)) = LOWER(TRIM(st.StockTypeNumber))
LEFT JOIN gds_grdm_int.HoldingType ht ON LOWER(TRIM(ht.HoldingTypeNumber)) = LOWER(TRIM(qg.holding_type))
  LEFT JOIN gds_grdm_int.RestrictionType rt ON LOWER(TRIM(rt.RestrictionTypeNumber)) = LOWER(TRIM(qg.restriction_type))
  LEFT JOIN gds_grdm_int.SECRole sr ON LOWER(TRIM(sr.SECRoleNumber)) = LOWER(TRIM(qg.sec_role))
WHERE
   qg.gds_batch_id = wid_GDSBatchID