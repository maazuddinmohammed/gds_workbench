SELECT 
  TRIM(lc.list_code_id) AS SurveySubTypeNumber,
  TRIM(lc.short_name) AS SurveySubTypeName,
  COALESCE(sst.SurveySubTypeBusinessName, lc.short_name) AS SurveySubTypeBusinessName,
  TRIM(lc.description) AS SurveySubTypeDescription,
  cr.ComplianceRegionID AS ComplianceRegionID,
	lc.start_effective_date AS	SurveySubTypeEffectiveStartDate,
	lc.end_effective_date AS SurveySubTypeEffectiveEndDate,
	lc.identifier AS SurveySubTypeIdentifier,
	lc.parent_list_code_id AS ParentSurveySubTypeListCodeNumber,
	lc.associated_security_type AS	SurveySubTypeAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS SurveySubTypeIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	SurveySubTypeSICCode,
	lc.show_acknowledgement_checkbox AS	SurveySubTypeShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS SurveySubTypeRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS SurveySubTypeFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	SurveySubTypeIsAccountTypeEligibleForBrokerageImport,  
  NULL AS SourceCreatedDate,
  lc.last_change_time AS SourceUpdatedDate,
  NULL AS SourceCreatedBy,
  NULL AS SourceUpdatedBy,
  ms.SourceSystemID AS SourceSystemID
FROM 
  gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
  gds_grdm_int.SurveySubType sst 
  ON TRIM(LOWER(lc.list_code_id)) = TRIM(LOWER(sst.SurveySubTypeNumber))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON TRIM(LOWER(lc.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
WHERE 
  lc.gds_batch_id = wid_GDSBatchID
  AND lc.list_code_type = 'Survey Subtype'