SELECT 
    trim(le.entity_id) as EntityNumber,
    trim(le.gisid) as EntityGisID,
    trim(le.name) as EntityName,
    trim(le.name) as EntityFullName,
    coalesce(eca.EntityName,le.name) as   EntityBusinessName,
    trim(le.duns_number) as EntityDUNSNumber,
    trim(le.immediate_parent_duns_number) as EntityImmediateParentDUNSNumber,
    trim(le.domestic_ultimate_parent_duns_number) as EntityDomesticUltimateParentDUNSNumber,
    trim(le.global_parent_duns_number) as EntityGlobalParentDUNSNumber,
    NULL as EntityMDMID,
    NULL as EntityTypeID,
    NULL as EntityStatusID,
    NULL as EntityOnboardStatusID,
    NULL as EntityClearanceStatusID,
    NULL as EntityPrimaryTradeStyleID,
    NULL as EntitySecondaryTradeStyleID,
    NULL AS IndustrySectorID,
    NULL as EntityFiscalYearEndMonth,
    NULL as GlobalUltimateParentID,
    NULL as EntityRequiredAuditRotationDate,
    NULL as EntityAuditStartDate,
    NULL as EntityNextAuditStartDate,
    NULL as EntityAuditCoolOffDate,
    NULL as ReplacementEntityID,
    NULL as IsClient,
    NULL as IsLiquidated,
    NULL as IsGlobalPipeline,
    NULL as IsPublicInterestEntity,
    NULL as IsMemberFirmEntity,
    NULL as IsEuropePublicInterestEntity,
    NULL as HasStockExchangeListing,
    NULL as HasAudit,
    TRIM(m.merge_time) as EntityMergeTime,
    TRIM(m. retained_security_acquisition_date_source) as EntityMergeDataSource,
    TRIM(m.merge_comment) as EntityMergeComment,
    TRIM(m.is_confirmation_required) as IsConfirmationRequired,
    TRIM(m.is_send_notification_selected) as IsSendNotification,
    le.created_time as SourceCreatedDate,
    NULL as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    s.SourceSystemID  as SourceSystemID
FROM 
    gds_grdm_raw.kics_entity_v1 le
LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'    
LEFT JOIN 
    gds_ref_int.Entity eca 
     ON lower(trim(le.entity_id)) = lower(trim(eca.EntityNumber))  AND eca.SourceSystemID = s.SourceSystemID
LEFT JOIN gds_grdm_raw.kics_entity_security_merge_record_v1 m ON LOWER(TRIM(m.entity_security_retained_id)) = LOWER(TRIM(le.entity_id))
WHERE     le.gds_batch_id = wid_GDSBatchID 

UNION ALL
 
SELECT 
  TRIM(e.entity_id) as EntityNumber,
  e.entity_id as EntityGISID, 
  coalesce(TRIM(e.full_business_name), 'N/A') as EntityName,
  coalesce(TRIM(e.full_business_name), 'N/A') as EntityFullName,
  coalesce(TRIM(COALESCE(r.EntityName, e.full_business_name)), 'N/A') as EntityBusinessName,
  coalesce(TRIM(e.duns), 'N/A') as EntityDUNSNumber, 
  NULL AS EntityImmediateParentDUNSNumber,
  NULL AS EntityDomesticUltimateParentDUNSNumber,
  NULL AS EntityGlobalParentDUNSNumber,
  NULL as EntityMDMID, 
  coalesce(et.EntityTypeID, NULL) as EntityTypeID, 
  coalesce(es.EntityStatusID, NULL) as EntityStatusID, 
  NULL as EntityOnboardStatusID, 
  NULL as EntityClearanceStatusID, 
  coalesce(ets1.EntityTradeStyleID, NULL) as EntityPrimaryTradeStyleID, 
  coalesce(ets2.EntityTradeStyleID, NULL) as EntitySecondaryTradeStyleID,
  i.IndustrySectorID AS IndustrySectorID, 
  CASE WHEN TRIM(e.fiscal_end) = '' THEN NULL ELSE coalesce(TRIM(e.fiscal_end), NULL) END as EntityFiscalYearEndMonth, 
  gup.GlobalUltimateParentEntityID as GlobalUltimateParentID, 
  coalesce(TRIM(e.Required_AuditRotation), NULL) as EntityRequiredAuditRotationDate, 
  coalesce(e.Start_Current_AuditTenure, NULL) as EntityAuditStartDate, 
  coalesce(e.Next_Expected_AuditTender, NULL) as EntityNextAuditStartDate, 
  coalesce(e.KPMGAudit_CoolingOff_Period, NULL) as EntityAuditCoolOffDate, 
  coalesce(er.EntityID, NULL) as ReplacementEntityID, 
  CASE WHEN TRIM(e.Audit_Client_KPMG)=1 THEN true else null END as IsClient, 
  coalesce(TRIM(e.Is_Liquidated_entity), NULL) as IsLiquidated, 
  coalesce(TRIM(e.GlobalPipelineClient), NULL) as IsGlobalPipeline, 
  coalesce(TRIM(e.PIE_Ind), NULL) as IsPublicInterestEntity, 
  NULL as IsMemberFirmEntity, 
  coalesce(TRIM(e.EU_PIE_Ind), NULL) as IsEuropePublicInterestEntity, 
  coalesce(TRIM(e.Listed_Ind), NULL) as HasStockExchangeListing, 
  coalesce(TRIM(e.Audit_Client_KPMG), NULL) as HasAudit, 
  NULL AS EntityMergeTime,
  NULL AS EntityMergeDataSource,
  NULL AS EntityMergeComment,
  NULL AS IsConfirmationRequired,
  NULL AS IsSendNotification,
  current_timestamp as SourceCreatedDate, 
  NULL as SourceUpdatedDate, 
  NULL as SourceCreatedBy, 
  NULL as SourceUpdatedBy, 
  s.SourceSystemID as SourceSystemID
FROM 
  gds_grdm_raw.sntl_x_entity e
LEFT JOIN 
  gds.MetaSourceSystem s 
  ON s.SourceSystemCode = 'SNTL' 
LEFT JOIN 
  gds_ref_int.Entity r 
  ON TRIM(LOWER(e.entity_id)) = TRIM(LOWER(r.EntityNumber))  AND r.SourceSystemID = s.SourceSystemID
LEFT JOIN 
 (SELECT a.* FROM gds_ref_int.EntityTree a INNER JOIN gds_grdm_int.AffiliateType aft
      ON a.AffiliateTypeID = aft.AffiliateTypeID WHERE aft.AffiliateTypeCode IN ('GUP','GUPI') ) gup
  ON TRIM(LOWER(r.EntityID)) = TRIM(LOWER(gup.EntityID))  AND r.SourceSystemID = s.SourceSystemID     
LEFT JOIN 
  gds_ref_int.Entity er 
  ON TRIM(LOWER(e.Replacement_Entity_Id)) = TRIM(LOWER(er.EntityNumber))  AND er.SourceSystemID = s.SourceSystemID
LEFT JOIN 
  gds_ref_int.EntityType et 
  ON TRIM(LOWER(e.organization_code)) = TRIM(LOWER(et.EntityTypeNumber))
LEFT JOIN 
  gds_ref_int.EntityStatus es 
  ON TRIM(LOWER(e.entity_status_code)) = TRIM(LOWER(es.EntityStatusNumber))
LEFT JOIN 
  gds_ref_int.EntityTradeStyle ets1 
  ON TRIM((e.trade_style)) = TRIM((ets1.EntityTradeStyleName))
LEFT JOIN 
  gds_ref_int.EntityTradeStyle ets2 
  ON TRIM((e.second_trade_style)) = TRIM((ets2.EntityTradeStyleName))
LEFT JOIN 
  gds_grdm_int.IndustrySector i 
  ON TRIM(LOWER(e.Industry_Sector_Code)) = TRIM(LOWER(i.IndustrySectorNumber))
WHERE 
  e.gds_batch_id = wid_GDSBatchID  
  AND (TRIM(e.fiscal_end) <> 'A' or e.fiscal_end IS NULL)