SELECT 
  TRIM(sh.last_change_time) as SecurityHistoryTime,
  s.SecurityID as SecurityID,
  TRIM(sh.security_id) as SecurityNumber,
  TRIM(styp.SecurityTypeId) as SecurityTypeId,
  TRIM(sh.name) as SecurityName,
  sh.Status as SecurityStatus,
  TRIM(sh.primary_alias_text) as SecurityPrimaryAliasText,
  TRIM(SUBSTRING(sh.symbol_exchange_array,3,(CHARINDEX('~',sh.symbol_exchange_array)-3))) AS SecuritySymbol,
  se.SecurityExchangeID,
  st2.StockTypeID as StockTypeID,
  cr.ComplianceRegionID as ComplianceRegionID,
  TRIM(sh.client_number) as SecurityClientNumber,
  srep.SecurityID as SecurityReplacedID,
  sret.SecurityID as SecurityRetainedID,
  TRIM(sh.administrative_comments) as SecurityAdministrativeComment,
  TRIM(sh.gmfid) as SecurityGlobalMasterFileID,
  TRIM(sh.external_identifier) as SecurityExternalID,
  TRIM(sh.mutual_fund_advisor_company_name) as SecurityMutualFundAdvisorCompanyName,
  TRIM(sh.mutual_fund_sub_advisor_company_name) as SecurityMutualFundSubAdvisorCompanyName,
  TRIM(sh.mutual_fund_auditor_company_name) as SecurityMutualFundAuditorCompanyName,
  TRIM(sh.mutual_fund_external_data_source_number) as SecurityMutualFundExternalDataSourceNumber,
  TRIM(sh.mutual_fund_sec_registrant_comment) as SecurityMutualFundSECRegistrantComment,
  sh.mutual_fund_partially_restricted_time as SecurityMutualFundPartiallyRestrictedTime,
  mff.MutualFundFamilyID as MutualFundFamilyID,
  TRIM(sh.mutual_fund_gisid) as SecurityMutualFundGISID,
  TRIM(sh.primary_symbol_exchange) as SecurityPrimarySymbolExchange,
  TRIM(sh.primary_cusip) as SecurityPrimaryCUSIPArray,
  TRIM(sh.primary_isin) as SecurityPrimaryISINArray,
  TRIM(sh.primary_sedol) as SecurityPrimarySEDOLArray,
  TRIM(sh.cusip_array) as SecurityCUSIPArray,
  TRIM(sh.parent_entity_security_type_array) as SecurityParentEntitySecurityTypeArray,
  TRIM(sh.is_restriction_flow_down_array) as SecurityRestrictionFlowDownArray,
  TRIM(sh.sedol_array) as SecuritySEDOLArray,
  TRIM(sh.isin_array) as SecurityISINArray,
  TRIM(sh.parent_entity_security_name_array) as SecurityParentEntitySecurityNameArray,
  TRIM(sh.relationship_type_array) as SecurityRelationshipTypeArray,
  TRIM(sh.alias_value_array) as SecurityAliasArray,
  TRIM(sh.add_type) as SecurityAddType,
  sh.inactivated_date as SecurityInactivatedTime,
  TRIM(m.selected_acquisition_date) AS SecuritySelectedAcquisitionDate,
  TRIM(m.entity_security_replaced_type) AS SecurityEntitySecurityReplacedType,
  TRIM(m.entity_security_retained_type) AS SecurityEntitySecurityRetainedType,
  TRIM(sh.mutual_fund_is_fund_family) as IsFundFamily,
  TRIM(sh.is_sec_registrant) as IsSECRegistrant,
  TRIM(sh.is_non_diversified) as IsNonDiversified,
  TRIM(sh.is_non_public) as IsNonPublic,
  TRIM(sh.is_in_watchlist) as IsInWatchList,
  TRIM(sh.is_mapping_program_allowed_to_update) as CanMappingProgramUpdate,
  m.merge_time as SecurityMergeTime,
  TRIM(m.retained_security_acquisition_date_source) as  SecurityMergeDataSource,
  TRIM(m.merge_comment) as SecurityMergeComment,
  m.is_confirmation_required as IsConfirmationRequired,
  m.is_send_notification_selected as IsSendNotification ,
  sh.created_time as SourceCreatedDate,
  sh.last_change_time as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  ms.SourceSystemID as SourceSystemID
FROM 
  gds_grdm_raw.v_kics_security_history_v1 sh
LEFT JOIN 
    gds_grdm_int.SecurityType styp
    ON LOWER(TRIM(styp.SecurityTypeNumber)) = LOWER(TRIM(sh.security_type))
LEFT JOIN 
  gds_grdm_int.Security s 
  ON LOWER(TRIM(s.SecurityNumber)) = LOWER(TRIM(sh.security_id))
LEFT JOIN 
  gds_ref_int.Status st 
  ON LOWER(TRIM(st.StatusName)) = LOWER(TRIM(sh.status))
LEFT JOIN 
  gds_grdm_int.StockType st2 
  ON LOWER(TRIM(st2.StockTypeName)) = LOWER(TRIM(sh.stock_type))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON LOWER(TRIM(cr.ComplianceRegionNumber)) = LOWER(TRIM(sh.compliance_region_id))
LEFT JOIN 
  gds_grdm_int.MutualFundFamily mff 
  ON LOWER(TRIM(mff.MutualFundFamilyNumber)) = LOWER(TRIM(sh.list_code_mutual_fund_fund_family_id))
LEFT JOIN gds_grdm_raw.v_kics_entity_security_merge_record_v1 m ON m.entity_security_retained_id = sh.security_id
AND m.gds_batch_id=sh.gds_batch_id
LEFT JOIN gds_grdm_int.Security srep ON LOWER(TRIM(srep.SecurityNumber)) = LOWER(TRIM(m.entity_security_replaced_id))
LEFT JOIN gds_grdm_int.Security sret ON LOWER(TRIM(sret.SecurityNumber)) = LOWER(TRIM(m.entity_security_retained_id))
LEFT JOIN gds_grdm_int.SecurityExchange se ON LOWER(TRIM(se.SecurityExchangeSymbol)) =LOWER(TRIM(SUBSTRING(sh.symbol_exchange_array,CHARINDEX('~',sh.symbol_exchange_array)+2,(CHARINDEX('"',sh.symbol_exchange_array,3)-CHARINDEX('~',sh.symbol_exchange_array)-2))))
LEFT JOIN 
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE 
  sh.gds_batch_id = wid_GDSBatchID
