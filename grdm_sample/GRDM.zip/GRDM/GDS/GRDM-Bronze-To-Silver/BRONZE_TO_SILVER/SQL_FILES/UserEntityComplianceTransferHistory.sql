SELECT 
    tuaeh.last_change_time as UserEntityComplianceTransferHistoryTime,
    uect.UserEntityComplianceTransferID as UserEntityComplianceTransferID,
    TRIM(tuaeh.user_added_entity_id) as UserEntityComplianceTransferNumber,
    ec.EntityComplianceID as EntityComplianceID,
    cs.SecurityID as SecurityID,
    se.SecurityExchangeID as SecurityExchangeID,
    cr1.ComplianceRegionID as ComplianceRegionID,
    cr2.ComplianceRegionID as ReviewerComplianceRegionID,
    coalesce(fit.FinancialInterestTypeID,fitp.FinancialInterestTypeID) AS FinancialInterestTypeID,
    fist.FinancialInterestSubTypeID AS FinancialInterestSubTypeID,
    at.AccountTypeID as AccountTypeID,
    b.BrokerageID as BrokerageID,
    TRIM(tuaeh.transferred_pending_associated_entity_security_type) as UserEntityComplianceTransferType,
    TRIM(tuaeh.description) as UserEntityComplianceTransferDescription,
    TRIM(tuaeh.status) as UserEntityComplianceTransferStatus,
    TRIM(tuaeh.status_comments) as UserEntityComplianceTransferStatusComment,
    --NULL as UserEntityComplianceTransferCUSIP,
    TRIM(tuaeh.isin) as UserEntityComplianceTransferISIN,
    TRIM(tuaeh.sedol) as UserEntityComplianceTransferISEDOL,
    tuaeh.replacement_action_acquisition_date as UserEntityComplianceTransferReplacementAcquisitionDate,
    TRIM(tuaeh.replacement_action_acquisition_date_option) as UserEntityComplianceTransferReplacementAcquisitionDateOption,
    TRIM(tuaeh.street) as UserEntityComplianceTransferAddress,
    TRIM(tuaeh.city) as UserEntityComplianceTransferCity,
    TRIM(tuaeh.state_province) as UserEntityComplianceTransferState,
    TRIM(tuaeh.postal) as UserEntityComplianceTransferPostalCode,
    c.CountryID as CountryID,
    tuaeh.action_time as UserEntityComplianceTransferActionTime,
    tuaeh.added_time as SourceCreatedDate,
    tuaeh.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,    
    NULL as SourceUpdatedBy,
    sys.SourceSystemID as SourceSystemID
FROM
    gds_grdm_raw.kics_transferred_user_added_entity_history_v1 tuaeh
LEFT JOIN
    gds_grdm_int.UserEntityComplianceTransfer uect ON LOWER(TRIM(uect.UserEntityComplianceTransferNumber)) = LOWER(TRIM(tuaeh.user_added_entity_id))
LEFT JOIN
    gds_grdm_int.EntityCompliance ec ON LOWER(TRIM(ec.EntityID)) = LOWER(TRIM(tuaeh.associated_entity_security_id))
LEFT JOIN
    gds_grdm_int.Security cs ON LOWER(TRIM(cs.SecurityNumber)) = LOWER(TRIM(tuaeh.associated_entity_security_id))
LEFT JOIN
    gds_grdm_int.SecurityExchange se ON LOWER(TRIM(se.SecurityExchangeNumber)) = LOWER(TRIM(tuaeh.exchange_id))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr1 ON LOWER(TRIM(cr1.ComplianceRegionNumber)) = LOWER(TRIM(tuaeh.compliance_region_id))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr2 ON LOWER(TRIM(cr2.ComplianceRegionNumber)) = LOWER(TRIM(tuaeh.reviewer_compliance_region_id))
LEFT JOIN
    gds_grdm_int.FinancialInterestSubType fist ON LOWER(TRIM(fist.FinancialInterestSubTypeNumber)) = LOWER(TRIM(tuaeh.financial_interest_sub_type_id))
LEFT JOIN  
    gds_grdm_int.FinancialInterestType fit ON LOWER(TRIM(fit.FinancialInterestTypeNumber)) = LOWER(TRIM(fist.ParentFinancialInterestSubTypeListCodeNumber))  
LEFT JOIN 
    gds_grdm_int.FinancialInterestType fitp ON TRIM(LOWER(fitp.FinancialInterestTypeNumber)) = TRIM(LOWER(tuaeh.financial_interest_sub_type_id))
LEFT JOIN
    gds_grdm_int.AccountType at ON LOWER(TRIM(at.AccountTypeNumber)) = LOWER(TRIM(tuaeh.account_type_id))
LEFT JOIN
    gds_grdm_int.Brokerage b ON LOWER(TRIM(b.BrokerageNumber)) = LOWER(TRIM(tuaeh.brokerage_import_entity_id))
LEFT JOIN
    gds_grdm_int.Country c ON LOWER(TRIM(c.CountryISOCode)) = LOWER(TRIM(tuaeh.country_id_of_origin))
LEFT JOIN
    gds.MetaSourceSystem sys ON sys.SourceSystemName = 'KICS'
WHERE 
    tuaeh.gds_batch_id = wid_GDSBatchID