SELECT 
  trim(lc.list_code_id) as UnitInvestmentTrustDisposalNumber,
  trim(lc.short_name) as UnitInvestmentTrustDisposalName,
  coalesce(utd.UnitInvestmentTrustDisposalBusinessName, trim(lc.short_name)) as UnitInvestmentTrustDisposalBusinessName,
  trim(lc.description) as UnitInvestmentTrustDisposalDescription,
  cr.ComplianceRegionID as ComplianceRegionID,
	lc.start_effective_date AS	UnitInvestmentTrustDisposalEffectiveStartDate,
	lc.end_effective_date AS UnitInvestmentTrustDisposalEffectiveEndDate,
	lc.identifier AS UnitInvestmentTrustDisposalIdentifier,
	lc.parent_list_code_id AS ParentUnitInvestmentTrustDisposalListCodeNumber,
	lc.associated_security_type AS	UnitInvestmentTrustDisposalAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS UnitInvestmentTrustDisposalIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	UnitInvestmentTrustDisposalSICCode,
	lc.show_acknowledgement_checkbox AS	UnitInvestmentTrustDisposalShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS UnitInvestmentTrustDisposalRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS UnitInvestmentTrustDisposalFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	UnitInvestmentTrustDisposalIsAccountTypeEligibleForBrokerageImport,  
  NULL as SourceCreatedDate,
  lc.last_change_time as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  ms.SourceSystemID as SourceSystemID
FROM 
  gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
  gds_grdm_int.UnitInvestmentTrustDisposal utd 
  ON trim(lower(lc.list_code_id)) = trim(lower(utd.UnitInvestmentTrustDisposalNumber))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON trim(lower(lc.compliance_region_id)) = trim(lower(cr.ComplianceRegionNumber))
LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
WHERE 
  lc.gds_batch_id = wid_GDSBatchID
  AND lc.list_code_type = 'UIT Disposed'