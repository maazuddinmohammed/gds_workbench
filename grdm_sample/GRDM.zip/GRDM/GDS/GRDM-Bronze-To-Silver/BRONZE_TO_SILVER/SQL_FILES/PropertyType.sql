SELECT 
    coalesce(TRIM(lc.list_code_id), 'N/A') as PropertyTypeNumber,
    coalesce(TRIM(lc.short_name), 'N/A') as PropertyTypeName,
    coalesce(pt.PropertyTypeBusinessName, TRIM(lc.short_name)) as PropertyTypeBusinessName,
    TRIM(lc.description) as PropertyTypeDescription,
    coalesce(cr.ComplianceRegionID, -1) as ComplianceRegionID,
	lc.start_effective_date AS	PropertyTypeEffectiveStartDate,
	lc.end_effective_date AS PropertyTypeEffectiveEndDate,
	lc.identifier AS PropertyTypeIdentifier,
	lc.parent_list_code_id AS ParentPropertyTypeListCodeNumber,
	lc.associated_security_type AS	PropertyTypeAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS PropertyTypeIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	PropertyTypeSICCode,
	lc.show_acknowledgement_checkbox AS	PropertyTypeShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS PropertyTypeRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS PropertyTypeFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	PropertyTypeIsAccountTypeEligibleForBrokerageImport,    
    NULL as SourceCreatedDate,
    lc.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(ms.SourceSystemID, -1) as SourceSystemID
FROM
    gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN
    gds_grdm_int.PropertyType pt 
    ON TRIM(LOWER(lc.list_code_id)) = TRIM(LOWER(pt.PropertyTypeNumber))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr 
    ON TRIM(LOWER(lc.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
LEFT JOIN
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE
    lc.gds_batch_id = wid_GDSBatchID
    AND lc.list_code_type = 'Property Type'