-------------------------------------------------------
-- Refresh ComplianceRegionHierarchy
-------------------------------------------------------

TRUNCATE TABLE gds_grdm_int.ComplianceRegionHierarchy;

WITH RECURSIVE ComplianceRegionHierarchy AS
(
  SELECT  
      cr.ComplianceRegionID,
      cr.ComplianceRegionName,
      cr.ComplianceRegionIdentifier, 
      cr.ParentComplianceRegionID,
      pcr.ComplianceRegionName as ParentComplianceRegionName,
      pcr.ComplianceRegionIdentifier as ParentComplianceRegionIdentifier,
      cr.SourceCreatedDate,
      cr.SourceUpdatedDate,
      cr.SourceCreatedBy,
      cr.SourceUpdatedBy,
      ms.SourceSystemID 
    FROM gds_grdm_int.ComplianceRegion cr
    LEFT JOIN gds_grdm_int.ComplianceRegion pcr ON
      pcr.ComplianceRegionID = cr.ParentComplianceRegionID
    LEFT JOIN gds.MetaSourceSystem ms ON 
      ms.SourceSystemName = 'KICS'
  UNION ALL
  SELECT  
      cr.ComplianceRegionID, 
      cr.ComplianceRegionName,
      cr.ComplianceRegionIdentifier, 
      cr.ParentComplianceRegionID,
      pcr.ComplianceRegionName as ParentComplianceRegionName,
      pcr.ComplianceRegionIdentifier as ParentComplianceRegionIdentifier,
      cr.SourceCreatedDate,
      cr.SourceUpdatedDate,
      cr.SourceCreatedBy,
      cr.SourceUpdatedBy,
      ms.SourceSystemID 
    FROM gds_grdm_int.ComplianceRegion cr
    LEFT JOIN gds_grdm_int.ComplianceRegion pcr ON
      pcr.ComplianceRegionID = cr.ParentComplianceRegionID
    LEFT JOIN gds.MetaSourceSystem ms ON 
      ms.SourceSystemName = 'KICS'
  INNER JOIN ComplianceRegionHierarchy crh ON
    cr.ParentComplianceRegionID = crh.ComplianceRegionID
)
SELECT * 
  FROM ComplianceRegionHierarchy;