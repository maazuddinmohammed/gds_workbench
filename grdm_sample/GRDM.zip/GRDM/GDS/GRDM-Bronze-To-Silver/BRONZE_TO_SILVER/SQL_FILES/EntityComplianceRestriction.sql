SELECT
  TRIM(ker.entity_restriction_id) AS EntityComplianceRestrictionNumber,
  ec.EntityComplianceID AS EntityComplianceID, 
  coalesce(cr.ComplianceRegionID,-1) AS ComplianceRegionID,
  cr2.ComplianceRegionID AS ParentComplianceRegionID,
  coalesce(rt.RestrictionTypeID,-1) AS RestrictionTypeID,
  rs.RestrictionStateID AS RestrictionStateID,
  TRIM(ker.restriction_applied) AS EntityComplianceRestriction,
  ker.restriction_reason AS EntityComplianceRestrictionReason,
  TRIM(ker.entity_type) AS EntityComplianceRestrictionEntityType,
  TRIM(ker.engagement_partner_assignment_array) AS EntityComplianceRestrictionEngagementPartnerAssignmentArray,
  TRIM(ker.covered_person_restriction_attribute_array) AS EntityComplianceRestrictionCoveredPersonRestrictionAttributeArray,
  TRIM(ker.is_restricted) AS IsRestricted,
  TRIM(ker.is_applicable) AS IsApplicable,
  current_timestamp AS SourceCreatedDate,
  ker.last_change_time AS SourceUpdatedDate,
  NULL AS SourceCreatedBy,
  NULL AS SourceUpdatedBy,
  s.SourceSystemID AS SourceSystemID
FROM 
  gds_grdm_raw.v_kics_entity_restriction_v1 ker
LEFT JOIN 
  gds.MetaSourceSystem s 
  ON s.SourceSystemName = 'KICS'
LEFT JOIN 
  gds_ref_int.Entity e 
  ON LOWER(TRIM(e.EntityNumber)) = LOWER(TRIM(ker.entity_id))
  AND e.SourceSystemID = s.SourceSystemID
LEFT JOIN 
  gds_grdm_int.EntityCompliance ec 
  ON TRIM(LOWER(ec.entityid)) = TRIM(LOWER(e.EntityID))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON LOWER(TRIM(cr.ComplianceRegionNumber)) = LOWER(TRIM(ker.restricted_compliance_region_id))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr2 
  ON LOWER(TRIM(cr2.ComplianceRegionNumber)) = LOWER(TRIM(ker.inherited_from_parent_compliance_region_id))
LEFT JOIN 
  gds_grdm_int.RestrictionType rt 
  ON LOWER(TRIM(ker.restriction_type)) = LOWER(TRIM(rt.RestrictionTypeNumber))
LEFT JOIN 
  gds_grdm_int.RestrictionState rs 
  ON LOWER(TRIM(ker.restriction_state)) = LOWER(TRIM(rs.RestrictionStateNumber))
WHERE ker.gds_batch_id = wid_GDSBatchID and trim(ker.entity_restriction_id) is not null
