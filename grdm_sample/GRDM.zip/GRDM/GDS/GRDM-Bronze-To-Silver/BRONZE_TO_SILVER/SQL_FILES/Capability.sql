SELECT 
    TRIM(dp.default_capability_id) AS CapabilityNumber,    
    TRIM(dp.capability_name) AS CapabilityName,
    TRIM(dp.is_admin_enabled) AS IsCapabilityAdminEnabled,
    TRIM(dp.is_compliance_officer_enabled) AS IsCapabilityComplianceOfficerEnabled,
    TRIM(dp.is_reviewer_enabled) AS IsCapabilityReviewerEnabled,
    TRIM(dp.is_superuser_enabled) AS IsCapabilitySuperUserEnabled,
    null AS SourceCreatedDate, 
    TRIM(dp.last_change_time) AS SourceUpdatedDate,
    null AS SourceCreatedBy,     
    null AS SourceUpdatedBy,  
    TRIM(ms.SourceSystemID) as SourceSystemID
FROM
    gds_grdm_raw.kics_default_capability dp
    LEFT JOIN
    meta.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE
    dp.gds_batch_id = wid_GDSBatchID