SELECT 
  TRIM(kuih.last_change_time) as UserHistoryTime,
  coalesce(u.UserID, -1) as UserID,
  coalesce(TRIM(kuih.tracking_system_user_id), 'N/A') as UserNumber,
  coalesce(TRIM(kuih.first_name), 'N/A') as UserFirstName,
  TRIM(kuih.middle_name) as UserMiddleName,
  coalesce(TRIM(kuih.last_name), 'N/A') as UserLastName,
  TRIM(kuih.marital_status) as UserMaritalStatus,
  TRIM(kuih.ssn) AS UserSSN,
  TRIM(kuih.job_title) as UserJobTitle,
  TRIM(kuih.job_service) as UserJobService,
  TRIM(kuih.job_class) as UserJobClass,
  TRIM(kuih.employment_status) as UserEmploymentStatus,
  TRIM(kuih.phone_number) AS UserPhoneNumber,
  TRIM(kuih.email) as UserEmailAddress,
  atyp.AddressTypeID as AddressTypeID,
  TRIM(kuih.address_line_1) as UserAddressLine1,
  TRIM(kuih.address_line_2) as UserAddressLine2,
  TRIM(kuih.address_line_3) as UserAddressLine3,
  TRIM(kuih.address_line_4) as UserAddressLine4,
  TRIM(kuih.city) as UserAddressCity,
  TRIM(kuih.state) as UserAddressState,
  TRIM(kuih.zip_code) as UserAddressPostalCode,
  -1 as CountryID,  -- Kingland doesn't have Country information for the address
  TRIM(kuih.userid) as UserIdentifier,
  TRIM(kuih.employee_identifier) as UserEmployeeIdentifier,
  TRIM(kuih.global_person_unique_identifier) as UserGlobalIdentifier,
  TRIM(kuih.status) as UserStatus,
  TRIM(kuih.external_identifier) AS UserExternalIdentifier,
  TRIM(kuih.supervisor_employee_identifier) as UserSupervisorEmployeeIdentifier,
  TRIM(kuih.supervisor_first_name) AS UserSupervisorFirstName,
  TRIM(kuih.supervisor_last_name) AS UserSupervisorLastName,
  TRIM(kuih.supervisor_email_address) AS UserSupervisorEmailAddress,
  cra.ComplianceRegionID as AuthorizedComplianceRegionID,
  crp.ComplianceRegionID as PrimaryComplianceRegionID,
  crs.ComplianceRegionID as SecondaryComplianceRegionID,
  cscr.ComplianceRegionID as CurrentSecondaryComplianceRegionID,
  crg.ComplianceRegionID as AssignedComplianceRegionID,
  l.LocationID as LocationID,
  crl.LanguageID as LanguageID,
  crl.ComplianceRegionLanguageID as ComplianceRegionLanguageID,
  TRIM(kuih.business_unit) as UserBusinessUnit,
  TRIM(kuih.department_code) as UserDepartmentCode,
  TRIM(kuih.department_name) as UserDepartmentName,  
  TRIM(kuih.department_number) as UserDepartmentNumber,
  TRIM(kuih.cost_center) as UserCostCenter,
  TRIM(kuih.cost_center_description) as UserCostCenterDescription,  
  TRIM(kuih.hired_date) as UserHireDate,
  TRIM(kuih.last_hire_date) as UserLastHireDate,
  TRIM(kuih.service_center_logon_time) as UserServiceCenterLogonTime,
  TRIM(kuih.affirmed_time) as UserAffirmedTime,
  TRIM(kuih.affirmed_uncheck_time) as UserAffirmedUncheckedTime,
  TRIM(kuih.monitored_time) as UserMonitoredTime,
  TRIM(kuih.closed_time) as UserClosedTime,
  TRIM(kuih.reopen_time) as UserReopenTime,
  TRIM(kuih.designated_month) as UserDesignatedMonth,
  TRIM(kuih.office_number) as UserOfficeNumber,
  TRIM(kuih.effective_date) as UserEffectiveDate,
  TRIM(kuih.bdi_role) as UserBDIRole,
  TRIM(kuih.primary_segment) as UserPrimarySegment,
  TRIM(kuih.secondary_segment) as UserSecondarySegment,
  TRIM(kuih.primary_industry_sector) as UserPrimaryIndustrySector,
  TRIM(kuih.additional_sec_role) as UserAdditionalSECRole,
  TRIM(kuih.leave_of_absence_start_date) as UserLeaveOfAbsenceStartDate,
  TRIM(kuih.leave_of_absence_planned_return_date) as UserLeaveOfAbsensePlannedReturnDate,
  NULL as IndustrySectorID,
  TRIM(kuih.portfolio_view) as UserPortfolioView,
  TRIM(kuih.service_center_authorization) as UserServiceCenterAuthorization,
  TRIM(kuih.monitoring_tab_default_action_type) as UserMonitoringTabDefaultActionType,
  TRIM(kuih.menu_layout) as UserMenuLayout,
  CASE 
    WHEN LOWER(TRIM(kuih.show_training_modal_at_login)) = 'enabled' THEN 'Yes'
    WHEN LOWER(TRIM(kuih.show_training_modal_at_login)) = 'disabled' THEN 'No'
    WHEN LOWER(TRIM(kuih.show_training_modal_at_login)) = 'preference not set' THEN NULL
    ELSE kuih.show_training_modal_at_login 
  END as UserShowTrainingModalAtLogin,
  TRIM(kuih.portfolio_affirmed) as IsPortfolioAffirmed,
  TRIM(kuih.allow_mapping_update) as AllowMappingUpdate,
  CASE 
    WHEN LOWER(TRIM(kuih.bulk_self_clear_enabled)) = 'enabled' THEN 'Yes'
    WHEN LOWER(TRIM(kuih.bulk_self_clear_enabled)) = 'disabled' THEN 'No'
    WHEN LOWER(TRIM(kuih.bulk_self_clear_enabled)) = 'preference not set' THEN NULL
    ELSE kuih.bulk_self_clear_enabled 
  END as BulkSelfClearEnabled,
  TRIM(kuih.can_review_all_locations) as CanReviewAllLocations,
  TRIM(kuih.has_investment) as HasInvestments,
  TRIM(kuih.has_insurance) as HasInsurance,
  TRIM(kuih.is_monitored_employee) as IsMonitoredUser,
  TRIM(kuih.monitored_user_flag) as IsMonitoredUserFlag,
  TRIM(kuih.is_compliance_officer) as IsComplianceOfficer,
  TRIM(kuih.is_monitored_employee) as IsMonitoredEmployee,
  TRIM(kuih.is_application_administrator) as IsApplicationAdministrator,
  TRIM(kuih.is_reviewer) as IsReviewer,
  TRIM(kuih.is_superuser) as IsSuperUser,
  TRIM(kuih.is_reviewer_of_partners) as IsReviewerOfPartner,
  TRIM(kuih.is_reviewer_of_managers) as IsReviewerOfManagers,
  TRIM(kuih.is_reviewer_of_professional_staff) as IsReviewerOfProfessionalStaff,
  TRIM(kuih.is_reviewer_of_firm_holdings) as IsReviewerOfFirmHoldings,
  TRIM(kuih.is_reviewer_of_pension_holdings) as IsReviewerOfPensionHoldings,
  TRIM(kuih.is_unmonitored_employee) as IsUnmonitoredEmployee,
  TRIM(kuih.is_reviewer_of_admins) as IsReviewerOfAdmins,
  TRIM(kuih.is_text_editor) as IsTextEditor,
  TRIM(kuih.is_text_reviewer) as IsTextReviewer,
  TRIM(kuih.is_assigned_to_mapping) as IsAssignedToMapping,
  TRIM(kuih.is_privacy_statement_viewed)  as IsPrivacyStatementViewed,
  TRIM(kuih.is_sec_role_professional) as IsSECRoleProfessional,
  TRIM(kuih.is_sec_role_partner) as IsSECRolePartner,
  TRIM(kuih.is_sec_role_manager) as IsSECRoleManager,
  TRIM(kuih.is_sec_role_firm) as IsSECRoleFirm,
  TRIM(kuih.is_sec_role_pension) as IsSECRolePension,
  TRIM(kuih.is_sec_role_admin) as IsSECRoleAdmin,
  TRIM(kuih.add_type) as UserAddType,
  TRIM(kuih.add_time) as UserAddTime,
  TRIM(kuih.last_info_update_time) as UserLastInformationUpdateTime,
  TRIM(kuih.last_info_update_user) as UserLastInformationUpdateUser,
  TRIM(kuih.last_info_update_time) as UserLastChangeTime,
  TRIM(kuih.last_change_user) as UserLastChangeUser,  
  NULL as SourceCreatedDate,
  NULL as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  ms.SourceSystemID as SourceSystemID
FROM 
  gds_grdm_raw.v_kics_user_info_history_v1 kuih
LEFT JOIN 
   gds_ref_int.AddressType atyp
   ON atyp.AddressTypeName = 'Primary'
LEFT JOIN 
  gds_grdm_int.User u ON LOWER(TRIM(u.UserNumber)) = LOWER(TRIM(kuih.tracking_system_user_id))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cra ON LOWER(TRIM(cra.ComplianceRegionNumber)) = LOWER(TRIM(kuih.authorized_compliance_region_id))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion crp ON LOWER(TRIM(crp.ComplianceRegionNumber)) = LOWER(TRIM(kuih.current_assigned_compliance_region_id))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion crs ON LOWER(TRIM(crs.ComplianceRegionNumber)) = LOWER(TRIM(kuih.secondary_compliance_region_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cscr 
    ON LOWER(TRIM(cscr.ComplianceRegionNumber)) = LOWER(TRIM(kuih.current_secondary_compliance_region_id))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion crg ON LOWER(TRIM(crg.ComplianceRegionNumber)) = LOWER(TRIM(kuih.assigned_compliance_region_id))
LEFT JOIN 
  gds_grdm_int.Location l ON LOWER(TRIM(l.LocationNumber)) = LOWER(TRIM(kuih.location_id))
LEFT JOIN gds_grdm_int.ComplianceRegionLanguage crl
    ON LOWER(TRIM(crl.ComplianceRegionLanguageNumber)) = LOWER(TRIM(kuih.preferred_language_assignment_id))
LEFT JOIN
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
WHERE 
  kuih.gds_batch_id = wid_GDSBatchID