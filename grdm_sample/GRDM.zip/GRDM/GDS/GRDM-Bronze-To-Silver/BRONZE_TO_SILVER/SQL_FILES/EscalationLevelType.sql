SELECT 
    DISTINCT
    trim(le.level_type) as EscalationLevelTypeNumber,
    trim(le.level_type) as EscalationLevelTypeName,
    coalesce(elt.EscalationLevelTypeBusinessName, le.level_type) as EscalationLevelTypeBusinessName,
    trim(le.level_type) as EscalationLevelTypeDescription,
    NULL as SourceCreatedDate,
    NULL as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(s.SourceSystemID, -1) as SourceSystemID
FROM 
    gds_grdm_raw.kics_escalation_level_v1 le
LEFT JOIN 
    gds_grdm_int.EscalationLevelType elt 
    ON trim(lower(le.level_type)) = trim(lower(elt.EscalationLevelTypeNumber))
LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
WHERE 
    le.gds_batch_id = wid_GDSBatchID