SELECT 
    TRIM(lc.list_code_id) as AccountTypeNumber,
    TRIM(lc.short_name) as AccountTypeName,
    COALESCE(at.AccountTypeBusinessName, TRIM(lc.short_name)) as AccountTypeBusinessName,
    TRIM(lc.description) as AccountTypeDescription,
    cr.ComplianceRegionID as ComplianceRegionID,
    lc.start_effective_date AS AccountTypeEffectiveStartDate,
    lc.end_effective_date AS AccountTypeEffectiveEndDate,
    lc.identifier AS AccountTypeIdentifier,
    lc.parent_list_code_id AS ParentAccountTypeListCodeNumber,
    lc.associated_security_type AS AccountTypeAssociatedSecurityType,
    lc.can_financial_interest_be_reassigned_issuer AS AccountTypeIsFinancialInterestBeReassignedIssuer,
    lc.sic_codes AS	AccountTypeSICCode,
    lc.show_acknowledgement_checkbox AS	AccountTypeShowAcknowledgementCheckbox,
    lc.require_comment_field_when_add_holding AS AccountTypeRequireCommentFieldWhenAddHolding,
    lc.financial_interest_display_type AS AccountTypeFinancialInterestDisplayType,
    lc.is_account_type_eligible_for_brokerage_import AS	AccountTypeIsAccountTypeEligibleForBrokerageImport,   
    NULL as SourceCreatedDate,
    lc.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    ms.SourceSystemID as SourceSystemID
FROM
    gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN
    gds_grdm_int.AccountType at 
    ON TRIM(LOWER(lc.list_code_id)) = TRIM(LOWER(at.AccountTypeNumber))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr 
    ON TRIM(LOWER(lc.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
LEFT JOIN
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE
    lc.gds_batch_id = wid_GDSBatchID
    AND lc.list_code_type = 'Account Type'