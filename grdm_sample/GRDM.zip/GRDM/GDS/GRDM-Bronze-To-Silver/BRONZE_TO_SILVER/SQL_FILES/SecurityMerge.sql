SELECT 
  TRIM(m.entity_security_merge_record_id) as SecurityMergeNumber,
  sret.SecurityID as SecurityRetainedID,
  srep.SecurityID as SecurityReplacedID,
  to_date(m.merge_time) as SecurityMergeDate,
  date_format(m.merge_time, 'HH:mm:ss') as SecurityMergeTime,
  TRIM(m.retained_security_acquisition_date_source) as SecurityMergeDataSource,
  TRIM(m.merge_comment) as SecurityMergeComment,
  TRIM(m.is_confirmation_required) as IsConfirmationRequired,
  TRIM(m.is_send_notification_selected) as IsSendNotification,
  NULL as SourceCreatedDate,
  m.last_change_time as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  coalesce(NULL, -1) as SourceSystemID
FROM 
  gds_grdm_raw.kics_entity_security_merge_record_v1 m
LEFT JOIN 
  gds_grdm_int.Security sret 
  ON LOWER(TRIM(sret.SecurityNumber)) = LOWER(TRIM(m.entity_security_retained_id))
LEFT JOIN 
  gds_grdm_int.Security srep 
  ON LOWER(TRIM(srep.SecurityNumber)) = LOWER(TRIM(m.entity_security_replaced_id))
WHERE 
  m.gds_batch_id = wid_GDSBatchID
  AND  sret.SecurityID IS NOT NULL  ---> SecurityID both must not be Null