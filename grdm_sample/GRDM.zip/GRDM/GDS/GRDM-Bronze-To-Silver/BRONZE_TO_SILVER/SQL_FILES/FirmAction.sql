SELECT 
    TRIM(fa.firm_action_case_id) as FirmActionNumber,
    ec.EntityComplianceID AS EntityComplianceID,
    ec2.EntityComplianceID AS PendingEntityComplianceID,
    l.LocationID as LocationID,
    fa.pending_user_location_id as PendingUserLocationID,
    cr.ComplianceRegionID as ComplianceRegionID,
    cr2.ComplianceRegionID as PendingComplianceRegionID,
    fa.current_affected_compliance_region_id AS CurrentAffectedComplianceRegionID,
    s.SecurityID as SecurityID,
    u.UserID as UserID,
    fg.FirmActionGroupID as FirmActionGroupID,
    sr.SecurityRestrictionID AS PendingSecurityRestrictionID,
    ecr.EntityComplianceRestrictionID AS PendingEntityComplianceRestrictionID,
    TRIM(fa.current_action) as FirmActionCurrentAction,
    TRIM(fa.entity_type) as FirmActionEntityType,
    TRIM(fa.pending_new_value) as FirmActionPendingNewValue,
    TRIM(fa.firm_action_applicability) as FirmActionApplicability,
    TRIM(fa.firm_action_state) as FirmActionState,
    TRIM(fa.auto_process_to) as FirmActionAutoProcessFinalState,
    TRIM(fa.review_status) as FirmActionReviewStatus,
    TRIM(fa.review_comments) as FirmActionReviewComment,
    TRIM(fa.sec_registrant_comments) as FirmActionSECRegistrantComment,
    TRIM(fa.auto_process) as IsAutoProcess,
    TRIM(fa.override_auto_self_clear_settings) as OverrideAutoSelfClearSetting,
    TRIM(fa.is_firm_action_require_review) as RequireReview,
    TRIM(fa.has_been_analyzed) as IsAnalyzed,
    current_timestamp as SourceCreatedDate,
    fa.last_change_time as SourceUpdatedDate,
    TRIM(fa.created_by) as SourceCreatedBy,
    TRIM(fa.last_change_user) as SourceUpdatedBy,
    sys.SourceSystemID as SourceSystemID
FROM
    gds_grdm_raw.kics_firm_action_v1 fa
LEFT JOIN
    gds.MetaSourceSystem sys ON sys.SourceSystemName = 'KICS'
LEFT JOIN 
    gds_ref_int.entity en ON TRIM(LOWER(en.EntityNumber)) = TRIM(LOWER(fa.current_affected_entity_id))  
    and en.SourceSystemID=sys.SourceSystemID  
LEFT JOIN
    gds_grdm_int.EntityCompliance ec ON ec.EntityID = en.EntityID
LEFT JOIN 
    gds_ref_int.Entity e2 
    ON LOWER(TRIM(e2.EntityNumber)) = LOWER(TRIM(fa.pending_entity_id)) 
       AND e2.SourceSystemID = sys.SourceSystemID
  LEFT JOIN 
    gds_grdm_int.EntityCompliance ec2 
    ON LOWER(TRIM(ec2.EntityID)) = LOWER(TRIM(e2.EntityID))
LEFT JOIN
    gds_grdm_int.Location l ON LOWER(TRIM(l.LocationNumber)) = LOWER(TRIM(fa.pending_user_location_id))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr ON LOWER(TRIM(cr.ComplianceRegionNumber)) = LOWER(TRIM(fa.compliance_region_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr2 ON LOWER(TRIM(cr2.ComplianceRegionNumber)) = LOWER(TRIM(fa.pending_user_compliance_region_id))
LEFT JOIN
    gds_grdm_int.Security s ON LOWER(TRIM(s.SecurityNumber)) = LOWER(TRIM(fa.current_affected_security_id))
LEFT JOIN
    gds_grdm_int.User u ON LOWER(TRIM(u.UserNumber)) = LOWER(TRIM(fa.current_affected_user_id))
LEFT JOIN
    gds_grdm_int.FirmActionGroup fg ON LOWER(TRIM(fg.FirmActionGroupNumber)) = LOWER(TRIM(fa.firm_action_group_id))
LEFT JOIN 
    gds_grdm_int.EntityComplianceRestriction ecr ON 
    LOWER(TRIM(ecr.EntityComplianceRestrictionNumber)) = LOWER(TRIM(fa.pending_entity_restriction_id))
    AND LOWER(TRIM(ecr.ComplianceRegionID)) = LOWER(TRIM(cr.ComplianceRegionID))  
LEFT JOIN 
    gds_grdm_int.SecurityRestriction sr ON 
    LOWER(TRIM(sr.SecurityRestrictionNumber)) = LOWER(TRIM(fa.pending_security_restriction_id))
    AND LOWER(TRIM(sr.ComplianceRegionID)) = LOWER(TRIM(cr.ComplianceRegionID))
WHERE
    fa.gds_batch_id = wid_GDSBatchID