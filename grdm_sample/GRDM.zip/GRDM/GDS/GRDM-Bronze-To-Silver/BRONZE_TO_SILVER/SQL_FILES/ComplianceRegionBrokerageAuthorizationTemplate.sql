SELECT 
  trim(a.brokerage_authorization_template_to_compliance_region_assignment_id) as ComplianceRegionBrokerageAuthorizationTemplateNumber,
  cr.ComplianceRegionID as ComplianceRegionID,
  bat.BrokerageAuthorizationTemplateID as BrokerageAuthorizationTemplateID,
  NULL as SourceCreatedDate,
  a.last_change_time as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  sys.SourceSystemID as SourceSystemID
FROM 
  gds_grdm_raw.kics_brokerage_authorization_template_to_compliance_region_assignment_v1 a
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON LOWER(TRIM(cr.ComplianceRegionNumber)) = LOWER(TRIM(a.compliance_region_id))
LEFT JOIN 
  gds_grdm_int.BrokerageAuthorizationTemplate bat 
  ON LOWER(TRIM(a.brokerage_authorization_template_id)) = LOWER(TRIM(bat.BrokerageAuthorizationTemplateNumber))
LEFT JOIN 
  gds.MetaSourceSystem sys 
  ON sys.SourceSystemName = 'KICS'
WHERE 
  a.gds_batch_id = wid_GDSBatchID