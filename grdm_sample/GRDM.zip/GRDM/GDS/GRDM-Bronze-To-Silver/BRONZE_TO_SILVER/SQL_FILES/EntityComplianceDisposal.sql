SELECT 
    trim(lc.list_code_id) as EntityComplianceDisposalNumber,
    trim(lc.short_name) as EntityComplianceDisposalName,
    coalesce(ecd.EntityComplianceDisposalBusinessName, lc.short_name) as EntityComplianceDisposalBusinessName,
    trim(lc.description) as EntityComplianceDisposalDescription,
    coalesce(cr.ComplianceRegionID, -1) as ComplianceRegionID,
	lc.start_effective_date AS	EntityComplianceDisposalEffectiveStartDate,
	lc.end_effective_date AS EntityComplianceDisposalEffectiveEndDate,
	lc.identifier AS EntityComplianceDisposalIdentifier,
	lc.parent_list_code_id AS ParentEntityComplianceDisposalListCodeNumber,
	lc.associated_security_type AS	EntityComplianceDisposalAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS EntityComplianceDisposalIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	EntityComplianceDisposalSICCode,
	lc.show_acknowledgement_checkbox AS	EntityComplianceDisposalShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS EntityComplianceDisposalRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS EntityComplianceDisposalFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	EntityComplianceDisposalIsAccountTypeEligibleForBrokerageImport,    
    NULL as SourceCreatedDate,
    lc.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(s.SourceSystemID, -1) as SourceSystemID
FROM 
    gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
    gds_grdm_int.EntityComplianceDisposal ecd 
    ON trim(lower(lc.list_code_id)) = trim(lower(ecd.EntityComplianceDisposalNumber))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON trim(lower(lc.compliance_region_id)) = trim(lower(cr.ComplianceRegionNumber))
LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
WHERE 
    lc.gds_batch_id = wid_GDSBatchID
  AND lc.list_code_type = 'Entity Disposed'


  