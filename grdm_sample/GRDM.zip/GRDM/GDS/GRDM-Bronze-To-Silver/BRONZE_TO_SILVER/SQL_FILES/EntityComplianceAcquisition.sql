SELECT 

    trim(lc.list_code_id) as EntityComplianceAcquisitionNumber,
    trim(lc.short_name) as EntityComplianceAcquisitionName,
    coalesce(eca.EntityComplianceAcquisitionBusinessName, lc.short_name) as EntityComplianceAcquisitionBusinessName,
    trim(lc.description) as EntityComplianceAcquisitionDescription,
    cr.ComplianceRegionID as ComplianceRegionID,
 	lc.start_effective_date AS	EntityComplianceAcquisitionEffectiveStartDate,
	lc.end_effective_date AS EntityComplianceAcquisitionEffectiveEndDate,
	lc.identifier AS EntityComplianceAcquisitionIdentifier,
	lc.parent_list_code_id AS ParentEntityComplianceAcquisitionListCodeNumber,
	lc.associated_security_type AS	EntityComplianceAcquisitionAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS EntityComplianceAcquisitionIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	EntityComplianceAcquisitionSICCode,
	lc.show_acknowledgement_checkbox AS	EntityComplianceAcquisitionShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS EntityComplianceAcquisitionRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS EntityComplianceAcquisitionFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	EntityComplianceAcquisitionIsAccountTypeEligibleForBrokerageImport,   
    NULL as SourceCreatedDate,
    lc.last_change_time as  SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(s.SourceSystemID, -1) as SourceSystemID
FROM 
    gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON lower(trim(lc.compliance_region_id)) = lower(trim(cr.ComplianceRegionNumber))
LEFT JOIN 
    gds_grdm_int.EntityComplianceAcquisition eca 
    ON lc.list_code_id = eca.EntityComplianceAcquisitionNumber
LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
WHERE 
    lc.gds_batch_id = wid_GDSBatchID
    AND lc.list_code_type = 'Entity Acquired'
