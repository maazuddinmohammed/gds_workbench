SELECT 
    uaeh.last_change_time as UserEntityComplianceHistoryTime,
    TRIM(uaeh.user_added_entity_id) as UserEntityComplianceNumber,
    uec.UserEntityComplianceID as UserEntityComplianceID,    
    coalesce(u.UserID,-1) as UserID,
    TRIM(uaeh.request_user_id) as RequestUserID,
    ec.EntityComplianceID as EntityComplianceID,
    TRIM(uaeh.transferred_pending_associated_entity_security_id) as PendingTransferEntityComplianceID,
    cs.SecurityID as SecurityID,
    TRIM(uaeh.transferred_pending_associated_entity_security_id) as PendingTransferSecurityID,    
    se.SecurityExchangeID as SecurityExchangeID,
    cr1.ComplianceRegionID as ComplianceRegionID,
    cr2.ComplianceRegionID as PrimaryComplianceRegionID,
    cr3.ComplianceRegionID as SecondaryComplianceRegionID,
    cr4.ComplianceRegionID as TransferredComplianceRegionID,
    cr5.ComplianceRegionID as ReviewerComplianceRegionID,
    coalesce(fit.FinancialInterestTypeID,fitp.FinancialInterestTypeID) AS FinancialInterestTypeID,
    fist.FinancialInterestSubTypeID AS FinancialInterestSubTypeID,
    at.AccountTypeID as AccountTypeID,
    b.BrokerageID AS BrokerageID,
    uaeh.action_time AS UserEntityComplianceActionTime,
    TRIM(uaeh.company) AS UserEntityComplianceCompany,
    TRIM(uaeh.symbol) AS UserEntityComplianceSymbol, 
    TRIM(uaeh.identifier) AS UserEntityComplianceIdentifier,
    TRIM(uaeh.transferred_pending_associated_entity_security_type) AS UserEntityCompliancePendingEntitySecurityType,
    TRIM(uaeh.user_assignment_status) AS UserEntityComplianceUserAssignmentStatus,    
    TRIM(uaeh.user_added_entity_type) as UserEntityComplianceType,
    TRIM(uaeh.user_added_entity_status) as UserEntityComplianceStatus,
    TRIM(uaeh.description) as UserEntityComplianceDescription,
    TRIM(uaeh.status_comments) as UserEntityComplianceStatusComment,
    TRIM(uaeh.comments) as UserEntityComplianceComment,
    TRIM(uaeh.street) as UserEntityComplianceAddress,
    TRIM(uaeh.city) as UserEntityComplianceCity,
    TRIM(uaeh.state_province) as UserEntityComplianceState,
    TRIM(uaeh.postal) as UserEntityCompliancePostalCode,
    c.CountryID as CountryID,
    TRIM(uaeh.cusip) as UserEntityComplianceCUSIP,
    TRIM(uaeh.isin) as UserEntityComplianceISIN,
    TRIM(uaeh.sedol) as UserEntityComplianceSEDOL,
    uaeh.replacement_action_acquisition_date as UserEntityComplianceReplacementAcquisitionDate,
    TRIM(uaeh.replacement_action_acquisition_date_option) as UserEntityComplianceAcquisitionDateOption,
    CASE WHEN uaeh.active = 'Y' THEN 'True' ELSE 'False' END AS UserEntityComplianceIsActive,
    TRIM(uaeh.attachment_required_time) as AttachmentRequiredTime,
    uaeh.added_time as SourceCreatedDate,
    uaeh.last_change_time as SourceUpdatedDate,
    TRIM(uaeh.add_user) as SourceCreatedBy,
    TRIM(uaeh.last_change_user) as SourceUpdatedBy,
    sys.SourceSystemID as SourceSystemID
FROM
    gds_grdm_raw.v_kics_user_added_entity_history_v1 uaeh
LEFT JOIN
    gds_grdm_int.User u ON LOWER(TRIM(u.UserNumber)) = LOWER(TRIM(uaeh.tracking_system_user_id))
LEFT JOIN
    gds_grdm_int.v_UserEntityCompliance uec ON LOWER(TRIM(uec.UserEntityComplianceNumber)) = LOWER(TRIM(uaeh.user_added_entity_id))
LEFT JOIN
    gds_grdm_int.EntityCompliance ec ON LOWER(TRIM(ec.EntityID)) = LOWER(TRIM(uaeh.associated_entity_security_id)) 
LEFT JOIN
    gds_grdm_int.Security cs ON LOWER(TRIM(cs.SecurityNumber)) = LOWER(TRIM(uaeh.associated_entity_security_id))
LEFT JOIN
    gds_grdm_int.SecurityExchange se ON LOWER(TRIM(se.SecurityExchangeNumber)) = LOWER(TRIM(uaeh.exchange_id))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr1 ON LOWER(TRIM(cr1.ComplianceRegionNumber)) = LOWER(TRIM(uaeh.compliance_region_id))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr2 ON LOWER(TRIM(cr2.ComplianceRegionNumber)) = LOWER(TRIM(uaeh.current_assigned_compliance_region_id))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr3 ON LOWER(TRIM(cr3.ComplianceRegionNumber)) = LOWER(TRIM(uaeh.current_secondary_compliance_region_id))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr4 ON LOWER(TRIM(cr4.ComplianceRegionNumber)) = LOWER(TRIM(uaeh.transferred_compliance_region_id))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr5 ON LOWER(TRIM(cr5.ComplianceRegionNumber)) = LOWER(TRIM(uaeh.reviewer_compliance_region_id))
LEFT JOIN
    gds_grdm_int.FinancialInterestSubType fist ON LOWER(TRIM(fist.FinancialInterestSubTypeNumber)) = LOWER(TRIM(uaeh.financial_interest_sub_type_id))
LEFT JOIN 
    gds_grdm_int.FinancialInterestType fit ON LOWER(TRIM(fit.FinancialInterestTypeNumber)) = LOWER(TRIM(fist.ParentFinancialInterestSubTypeListCodeNumber))  
LEFT JOIN 
    gds_grdm_int.FinancialInterestType fitp ON TRIM(LOWER(fitp.FinancialInterestTypeNumber)) = TRIM(LOWER(uaeh.financial_interest_sub_type_id))
LEFT JOIN
    gds_grdm_int.AccountType at ON LOWER(TRIM(at.AccountTypeNumber)) = LOWER(TRIM(uaeh.account_type_id))
LEFT JOIN
    gds_ref_int.Country c ON LOWER(TRIM(c.CountryISOCode)) = LOWER(TRIM(uaeh.country_id_of_origin))
LEFT JOIN 
    gds_grdm_int.Brokerage b 
    ON LOWER(TRIM(b.BrokerageNumber)) = LOWER(TRIM(uaeh.brokerage_import_entity_id))
LEFT JOIN
    gds.MetaSourceSystem sys ON sys.SourceSystemName = 'KICS'
WHERE 
    uaeh.gds_batch_id = wid_GDSBatchID 

QUALIFY ROW_NUMBER() OVER(PARTITION BY uaeh.last_change_time, TRIM(uaeh.user_added_entity_id), coalesce(u.UserID,-1) ORDER BY uaeh.last_change_time DESC) = 1