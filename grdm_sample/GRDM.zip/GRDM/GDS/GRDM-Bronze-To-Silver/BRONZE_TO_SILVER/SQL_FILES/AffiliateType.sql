SELECT 
    TRIM(at.AffiliateTypeID) as AffiliateTypeNumber,
    TRIM(at.AffiliateTypeCode) as AffiliateTypeCode,
    TRIM(at.DisplayCode) as AffiliateTypeDisplayCode,
    TRIM(at.AffiliateTypeName) as AffiliateTypeName,
    TRIM(at.LongDescription) as AffiliateTypeBusinessName,
    TRIM(at.Description) as AffiliateTypeDescription,
    TRIM(at.AffiliateTypeRank) as AffiliateTypeRank,
    TRIM(at.AffiliateTypeAliasCode) as AffiliateTypeAlias,
    TRIM(at.OrganizationType) as AffiliateTypeOrganizationType,
    TRIM(at.DisplayOrder) as AffiliateTypeDisplayOrder,
    CASE WHEN at.IsActive = 1 THEN 'True' ELSE 'False' END as AffiliateTypeIsActive,
    NULL as SourceCreatedDate,
    NULL as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    ms.SourceSystemID as SourceSystemID
FROM
     gds_grdm_raw.sntl_x_affiliatetype at
LEFT JOIN
     gds.MetaSourceSystem ms 
    ON ms.SourceSystemCode = 'SNTL'
WHERE
    at.gds_batch_id = wid_GDSBatchID

