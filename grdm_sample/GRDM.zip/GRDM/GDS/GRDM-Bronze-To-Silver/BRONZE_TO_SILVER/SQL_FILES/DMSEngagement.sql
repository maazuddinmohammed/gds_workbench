SELECT 
dent.EntityId as EntityId,
coalesce(deng.RMDId,-1) AS RMDId	,
deng.Name	,
deng.MutualFundComments	,
coalesce(deng.IsActive,true) as EngagementIsActive	,
deng.Restricted	as Restricted,
0 as SecurityID,
current_timestamp() as SourceCreatedDate ,
current_timestamp() as SourceUpdatedDate ,
current_user() as SourceCreatedBy ,
current_user() as SourceUpdatedBy ,
deng.source_system_id as SourceSystemID 
FROM gds_grdm_raw.dms_engagement as deng 
JOIN gds_grdm_int.dmsentity as dent ON deng.EntityId = dent.SourceSystemEntityID 
WHERE deng.gds_batch_id = wid_GDSBatchID
AND (deng.RMDId IS NOT NULL OR deng.Name <> 'NA' OR deng.MutualFundComments <> 'NA' OR deng.Restricted IS NOT NULL)
UNION ALL
SELECT 
0 as EntityID,
coalesce(deng.RMDId,-1) AS RMDId	,
deng.Name	,
deng.MutualFundComments	,
coalesce(deng.IsActive,true) as EngagementIsActive	,
deng.Restricted	as Restricted,
dens.SecurityId as SecurityId,
current_timestamp() as SourceCreatedDate ,
current_timestamp() as SourceUpdatedDate ,
current_user() as SourceCreatedBy ,
current_user() as SourceUpdatedBy ,
deng.source_system_id as SourceSystemID 
FROM gds_grdm_raw.dms_engagement as deng 
JOIN gds_grdm_int.dmssecurity as dens ON deng.SecurityId = dens.SourceSystemSecurityId
WHERE deng.gds_batch_id = wid_GDSBatchID
AND (deng.RMDId IS NOT NULL OR deng.Name <> 'NA' OR deng.MutualFundComments <> 'NA' OR deng.Restricted IS NOT NULL)
