SELECT 
    TRIM(r.reason_id) AS WaiverReasonNumber,
    TRIM(r.reason_language_description_id) AS WaiverReasonDescription,
    TRIM(r.identifier) AS WaiverReasonIdentifier,
    cr.ComplianceRegionID AS ComplianceRegionID,
    wrt.WaiverReasonTypeID AS WaiverReasonTypeID,
    r.Status AS WaiverReasonStatus, 
    l2.LanguageID AS LanguageID,
    TRIM(r.reason_language_description_status) AS WaiverReasonLanguageDescriptionStatus,
    TRIM(r.reason_language_description) AS WaiverReasonLanguageDescription,
    TRIM(r.reason_language_description_comment) AS WaiverReasonComment,
    TRIM(r.default_day_count_until_expiration) AS DefaultDayCountUntlExpiration,
    TRIM(r.max_day_count_until_expiration) AS ReasonWaiverMaximumExpirationDays,
    r.is_default_language AS IsDefaultLanguage,
    NULL AS SourceCreatedDate,
    r.last_change_time AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
FROM 
    gds_grdm_raw.kics_reason_v1 r
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON cr.ComplianceRegionNumber = r.compliance_region_id
LEFT JOIN 
    gds_grdm_int.WaiverReasonType wrt 
    ON wrt.WaiverReasonTypeNumber = r.type
LEFT JOIN 
    gds_grdm_raw.kics_language_v1 l1 
    ON r.language_id = l1.language_id AND l1.gds_batch_id=r.gds_batch_id
LEFT JOIN 
    gds_ref_int.Language l2 
    ON l2.LanguageISO1 = l1.identifier
LEFT JOIN    
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE 
    r.gds_batch_id = wid_GDSBatchID
QUALIFY ROW_NUMBER() OVER(PARTITION BY TRIM(r.reason_id)  ORDER BY r.last_change_time DESC) = 1 