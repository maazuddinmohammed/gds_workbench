SELECT 
    TRIM(ur.user_review_id) AS UserReviewNumber,
    u.UserID AS UserID,
    TRIM(ur.user_review_case_id) AS UserReviewCaseNumber,
    TRIM(ur.user_action_type) AS UserReviewActionType,
    cr.ComplianceRegionID AS PrimaryComplianceRegionID,
    cr2.ComplianceRegionID AS SecondaryComplianceRegionID,
    el.EscalationLevelID AS EscalationLevelID,
    TRIM(ur.extension_granted_date) AS ExtensionGrantedDate,
    TRIM(ur.extension_expiration_date) AS UserReviewExtensionGrantedDate,
    TRIM(ur.user_action_record_start_monitoring_time) AS UserReviewStartTime,
    TRIM(ur.escalation_time) AS UserReviewEscalationTime,
    TRIM(ur.reviewer_comments) AS UserReviewComment,
    TRIM(ur.comment_saved_time) AS UserReviewCommentSaveTime,
    TRIM(ur.admin_action) AS UserReviewAdministrativeAction,
    TRIM(ur.admin_action_time) AS UserReviewAdministrativeActionTime,
    TRIM(ur.discipline_level_id) AS UserReviewDisciplineLevel,
    TRIM(ur.disciplined_time) AS UserReviewDisciplinedTime,
    TRIM(ur.status) AS UserReviewStatus,
    TRIM(ur.last_change_time) AS UserReviewLastChangeTime,
    TRIM(ur.last_change_user) AS UserReviewLastChangeUser,
    NULL AS SourceCreatedDate,
    ur.last_change_time AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
FROM 
    gds_grdm_raw.v_kics_user_review_v1 ur
LEFT JOIN 
    gds_grdm_int.User u 
    ON LOWER(TRIM(u.UserNumber)) = LOWER(TRIM(ur.tracking_system_user_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON LOWER(TRIM(cr.ComplianceRegionNumber)) = LOWER(TRIM(ur.current_assigned_compliance_region_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr2 
    ON LOWER(TRIM(cr2.ComplianceRegionNumber)) = LOWER(TRIM(ur.current_secondary_compliance_region_id))
LEFT JOIN 
    gds_grdm_int.EscalationLevel el 
    ON LOWER(TRIM(el.EscalationLevelNumber)) = LOWER(TRIM(ur.escalation_level_id))
LEFT JOIN 
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE 
    ur.gds_batch_id = wid_GDSBatchID