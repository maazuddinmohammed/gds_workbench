SELECT 
    coalesce(TRIM(lc.list_code_id), 'N/A') as MutualFundDisposalNumber,
    coalesce(TRIM(lc.short_name), 'N/A') as MutualFundDisposalName,
    coalesce(mfd.MutualFundDisposalBusinessName, TRIM(lc.short_name)) as MutualFundDisposalBusinessName,
    TRIM(lc.description) as MutualFundDisposalDescription,
    coalesce(cr.ComplianceRegionID, -1) as ComplianceRegionID,
	lc.start_effective_date AS	MutualFundDisposalEffectiveStartDate,
	lc.end_effective_date AS MutualFundDisposalEffectiveEndDate,
	lc.identifier AS MutualFundDisposalIdentifier,
	lc.parent_list_code_id AS ParentMutualFundDisposalListCodeNumber,
	lc.associated_security_type AS	MutualFundDisposalAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS MutualFundDisposalIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	MutualFundDisposalSICCode,
	lc.show_acknowledgement_checkbox AS	MutualFundDisposalShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS MutualFundDisposalRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS MutualFundDisposalFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	MutualFundDisposalIsAccountTypeEligibleForBrokerageImport,    
    NULL as SourceCreatedDate,
    lc.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(ms.SourceSystemID, -1) as SourceSystemID
FROM
    gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN
    gds_grdm_int.MutualFundDisposal mfd 
    ON TRIM(LOWER(lc.list_code_id)) = TRIM(LOWER(mfd.MutualFundDisposalNumber))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr 
    ON TRIM(LOWER(lc.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
LEFT JOIN
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE
    lc.gds_batch_id =wid_GDSBatchID
 AND lc.list_code_type = 'Mutual Fund Disposed'