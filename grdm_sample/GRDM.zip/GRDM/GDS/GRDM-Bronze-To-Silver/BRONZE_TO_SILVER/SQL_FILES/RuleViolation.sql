SELECT 
  TRIM(lc.list_code_id) AS RuleViolationNumber,
  TRIM(lc.short_name) AS RuleViolationName,
  COALESCE(rv.RuleViolationBusinessName, lc.short_name) AS RuleViolationBusinessName,
  TRIM(lc.description) AS RuleViolationDescription,
  cr.ComplianceRegionID AS ComplianceRegionID,
	lc.start_effective_date AS	RuleViolationEffectiveStartDate,
	lc.end_effective_date AS RuleViolationEffectiveEndDate,
	lc.identifier AS RuleViolationIdentifier,
	lc.parent_list_code_id AS ParentRuleViolationListCodeNumber,
	lc.associated_security_type AS	RuleViolationAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS RuleViolationIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	RuleViolationSICCode,
	lc.show_acknowledgement_checkbox AS	RuleViolationShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS RuleViolationRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS RuleViolationFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	RuleViolationIsAccountTypeEligibleForBrokerageImport,  
  NULL AS SourceCreatedDate,
  lc.last_change_time AS SourceUpdatedDate,
  NULL AS SourceCreatedBy,
  NULL AS SourceUpdatedBy,
  ms.SourceSystemID AS SourceSystemID
FROM 
  gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
  gds_grdm_int.RuleViolation rv 
  ON TRIM(LOWER(lc.list_code_id)) = TRIM(LOWER(rv.RuleViolationNumber))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON TRIM(LOWER(lc.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
WHERE 
  lc.gds_batch_id = wid_GDSBatchID
  AND lc.list_code_type = 'Violation Nature'