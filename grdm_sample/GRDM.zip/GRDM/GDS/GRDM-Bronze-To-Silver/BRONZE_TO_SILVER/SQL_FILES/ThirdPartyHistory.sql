SELECT 
    TRIM(tp.third_party_history_id) as ThirdPartyHistoryNumber,
    TRIM(tp.user_history_id) as ThirdPartyUserHistoryNumber,
    TRIM(u.userID) AS UserID,
    tp.status_action AS ThirdPartyStatusAction,
    t.ThirdPartyID AS ThirdPartyID,
    tp.user_id AS ThirdPartyUserNumber,
    tp.user_email AS ThirdPartyUserEmail,
    tp.created_time AS ThirdPartyCreatedTime,
    rref.languageID AS ThirdPartyUserLanguageID,
    tpu.ThirdPartyUserID  AS ThirdPartyUserID,   
    tp.user_first_name    AS ThirdPartyUserFirstName,
    tp.user_last_name     AS ThirdPartyUserLastName,
    tp.third_party_user_language_id AS ThirdPartyUserStatus,
    tp.user_creation_time  AS ThirdPartyUserCreationTime,
    tp.agreement_acknowledgement_time AS ThirdPartyAgreementAcknowledgementTime,
    tp.user_modification_time AS ThirdPartyUserModificationTime,
    tp.user_removal_time AS ThirdPartyUserRemovalTime,
    cr1.ComplianceRegionID AS CurrentAssignedComplianceRegionID,
    cr2.ComplianceRegionID AS CurrentSecondaryComplianceRegionID,
    tp.last_change_time AS ThirdPartyLastChangeTime,
    tp.last_change_user AS ThirdPartyLastChangeUser,
    tp.identity_provider_status AS IdentityProviderStatus,
    tp.identity_provider_status_code AS IdentityProviderStatusCode,
    tp.identity_provider_user_id AS IdentityProviderUserID,
    tp.created_time AS SourceCreatedDate,
    tp.last_change_time  AS SourceUpdatedDate,
    tp.last_change_user AS SourceCreatedBy,     
    tp.last_change_user AS SourceUpdatedBy,  
    ms.SourceSystemID as SourceSystemID
FROM
    gds_grdm_raw.kics_third_party_history tp
LEFT JOIN gds_grdm_int.ThirdParty t
       ON TRIM(LOWER(tp.third_party_id)) = TRIM(LOWER(t.ThirdPartyNumber))
LEFT JOIN gds_grdm_int.User u
       ON TRIM(LOWER(tp.tracking_system_user_id)) = TRIM(LOWER(u.UserNumber))
LEFT JOIN gds_grdm_raw.kics_language_v1 rl 
       ON TRIM(LOWER(tp.third_party_user_language_id)) = TRIM(LOWER(rl.language_id)) AND TRIM(LOWER(tp.gds_batch_id)) = TRIM(LOWER(rl.gds_batch_id))
LEFT JOIN gds_ref_int.language rref
       ON TRIM(LOWER(rl.identifier)) = TRIM(LOWER(rref.languageISO1))
      AND TRIM(LOWER(rl.identifier2)) = TRIM(LOWER(rref.languageISO2))   
LEFT JOIN gds_grdm_int.ThirdPartyUser tpu
       ON TRIM(LOWER(tp.third_party_list_code_id)) = TRIM(LOWER(tpu.ThirdPartyUserNumber))
LEFT JOIN gds_grdm_int.ComplianceRegion cr1
       ON TRIM(LOWER(tp.current_assigned_compliance_region_id))  = TRIM(LOWER(cr1.ComplianceRegionNumber))
LEFT JOIN gds_grdm_int.ComplianceRegion cr2
       ON TRIM(LOWER(tp.current_secondary_compliance_region_id)) = TRIM(LOWER(cr2.ComplianceRegionNumber))
LEFT JOIN
    meta.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE
    tp.gds_batch_id = wid_GDSBatchID