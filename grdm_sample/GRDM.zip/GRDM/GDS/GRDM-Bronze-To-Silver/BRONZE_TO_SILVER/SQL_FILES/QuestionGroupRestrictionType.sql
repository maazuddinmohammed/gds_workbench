SELECT    
    qg.QuestionGroupID AS QuestionGroupID
    ,rt.RestrictionTypeID AS RestrictionTypeID
    ,NULL AS SourceCreatedDate
    ,NULL AS SourceUpdatedDate
    ,NULL AS SourceCreatedBy
    ,NULL AS SourceUpdatedBy
    ,ms.SourceSystemID AS SourceSystemID
  FROM 
    gds_grdm_raw.kics_question_group_v1 q
  LEFT JOIN 
    gds_grdm_int.QuestionGroup qg 
    ON TRIM(LOWER(qg.QuestionGroupNumber)) = TRIM(LOWER(q.question_group_id))
  LEFT JOIN 
    gds_grdm_int.RestrictionType rt 
    ON TRIM(LOWER(rt.RestrictionTypeNumber)) = TRIM(LOWER(q.restriction_type))
  LEFT JOIN 
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
  WHERE     q.gds_batch_id = wid_GDSBatchID