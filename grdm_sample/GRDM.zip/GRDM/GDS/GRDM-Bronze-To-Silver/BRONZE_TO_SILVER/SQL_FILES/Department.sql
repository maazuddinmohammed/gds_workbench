SELECT 
    trim(b.department_code) as DepartmentNumber,
    trim(b.department_name) as DepartmentName,
    coalesce(trim(d.DepartmentBusinessName), trim(b.department_name)) as DepartmentBusinessName,
    trim(b.department_name) as DepartmentDescription,
    NULL as SourceCreatedDate,
    NULL as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(m.SourceSystemID, -1) as SourceSystemID
FROM 
    gds_grdm_raw.kics_user_info_v1 b
LEFT JOIN 
    gds_grdm_int.department d 
    ON trim(lower(b.department_code)) = trim(lower(d.DepartmentNumber))
LEFT JOIN 
    gds.MetaSourceSystem m 
    ON m.SourceSystemName = 'KICS'
WHERE 
    b.gds_batch_id = wid_GDSBatchID