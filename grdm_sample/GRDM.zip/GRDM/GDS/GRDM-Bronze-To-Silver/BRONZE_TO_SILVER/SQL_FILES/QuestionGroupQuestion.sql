 SELECT 
  TRIM(a.question_id) as QuestionGroupQuestionNumber,
  TRIM(qs.QuestionSetID) as QuestionSetID, 
  TRIM(a.question_number) as QuestionGroupQuestionOrder,
  TRIM(a.question_set_type) as QuestionGroupQuestionType,
  TRIM(a.question_status) as QuestionGroupQuestionStatus,
  cr2.ComplianceRegionID as QuestionSetComplianceRegionID,
  u3.UserID as QuestionSetProductionUserID,
  u4.UserID as QuestionSetArchiveUserID,
  cr1.ComplianceRegionID as SystemQueryComplianceRegionID,
  u1.UserID as SystemQueryProductionUserID,
  u2.UserID as SystemQueryArchiveUserID,
  l.LanguageID,
  TRIM(a.is_comment_required_in_question_set) as IsDefault, 
  current_timestamp as SourceCreatedDate, 
  a.last_change_time as SourceUpdatedDate, 
  NULL as SourceCreatedBy, 
  NULL as SourceUpdatedBy, 
  s.SourceSystemID as SourceSystemID
FROM gds_grdm_raw.kics_question_group_question_v1 a
LEFT JOIN gds_grdm_int.QuestionSet qs ON 
  LOWER(TRIM(qs.QuestionSetNumber)) = LOWER(TRIM(a.question_set_id))
LEFT JOIN gds.MetaSourceSystem s ON 
  s.SourceSystemName = 'KICS'
LEFT JOIN gds_grdm_int.ComplianceRegion cr1 ON
  LOWER(TRIM(cr1.ComplianceRegionNumber)) = LOWER(TRIM(a.system_query_compliance_region_id))
LEFT JOIN gds_grdm_int.ComplianceRegion cr2 ON
  LOWER(TRIM(cr2.ComplianceRegionNumber)) = LOWER(TRIM(a.question_set_compliance_region_id))
LEFT JOIN gds_grdm_int.User u1 ON
  LOWER(TRIM(u1.UserNumber)) = LOWER(TRIM(a.system_query_move_to_production_user_id))
LEFT JOIN gds_grdm_int.User u2 ON
  LOWER(TRIM(u2.UserNumber)) = LOWER(TRIM(a.system_query_move_to_archive_user_id))
LEFT JOIN gds_grdm_int.User u3 ON
  LOWER(TRIM(u3.UserNumber)) = LOWER(TRIM(a.question_set_move_to_production_user_id))
LEFT JOIN gds_grdm_int.User u4 ON
  LOWER(TRIM(u4.UserNumber)) = LOWER(TRIM(a.question_set_move_to_archive_user_id))
LEFT JOIN gds_grdm_raw.kics_language_v1 lan ON
  LOWER(TRIM(lan.language_id)) = LOWER(TRIM(a.question_set_language_id))  AND lan.gds_batch_id =a.gds_batch_id
LEFT JOIN gds_ref_int.Language l ON
  LOWER(TRIM(l.LanguageISO1)) = LOWER(TRIM(lan.identifier))
WHERE
  a.gds_batch_id = wid_GDSBatchID