SELECT 
    coalesce(TRIM(lc.list_code_id), 'N/A') as MutualFundFamilyNumber,
    coalesce(TRIM(lc.short_name), 'N/A') as MutualFundFamilyName,
    coalesce(mff.MutualFundFamilyBusinessName, TRIM(lc.short_name)) as MutualFundFamilyBusinessName,
    TRIM(lc.description) as MutualFundFamilyDescription,
    coalesce(cr.ComplianceRegionID, -1) as ComplianceRegionID,
	lc.start_effective_date AS	MutualFundFamilyEffectiveStartDate,
	lc.end_effective_date AS MutualFundFamilyEffectiveEndDate,
	lc.identifier AS MutualFundFamilyIdentifier,
	lc.parent_list_code_id AS ParentMutualFundFamilyListCodeNumber,
	lc.associated_security_type AS	MutualFundFamilyAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS MutualFundFamilyIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	MutualFundFamilySICCode,
	lc.show_acknowledgement_checkbox AS	MutualFundFamilyShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS MutualFundFamilyRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS MutualFundFamilyFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	MutualFundFamilyIsAccountTypeEligibleForBrokerageImport,    
    NULL as SourceCreatedDate,
    lc.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(ms.SourceSystemID, -1) as SourceSystemID
FROM
    gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN
    gds_grdm_int.MutualFundFamily mff 
    ON TRIM(LOWER(lc.list_code_id)) = TRIM(LOWER(mff.MutualFundFamilyNumber))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr 
    ON TRIM(LOWER(lc.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
LEFT JOIN
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE
    lc.gds_batch_id = wid_GDSBatchID
AND lc.list_code_type = 'Mutual Fund Family'
 