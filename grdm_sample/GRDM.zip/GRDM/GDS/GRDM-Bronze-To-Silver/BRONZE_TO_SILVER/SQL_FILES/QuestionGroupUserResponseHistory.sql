SELECT 
    qgurh.last_change_time as QuestionGroupUserResponseHistoryTime,
    qgur.QuestionGroupUserResponseID as QuestionGroupUserResponseID,
    TRIM(qgurh.user_answer_id) as QuestionGroupUserResponseNumber,
    TRIM(qgurh.answer_choice_and_decision_tree_id) as QuestionGroupAnswerTreeID,
    cr1.ComplianceRegionID as PrimaryComplianceRegionID,
    cr2.ComplianceRegionID as SecondaryComplianceRegionID,
    u.UserID as UserID,
    q2.QuestionID as UserQuestionID,
    q1.QuestionID as QuestionID,
    q3.QuestionID as NextQuestionID,
    h.HoldingID as HoldingID,
    qs.QuestionSetID as QuestionSetID,
    trim(qgurh.user_question_set_case_id) as QuestionSetCaseID,
    TRIM(qgurh.user_supplemental_data_question_set_case_id) AS SupplementalQuestionSetID,
    TRIM(qgurh.question_group_submission_id) AS QuestionGroupSubmissionID,
    cm.ConflictMessageID,
    TRIM(qgurh.user_answer_text) as QuestionGroupUserResponseAnswerText,
    qgurh.review_time as QuestionGroupUserResponseReviewTime,
    TRIM(qgurh.reviewer_comment_on_user_answer) as QuestionGroupUserResponseAnswerReviewerComment,
    TRIM(qgurh.self_clear_attempt_count) as QuestionGroupUserResponseSelfClearAttemptCount,
    TRIM(qgurh.question_set_question_type) as QuestionGroupUserResponseQuestionType,
    TRIM(qgurh.user_question_status) AS QuestionGroupUserResponseQuestionStatus,
    TRIM(qgurh.user_answer_status) as QuestionGroupUserResponseAnswerStatus,
    TRIM(qgurh.submission_status) as QuestionGroupUserResponseSubmissionStatus,
    TRIM(qgurh.response_type) as QuestionGroupUserResponseType,
    TRIM(qgurh.first_user_question_in_question_set) AS QuestionGroupUserResponseFirstQuestionInQuestionSet,
    TRIM(qgurh.is_question_set_skipped) as IsQuestionSetSkipped,
    NULL as SourceCreatedDate,
    qgurh.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    TRIM(qgurh.last_change_user) as SourceUpdatedBy,
    sys.SourceSystemID as SourceSystemID
FROM
    gds_grdm_raw.v_kics_question_group_user_response_history_v1 qgurh
LEFT JOIN
    gds_grdm_int.QuestionGroupUserResponse qgur ON qgur.QuestionGroupUserResponseNumber = qgurh.user_answer_id
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr1 ON LOWER(TRIM(cr1.ComplianceRegionNumber)) = LOWER(TRIM(qgurh.current_assigned_compliance_region_id))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr2 ON LOWER(TRIM(cr2.ComplianceRegionNumber)) = LOWER(TRIM(qgurh.current_secondary_compliance_region_id))
LEFT JOIN
    gds_grdm_int.User u ON LOWER(TRIM(u.UserNumber)) = LOWER(TRIM(qgurh.tracking_system_user_id))
LEFT JOIN
    gds_grdm_int.Question q1 ON LOWER(TRIM(q1.QuestionNumber)) = LOWER(TRIM(qgurh.question_id))
LEFT JOIN
    gds_grdm_int.Question q2 ON LOWER(TRIM(q2.QuestionNumber)) = LOWER(TRIM(qgurh.user_question_id))
LEFT JOIN
    gds_grdm_int.Question q3 ON LOWER(TRIM(q3.QuestionNumber)) = LOWER(TRIM(qgurh.next_user_question_id))
LEFT JOIN 
  gds_grdm_int.QuestionSet qs 
  ON LOWER(TRIM(qs.QuestionSetNumber)) = LOWER(TRIM(qgurh.question_set_id))
LEFT JOIN
    gds_grdm_int.Holding h ON LOWER(TRIM(h.HoldingNumber)) = LOWER(TRIM(qgurh.holding_case_id))
LEFT JOIN 
  gds_grdm_int.ConflictMessage cm 
  ON LOWER(TRIM(cm.ConflictMessageNumber)) = LOWER(TRIM(qgurh.question_group_submission_case_id))  
LEFT JOIN
    gds.MetaSourceSystem sys ON sys.SourceSystemName = 'KICS'
WHERE
    qgurh.gds_batch_id = wid_GDSBatchID