SELECT 
  se.Entity_ID as EntityID,
  pt.PhoneTypeID as PhoneTypeID,
  trim(se.Phone) as EntityPhoneNumber,
  NULL as SourceCreatedDate,
  NULL as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  ms.SourceSystemID as SourceSystemID
FROM 
 (SELECT DISTINCT Entity_ID,Phone,gds_batch_id FROM gds_grdm_raw.sntl_x_entity
 WHERE Phone IS NOT NULL) se
  LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'SENTINEL'
LEFT JOIN 
  gds_ref_int.Entity e 
  ON LOWER(TRIM(se.entity_id)) = LOWER(TRIM(e.EntityNumber))  AND e.SourceSystemID = ms.SourceSystemID
LEFT JOIN 
  gds_ref_int.PhoneType pt On pt.PhoneTypeName='Work'
WHERE 
  se.gds_batch_id = wid_GDSBatchID
  AND se.Phone IS NOT NULL