SELECT 
  TRIM(up.profile_id) as UserProfileNumber,
  u.UserID as UserID,
  TRIM(up.first_name) as UserProfileFirstName,
  TRIM(up.last_name) as UserProfileMiddleName,
  TRIM(up.middle_name) as UserProfileLastName,
  up.ssn as UserProfileSSN,
  cr.ComplianceRegionID as PrimaryComplianceRegionID,
  cr2.ComplianceRegionID as SecondaryComplianceRegionID,
  upt.UserProfileTypeID as UserProfileTypeID,
  st.StatusID as UserProfileStatusID,
  NULL as SourceCreatedDate,
  TRIM(CAST(up.last_change_time AS DATE)) as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  TRIM(up.last_change_user) as SourceUpdatedBy,
  ms.SourceSystemID as SourceSystemID
FROM 
  gds_grdm_raw.v_kics_profile_v1 up
LEFT JOIN 
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'    
LEFT JOIN 
  gds_grdm_int.User u 
  ON LOWER(TRIM(u.UserNumber)) = LOWER(TRIM(up.tracking_system_user_id))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON LOWER(TRIM(cr.ComplianceRegionNumber)) = LOWER(TRIM(up.current_assigned_compliance_region_id))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr2 
  ON LOWER(TRIM(cr2.ComplianceRegionNumber)) = LOWER(TRIM(up.current_secondary_compliance_region_id))
LEFT JOIN 
  gds_grdm_int.UserProfileType upt 
  ON LOWER(TRIM(upt.UserProfileTypeNumber)) = LOWER(TRIM(up.profile_type))
LEFT JOIN 
  gds_ref_int.Status st 
  ON LOWER(TRIM(st.StatusName)) = LOWER(TRIM(up.profile_status))
WHERE 
  up.gds_batch_id = wid_GDSBatchID