SELECT  * 
FROM (
SELECT

     TRIM(ks.security_type) as securityTypeNumber,
     TRIM(ks.security_type) as securityTypeName,
    coalesce(st.securityTypeBusinessName,TRIM(ks.security_type)) as securityTypeBusinessName,
     TRIM(ks.security_type) as securityTypeDescription,
     NULL as SourceCreatedDate,
     NULL as SourceUpdatedDate,
     NULL as SourceCreatedBy,
     NULL as SourceUpdatedBy,
     s.SourceSystemID as SourceSystemID
FROM
 (SELECT DISTINCT security_type,gds_batch_id FROM gds_grdm_raw.kics_security_v1 WHERE security_type IS NOT NULL) ks
LEFT JOIN
  gds.MetaSourceSystem s ON s.SourceSystemName = 'KICS'
LEFT JOIN
 gds_grdm_int.securityType st ON TRIM(LOWER(st.securityTypeNumber)) = TRIM(LOWER(ks.security_type))

WHERE 
  ks.gds_batch_id = wid_GDSBatchID
)