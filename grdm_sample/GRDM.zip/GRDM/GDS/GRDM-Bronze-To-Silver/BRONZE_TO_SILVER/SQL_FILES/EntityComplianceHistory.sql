SELECT
    CAST(TRIM(eh.last_change_time) AS TIMESTAMP) AS EntityComplianceHistoryTime,
    TRIM(eh.entity_id) as EntityComplianceNumber,
    enc.EntityComplianceID AS EntityComplianceID,
    TRIM(eh.entity_id) AS EntityID,
    TRIM(eh.external_identifier) AS EntityComplianceExternalID,
    TRIM(eh.client_number) AS EntityComplianceClientNumber,
    cr.ComplianceRegionID AS ComplianceRegionID,
    TRIM(eh.primary_alias_text) AS EntityCompliancePrimaryAlias,
    ecc.EntityComplianceCategoryID AS EntityComplianceCategoryID,
    ecs.EntityComplianceStatusID AS EntityComplianceStatusID,
    TRIM(eh.quick_search_list_type) AS EntityComplianceQuickSearchListType,
    TRIM(eh.isin) AS EntityComplianceISIN,
    TRIM(eh.naics) AS EntityComplianceNAICS,
    TRIM(eh.sec_registrant_comment) AS EntityComplianceComment,
    TRIM(eh.gmfid) AS EntityComplianceGMFID,
    TRIM(eh.brokerage_import_state) AS EntityComplianceBrokerageImportState,
    TRIM(eh.central_index_key) AS EntityComplianceCentralIndexKey,
    TRIM(eh.sedol) AS EntityComplianceSEDOL,
    TRIM(eh.rssd) AS EntityComplianceRSSD,
    CAST(TRIM(eh.last_bdi_mapping_update_date) AS TIMESTAMP) AS EntityComplianceLastBDIMappingDate,
    TRIM(eh.sec_registrant_comment) AS EntityComplianceSECRegistrantComment,
    TRIM(eh.add_type) AS EntityComplianceAddType,
    CAST(TRIM(eh.inactivated_date) AS TIMESTAMP) AS EntityComplianceInactivatedTime,
    TRIM(eh.sic_array) AS EntityComplianceSICArray,
    TRIM(eh.icusip_array) AS EntityComplianceICUSIPArray,
    TRIM(eh.nmls_array) AS EntityComplianceNMLSArray,
    TRIM(eh.refinitiv_identifier_array) AS EntityComplianceRefinitiveIDArray,
    TRIM(eh.alias_value_array) AS EntityComplianceAliasArray,
    TRIM(eh.child_entity_security_name_array) AS EntityComplianceChildSecurityNameArray,
    TRIM(eh.child_entity_security_type_array) AS EntityComplianceChildSecurityTypeArray,
    TRIM(eh.relationship_type_array) AS EntityComplianceRelationshipTypeArray,
    TRIM(eh.is_in_watchlist) AS OnWatchList,
    TRIM(eh.is_issuer_529_plan) AS On529Plan,
    TRIM(eh.is_mapping_program_allowed_to_update) AS CanMappingProgramUpdate,
    TRIM(eh.is_sec_registrant) AS IsSECRegistrant,
    TRIM(eh.covered_person_indicator) AS IsCoveredPerson,
    TRIM(eh.is_clearing_broker) AS IsClearingBroker,
    TRIM(eh.is_controlled_by_ems) AS IsEMSControlled,
    TRIM(eh.is_restriction_flow_down_array) AS IsRestrictionFlowDown,
    NULL AS SourceCreatedDate,
    eh.last_change_time AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
  FROM gds_grdm_raw.v_kics_entity_history_v1 eh
  LEFT JOIN gds_ref_int.Entity en
    ON TRIM(LOWER(eh.entity_id)) = TRIM(LOWER(en.EntityNumber))
  LEFT JOIN gds_grdm_int.EntityCompliance enc
    ON TRIM(LOWER(en.EntityID)) = TRIM(LOWER(enc.EntityID))
  LEFT JOIN gds_grdm_int.ComplianceRegion cr
    ON TRIM(LOWER(eh.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
  LEFT JOIN gds_grdm_int.EntityComplianceCategory ecc
    ON TRIM(LOWER(eh.category)) = TRIM(LOWER(ecc.EntityComplianceCategoryNumber))
  LEFT JOIN gds_grdm_int.EntityComplianceStatus ecs
    ON TRIM(LOWER(eh.status)) = TRIM(LOWER(ecs.EntityComplianceStatusNumber))
  LEFT JOIN gds.MetaSourceSystem ms
    ON ms.SourceSystemName = 'KICS'
  WHERE eh.gds_batch_id = wid_GDSBatchID

