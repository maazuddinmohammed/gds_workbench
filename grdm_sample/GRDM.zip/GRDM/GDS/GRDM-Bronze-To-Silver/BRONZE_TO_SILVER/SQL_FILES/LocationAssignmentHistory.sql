SELECT 
    leah.last_change_time as LocationAssignmentHistoryTime,
    las.LocationAssignmentID as LocationAssignmentID,
    TRIM(leah.location_engagement_assignment_case_id) as LocationAssignmentNumber,
    s.SecurityID as SecurityID,
    ec.EntityComplianceID,
    l.LocationID as LocationID,
    TRIM(leah.assignment_status) as LocationAssignmentStatus,
    TRIM(leah.entity_security_type) as LocationAssignmentEntitySecurityType,
    TRIM(leah.engagement_location_type) as EngagementLocationType,
    TRIM(leah.engagement_comments) as LocationAssignmentComment,
    NULL as SourceCreatedDate,
    leah.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(ms.SourceSystemID, -1) as SourceSystemID
FROM
    gds_grdm_raw.v_kics_location_engagement_assignment_history_v1 leah
LEFT JOIN
    gds.MetaSourceSystem ms
    ON ms.SourceSystemName = 'KICS'    
LEFT JOIN 
    gds_ref_int.Entity e ON LOWER(TRIM(e.EntityNumber)) = LOWER(TRIM(leah.entity_security_id)) AND e.SourceSystemID = ms.SourceSystemID
LEFT JOIN 
    gds_grdm_int.EntityCompliance ec ON e.EntityID = ec.EntityID
LEFT JOIN
    gds_grdm_int.LocationAssignment las
    ON LOWER(TRIM(leah.location_engagement_assignment_case_id)) = LOWER(TRIM(las.LocationAssignmentNumber)) 
    AND las.SourceSystemID = ms.SourceSystemID
LEFT JOIN
    gds_grdm_int.Security s
    ON LOWER(TRIM(leah.entity_security_id)) = LOWER(TRIM(s.SecurityNumber))
LEFT JOIN
    gds_grdm_int.Location l
    ON LOWER(TRIM(leah.location_id)) = LOWER(TRIM(l.LocationNumber))
WHERE
    leah.gds_batch_id = wid_GDSBatchID