SELECT 
  TRIM(q.question_id) as QuestionNumber,
  TRIM(q.question_number) as QuestionNumberOrder,
  qs.QuestionSetID,
  qs.ComplianceRegionID as ComplianceRegionID,
  TRIM(q.question_set_identifier) AS QuestionSetIdentifier,
  TRIM(q.question_set_text) as QuestionSetText,
  TRIM(q.question_text) as QuestionText,
  TRIM(q.system_query_identifier) AS QuestionSystemQueryIdentifier,
  TRIM(q.system_query_source_category) AS QuestionSystemQuerySourceCategory,
  q.question_set_move_to_production_time as QuestionSetProductionTime,
  q.question_set_move_to_archive_time as QuestionSetArchiveTime,
  TRIM(q.system_query_action) as  QuestionSystemQueryAction,
  TRIM(q.system_query_target_field) as QuestionSystemQueryTargetField,
  TRIM(q.system_query_compared_value) as QuestionSystemQueryComparedValue,
  TRIM(q.question_set_status) as QuestionSetStatus,
  q.system_query_move_to_production_time as QuestionSystemQueryProductionTime,
  q.system_query_move_to_archive_time as QuestionSystemQueryArchiveTime,
  TRIM(q.question_set_modification_number) as QuestionSetModificationNumber,
  TRIM(q.system_query_status) as QuestionSystemQueryStatus,
  TRIM(q.system_query_name) as QuestionSystemQueryName,
  TRIM(q.system_query_source_field) as QuestionSystemQuerySourceField,
  TRIM(q.system_query_condition) as QuestionSystemQueryCondition,
  TRIM(q.system_query_description) as QuestionSystemQueryDescription,
  NULL as SourceCreatedDate,
  TRIM(CAST(q.last_change_time AS DATE)) as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  coalesce(ms.SourceSystemID, -1) as SourceSystemID
FROM 
  gds_grdm_raw.kics_question_group_question_v1 q
LEFT JOIN 
  gds_grdm_int.questionset qs 
  ON LOWER(TRIM(qs.QuestionSetNumber)) = LOWER(TRIM(q.question_set_id))
LEFT JOIN
    gds.MetaSourceSystem ms
    ON ms.SourceSystemName = 'KICS'  
WHERE 
  q.gds_batch_id = wid_GDSBatchID