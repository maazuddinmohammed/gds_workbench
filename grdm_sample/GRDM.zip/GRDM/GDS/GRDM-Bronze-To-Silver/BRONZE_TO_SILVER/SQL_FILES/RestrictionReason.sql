SELECT 
    coalesce(TRIM(lc.list_code_id), 'N/A') as RestrictionReasonNumber,
    coalesce(TRIM(lc.short_name), 'N/A') as RestrictionReasonName,
    coalesce(rr.RestrictionReasonBusinessName, TRIM(lc.short_name)) as RestrictionReasonBusinessName,
    TRIM(lc.description) as RestrictionReasonDescription,
    coalesce(cr.ComplianceRegionID, -1) as ComplianceRegionID,
	lc.start_effective_date AS	RestrictionReasonEffectiveStartDate,
	lc.end_effective_date AS RestrictionReasonEffectiveEndDate,
	lc.identifier AS RestrictionReasonIdentifier,
	lc.parent_list_code_id AS ParentRestrictionReasonListCodeNumber,
	lc.associated_security_type AS	RestrictionReasonAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS RestrictionReasonIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	RestrictionReasonSICCode,
	lc.show_acknowledgement_checkbox AS	RestrictionReasonShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS RestrictionReasonRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS RestrictionReasonFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	RestrictionReasonIsAccountTypeEligibleForBrokerageImport,    
    NULL as SourceCreatedDate,
    lc.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(ms.SourceSystemID, -1) as SourceSystemID
FROM
    gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN
    gds_grdm_int.RestrictionReason rr 
    ON TRIM(LOWER(lc.list_code_id)) = TRIM(LOWER(rr.RestrictionReasonNumber))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr 
    ON TRIM(LOWER(lc.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
LEFT JOIN
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE
    lc.gds_batch_id = wid_GDSBatchID
    AND lc.list_code_type = 'Restriction Reason'