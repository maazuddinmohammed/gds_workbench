SELECT 
    TRIM(tuae.user_added_entity_id) AS UserEntityComplianceTransferNumber,
    uec.UserEntityComplianceID AS EntityComplianceID,
    s.SecurityID AS SecurityID,
    se.SecurityExchangeID AS SecurityExchangeID,
    cr1.ComplianceRegionID AS ComplianceRegionID,
    cr2.ComplianceRegionID AS ReviewerComplianceRegionID,
    coalesce(fit.FinancialInterestTypeID,fitp.FinancialInterestTypeID) AS FinancialInterestTypeID,
    fist.FinancialInterestSubTypeID AS FinancialInterestSubTypeID,
    at.AccountTypeID AS AccountTypeID,
    b.BrokerageID AS BrokerageID,
    TRIM(tuae.user_added_entity_type) AS UserEntityComplianceTransferType,
    tuae.description AS UserEntityComplianceTransferDescription,
    tuae.status AS UserEntityComplianceTransferStatus,
    TRIM(tuae.status_comments) AS UserEntityComplianceTransferStatusComment,
    TRIM(tuae.status_comments) AS UserEntityComplianceTransfer,  ---> omments
    TRIM(tuae.isin) AS UserEntityComplianceTransferISIN,
    TRIM(tuae.sedol) AS UserEntityComplianceTransferISEDOL,
    tuae.replacement_action_acquisition_date AS UserEntityComplianceTransferReplacementAcquisitionDate,
    TRIM(tuae.replacement_action_acquisition_date_option) AS UserEntityComplianceTransferReplacementAcquisitionDateOption,
    TRIM(tuae.street) AS UserEntityComplianceTransferAddress,
    TRIM(tuae.city) AS UserEntityComplianceTransferCity,
    TRIM(tuae.state_province) AS UserEntityComplianceTransferState,
    TRIM(tuae.postal) AS UserEntityComplianceTransferPostalCode,
    c.CountryID AS CountryID,
    tuae.action_time AS UserEntityComplianceTransferActionTime,
    tuae.added_time AS SourceCreatedDate,
    tuae.last_change_time AS SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
FROM 
    gds_grdm_raw.kics_transferred_user_added_entity_v1 tuae
LEFT JOIN 
    gds_grdm_int.UserEntityCompliance uec 
    ON LOWER(TRIM(uec.UserEntityComplianceNumber)) = LOWER(TRIM(tuae.associated_entity_security_id))
LEFT JOIN 
    gds_grdm_int.Security s 
    ON LOWER(TRIM(s.SecurityNumber)) = LOWER(TRIM(tuae.associated_entity_security_id))
LEFT JOIN 
    gds_grdm_int.SecurityExchange se 
    ON LOWER(TRIM(se.SecurityExchangeNumber)) = LOWER(TRIM(tuae.exchange_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr1 
    ON LOWER(TRIM(cr1.ComplianceRegionNumber)) = LOWER(TRIM(tuae.compliance_region_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr2 
    ON LOWER(TRIM(cr2.ComplianceRegionNumber)) = LOWER(TRIM(tuae.reviewer_compliance_region_id))
LEFT JOIN 
    gds_grdm_int.FinancialInterestSubType fist 
    ON LOWER(TRIM(fist.FinancialInterestSubTypeNumber)) = LOWER(TRIM(tuae.financial_interest_sub_type_id))
LEFT JOIN  
    gds_grdm_int.FinancialInterestType fit 
    ON LOWER(TRIM(fit.FinancialInterestTypeNumber)) = LOWER(TRIM(fist.ParentFinancialInterestSubTypeListCodeNumber))  
LEFT JOIN 
    gds_grdm_int.FinancialInterestType fitp 
    ON TRIM(LOWER(fitp.FinancialInterestTypeNumber)) = TRIM(LOWER(tuae.financial_interest_sub_type_id))
LEFT JOIN 
    gds_grdm_int.AccountType at 
    ON LOWER(TRIM(at.AccountTypeNumber)) = LOWER(TRIM(tuae.account_type_id))
LEFT JOIN 
    gds_grdm_int.Brokerage b 
    ON LOWER(TRIM(b.BrokerageNumber)) = LOWER(TRIM(tuae.brokerage_import_entity_id))
LEFT JOIN 
    gds_grdm_int.Country c 
    ON LOWER(TRIM(c.CountryISOCode)) = LOWER(TRIM(tuae.country_id_of_origin))
LEFT JOIN 
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE 
    tuae.gds_batch_id = wid_GDSBatchID