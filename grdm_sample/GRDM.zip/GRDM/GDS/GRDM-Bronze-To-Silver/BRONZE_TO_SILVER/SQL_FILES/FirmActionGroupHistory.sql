SELECT 
  fagh.last_change_time as FirmActionGroupHistoryTime,
  trim(fg.FirmActionGroupID) as FirmActionGroupID,
  trim(fagh.firm_action_group_id) as FirmActionGroupNumber,
  trim(fagh.firm_action_group_state) as FirmActionGroupState,
  trim(fagh.auto_process_to) as FirmActionGroupAutoProcessFinalState,
  trim(fagh.firm_action_group_current_action) as FirmActionGroupCurrentAction,
  trim(fagh.review_comments) as FirmActionGroupReviewerComment,
  cr.ComplianceRegionID as ComplianceRegionID,
  trim(fagh.auto_process) as IsAutoProcess,
  trim(fagh.is_action_group_retroactive) as IsRetroactive,
  NULL as SourceCreatedDate,
  fagh.last_change_time as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  fagh.last_change_user as SourceUpdatedBy,
  ms.SourceSystemID as SourceSystemID
FROM 
    gds_grdm_raw.v_kics_firm_action_group_history_v1 fagh
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON LOWER(TRIM(fagh.compliance_region_id)) = LOWER(TRIM(cr.ComplianceRegionNumber))
LEFT JOIN gds_grdm_int.firmactiongroup fg  
  ON fg.FirmActionGroupNumber = TRIM(fagh.firm_action_group_id)
LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
WHERE 
  fagh.gds_batch_id =  wid_GDSBatchID
