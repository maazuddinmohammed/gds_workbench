SELECT 
    coalesce(qgsh.last_change_time, '1900-01-01') as QuestionGroupSubmissionHistoryTime,
    qgs.QuestionGroupSubmissionID as QuestionGroupSubmissionID,
    coalesce(TRIM(qgsh.question_group_submission_id), 'N/A') as QuestionGroupSubmissionNumber,
    cm.ConflictMessageID as ConflictMessageID,
    cr1.ComplianceRegionID as PrimaryComplianceRegionID,
    cr2.ComplianceRegionID as SecondaryComplianceRegionID,
    h.HoldingID as HoldingID,
    l.LocationID as LocationID,
    u.UserID as UserID,
    up.UserProfileID as UserProfileID,
    sr.SECRoleID as SECRoleID,
    qt.QuestionTypeID as QuestionTypeID,
    wr.WaiverReasonID as WaiverReasonID,
    coalesce(TRIM(qgsh.waiver_case_id), 'N/A') as QuestionGroupSubmissionWaiverCaseID,
    coalesce(TRIM(qgsh.question_group_submission_current_action), 'N/A') as QuestionGroupSubmissionCurrentAction,
    coalesce(TRIM(qgsh.self_clear_attempt_count), 'N/A') as QuestionGroupSubmissionSelfClearAttempts,
    coalesce(TRIM(qgsh.self_clear_review_count), 'N/A') as QuestionGroupSubmissionSelfClearReviews,
    coalesce(TRIM(qgsh.user_self_clear_comments), NULL) as QuestionGroupSubmissionSelfClearComment,
    coalesce(TRIM(qgsh.reviewer_self_clear_comments), NULL) as QuestionGroupSubmissionSelfClearReviewerComment,
    coalesce(TRIM(qgsh.question_group_submission_initial_sent_time), NULL) as QuestionGroupSubmmionInitialSentTime,
    coalesce(TRIM(qgsh.question_group_submission_initial_view_time), NULL) as QuestionGroupSubmissionInitialViewTime,
    coalesce(TRIM(qgsh.question_group_submission_email_sent_time), NULL) as QuestionGroupSubmissionEmailSentTime,
    coalesce(TRIM(qgsh.question_group_submission_reason), NULL) as QuestionGroupSubmissionReason,
    coalesce(TRIM(qgsh.threshold_time_to_allow_holding_to_be_removed_without_self_clear), NULL) as QuestionGroupSubmissionThreshold,
    coalesce(TRIM(qgsh.question_group_submission_lingering_state), NULL) as QuestionGroupSubmissionLingeringState,
    coalesce(TRIM(qgsh.question_group_submission_action_role), NULL) as QuestionGroupSubmissionActionRole,
    coalesce(TRIM(qgsh.reviewer_agree_with_self_clear_success_time), NULL) as QuestionGroupSubmissionAgreedSelfClearSuccessTime,
    coalesce(TRIM(qgsh.self_clear_expiration_email_time), NULL) as QuestionGroupSubmissionSelfClearExpirationEmailTime,
    coalesce(TRIM(qgsh.self_clear_expire_time), NULL) as QuestionGroupSubmissionSelfClearExpirationTime,
    coalesce(TRIM(qgsh.override_self_clear_days), NULL) as QuestionGroupSubmissionOverrideSelfClearDays,
    coalesce(TRIM(qgsh.waiver_expiration_time), NULL) as QuestionGroupSubmissionWaiverExpirationTime,
    coalesce(TRIM(qgsh.waiver_comments), NULL) as QuestionGroupSubmissionWaiverComment,
    coalesce(TRIM(qgsh.waiver_state), NULL) as QuestionGroupSubmissionWaiverState,
    coalesce(TRIM(qgsh.waiver_email_time), NULL) as QuestionGroupSubmissionWaiverEmailTime,
    coalesce(TRIM(qgsh.initial_delivery_question_types),NULL) as QuestionGroupSubmissionInitialDeliveryQuestionTypes,
    coalesce(TRIM(qgsh.waiver_last_change_user_id),NULL) as QuestionGroupSubmissionLastChangeUserID, 
    coalesce(TRIM(qgsh.is_question_group_submission_exempt), NULL) as IsExempt,
    coalesce(TRIM(qgsh.is_self_clear_days_overridden), NULL) as IsSelfClearDaysOverride,
    coalesce(TRIM(qgsh.is_service_center_update), NULL) as IsServiceCenterUpdate,
    CASE   
    WHEN LOWER(TRIM(qgsh.is_restriction_office_matched)) = 'y' THEN 'YES'
    WHEN LOWER(TRIM(qgsh.is_restriction_office_matched)) = 'n' THEN 'NO'
    WHEN LOWER(TRIM(qgsh.is_restriction_office_matched)) = 'u' THEN NULL
    ELSE qgsh.is_restriction_office_matched END as IsRestrictionOfficeMatched,
    CASE 
    WHEN LOWER(TRIM(qgsh.is_restricted_office_match_require_review)) = 'yes' THEN 'YES'
    WHEN LOWER(TRIM(qgsh.is_restricted_office_match_require_review)) = 'no' THEN 'NO'
    ELSE NULL END as IsRestrictedOfficeMatchRequireReview,  ---> Distinct (UNKNOWN ,NO)
    coalesce(TRIM(qgsh.has_related_question_group_submission), NULL) as HasRelatedQuestionGroupSubmission,
    coalesce(TRIM(qgsh.is_question_group_submission_originated_from_confirmed_preclear), NULL) as HasOriginatedFromConfirmedPreClear,
    NULL as SourceCreatedDate,
    TRIM(qgsh.is_question_group_submission_reason_ever_timecharged) AS IsReasonEverTimecharged,
    TRIM(qgsh.is_third_party_user_update) AS IsThirdPartyUserUpdate,
    qgsh.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    qgsh.last_change_user as SourceUpdatedBy,
    s.SourceSystemID as SourceSystemID
FROM
    gds_grdm_raw.v_kics_question_group_submission_history_v1 qgsh
LEFT JOIN
    gds_grdm_int.ConflictMessage cm ON TRIM(LOWER(cm.ConflictMessageNumber)) = TRIM(LOWER(qgsh.question_group_submission_description_id))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr1 ON TRIM(LOWER(cr1.ComplianceRegionNumber)) = TRIM(LOWER(qgsh.current_assigned_compliance_region_id))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr2 ON TRIM(LOWER(cr2.ComplianceRegionNumber)) = TRIM(LOWER(qgsh.current_secondary_compliance_region_id))
LEFT JOIN
    gds_grdm_int.Holding h ON TRIM(LOWER(h.HoldingNumber)) = TRIM(LOWER(qgsh.holding_case_id))
LEFT JOIN
    gds_grdm_int.Location l ON TRIM(LOWER(l.LocationNumber)) = TRIM(LOWER(qgsh.location_id))
LEFT JOIN
    gds_grdm_int.User u ON TRIM(LOWER(u.UserNumber)) = TRIM(LOWER(qgsh.tracking_system_user_id))
LEFT JOIN
    gds_grdm_int.UserProfile up ON TRIM(LOWER(up.UserProfileNumber)) = TRIM(LOWER(qgsh.profile_id))
LEFT JOIN
    gds_grdm_int.SECRole sr ON TRIM(LOWER(sr.SECRoleNumber)) = TRIM(LOWER(qgsh.sec_role))
LEFT JOIN
    gds_grdm_int.QuestionType qt ON TRIM(LOWER(qt.QuestionTypeNumber)) = TRIM(LOWER(qgsh.question_type))
LEFT JOIN
    gds_grdm_int.WaiverReason wr ON TRIM(LOWER(wr.WaiverReasonNumber)) = TRIM(LOWER(qgsh.waiver_reason_id))
LEFT JOIN
    gds_grdm_int.QuestionGroupSubmission qgs ON TRIM(LOWER(qgs.QuestionGroupSubmissionNumber)) = TRIM(LOWER(qgsh.question_group_submission_case_id))
    AND qgs.primarycomplianceregionid = cr1.ComplianceRegionid
LEFT JOIN
    gds.MetaSourceSystem s ON s.SourceSystemName = 'KICS'
WHERE
    qgsh.gds_batch_id = wid_GDSBatchID