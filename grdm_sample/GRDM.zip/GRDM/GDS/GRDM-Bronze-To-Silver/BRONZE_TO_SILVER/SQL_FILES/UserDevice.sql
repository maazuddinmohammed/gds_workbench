SELECT 
    TRIM(ud.user_device_information_id) AS UserDeviceNumber,
    u.UserID AS UserID,
    TRIM(ud.notification_platform) AS UserDeviceNotificationPlatform,
    TRIM(ud.installed_app_version) AS UserDeviceApplicationVersion,
    TRIM(ud.status) AS UserDeviceStatus,
    NULL AS UserDeviceRecordType,
    TRIM(ud.last_access_time) AS UserDeviceLastAccessTime,
    TRIM(ud.last_change_time) AS UserDeviceLastChangeTime,
    current_timestamp AS SourceCreatedDate,
    ud.last_change_time AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
FROM 
    gds_grdm_raw.kics_user_device_v1 ud
LEFT JOIN 
    gds_grdm_int.User u 
    ON LOWER(TRIM(u.UserNumber)) = LOWER(TRIM(ud.tracking_system_user_id))
LEFT JOIN 
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE 
    ud.gds_batch_id = wid_GDSBatchID