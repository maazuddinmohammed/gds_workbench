SELECT 
    coalesce(TRIM(lc.list_code_id), 'N/A') as MutualFundAcquisitionNumber,
    coalesce(TRIM(lc.short_name), 'N/A') as MutualFundAcquisitionName,
    coalesce(mfa.MutualFundAcquisitionBusinessName, TRIM(lc.short_name)) as MutualFundAcquisitionBusinessName,
    TRIM(lc.description) as MutualFundAcquisitionDescription,
    coalesce(cr.ComplianceRegionID, -1) as ComplianceRegionID,
	lc.start_effective_date AS	MutualFundAcquisitionEffectiveStartDate,
	lc.end_effective_date AS MutualFundAcquisitionEffectiveEndDate,
	lc.identifier AS MutualFundAcquisitionIdentifier,
	lc.parent_list_code_id AS ParentMutualFundAcquisitionListCodeNumber,
	lc.associated_security_type AS	MutualFundAcquisitionAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS MutualFundAcquisitionIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	MutualFundAcquisitionSICCode,
	lc.show_acknowledgement_checkbox AS	MutualFundAcquisitionShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS MutualFundAcquisitionRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS MutualFundAcquisitionFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	MutualFundAcquisitionIsAccountTypeEligibleForBrokerageImport,    
    NULL as SourceCreatedDate,
    lc.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(ms.SourceSystemID, -1) as SourceSystemID
FROM
    gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN
    gds_grdm_int.MutualFundAcquisition mfa 
    ON TRIM(LOWER(lc.list_code_id)) = TRIM(LOWER(mfa.MutualFundAcquisitionNumber))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr 
    ON TRIM(LOWER(lc.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
LEFT JOIN
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE
    lc.gds_batch_id = wid_GDSBatchID
and lc.list_code_type = 'Mutual Fund Acquired'
 