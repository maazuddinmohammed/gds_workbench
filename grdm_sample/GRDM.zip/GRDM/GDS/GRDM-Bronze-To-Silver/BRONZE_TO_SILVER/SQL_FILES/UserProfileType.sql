SELECT DISTINCT
    TRIM(kp.profile_type) AS UserProfileTypeNumber,
    TRIM(kp.profile_type) AS UserProfileTypeName,
    COALESCE(upt.UserProfileTypeBusinessName, TRIM(kp.profile_type)) AS UserProfileTypeBusinessName,
    TRIM(kp.profile_type) AS UserProfileTypeDescription,
    NULL AS SourceCreatedDate
    ,NULL AS SourceUpdatedDate
    ,NULL AS SourceCreatedBy
    ,NULL AS SourceUpdatedBy
    ,s.SourceSystemID AS SourceSystemID
FROM 
    gds_grdm_raw.v_kics_profile_v1 kp
LEFT JOIN 
    gds_grdm_int.UserProfileType upt ON TRIM(LOWER(kp.profile_type)) = TRIM(LOWER(upt.UserProfileTypeNumber))

LEFT JOIN
    gds.MetaSourceSystem s ON s.SourceSystemCode = 'KICS'
WHERE 
    kp.gds_batch_id = 'wid_GDSBatchID'