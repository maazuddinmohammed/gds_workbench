SELECT 
    TRIM(qgsd.holding_type_scope) AS ConflictMessageScopeNumber,
    TRIM(qgsd.holding_type_scope) AS ConflictMessageScopeName,
    COALESCE(TRIM(cms.ConflictMessageScopeBusinessName), TRIM(qgsd.holding_type_scope)) AS ConflictMessageScopeBusinessName,
    TRIM(qgsd.holding_type_scope) AS ConflictMessageScopeDescription,
    NULL AS SourceCreatedDate,
    qgsd.last_change_time AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
  FROM
    gds_grdm_raw.kics_question_group_submission_description_v1 qgsd
  JOIN (SELECT a.holding_type_scope,MAX(a.last_change_time) AS last_change_time FROM gds_grdm_raw.kics_question_group_submission_description_v1 a group by a.holding_type_scope) b 
   on b.holding_type_scope=qgsd.holding_type_scope and b.last_change_time=qgsd.last_change_time
  LEFT JOIN
    gds_grdm_int.conflictmessagescope cms
    ON TRIM(LOWER(qgsd.holding_type_scope)) = TRIM(LOWER(cms.ConflictMessageScopeNumber))
  LEFT JOIN
    gds.MetaSourceSystem ms
    ON ms.SourceSystemName = 'KICS'
  WHERE
    qgsd.gds_batch_id = wid_GDSBatchID