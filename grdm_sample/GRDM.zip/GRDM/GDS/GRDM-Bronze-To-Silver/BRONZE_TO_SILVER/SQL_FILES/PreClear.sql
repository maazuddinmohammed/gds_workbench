SELECT
    u.UserID AS UserID,
    p.holding_case_id AS HoldingNumber,
    h.HoldingID AS HoldingID,    
    coalesce(cr1.ComplianceRegionID, -1) AS PrimaryComplianceRegionID,
    cr2.ComplianceRegionID AS SecondaryComplianceRegionID,
    cm.ConflictMessageID AS ConflictMessageID,
    l.LocationID AS LocationID,
    trim(p.current_preclear_status) AS PreClearStatus,
    trim(p.preclear_result) AS PreClearResult,
    try_cast(p.preclear_creation_time as DATE) AS PreClearCreationDate,
    try_cast(p.preclear_creation_time AS TIMESTAMP) AS PreClearCreationTime,
    try_cast(p.preclear_complete_time as DATE) AS PreClearCompletionDate,
    try_cast(p.preclear_complete_time AS TIMESTAMP) AS PreClearCompletionTime,
    try_cast(p.preclear_expiration_time as DATE) AS PreClearExpirationDate,
    try_cast(p.preclear_expiration_time AS TIMESTAMP) AS PreClearExpirationTime,
    trim(p.preclear_expiration_reason) AS PreClearExpirationReason,
    trim(p.preclear_comments) AS PreClearComment,
    trim(p.is_service_center_update) AS IsServiceCenterUpdate,
    TRIM(p.is_third_party_user_update) AS IsThirdPartyUserUpdate,
    current_timestamp AS SourceCreatedDate,
    p.last_change_time AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    trim(p.last_change_user) AS SourceUpdatedBy,
    s.SourceSystemID AS SourceSystemID
 FROM  gds_grdm_raw.v_kics_preclear_v1 p
  LEFT JOIN gds_grdm_int.Holding h 
    ON trim(lower(h.HoldingNumber)) = trim(lower(p.holding_case_id))
  LEFT JOIN gds_grdm_int.User u 
    ON trim(lower(u.UserNumber)) = trim(lower(p.tracking_system_user_id))
  LEFT JOIN gds_grdm_int.ComplianceRegion cr1 
    ON trim(lower(cr1.ComplianceRegionNumber)) = trim(lower(p.current_assigned_compliance_region_id))
  LEFT JOIN gds_grdm_int.ComplianceRegion cr2 
    ON trim(lower(cr2.ComplianceRegionNumber)) = trim(lower(p.current_secondary_compliance_region_id))
  LEFT JOIN gds_grdm_int.ConflictMessage cm 
    ON trim(lower(cm.ConflictMessageNumber)) = trim(lower(p.question_group_submission_description_id))
  LEFT JOIN gds_grdm_int.Location l ON trim(lower(l.LocationNumber)) = trim(lower(p.location_id))
  LEFT JOIN gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
  WHERE p.gds_batch_id = wid_GDSBatchID