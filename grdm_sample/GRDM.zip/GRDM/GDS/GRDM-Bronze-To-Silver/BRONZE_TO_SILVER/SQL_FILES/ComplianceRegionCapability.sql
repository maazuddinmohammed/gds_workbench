SELECT 
    TRIM(crc.compliance_region_capability_id) AS ComplianceRegionCapabilityNumber,
    TRIM(c.CapabilityID) AS CapabilityID,
    TRIM(cr1.ComplianceRegionID) AS ComplianceRegionID,
    TRIM(crc.is_admin_enabled) AS IsCapabilityAdminEnabled,
    TRIM(crc.is_compliance_officer_enabled) AS IsCapabilityComplianceOfficerEnabled,
    TRIM(crc.is_reviewer_enabled) AS IsCapabilityReviewerEnabled,
    TRIM(crc.is_superuser_enabled) AS IsCapabilitySuperUserEnabled,
    null AS SourceCreatedDate,
    TRIM(crc.last_change_time) AS SourceUpdatedDate,
    TRIM(crc.last_change_user) AS SourceCreatedBy,     
    TRIM(crc.last_change_user) AS SourceUpdatedBy,  
    TRIM(ms.SourceSystemID) as SourceSystemID
    FROM
    gds_grdm_raw.kics_compliance_region_capability crc
   
    LEFT JOIN gds_grdm_int.capability c
       ON TRIM(LOWER(crc.capability_name)) = TRIM(LOWER(c.CapabilityName))
    LEFT JOIN gds_grdm_int.ComplianceRegion cr1
       ON TRIM(LOWER(crc.compliance_region_id))  = TRIM(LOWER(cr1.ComplianceRegionNumber))
   LEFT JOIN
       meta.MetaSourceSystem ms 
       ON ms.SourceSystemName = 'KICS'
    WHERE
       crc.gds_batch_id = wid_GDSBatchID