SELECT 
    TRIM(ba.brokerage_assignment_id) AS BrokerageNumber,
    coalesce(ec.EntityComplianceID,-1) AS EntityComplianceID, 
    cr1.ComplianceRegionID AS ComplianceRegionID,
    cr2.ComplianceRegionID AS BDIAuthorizedComplianceRegionID,
    CAST(ba.bdi_enable_status_change_time AS TIMESTAMP) AS BrokerageBDIEnableChangeTime,
    CAST(ba.bdi_exempt_status_change_time AS TIMESTAMP) AS BrokerageBDIExemptChangeTime,
    TRIM(ba.is_bdi_enable) AS IsBDIEnable,
    TRIM(ba.is_bdi_exempt) AS IsBDIExempt,
    NULL AS SourceCreatedDate,
    ba.last_change_time AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
 FROM gds_grdm_raw.kics_brokerage_assignment_v1 ba  
  LEFT JOIN gds.MetaSourceSystem ms    ON ms.SourceSystemName = 'KICS'
  LEFT JOIN gds_ref_int.Entity e ON LOWER(TRIM(e.EntityNumber)) = LOWER(TRIM(ba.entity_id))  AND e.SourceSystemID = ms.SourceSystemID
  LEFT JOIN gds_grdm_int.EntityCompliance ec    ON TRIM(LOWER(e.entityid)) = TRIM(LOWER(ec.EntityID))
  LEFT JOIN gds_grdm_int.ComplianceRegion cr1    ON cr1.ComplianceRegionNumber = ba.compliance_region_id
  LEFT JOIN gds_grdm_int.ComplianceRegion cr2    ON cr2.ComplianceRegionNumber = ba.bdi_action_authorized_compliance_region_id
  WHERE ba.gds_batch_id = wid_GDSBatchID