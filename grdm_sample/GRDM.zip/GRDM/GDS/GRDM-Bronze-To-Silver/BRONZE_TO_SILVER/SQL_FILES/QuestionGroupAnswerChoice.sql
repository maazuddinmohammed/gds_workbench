SELECT 
    TRIM(q.answer_description_id) as QuestionGroupAnswerChoiceNumber,
    TRIM(q.answer_choice_number) as QuestionGroupAnswerChoiceOrder,
    TRIM(q.answer_choice_type) as QuestionGroupAnswerChoiceType,
    TRIM(q.answer_choice_status) as QuestionGroupAnswerChoiceStatus,
    TRIM(q.answer_choice_text) as QuestionGroupAnswerChoiceText,
    TRIM(q.answer_description_style) as QuestionGroupAnswerChoiceDescriptionStyle,
    CASE TRIM(q.is_system_query_comparison_enabled)
      WHEN 'YES' THEN 'True'
      WHEN 'NO' THEN 'False'
      ELSE NULL
    END as IsSystemQueryComparisonEnabled,
    NULL as SourceCreatedDate,
    q.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    ms.SourceSystemID as SourceSystemID
FROM
    gds_grdm_raw.v_kics_question_group_answer_choice_v1 q
LEFT JOIN
    gds.MetaSourceSystem ms
    ON ms.SourceSystemName = 'KICS' 
WHERE
   q.gds_batch_id = wid_GDSBatchID