
SELECT
    Status.StatusName AS StatusName,
    Status.StatusBusinessName AS StatusBusinessName,
    Status.StatusDescription AS StatusDescription,
    NULL AS SourceCreatedDate,
    NULL AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy ,              
    s.SourceSystemID AS SourceSystemID                
                       
FROM
  (   
       SELECT "Active" AS StatusName , "Active" AS StatusBusinessName, "Active" AS StatusDescription
        UNION ALL
        SELECT "Inactive" AS StatusName, "Inactive" AS StatusBusinessName , "Inactive" AS StatusDescription 
    ) AS Status
LEFT JOIN
    gds.MetaSourceSystem s ON s.SourceSystemCode = 'SNTL'

  





