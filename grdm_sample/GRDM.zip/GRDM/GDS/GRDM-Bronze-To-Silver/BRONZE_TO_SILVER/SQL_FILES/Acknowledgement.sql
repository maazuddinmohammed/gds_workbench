SELECT 
    trim(a.acknowledgement_text_assignment_id) as AcknowledgementNumber,
    ec.EntityComplianceID as EntityComplianceID, 
    cr.ComplianceRegionID as ComplianceRegionID, 
    l.LanguageID as LanguageID,
    trim(a.status) as AcknowledgementStatus,
    trim(a.acknowledgement_name) as AcknowledgementName,
    trim(a.acknowledgement_heading) as AcknowledgementHeading, 
    trim(a.acknowledgement_text) as AcknowledgementText,  
    trim(a.brokerage_instruction) as AcknowledgementBrokerageInstruction, 
    trim(a.example_account_identifier) as AcknowledgementExampleAccountID, 
    NULL as SourceCreatedDate, 
    a.last_change_time as SourceUpdatedDate, 
    NULL as SourceCreatedBy, 
    NULL as SourceUpdatedBy, 
    s.SourceSystemID as SourceSystemID
FROM 
    gds_grdm_raw.kics_acknowledgement_text_assignment_v1 a
LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
LEFT JOIN 
    gds_ref_int.entity en
    ON trim(lower(a.entity_id))=trim(lower(en.EntityNumber))
    AND en.SourceSystemID = s.SourceSystemID
LEFT JOIN
    gds_grdm_int.EntityCompliance ec 
    ON trim(lower(ec.EntityID)) = trim(lower(en.EntityID))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON trim(lower(cr.ComplianceRegionNumber)) = trim(lower(a.compliance_region_id))
LEFT JOIN 
    gds_grdm_raw.kics_language_v1 kl 
    ON trim(lower(kl.language_id)) = trim(lower(a.language_id)) AND kl.gds_batch_id=a.gds_batch_id
LEFT JOIN 
    gds_ref_int.Language l 
    ON trim(lower(l.LanguageISO1)) = trim(lower(kl.identifier))
WHERE 
    a.gds_batch_id = wid_GDSBatchID