SELECT 
    TRIM(sr.security_restriction_id) AS SecurityRestrictionNumber,
    Coalesce(s.SecurityID, -1)  AS SecurityID,
    cr.ComplianceRegionID AS ComplianceRegionID,
    cr2.ComplianceRegionID AS ParentComplianceRegionID,
    rt.RestrictionTypeID AS RestrictionTypeID,
    rs.RestrictionStateID AS RestrictionStateID,
    TRIM(sr.restriction_applied) AS SecurityRestriction,
    sr.restriction_reason AS SecurityRestrictionReason,
    TRIM(sr.engagement_partner_assignment_array) AS SecurityRestrictionEngagementPartnerAssignmentArray,
    TRIM(sr.covered_person_restriction_attribute_array) AS SecurityRestrictionCoveredPersonAttributeArray,
    sr.is_restricted AS IsRestricted,
    sr.is_applicable AS IsApplicable,
    current_timestamp AS SourceCreatedDate,
    TRIM(sr.last_change_time) AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
FROM 
    gds_grdm_raw.v_kics_security_restriction_v1 sr
LEFT JOIN 
    gds_grdm_int.Security s 
    ON LOWER(TRIM(s.SecurityNumber)) = LOWER(TRIM(sr.security_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON LOWER(TRIM(cr.ComplianceRegionNumber)) = LOWER(TRIM(sr.restricted_compliance_region_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr2 
    ON LOWER(TRIM(cr2.ComplianceRegionNumber)) = LOWER(TRIM(sr.inherited_from_parent_compliance_region_id))
LEFT JOIN 
    gds_grdm_int.RestrictionType rt 
    ON LOWER(TRIM(rt.RestrictionTypeNumber)) = LOWER(TRIM(sr.restriction_type))
LEFT JOIN 
    gds_grdm_int.RestrictionState rs 
    ON LOWER(TRIM(rs.RestrictionStateNumber)) = LOWER(TRIM(sr.restriction_state))
LEFT JOIN 
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE 
    sr.gds_batch_id = wid_GDSBatchID