SELECT 
    TRIM(tp.third_party_id) AS ThirdPartyNumber,
    TRIM(tp.user_id) AS ThirdPartyUserNumber,
    TRIM(u.userID) AS UserID,
    TRIM(tp.user_email) AS ThirdPartyUserEmail,
    TRIM(tp.created_time) AS ThirdPartyCreatedTime,
    TRIM(rref.languageID) AS ThirdPartyUserLanguageID,
    TRIM(tpu.ThirdPartyUserID)  AS ThirdPartyUserID,         
    TRIM(tp.user_first_name) AS ThirdPartyUserFirstName,
    TRIM(tp.user_last_name)  AS ThirdPartyUserLastName,
    TRIM(tp.third_party_user_language_id) AS ThirdPartyUserStatus,
    TRIM(tp.user_creation_time) AS ThirdPartyUserCreationTime,
    TRIM(tp.agreement_acknowledgement_time) AS ThirdPartyAgreementAcknowledgementTime,
    TRIM(tp.user_modification_time) AS ThirdPartyUserModificationTime,
    TRIM(tp.user_removal_time) AS ThirdPartyUserRemovalTime,
    TRIM(cr1.ComplianceRegionID) AS CurrentAssignedComplianceRegionID,
    TRIM(cr2.ComplianceRegionID) AS CurrentSecondaryComplianceRegionID,
    TRIM(tp.last_change_time) AS ThirdPartyLastChangeTime,
    TRIM(tp.last_change_user) AS ThirdPartyLastChangeUser,
    TRIM(tp.identity_provider_status) AS IdentityProviderStatus,
    TRIM(tp.identity_provider_status_code) AS IdentityProviderStatusCode,
    TRIM(tp.identity_provider_user_id) AS IdentityProviderUserID,
    TRIM(tp.created_time) AS SourceCreatedDate,
    TRIM(tp.last_change_time) AS SourceUpdatedDate,
    TRIM(tp.last_change_user) AS SourceCreatedBy,     
    TRIM(tp.last_change_user) AS SourceUpdatedBy,  
    TRIM(ms.SourceSystemID) as SourceSystemID
FROM
    gds_grdm_raw.kics_third_party tp
LEFT JOIN gds_grdm_int.User u
       ON TRIM(LOWER(tp.tracking_system_user_id)) = TRIM(LOWER(u.UserNumber))
LEFT JOIN gds_grdm_raw.kics_language_v1 rl 
       ON TRIM(LOWER(tp.third_party_user_language_id)) = TRIM(LOWER(rl.language_id)) AND tp.gds_batch_id = rl.gds_batch_id
LEFT JOIN gds_ref_int.language rref
       ON TRIM(LOWER(rl.identifier))  = TRIM(LOWER(rref.languageISO1))
      AND TRIM(LOWER(rl.identifier2)) = TRIM(LOWER(rref.languageISO2))  
LEFT JOIN gds_grdm_int.ThirdPartyUser tpu
       ON TRIM(LOWER(tp.third_party_list_code_id)) = TRIM(LOWER(tpu.ThirdPartyUserNumber))
LEFT JOIN gds_grdm_int.ComplianceRegion cr1
       ON TRIM(LOWER(tp.current_assigned_compliance_region_id))  = TRIM(LOWER(cr1.ComplianceRegionNumber))
LEFT JOIN gds_grdm_int.ComplianceRegion cr2
       ON TRIM(LOWER(tp.current_secondary_compliance_region_id)) = TRIM(LOWER(cr2.ComplianceRegionNumber))
LEFT JOIN
    meta.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE
    tp.gds_batch_id = wid_GDSBatchID