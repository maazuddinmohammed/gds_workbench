 SELECT 
    TRIM(em.entity_security_merge_record_id) AS EntityComplianceMergeNumber,
    coalesce(ecret.EntityComplianceID,-1) AS EntityComplianceRetainedID,
    coalesce(ecrep.EntityComplianceID,-1) AS EntityComplianceReplacedID,
    cast(em.merge_time as timestamp) AS EntityComplianceMergeDate,
    cast(em.merge_time as timestamp) AS EntityComplianceMergeTime,
    TRIM(em.retained_security_acquisition_date_source) AS EntityComplianceMergeDataSource,
    TRIM(em.merge_comment) AS EntityComplianceMergeComment,
    TRIM(em.is_confirmation_required) AS IsConfirmationRequired,
    TRIM(em.is_send_notification_selected) AS IsSendNotification,
    NULL AS SourceCreatedDate,
    em.last_change_time AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    s.SourceSystemID AS SourceSystemID
  FROM 
    gds_grdm_raw.kics_entity_security_merge_record_v1 em
  LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
  LEFT JOIN 
    gds_ref_int.Entity eret 
    ON LOWER(TRIM(em.entity_security_retained_id)) = LOWER(TRIM(eret.EntityNumber))
    AND eret.SourceSystemID = s.SourceSystemID
      ------SELECT entity_security_retained_id,* FROM gds_grdm_raw.kics_entity_security_merge_record_v1 WHERE entity_security_retained_id IN (SELECT EntityNumber FROM gds_ref_int.Entity)
  LEFT JOIN 
    gds_grdm_int.EntityCompliance ecret 
    ON eret.EntityID = ecret.EntityID
  LEFT JOIN 
    gds_ref_int.Entity erep 
    ON LOWER(TRIM(em.entity_security_replaced_id)) = LOWER(TRIM(erep.EntityNumber))
    AND erep.SourceSystemID = s.SourceSystemID
  LEFT JOIN 
    gds_grdm_int.EntityCompliance ecrep        
    ON erep.EntityID = ecrep.EntityID
  WHERE     em.gds_batch_id = wid_GDSBatchID