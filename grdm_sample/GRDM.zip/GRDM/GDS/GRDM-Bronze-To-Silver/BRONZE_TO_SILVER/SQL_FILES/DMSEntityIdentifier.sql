SELECT 
dent.EntityId	as EntityId,
deni.IdentifierId	as IdentifierId,
deni.IdentifierType	as IdentifierType,
deni.IdentifierValue	as IdentifierValue,
current_timestamp() as SourceCreatedDate ,
current_timestamp() as SourceUpdatedDate ,
current_user() as SourceCreatedBy ,
current_user() as SourceUpdatedBy ,
deni.source_system_id as SourceSystemID 
FROM gds_grdm_raw.dms_entityidentifier as deni 
JOIN gds_grdm_int.dmsentity as dent ON deni.EntityId = dent.SourceSystemEntityID
WHERE deni.gds_batch_id = wid_GDSBatchID
