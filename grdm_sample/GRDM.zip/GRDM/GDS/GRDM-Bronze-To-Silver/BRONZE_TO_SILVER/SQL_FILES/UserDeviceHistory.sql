SELECT 
    udh.last_change_time AS UserDeviceHistoryTime,
    ud.UserDeviceID AS UserDeviceID,
    TRIM(udh.user_device_information_id) AS UserDeviceNumber,
    u.UserID AS UserID,
    TRIM(udh.notification_platform) AS UserDeviceNotificationPlatform,
    TRIM(udh.installed_app_version) AS UserDeviceApplicationVersion,
    TRIM(udh.status) AS UserDeviceStatus,
    TRIM(udh.record_type) AS UserDeviceRecordType,
    TRIM(udh.last_access_time) AS UserDeviceLastAccessTime,
    TRIM(udh.last_change_time) AS UserDeviceLastChangeTime,
    NULL AS SourceCreatedDate,
    udh.last_change_time AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
FROM 
    gds_grdm_raw.v_kics_user_device_history_v1 udh
LEFT JOIN 
    gds_grdm_int.User u 
    ON LOWER(TRIM(u.UserNumber)) = LOWER(TRIM(udh.tracking_system_user_id))
LEFT JOIN 
    gds_grdm_int.UserDevice ud 
    ON LOWER(TRIM(ud.UserDeviceNumber)) = LOWER(TRIM(udh.user_device_information_id))
LEFT JOIN 
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE 
    udh.gds_batch_id = wid_GDSBatchID