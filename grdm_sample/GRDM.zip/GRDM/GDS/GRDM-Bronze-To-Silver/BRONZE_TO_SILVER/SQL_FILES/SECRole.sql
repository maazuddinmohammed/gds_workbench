SELECT DISTINCT
  TRIM(lc.sec_role) AS SECRoleNumber,
  TRIM(lc.sec_role) AS SECRoleName,
  COALESCE(sec.SECRoleBusinessName, lc.sec_role) AS SECRoleBusinessName,
  TRIM(lc.sec_role) AS SECRoleDescription,
  NULL AS SourceCreatedDate,
  NULL AS SourceUpdatedDate,
  NULL AS SourceCreatedBy,
  NULL AS SourceUpdatedBy,
  ms.SourceSystemID AS SourceSystemID
FROM  gds_grdm_raw.kics_question_group_v1 lc
LEFT JOIN 
  gds_grdm_int.secrole sec 
  ON TRIM(LOWER(lc.sec_role)) = TRIM(LOWER(sec.SECRoleNumber))
LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
WHERE 
  lc.gds_batch_id = wid_GDSBatchID
  and lc.sec_role <>''  --> 1 record