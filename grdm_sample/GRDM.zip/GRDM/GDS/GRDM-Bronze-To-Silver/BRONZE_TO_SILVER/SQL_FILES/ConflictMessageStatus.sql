SELECT Distinct
    TRIM(a.status) AS ConflictMessageStatusNumber,
    TRIM(a.status) AS ConflictMessageStatusName,
    COALESCE(TRIM(cms.ConflictMessageStatusBusinessName), TRIM(a.status)) AS ConflictMessageStatusBusinessName,
    NULL AS ConflictMessageStatusDescription,
    NULL AS SourceCreatedDate,
    NULL AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
FROM gds_grdm_raw.kics_question_group_submission_description_v1 a
    LEFT JOIN gds_grdm_int.ConflictMessageStatus cms
    ON TRIM(LOWER(cms.ConflictMessageStatusNumber)) = TRIM(LOWER(a.status))
LEFT JOIN gds.MetaSourceSystem ms
    ON ms.SourceSystemName = 'KICS'
WHERE a.gds_batch_id = wid_GDSBatchID