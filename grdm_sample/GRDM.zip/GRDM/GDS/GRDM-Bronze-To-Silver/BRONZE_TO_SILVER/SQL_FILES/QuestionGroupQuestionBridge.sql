SELECT 
    TRIM(qb.question_set_assignment_id) as QuestionSetAssignmentID,
    qs.QuestionSetID as QuestionSetID,
    qg.QuestionGroupID as QuestionGroupID,
    TRIM(qb.question_set_number) as QuestionSetNumber,
    TRIM(qb.question_set_assignment_status) as QuestionSetAssignmentStatus,
    TRIM(qb.question_set_question_type) as QuestionSetQuestionType,
    CASE WHEN UPPER(qb.is_default_question_set) = 'YES' THEN 'True' ELSE 'False' END as IsDefaultQuestionSet,
    NULL as SourceCreatedDate,
    NULL as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    ms.SourceSystemID as SourceSystemID
FROM
    gds_grdm_raw.kics_question_group_to_question_bridge_v1 qb
LEFT JOIN
    gds.MetaSourceSystem ms
    ON ms.SourceSystemName = 'KICS' 
LEFT JOIN
    gds_grdm_int.QuestionSet qs ON
      LOWER(TRIM(qs.QuestionSetNumber)) = LOWER(TRIM(qb.question_set_id))
LEFT JOIN
    gds_grdm_int.QuestionGroup qg ON
      LOWER(TRIM(qg.QuestionGroupNumber)) = LOWER(TRIM(qb.question_group_id))
WHERE
   qb.gds_batch_id = wid_GDSBatchID