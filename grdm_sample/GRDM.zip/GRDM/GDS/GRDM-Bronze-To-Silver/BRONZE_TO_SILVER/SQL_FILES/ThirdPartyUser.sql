SELECT
      klc.list_code_id as ThirdPartyUserNumber,
      klc.short_name as ThirdPartyUserName,
      coalesce(thu.ThirdPartyUserBusinessName, klc.short_name) as ThirdPartyUserBusinessName,
      klc.description as ThirdPartyUserDescription,
      cl.ComplianceRegionID as ComplianceRegionID,
      klc.start_effective_date as ThirdPartyUserEffectiveStartDate,
      klc.end_effective_date as ThirdPartyUserEffectiveEndDate,
      klc.identifier as ThirdPartyUserIdentifier,
      klc.parent_list_code_id as ParentThirdPartyUserListCodeNumber,
      klc.associated_security_type as ThirdPartyUserAssociatedSecurityType,
      klc.can_financial_interest_be_reassigned_issuer as ThirdPartyUserIsFinancialInterestBeReassignedIssuer,
      klc.sic_codes as ThirdPartyUserSICCode,
      klc.show_acknowledgement_checkbox as ThirdPartyUserShowAcknowledgementCheckbox,
      klc.require_comment_field_when_add_holding as ThirdPartyUserRequireCommentFieldWhenAddHolding,
      klc.financial_interest_display_type as ThirdPartyUserFinancialInterestDisplayType,
      klc.is_account_type_eligible_for_brokerage_import as ThirdPartyUserIsAccountTypeEligibleForBrokerageImport,
      NULL as SourceCreatedDate,
      NULL AS SourceUpdatedDate,
      NULL as SourceCreatedBy,
      NULL as SourceUpdatedBy,
      ms.SourceSystemID as SourceSystemID
FROM gds_grdm_raw.kics_list_code_v1 as klc

INNER JOIN gds_grdm_int.complianceregion as cl ON klc.compliance_region_id = cl.ComplianceRegionNumber

LEFT JOIN gds_grdm_int.thirdpartyuser as thu 
   ON TRIM(thu.ThirdPartyUserNumber) = TRIM(klc.short_name)

LEFT JOIN meta.MetaSourceSystem ms    
   ON ms.SourceSystemName = 'KICS'

WHERE klc.gds_batch_id = wid_GDSBatchID