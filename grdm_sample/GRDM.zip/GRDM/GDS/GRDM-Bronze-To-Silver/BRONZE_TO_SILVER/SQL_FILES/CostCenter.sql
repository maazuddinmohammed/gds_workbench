SELECT 
    trim(b.cost_center) as CostCenterNumber,
    trim(b.cost_center_description) as CostCenterName,
    coalesce(trim(cc.CostCenterBusinessName), trim(b.cost_center)) as CostCenterBusinessName,
    trim(b.cost_center_description) as CostCenterDescription,
    NULL as SourceCreatedDate,
    NULL as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(m.SourceSystemID, -1) as SourceSystemID
FROM 
    gds_grdm_raw.kics_user_info_v1 b
LEFT JOIN 
    gds_grdm_int.costcenter cc 
    ON trim(lower(b.cost_center)) = trim(lower(cc.CostCenterNumber))
LEFT JOIN 
    gds.MetaSourceSystem m 
    ON m.SourceSystemName = 'KICS'
WHERE 
    b.gds_batch_id = wid_GDSBatchID