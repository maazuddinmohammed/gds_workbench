SELECT
    TRIM(qgsd.question_group_submission_description_id) AS ConflictMessageNumber,
    TRIM(qgsd.subject_title) AS ConflictMessageTitle,
    TRIM(qgsd.message_text) AS ConflictMessage,
    cms.ConflictMessageStatusID AS ConflictMessageStatusID,
    cr.ComplianceRegionID AS ComplianceRegionID,
    s.SecurityID AS SecurityID,
    ec.EntityComplianceID as EntityComplianceID,
    x.ConflictMessageScopeID AS ConflictMessageScopeID,
    l2.LanguageID  AS LanguageID,
    fist.FinancialInterestSubTypeID AS FinancialInterestSubTypeID,
    ht.HoldingTypeID as HoldingTypeID,
    rt.RestrictionTypeID as RestrictionTypeID,
    sr.SECRoleID as SECRoleID,
    qgsd.development_description_holding_type_array as ConflictMessageHoldingTypeArray,
    qgsd.development_description_restriction_type_array as ConflictMessageRestrictionTypeArray,
    qgsd.development_description_sec_role_array as ConflictMessageSECRoleArray,
    qgsd.limitation_days AS ConflictMessageLimitationDays,
    qgsd.self_clear_expiration_days AS ConflictMessageSelfClearExpirationDays,
    qgsd.move_to_production_time AS ConflictMessageProductionTime,
    qgsd.archive_time AS ConflictMessageArchiveTime,
    TRIM(qgsd.last_action) AS ConflictMessageLastAction,
    NULL AS ReplacementConflictMessageID,
    TRIM(qgsd.new_question_group_submission_definition_id) AS NewConflictMessageID,
    TRIM(qgsd.covered_person_eligibility) AS IsCoveredPersonEligibility,
    NULL AS SourceCreatedDate,
    qgsd.last_change_time AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    mss.SourceSystemID AS SourceSystemID
  FROM 
    gds_grdm_raw.kics_question_group_submission_description_v1 qgsd
  LEFT JOIN 
    gds_grdm_int.ConflictMessageStatus cms 
    ON LOWER(TRIM(cms.ConflictMessageStatusNumber)) = LOWER(TRIM(qgsd.status))
  LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON LOWER(TRIM(cr.ComplianceRegionNumber)) = LOWER(TRIM(qgsd.compliance_region_id))
  LEFT JOIN 
    gds_grdm_int.Security s 
    ON LOWER(TRIM(s.SecurityNumber)) = LOWER(TRIM(qgsd.entity_security_id))
LEFT JOIN gds_ref_int.Entity e ON LOWER(TRIM(e.EntityNumber)) = LOWER(TRIM(qgsd.entity_security_id)) AND e.SourceSystemID = s.SourceSystemID
LEFT JOIN gds_grdm_int.EntityCompliance ec ON LOWER(TRIM(ec.EntityID)) = LOWER(TRIM(e.EntityID))
  LEFT JOIN 
    gds_grdm_int.ConflictMessageScope x 
    ON LOWER(TRIM(x.ConflictMessageScopeNumber)) = LOWER(TRIM(qgsd.holding_type_scope))
  LEFT JOIN 
    gds_grdm_int.FinancialInterestSubType fist 
    ON LOWER(TRIM(fist.FinancialInterestSubTypeNumber)) = LOWER(TRIM(qgsd.financial_interest_sub_type_list_code_id))
  LEFT JOIN 
    gds_grdm_int.StockType st 
    ON LOWER(TRIM(st.StockTypeNumber)) = LOWER(TRIM(qgsd.stock_type))
  LEFT JOIN gds_grdm_int.HoldingType ht ON LOWER(TRIM(ht.HoldingTypeNumber)) = LOWER(TRIM(qgsd.holding_type))
  LEFT JOIN gds_grdm_int.RestrictionType rt ON LOWER(TRIM(rt.RestrictionTypeNumber)) = LOWER(TRIM(qgsd.restriction_type))
  LEFT JOIN gds_grdm_int.SECRole sr ON LOWER(TRIM(sr.SECRoleNumber)) = LOWER(TRIM(qgsd.sec_role))
  LEFT JOIN gds_grdm_raw.kics_language_v1 l 
  ON LOWER(TRIM(l.language_id)) = LOWER(TRIM(qgsd.language_id)) AND l.gds_batch_id=qgsd.gds_batch_id
  LEFT JOIN 
    gds_ref_int.Language l2 
    ON LOWER(TRIM(l2.LanguageISO1)) = LOWER(TRIM(l.identifier))
  LEFT JOIN 
    gds.MetaSourceSystem mss 
    ON mss.SourceSystemName = 'KICS'
  WHERE     qgsd.gds_batch_id = wid_GDSBatchID