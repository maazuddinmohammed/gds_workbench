SELECT 
  TRIM(lc.list_code_id) AS UnitInvestmentTrustAcquisitionNumber,
  TRIM(lc.short_name) AS UnitInvestmentTrustAcquisitionName,
  COALESCE(uta.UnitInvestmentTrustAcquisitionBusinessName, lc.short_name) AS UnitInvestmentTrustAcquisitionBusinessName,
  TRIM(lc.description) AS UnitInvestmentTrustAcquisitionDescription,
  cr.ComplianceRegionID AS ComplianceRegionID,
	lc.start_effective_date AS	UnitInvestmentTrustAcquisitionEffectiveStartDate,
	lc.end_effective_date AS UnitInvestmentTrustAcquisitionEffectiveEndDate,
	lc.identifier AS UnitInvestmentTrustAcquisitionIdentifier,
	lc.parent_list_code_id AS ParentUnitInvestmentTrustAcquisitionListCodeNumber,
	lc.associated_security_type AS	UnitInvestmentTrustAcquisitionAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS UnitInvestmentTrustAcquisitionIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	UnitInvestmentTrustAcquisitionSICCode,
	lc.show_acknowledgement_checkbox AS	UnitInvestmentTrustAcquisitionShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS UnitInvestmentTrustAcquisitionRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS UnitInvestmentTrustAcquisitionFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	UnitInvestmentTrustAcquisitionIsAccountTypeEligibleForBrokerageImport,  
  NULL AS SourceCreatedDate,
  lc.last_change_time AS SourceUpdatedDate,
  NULL AS SourceCreatedBy,
  NULL AS SourceUpdatedBy,
  ms.SourceSystemID AS SourceSystemID
FROM 
  gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
  gds_grdm_int.UnitInvestmentTrustAcquisition uta 
  ON TRIM(LOWER(lc.list_code_id)) = TRIM(LOWER(uta.UnitInvestmentTrustAcquisitionNumber))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON TRIM(LOWER(lc.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
WHERE 
  lc.gds_batch_id = wid_GDSBatchID
  AND lc.list_code_type = 'UIT Acquired'