SELECT 
  e.EntityID as EntityID,
  trim(ke.external_identifier) as EntityComplianceExternalID,
  trim(ke.client_number) as EntityComplianceClientNumber,
  cr.ComplianceRegionID as ComplianceRegionID,
  trim(ke.primary_alias_text) as EntityCompliancePrimaryAlias,
  ecc.EntityComplianceCategoryID as EntityComplianceCategoryID,
  ecs.EntityComplianceStatusID as EntityComplianceStatusID,
  trim(ke.quick_search_list_type) as EntityComplianceQuickSearchListType,
  trim(ke.isin) as EntityComplianceISIN,
  trim(ke.naics) as EntityComplianceNAICS,
  trim(ke.administrative_comments) as EntityComplianceComment,
  trim(ke.gmfid) as EntityComplianceGMFID,
  trim(ke.brokerage_import_state) as EntityComplianceBrokerageImportState,
  trim(ke.central_index_key) as EntityComplianceCentralIndexKey,
  trim(ke.sedol) as EntityComplianceSEDOL,
  trim(ke.rssd) as EntityComplianceRSSD,
  trim(ke.last_bdi_mapping_update_date) as EntityComplianceLastBDIMappingDate,
  trim(ke.sec_registrant_comment) as EntityComplianceSECRegistrantComment,
  trim(ke.add_type) as EntityComplianceAddType,
  trim(ke.inactivated_date) as EntityComplianceInactivatedTime,
  trim(ke.sic_array) as EntityComplianceSICArray,
  trim(ke.icusip_array) as EntityComplianceICUSIPArray,
  trim(ke.nmls_array) as EntityComplianceNMLSArray,
  trim(ke.refinitiv_identifier_array) as EntityComplianceRefinitiveIDArray,
  trim(ke.alias_value_array) as EntityComplianceAliasArray,
  trim(ke.child_entity_security_name_array) as EntityComplianceChildSecurityNameArray,
  trim(ke.child_entity_security_type_array) as EntityComplianceChildSecurityTypeArray,
  trim(ke.relationship_type_array) as EntityComplianceRelationshipTypeArray,
  trim(ke.is_in_watchlist) as OnWatchList,
  trim(ke.is_issuer_529_plan) as On529Plan,
  trim(ke.is_mapping_program_allowed_to_update) as CanMappingProgramUpdate,
  trim(ke.is_sec_registrant) as IsSECRegistrant,
  CASE WHEN LOWER(TRIM(ke.covered_person_indicator)) = 'blank' THEN NULL ELSE ke.covered_person_indicator END as IsCoveredPerson,
  trim(ke.is_clearing_broker) as IsClearingBroker,
  trim(ke.is_controlled_by_ems) as IsEMSControlled,
  trim(ke.is_restriction_flow_down_array) as EntityComplianceRestrictionFlowDownArray,
  NULL as SourceCreatedDate,
  ke.last_change_time as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  ms.SourceSystemID as SourceSystemID
FROM 
 gds_grdm_raw.kics_entity_v1 ke
LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
LEFT JOIN 
  gds_ref_int.Entity e 
  ON LOWER(TRIM(ke.entity_id)) = LOWER(TRIM(e.EntityNumber))  AND e.SourceSystemID = ms.SourceSystemID
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON LOWER(TRIM(ke.compliance_region_id)) = LOWER(TRIM(cr.ComplianceRegionNumber))
LEFT JOIN 
 gds_grdm_int.EntityComplianceCategory ecc 
  ON ke.category = ecc.EntityComplianceCategoryNumber 
LEFT JOIN 
 gds_grdm_int.EntityComplianceStatus ecs 
  ON LOWER(TRIM(ke.status)) = LOWER(TRIM(ecs.EntityComplianceStatusNumber)) 
WHERE 
  ke.gds_batch_id = wid_GDSBatchID  