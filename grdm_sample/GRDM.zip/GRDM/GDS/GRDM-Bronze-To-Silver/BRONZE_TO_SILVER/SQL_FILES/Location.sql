SELECT 
    coalesce(TRIM(lc.location_id), -1) as LocationNumber,
    coalesce(TRIM(lc.office_number), 'N/A') as LocationName,
    coalesce(TRIM(lc.street1), 'N/A') as LocationAddressLine1,
    TRIM(lc.street2) as LocationAddressLine2,
    coalesce(TRIM(lc.city), 'N/A') as LocationAddressCity,
    coalesce(TRIM(lc.state_or_province), 'N/A') as LocationAddressState,
    coalesce(TRIM(lc.postal), 'N/A') as LocationAddressPostalCode,
    coalesce(c.CountryID, NULL) as CountryID,
    coalesce(cr.ComplianceRegionID, -1) as ComplianceRegionID,
    TRIM(lc.status) AS LocationStatus,
    TRIM(lc.override_auto_self_clear_configuration) AS LocationOverrideAutoSelfClearConfiguration,
    lc.created_time as SourceCreatedDate,
    lc.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    ms.SourceSystemID as SourceSystemID
FROM
    gds_grdm_raw.kics_location_v1 lc
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr 
    ON TRIM(LOWER(lc.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
LEFT JOIN
    gds_ref_int.country c 
    ON TRIM(LOWER(lc.country)) = TRIM(LOWER(c.CountryISOCode))
LEFT JOIN
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE
    lc.gds_batch_id = wid_GDSBatchID