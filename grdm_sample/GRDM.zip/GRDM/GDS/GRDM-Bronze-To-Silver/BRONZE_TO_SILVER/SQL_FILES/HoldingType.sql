SELECT DISTINCT
    TRIM(h.holding_type) as HoldingTypeNumber,
    TRIM(h.holding_type) as HoldingTypeName,
    COALESCE(ht.HoldingTypeBusinessName, TRIM(h.holding_type)) as HoldingTypeBusinessName,
    NULL as HoldingTypeDescription,
    NULL as SourceCreatedDate,
    NULL as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(ms.SourceSystemID, -1) as SourceSystemID
FROM gds_grdm_raw.kics_holding_v1 h
LEFT JOIN
    gds.MetaSourceSystem ms
    ON ms.SourceSystemName = 'KICS'    
LEFT JOIN
    gds_grdm_int.holdingtype ht
    ON LOWER(TRIM(ht.HoldingTypeNumber)) = LOWER(TRIM(h.holding_type)) AND ht.SourceSystemID = ms.SourceSystemID
WHERE
    h.gds_batch_id = wid_GDSBatchID