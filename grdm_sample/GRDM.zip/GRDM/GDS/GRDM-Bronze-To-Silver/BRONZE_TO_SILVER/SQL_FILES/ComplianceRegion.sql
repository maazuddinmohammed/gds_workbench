SELECT 
    trim(b.compliance_region_id) as ComplianceRegionNumber,
    trim(b.name) as ComplianceRegionName,
    trim(b.type) as ComplianceRegionType,
    trim(b.status) as ComplianceRegionStatus,
    trim(b.compliance_region_iso_identifier) as ComplianceRegionISOID,
    trim(b.iso_subdivision_code) as ComplianceRegionISOSubDivisionCode,
    trim(b.identifier) AS ComplianceRegionIdentifier,
    c.CountryID as CountryID,
    pcr.ComplianceRegionID AS ParentComplianceRegionID,
    trim(b.availability) as ComplianceRegionAvailability,
    trim(b.service_center_available_sec_roles) as ServiceCenterAvailableSECRoles,
    trim(b.scheduled_portfolio_change_summary_unc_trigger_time_of_day) as SchedulePortfolioChangeSummaryUNCTriggerTimeOfDay,
    trim(b.disabled_unc_types) as DisabledUNCTypes,
    trim(b.default_to_address) as DefaultEmailToAddress,
    trim(b.default_cc_address) as DefaultEmailCopyAddress,
    trim(b.authorization_notification_default_to_address) as AuthorizationNotificationDefaultEmailToAddress,  
    trim(b.authorization_notification_default_cc_address) as AuthorirzationNotificationDefaultEmailCopyAddess,
    trim(b.adhoc_push_notification_email_address) as AdhocPushNotificationEmailToAddress,
    trim(b.utility_error_default_cc_address) as UtilityErrorDefaultEmailCopyAddress,
    trim(b.granting_extensions_days) as GrantingExtensionDays,
    trim(b.outstanding_exception_threshold_days) as OutstandingExceptonThresholdDays,
    trim(b.newly_opened_accounts_grace_period_days) as NewlyOpenedAccountGracePeriodDays,
    trim(b.existing_accounts_grace_period_days) as ExistingAccountGracePeriodDays,
    trim(b.pre_clear_expiration_days) as PreClearExpirationDays,
    trim(b.extended_inactivity_days_inactive) as ExtendedInactivityDaysInactive,
    trim(b.service_center_early_alert_days) as ServiceCenterEarlyAlertDays,
    trim(b.inspection_auto_purge_days) as InspectionAndPurgeDays,
    trim(b.enable_service_center) as EnableServiceCenter,
    trim(b.auto_enrolled_service_center) as AutoEnrolledServiceCenter,
    trim(b.enable_self_clear) as EnableSelfClear,
    trim(b.enable_pre_clear) as EnablePreClear,
    trim(b.enable_response_to_le_and_pr) as EnableResponseLateEntryPreviousRestriction,
    trim(b.enable_financial_interest_tracking) as EnableFinancialInterestTracking,
    trim(b.enable_index_search) as EnableIndexSearch,
    trim(b.email_marked_as_private) as EmailMarkedAsPrivate,
    trim(b.enable_at_count) as EnableATCount,
    trim(b.allow_reopen_auto_hr_account) as AllowReOpenAutoAccount,
    trim(b.enable_anonymity) as EnableAnonymity,
    trim(b.covered_person_eligibility) as CoveredPersonEligibility,
    trim(b.require_financial_interest_comments) as RequireFinancialInterestComment,
    trim(b.enable_financial_interest_acknowledgement) as EnableFinancialInterestAcknowledgement,
    trim(b.enable_training_modal) as EnableTrainingModal,
    trim(b.show_override_self_clear_expiration_fields) as ShowOverrideSelfClearExpirationFields,
    trim(b.enable_confirmation_navigation_objects) as EnableConfirmationNavigationObjects,
    trim(b.enable_personal_information_section) as EnablePersonalInformationSection,
    trim(b.disable_type_along_search) as DisableTypeAlongSearch,
    case 
        when lower(trim(b.discipline_setting)) = 'enabled' then true
        when lower(trim(b.discipline_setting)) = 'disabled' then false
        when lower(trim(b.discipline_setting)) = 'expanded discipline configuration' then true
    else null end as EnableDisciplineSetting,
    trim(b.previously_restricted_opt_in) as EnablePreviouslyRestrictedOptIn,
    trim(b.upload_or_associate_authorization_forms) as UploadOrAssociateAuthorizationForms,
    trim(b.auto_enroll_brokers) as AutoEnrollBrokers,
    trim(b.enable_time_to_holdings) as EnableTimeToHoldings,
    trim(b.third_party_level_of_access) as ThirdPartyLevelOfAccess,
    trim(b.third_party_scheduled_portfolio_change_summary_unc_trigger_time_of_day) as ThirdPartyPortfolioChangeTriggerTime,
    NULL as SourceCreatedDate,
    b.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    m.SourceSystemID as SourceSystemID
FROM 
    gds_grdm_raw.kics_compliance_region_v1 b
LEFT JOIN gds_grdm_int.ComplianceRegion cr 
    ON trim(cr.ComplianceRegionNumber) = trim(b.compliance_region_id)
LEFT JOIN gds_grdm_int.ComplianceRegion pcr 
    ON trim(pcr.ComplianceRegionNumber) = trim(b.immediate_parent_compliance_region_id)  
LEFT JOIN 
    gds_ref_int.country c 
    ON trim(lower(b.identifier)) = trim(lower(c.CountryISOCode))
LEFT JOIN 
    gds.MetaSourceSystem m 
    ON m.SourceSystemName = 'KICS'
WHERE 
    b.gds_batch_id = wid_GDSBatchID