SELECT 

    trim(lc.list_code_id) as BondDisposalNumber,
    trim(lc.short_name) as BondDisposalName,
    coalesce(bd.BondDisposalBusinessName, lc.short_name) as BondDisposalBusinessName,
    trim(lc.description) as BondDisposalDescription,
    coalesce(cr.ComplianceRegionID, -1) as ComplianceRegionID,
	lc.start_effective_date AS	BondDisposalEffectiveStartDate,
	lc.end_effective_date AS BondDisposalEffectiveEndDate,
	lc.identifier AS BondDisposalIdentifier,
	lc.parent_list_code_id AS ParentBondDisposalListCodeNumber,
	lc.associated_security_type AS	BondDisposalAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS BondDisposalIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	BondDisposalSICCode,
	lc.show_acknowledgement_checkbox AS	BondDisposalShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS BondDisposalRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS BondDisposalFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	BondDisposalIsAccountTypeEligibleForBrokerageImport,    
    NULL as SourceCreatedDate,
    lc.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(s.SourceSystemID, -1) as SourceSystemID
FROM 
    gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
    gds_grdm_int.BondDisposal bd 
    ON trim(lower(lc.list_code_id)) = trim(lower(bd.BondDisposalNumber))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON trim(lower(lc.compliance_region_id)) = trim(lower(cr.ComplianceRegionNumber))
LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
WHERE 
    lc.gds_batch_id = wid_GDSBatchID
    AND TRIM(lc.list_code_type) = 'Bond Disposed'
