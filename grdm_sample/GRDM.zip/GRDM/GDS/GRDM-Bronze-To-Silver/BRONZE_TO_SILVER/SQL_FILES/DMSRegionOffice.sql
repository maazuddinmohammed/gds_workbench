
SELECT * except(RN) FROM (
SELECT deng.locationOIDH as locationOIDH,
deng.OfficeNumber as OfficeNumber,
deng.City as City,
deng.State as State,
deng.Country as Country,
deng.Count as Count,
er.EngagementRegionID as EngagementRegionID,
coalesce(deng.IsActive,true) as RegionIsActive,
current_timestamp() as SourceCreatedDate ,
current_timestamp() as SourceUpdatedDate ,
current_user() as SourceCreatedBy ,
current_user() as SourceUpdatedBy ,
deng.source_system_id as SourceSystemID,
ROW_NUMBER() OVER(PARTITION BY deng.locationOIDH,deng.OfficeNumber,deng.City,deng.State,deng.Country,deng.Count,er.EngagementRegionID,coalesce(deng.IsActive,true) order by deng.RegionOfficeId desc) AS RN
FROM gds_grdm_raw.dms_regionoffice as deng 
LEFT JOIN gds_grdm_int.dmsentity as e ON deng.EntityID = e.SourceSystemEntityID
LEFT JOIN gds_grdm_int.dmsengagement as en  ON en.EntityId = e.EntityId AND coalesce(en.RMDId,-1) = coalesce(deng.RMDId,-1)
LEFT JOIN gds_grdm_int.dmsengagementregion as er ON er.EngagementID = en.EngagementId AND TRIM(deng.region) = TRIM(er.Region) AND TRIM(deng.regionCode) = TRIM(er.RegionCode) AND TRIM(deng.AppliedFirmAction) = TRIM(er.AppliedFirmAction) AND TRIM(deng.RestrictionReason) = TRIM(deng.RestrictionReason) AND TRIM(deng.RestrictionType) = TRIM(er.RestrictionType) AND deng.IsActive = er.EngagementRegionIsActive
WHERE deng.gds_batch_id = wid_GDSBatchID AND deng.EntityID IS NOT NULL
) WHERE RN = 1
UNION ALL
SELECT * except(RN) FROM (
SELECT 
deng.locationOIDH as locationOIDH,
deng.OfficeNumber as OfficeNumber,
deng.City as City,
deng.State as State,
deng.Country as Country,
deng.Count as Count,
er.EngagementRegionID as EngagementRegionID,
coalesce(deng.IsActive,true) as RegionIsActive,
current_timestamp() as SourceCreatedDate ,
current_timestamp() as SourceUpdatedDate ,
current_user() as SourceCreatedBy ,
current_user() as SourceUpdatedBy ,
deng.source_system_id as SourceSystemID,
ROW_NUMBER() OVER(PARTITION BY deng.locationOIDH,deng.OfficeNumber,deng.City,deng.State,deng.Country,deng.Count,er.EngagementRegionID,coalesce(deng.IsActive,true) order by deng.RegionOfficeId desc) AS RN
FROM gds_grdm_raw.dms_regionoffice as deng 
LEFT JOIN gds_grdm_int.dmssecurity as s ON deng.SecurityID = s.SourceSystemSecurityId
LEFT JOIN gds_grdm_int.dmsengagement as en  ON en.SecurityId = s.SecurityId AND coalesce(en.RMDId,-1) = coalesce(deng.RMDId,-1)
LEFT JOIN gds_grdm_int.dmsengagementregion as er ON er.EngagementID = en.EngagementId AND TRIM(deng.region) = TRIM(er.Region) AND TRIM(deng.regionCode) = TRIM(er.RegionCode) AND TRIM(deng.AppliedFirmAction) = TRIM(er.AppliedFirmAction) AND TRIM(deng.RestrictionReason) = TRIM(deng.RestrictionReason) AND TRIM(deng.RestrictionType) = TRIM(er.RestrictionType) AND deng.IsActive = er.EngagementRegionIsActive
WHERE deng.gds_batch_id = wid_GDSBatchID AND deng.SecurityID IS NOT NULL
) WHERE RN = 1
