SELECT 
    trim(b.business_unit) as BusinessUnitNumber,
    trim(b.business_unit) as BusinessUnitName,
    coalesce(s.BusinessUnitBusinessName, trim(b.business_unit)) as BusinessUnitBusinessName,
    trim(b.business_unit) as BusinessUnitDescription,
    NULL as SourceCreatedDate,
    NULL as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(m.SourceSystemID, -1) as SourceSystemID
FROM 
    gds_grdm_raw.kics_user_info_v1 b
LEFT JOIN 
    gds_grdm_int.BusinessUnit s 
    ON trim(lower(b.business_unit)) = trim(lower(s.BusinessUnitNumber))
LEFT JOIN 
    gds.MetaSourceSystem m 
    ON m.SourceSystemName = 'KICS'
WHERE 
    b.gds_batch_id = wid_GDSBatchID