SELECT 
    trim(b.isocountrycode) as CountryISOCode,
    trim(b.uncountrycode) as CountryUNCode,
    trim(b.country) as CountryName,
    CASE b.isactive WHEN 1 THEN 'True' ELSE 'False' END as CountryIsActive,
    NULL as SourceCreatedDate,
    NULL as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(m.SourceSystemID, -1) as SourceSystemID
FROM 
    gds_grdm_raw.sntl_x_country b
LEFT JOIN 
    gds.MetaSourceSystem m 
    ON m.SourceSystemName = 'SNTL'
WHERE 
    b.gds_batch_id = wid_GDSBatchID