SELECT 
  trim(fag.firm_action_group_id) as FirmActionGroupNumber,
  trim(fag.firm_action_group_state) as FirmActionGroupState,
  trim(fag.auto_process_to) as FirmActionGroupAutoProcessFinalState,
  trim(fag.firm_action_group_current_action) as FirmActionGroupCurrentAction,
  trim(fag.review_comments) as FirmActionGroupReviewerComment,
  cr.ComplianceRegionID as ComplianceRegionID,
  trim(fag.auto_process) as IsAutoProcess,
  trim(fag.is_action_group_retroactive) as IsRetroactive,
  current_timestamp as SourceCreatedDate,
  fag.last_change_time as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  fag.last_change_user as SourceUpdatedBy,
  ms.SourceSystemID as SourceSystemID
FROM 
   gds_grdm_raw.kics_firm_action_group_v1 fag
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON trim(lower(fag.compliance_region_id)) = trim(lower(cr.ComplianceRegionNumber))
LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
WHERE 
  fag.gds_batch_id = wid_GDSBatchID