SELECT 
    coalesce(TRIM(a.question_set_id)) as QuestionSetNumber,
    coalesce(TRIM(a.question_set_name)) as QuestionSetName,
    coalesce(COALESCE(qs.QuestionSetBusinessName, TRIM(a.question_set_name)), 'N/A') as QuestionSetBusinessName,
    TRIM(a.question_set_name) as QuestionSetDescription,
    cr.ComplianceRegionID as ComplianceRegionID,
    NULL as SourceCreatedDate,
    NULL as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    sss.SourceSystemID as SourceSystemID
FROM
    (SELECT DISTINCT question_set_id, question_set_name, question_set_compliance_region_id, gds_batch_id FROM gds_grdm_raw.kics_question_group_question_v1) a
LEFT JOIN
    gds_grdm_int.QuestionSet qs ON LOWER(TRIM(qs.QuestionSetNumber)) = LOWER(TRIM(a.question_set_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr ON LOWER(TRIM(cr.ComplianceRegionNumber)) = LOWER(TRIM(a.question_set_compliance_region_id))
LEFT JOIN
    gds.MetaSourceSystem sss ON sss.SourceSystemName = 'KICS'
WHERE
    a.gds_batch_id = wid_GDSBatchID