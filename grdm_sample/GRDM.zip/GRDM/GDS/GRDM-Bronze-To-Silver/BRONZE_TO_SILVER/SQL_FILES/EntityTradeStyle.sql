SELECT 
    ts.Tradestyle as EntityTradeStyleNumber,
    ts.Tradestyle as EntityTradeStyleName,
    coalesce(ets.EntityTradeStyleBusinessName, ts.Tradestyle) as EntityTradeStyleBusinessName,
    ts.Tradestyle as EntityTradeStyleDescription, 
    NULL as SourceCreatedDate, 
    NULL as SourceUpdatedDate, 
    NULL as SourceCreatedBy, 
    NULL as SourceUpdatedBy, 
    ms.SourceSystemID AS SourceSystemID
FROM (
    SELECT DISTINCT 
        trim(trade_style) as Tradestyle ,gds_batch_id
    FROM 
        gds_grdm_raw.sntl_x_entity where TRIM(trade_style) <> '' AND trade_style IS NOT NULL
        --Where trade_style IS NOT NULL
    UNION 
    SELECT DISTINCT 
        trim(second_trade_style) as Tradestyle ,gds_batch_id
    FROM 
        gds_grdm_raw.sntl_x_entity where TRIM(second_trade_style) <> '' AND second_trade_style IS NOT NULL
        --Where second_trade_style IS NOT NULL
) ts
LEFT JOIN 
    gds_ref_int.entitytradestyle ets 
    ON trim(ts.Tradestyle) = trim(ets.EntityTradeStyleNumber)
LEFT JOIN 
    gds.metasourcesystem ms 
    ON ms.SourceSystemName = 'SENTINEL'
WHERE 
    ts.gds_batch_id = wid_GDSBatchID