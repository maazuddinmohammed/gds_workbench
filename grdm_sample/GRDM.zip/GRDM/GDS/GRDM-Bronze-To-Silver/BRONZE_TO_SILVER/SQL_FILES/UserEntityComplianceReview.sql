SELECT 
    TRIM(uaer.user_added_entity_review_id) AS UserEntityComplianceReviewNumber,
    uec.UserEntityComplianceID AS UserEntityComplianceID,
    cr.ComplianceRegionID AS ComplianceRegionID,
    TRIM(uaer.user_added_entity_action_type) AS UserEntityComplianceReviewActionType,
    el.EscalationLevelID AS EscalationLevelID,
    TRIM(eld.EscalationLevelID) AS EscalationDisciplineLevelID,
    TRIM(uaer.user_added_entity_review_case_id) as UserEntityComplianceReviewCaseID,
    TRIM(uaer.reviewer_comments) AS UserEntityComplianceReviewComment,
    uaer.user_added_entity_start_monitoring_time AS UserEntityComplianceReviewStartMonitoringTime,
    uaer.extension_expiration_date AS UserEntityComplianceReviewExtensionExpirationTime,
    uaer.escalation_time AS UserEntityComplianceReviewEscalationTime,
    uaer.extension_granted_date AS UserEntityComplianceReviewExtensionGrantedTime,
    uaer.comment_saved_time AS UserEntityComplianceReviewCommentSaveTime,
    TRIM(uaer.admin_action) AS UserEntityComplianceReviewAdminAction,
    uaer.admin_action_time AS UserEntityComplianceReviewAdminActionTime,
    uaer.disciplined_time AS UserEntityComplianceReviewDisciplinedTime,
    TRIM(uaer.status) AS UserEntityComplianceReviewStatus,
    uaer.last_change_time AS SourceCreatedDate,
    uaer.last_change_time AS SourceUpdatedDate,    
    TRIM(uaer.last_change_user) AS SourceCreatedBy,
    TRIM(uaer.last_change_user) AS SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
FROM 
    gds_grdm_raw.kics_user_added_entity_review_v1 uaer
LEFT JOIN 
    gds_grdm_int.v_UserEntityCompliance uec 
    ON LOWER(TRIM(uec.UserEntityComplianceNumber)) = LOWER(TRIM(uaer.user_added_entity_id)) 
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON LOWER(TRIM(cr.ComplianceRegionNumber)) = LOWER(TRIM(uaer.compliance_region_id))
LEFT JOIN 
    gds_grdm_int.EscalationLevel el 
    ON LOWER(TRIM(el.EscalationLevelNumber)) = LOWER(TRIM(uaer.escalation_level_id))
LEFT JOIN 
    gds_grdm_int.EscalationLevel eld
    ON LOWER(TRIM(el.EscalationLevelNumber)) = LOWER(TRIM(uaer.discipline_level_id))
LEFT JOIN 
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE 
    uaer.gds_batch_id = wid_GDSBatchID
