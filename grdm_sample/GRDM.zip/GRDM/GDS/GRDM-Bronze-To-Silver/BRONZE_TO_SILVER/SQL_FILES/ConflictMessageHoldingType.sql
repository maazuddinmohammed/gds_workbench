SELECT 
    coalesce(cm.ConflictMessageID, -1) as ConflictMessageID,
    coalesce(ht.HoldingTypeID, -1) as HoldingTypeID,
    NULL as SourceCreatedDate, 
    NULL as SourceUpdatedDate, 
    NULL as SourceCreatedBy, 
    NULL as SourceUpdatedBy, 
    coalesce(s.SourceSystemID, -1) as SourceSystemID
FROM 
    gds_grdm_raw.kics_question_group_submission_description_v1 qgsd
LEFT JOIN 
    gds_grdm_int.ConflictMessage cm 
    ON LOWER(TRIM(cm.ConflictMessageNumber)) = LOWER(TRIM(qgsd.question_group_submission_description_id))
LEFT JOIN 
    gds_grdm_int.HoldingType ht 
    ON LOWER(TRIM(ht.HoldingTypeNumber)) = LOWER(TRIM(qgsd.holding_type))
LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
WHERE 
    qgsd.gds_batch_id = wid_BatchID