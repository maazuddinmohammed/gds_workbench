
SELECT 
dent.EntityID as SourceSystemEntityID,
coalesce(dent.IsActive,true) as EntityIsActive,
IsActiveReason ,
EntityType ,
LastUpdatedDate	,
LastUpdatedUser	,
IsSECRegistrant	,
BrokerageHolderCount	,
FinancialHolderCount	,
LenderHolderCount	,
Published	,
Diversified	,
EntityIdDMS	,
Pending	,
HolderCount	,
StockHolderCount	,
BondHolderCount	,
CryptoHolderCount	,
current_timestamp() as SourceCreatedDate ,
current_timestamp() as SourceUpdatedDate ,
current_user() as SourceCreatedBy ,
current_user() as SourceUpdatedBy ,
dent.source_system_id as SourceSystemID 
FROM gds_grdm_raw.dms_entity as dent
WHERE gds_batch_id = wid_GDSBatchID
