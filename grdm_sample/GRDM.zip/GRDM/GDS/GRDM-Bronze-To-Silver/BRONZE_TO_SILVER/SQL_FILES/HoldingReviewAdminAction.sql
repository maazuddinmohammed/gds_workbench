SELECT DISTINCT
  trim(a.admin_action) as HoldingReviewAdminActionNumber,
  trim(a.admin_action) as HoldingReviewAdminActionName,
  coalesce(hra.HoldingReviewActionBusinessName, trim(a.admin_action)) as HoldingReviewAdminActionBusinessName,
  trim(a.admin_action) as HoldingReviewAdminActionDescription,
  NULL as SourceCreatedDate,
  NULL as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  sys.SourceSystemID as SourceSystemID
FROM  gds_grdm_raw.v_kics_holding_review_v1 a
LEFT JOIN 
  gds_grdm_int.HoldingReviewAction hra 
  ON LOWER(TRIM(hra.HoldingReviewActionNumber)) = LOWER(TRIM(a.admin_action))
LEFT JOIN 
  gds.MetaSourceSystem sys 
  ON sys.SourceSystemName = 'KICS'
WHERE 
  a.gds_batch_id = wid_GDSBatchID