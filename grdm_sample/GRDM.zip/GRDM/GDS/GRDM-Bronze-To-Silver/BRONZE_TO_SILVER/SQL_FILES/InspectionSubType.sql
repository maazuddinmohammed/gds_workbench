SELECT 
    TRIM(lc.list_code_id) as InspectionSubTypeNumber,
    TRIM(lc.short_name) as InspectionSubTypeName,
    COALESCE(ist.InspectionSubTypeBusinessName, TRIM(lc.short_name)) as InspectionSubTypeBusinessName,
    TRIM(lc.description) as InspectionSubTypeDescription,
    cr.ComplianceRegionID as ComplianceRegionID,
	lc.start_effective_date AS	InspectionSubTypeEffectiveStartDate,
	lc.end_effective_date AS InspectionSubTypeEffectiveEndDate,
	lc.identifier AS InspectionSubTypeIdentifier,
	lc.parent_list_code_id AS ParentInspectionSubTypeListCodeNumber,
	lc.associated_security_type AS	InspectionSubTypeAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS InspectionSubTypeIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	InspectionSubTypeSICCode,
	lc.show_acknowledgement_checkbox AS	InspectionSubTypeShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS InspectionSubTypeRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS InspectionSubTypeFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	InspectionSubTypeIsAccountTypeEligibleForBrokerageImport,    
    NULL as SourceCreatedDate,
    lc.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    s.SourceSystemID as SourceSystemID
FROM 
    gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
    gds_grdm_int.InspectionSubType ist 
    ON TRIM(lc.list_code_id) = TRIM(ist.InspectionSubTypeNumber)
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON LOWER(TRIM(lc.compliance_region_id)) = LOWER(TRIM(cr.ComplianceRegionNumber))
LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
WHERE 
    lc.gds_batch_id = wid_GDSBatchID
    AND lc.list_code_type = 'Inspection Sub-Type'