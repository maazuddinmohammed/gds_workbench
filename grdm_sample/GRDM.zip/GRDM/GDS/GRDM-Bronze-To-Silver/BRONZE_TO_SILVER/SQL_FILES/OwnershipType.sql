SELECT 
    coalesce(TRIM(lc.list_code_id), 'N/A') as OwnershipTypeNumber,
    coalesce(TRIM(lc.short_name), 'N/A') as OwnershipTypeName,
    coalesce(ot.OwnershipTypeBusinessName, TRIM(lc.short_name)) as OwnershipTypeBusinessName,
    TRIM(lc.description) as OwnershipTypeDescription,
    coalesce(cr.ComplianceRegionID, -1) as ComplianceRegionID,
	lc.start_effective_date AS	OwnershipTypeEffectiveStartDate,
	lc.end_effective_date AS OwnershipTypeEffectiveEndDate,
	lc.identifier AS OwnershipTypeIdentifier,
	lc.parent_list_code_id AS ParentOwnershipTypeListCodeNumber,
	lc.associated_security_type AS	OwnershipTypeAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS OwnershipTypeIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	OwnershipTypeSICCode,
	lc.show_acknowledgement_checkbox AS	OwnershipTypeShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS OwnershipTypeRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS OwnershipTypeFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	OwnershipTypeIsAccountTypeEligibleForBrokerageImport,    
    NULL as SourceCreatedDate,
    lc.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(ms.SourceSystemID, -1) as SourceSystemID
FROM
    gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN
    gds_grdm_int.OwnershipType ot 
    ON TRIM(LOWER(lc.list_code_id)) = TRIM(LOWER(ot.OwnershipTypeNumber))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr 
    ON TRIM(LOWER(lc.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
LEFT JOIN
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE
    lc.gds_batch_id = wid_GDSBatchID
AND lc.list_code_type = 'Type of Ownership'