SELECT 
dsec.SecurityId           AS SecurityID,
dsse.Exchange             AS Exchange,
dsse.Symbol               AS Symbol,
current_timestamp()       AS SourceCreatedDate,
current_timestamp()       AS SourceUpdatedDate,
current_user()            AS SourceCreatedBy,
current_user()            AS SourceUpdatedBy,
dsse.source_system_id     AS SourceSystemID
FROM gds_grdm_raw.dms_securitysymbolexchange AS dsse
JOIN gds_grdm_int.DMSSecurity AS dsec ON dsse.SecurityId = dsec.SourceSystemSecurityId
WHERE dsse.gds_batch_id = wid_GDSBatchID
