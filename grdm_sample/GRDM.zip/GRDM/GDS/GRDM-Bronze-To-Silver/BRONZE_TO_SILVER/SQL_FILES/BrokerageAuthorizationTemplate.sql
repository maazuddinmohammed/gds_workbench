   SELECT
    distinct
    TRIM(bat1.brokerage_authorization_template_id) AS BrokerageAuthorizationTemplateNumber,
    TRIM(bat1.brokerage_authorization_template_name) AS BrokerageAuthorizationTemplateName,
    TRIM(bat1.status) AS BrokerageAuthorizationTemplateStatus,
    ec.EntityComplianceID,
    coalesce(l2.LanguageID,-1) AS LanguageID, ---Not matching
    bat1.move_to_production_time AS BrokerageAuthorizationTemplateProductionTime,
    u1.UserID AS BrokerageAuthorizationTemplateProductionUserID,
    bat1.archived_time AS BrokerageAuthorizationTemplateArchivedTime,
    u2.UserID AS BrokerageAuthorizationTemplateArchivedUserID,
    TRIM(bat1.brokerage_authorization_template_attachment_filename) AS BrokerageAuthorizationTemplateAttachmentFilename,
    bat1.brokerage_authorization_template_attachment_add_time AS BrokerageAuthorizationTemplateAttachmentAddTime,
    NULL AS SourceCreatedDate,
    bat1.last_change_time AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    s.SourceSystemID AS SourceSystemID
   FROM 
   gds_grdm_raw.kics_brokerage_authorization_template_v1 bat1
   LEFT JOIN 
    gds_grdm_int.User u1 
    ON TRIM(LOWER(u1.UserNumber)) = TRIM(LOWER(bat1.move_to_production_user_id))
  LEFT JOIN 
    gds_grdm_int.User u2 
    ON TRIM(LOWER(u2.UserNumber)) = TRIM(LOWER(bat1.archived_user))
  LEFT JOIN 
    gds_grdm_raw.kics_language_v1 kl
    ON trim(lower(kl.language_id)) = trim(lower(bat1.language_id))
    AND kl.gds_batch_id = bat1.gds_batch_id
  LEFT JOIN 
    gds_ref_int.Language l2 
    ON TRIM(LOWER(l2.LanguageISO1)) = TRIM(LOWER(kl.identifier))
  LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
  LEFT JOIN 
    gds_ref_int.Entity e 
    ON LOWER(TRIM(e.EntityNumber)) = LOWER(TRIM(bat1.entity_id))
    AND e.SourceSystemID = s.SourceSystemID
  LEFT JOIN 
    gds_grdm_int.EntityCompliance ec
    ON ec.EntityID = e.EntityID
  
 WHERE    bat1.gds_batch_id = wid_GDSBatchID

