SELECT
    TRIM(qgs.question_group_submission_case_id) AS QuestionGroupSubmissionNumber
    ,cm.ConflictMessageID AS ConflictMessageID
    ,cr1.ComplianceRegionID AS PrimaryComplianceRegionID
    ,cr2.ComplianceRegionID AS SecondaryComplianceRegionID
    ,h.HoldingID AS HoldingID
    ,l.LocationID AS LocationID
    ,u.UserID AS UserID
    ,up.UserProfileID AS UserProfileID
    ,sr.SECRoleID AS SECRoleID
    ,qt.QuestionTypeID AS QuestionTypeID
    ,wr.WaiverReasonID AS WaiverReasonID
    ,TRIM(qgs.waiver_case_id) as QuestionGroupSubmissionWaiverCaseID
    ,TRIM(qgs.question_group_submission_current_action) AS QuestionGroupSubmissionCurrentAction
    ,TRIM(qgs.self_clear_attempt_count) AS QuestionGroupSubmissionSelfClearAttempts
    ,TRIM(qgs.self_clear_review_count) AS QuestionGroupSubmissionSelfClearReviews
    ,TRIM(qgs.user_self_clear_comments) AS QuestionGroupSubmissionSelfClearComment
    ,TRIM(qgs.reviewer_self_clear_comments) AS QuestionGroupSubmissionSelfClearReviewerComment
    ,TRIM(qgs.question_group_submission_initial_sent_time) AS QuestionGroupSubmmionInitialSentTime
    ,TRIM(qgs.question_group_submission_initial_view_time) AS QuestionGroupSubmissionInitialViewTime
    ,TRIM(qgs.question_group_submission_email_sent_time) AS QuestionGroupSubmissionEmailSentTime
    ,TRIM(qgs.question_group_submission_reason) AS QuestionGroupSubmissionReason
    ,TRIM(qgs.threshold_time_to_allow_holding_to_be_removed_without_self_clear) AS QuestionGroupSubmissionThreshold
    ,TRIM(qgs.question_group_submission_lingering_state) AS QuestionGroupSubmissionLingeringState
    ,TRIM(qgs.question_group_submission_action_role) AS QuestionGroupSubmissionActionRole
    ,TRIM(qgs.reviewer_agree_with_self_clear_success_time) AS QuestionGroupSubmissionAgreedSelfClearSuccessTime
    ,TRIM(qgs.self_clear_expiration_email_time) AS QuestionGroupSubmissionSelfClearExpirationEmailTime
    ,TRIM(qgs.self_clear_expire_time) AS QuestionGroupSubmissionSelfClearExpirationTime
    ,TRIM(qgs.override_self_clear_days) AS QuestionGroupSubmissionOverrideSelfClearDays
    ,TRIM(qgs.waiver_expiration_time) AS QuestionGroupSubmissionWaiverExpirationTime
    ,TRIM(qgs.waiver_comments) AS QuestionGroupSubmissionWaiverComment
    ,TRIM(qgs.waiver_state) AS QuestionGroupSubmissionWaiverState
    ,TRIM(qgs.waiver_email_time) AS QuestionGroupSubmissionWaiverEmailTime
    ,TRIM(qgs.initial_delivery_question_types) AS QuestionGroupSubmissionInitialDeliveryQuestionTypes
    ,u2.UserID as QuestionGroupSubmissionLastChangeUserID
    ,TRIM(try_cast(qgs.is_question_group_submission_exempt as boolean)) AS IsExempt
    ,TRIM(try_cast(qgs.is_self_clear_days_overridden as boolean)) AS IsSelfClearDaysOverride
    ,TRIM(try_cast(qgs.is_service_center_update as boolean)) AS IsServiceCenterUpdate
    ,TRIM(try_cast(qgs.is_restriction_office_matched as boolean)) AS IsRestrictionOfficeMatched
    ,TRIM(try_cast(qgs.is_restricted_office_match_require_review as boolean)) AS IsRestrictedOfficeMatchRequireReview
    ,TRIM(try_cast(qgs.has_related_question_group_submission as boolean)) AS HasRelatedQuestionGroupSubmission
    ,TRIM(qgs.is_question_group_submission_originated_from_confirmed_preclear) AS HasOriginatedFromConfirmedPreClear  
    ,TRIM(qgs.is_question_group_submission_reason_ever_timecharged) AS IsReasonEverTimecharged  
    ,TRIM(qgs.is_third_party_user_update) AS IsThirdPartyUserUpdate  
    ,current_timestamp AS SourceCreatedDate
    ,qgs.last_change_time AS SourceUpdatedDate
    ,NULL AS SourceCreatedBy
    ,qgs.last_change_user AS SourceUpdatedBy
    ,ms.SourceSystemID AS SourceSystemID
  FROM gds_grdm_raw.v_kics_question_group_submission_v1 qgs
  LEFT JOIN gds_grdm_int.ConflictMessage cm 
    ON TRIM(LOWER(cm.ConflictMessageNumber)) = TRIM(LOWER(qgs.question_group_submission_description_id)) 
  LEFT JOIN gds_grdm_int.ComplianceRegion cr1 
    ON TRIM(LOWER(cr1.ComplianceRegionNumber)) = TRIM(LOWER(qgs.current_assigned_compliance_region_id))
  LEFT JOIN gds_grdm_int.ComplianceRegion cr2 
    ON TRIM(LOWER(cr2.ComplianceRegionNumber)) = TRIM(LOWER(qgs.current_secondary_compliance_region_id))
  LEFT JOIN gds_grdm_int.Holding h 
    ON TRIM(LOWER(h.HoldingNumber)) = TRIM(LOWER(qgs.holding_case_id))
  LEFT JOIN gds_grdm_int.Location l 
    ON TRIM(LOWER(l.LocationNumber)) = TRIM(LOWER(qgs.location_id))
  LEFT JOIN gds_grdm_int.User u 
    ON TRIM(LOWER(u.UserNumber)) = TRIM(LOWER(qgs.tracking_system_user_id))
  LEFT JOIN gds_grdm_int.User u2 
    ON TRIM(LOWER(u.UserNumber)) = TRIM(LOWER(qgs.waiver_last_change_user_id))
  LEFT JOIN gds_grdm_int.UserProfile up 
    ON TRIM(LOWER(up.UserProfileNumber)) = TRIM(LOWER(qgs.profile_id))
  LEFT JOIN gds_grdm_int.SECRole sr 
    ON TRIM(LOWER(sr.SECRoleNumber)) = TRIM(LOWER(qgs.sec_role))
  LEFT JOIN gds_grdm_int.QuestionType qt 
    ON TRIM(LOWER(qt.QuestionTypeNumber)) = TRIM(LOWER(qgs.question_type))
  LEFT JOIN gds_grdm_int.WaiverReason wr 
    ON TRIM(LOWER(wr.WaiverReasonNumber)) = TRIM(LOWER(qgs.waiver_reason_id))
  LEFT JOIN gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
  WHERE 
    qgs.gds_batch_id = wid_GDSBatchID