SELECT 
    TRIM(uad.user_added_entity_id) AS UserEntityComplianceNumber,
    u.UserID AS UserID,
    TRIM(uad.request_user_id) as RequestUserID,
    ec1.EntityComplianceID AS EntityComplianceID,
    ec.EntityComplianceID as PendingTransferEntityComplianceID,    
    cs.SecurityID AS SecurityID,
    cs1.SecurityID AS PendingTransferSecurityID,   
    se.SecurityExchangeID AS SecurityExchangeID,
    cr1.ComplianceRegionID AS ComplianceRegionID,
    cr2.ComplianceRegionID AS PrimaryComplianceRegionID,
    cr3.ComplianceRegionID AS SecondaryComplianceRegionID,
    cr4.ComplianceRegionID AS TransferredComplianceRegionID,
    cr5.ComplianceRegionID AS ReviewerComplianceRegionID,
    coalesce(fit.FinancialInterestTypeID,fitp.FinancialInterestTypeID) AS FinancialInterestTypeID,
    fist.FinancialInterestSubTypeID AS FinancialInterestSubTypeID,
    at.AccountTypeID AS AccountTypeID,
    b.BrokerageID AS BrokerageID,
    uad.action_time AS UserEntityComplianceActionTime,
    TRIM(uad.company) AS UserEntityComplianceCompany,
    TRIM(uad.identifier) AS UserEntityComplianceIdentifier,
    TRIM(uad.transferred_pending_associated_entity_security_type) AS UserEntityCompliancePendingEntitySecurityType,
    NULL AS UserEntityComplianceUserAssignmentStatus,  -- only exists in the History table for Kingland
    TRIM(uad.symbol) AS UserEntityComplianceSymbol, 
    TRIM(uad.user_added_entity_type) AS UserEntityComplianceType,
    TRIM(uad.user_added_entity_status) AS UserEntityComplianceStatus,
    TRIM(uad.description) AS UserEntityComplianceDescription,
    TRIM(uad.status_comments) AS UserEntityComplianceStatusComment,
    TRIM(uad.comments) AS UserEntityComplianceComment,
    TRIM(uad.street) AS UserEntityComplianceAddress,
    TRIM(uad.city) AS UserEntityComplianceCity,
    TRIM(uad.state_province) AS UserEntityComplianceState,
    TRIM(uad.postal) AS UserEntityCompliancePostalCode,
    c.CountryID AS CountryID,
    TRIM(uad.cusip) AS UserEntityComplianceCUSIP,
    TRIM(uad.isin) AS UserEntityComplianceISIN,
    TRIM(uad.sedol) AS UserEntityComplianceSEDOL,
    uad.replacement_action_acquisition_date AS UserEntityComplianceReplacementAcquisitionDate,
    TRIM(uad.replacement_action_acquisition_date_option) AS UserEntityComplianceAcquisitionDateOption,
    CASE WHEN uad.active = 'Y' THEN 'True' ELSE 'False' END AS UserEntityComplianceIsActive,
    TRIM(uad.attachment_required_time) AS AttachmentRequiredTime,
    current_timestamp AS SourceCreatedDate,
    uad.last_change_time AS SourceUpdatedDate,
    TRIM(uad.add_user) AS SourceCreatedBy,
    TRIM(uad.last_change_user) AS SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
FROM 
    gds_grdm_raw.v_kics_user_added_entity_v1 uad
LEFT JOIN 
    gds_grdm_int.User u 
    ON LOWER(TRIM(u.UserNumber)) = LOWER(TRIM(uad.tracking_system_user_id))
LEFT JOIN 
    gds_ref_int.Entity e 
    ON LOWER(TRIM(e.entitynumber)) = LOWER(TRIM(uad.transferred_pending_associated_entity_security_id))  
LEFT JOIN 
    gds_grdm_int.EntityCompliance ec 
    ON  ec.EntityID = e.entityid   
LEFT JOIN 
    gds_ref_int.Entity e2 
    ON LOWER(TRIM(e2.entitynumber)) = LOWER(TRIM(uad.associated_entity_security_id))      
LEFT JOIN 
    gds_grdm_int.EntityCompliance ec1 
    ON ec1.EntityID = e2.entityid    
LEFT JOIN 
    gds_grdm_int.Security cs 
    ON LOWER(TRIM(cs.SecurityNumber)) = LOWER(TRIM(uad.associated_entity_security_id))
LEFT JOIN 
    gds_grdm_int.Security cs1 
    ON LOWER(TRIM(cs1.SecurityNumber)) = LOWER(TRIM(uad.transferred_pending_associated_entity_security_id))    
LEFT JOIN 
    gds_grdm_int.SecurityExchange se 
    ON LOWER(TRIM(se.SecurityExchangeNumber)) = LOWER(TRIM(uad.exchange_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr1 
    ON LOWER(TRIM(cr1.ComplianceRegionNumber)) = LOWER(TRIM(uad.compliance_region_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr2 
    ON LOWER(TRIM(cr2.ComplianceRegionNumber)) = LOWER(TRIM(uad.current_assigned_compliance_region_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr3 
    ON LOWER(TRIM(cr3.ComplianceRegionNumber)) = LOWER(TRIM(uad.current_secondary_compliance_region_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr4 
    ON LOWER(TRIM(cr4.ComplianceRegionNumber)) = LOWER(TRIM(uad.transferred_compliance_region_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr5 
    ON LOWER(TRIM(cr5.ComplianceRegionNumber)) = LOWER(TRIM(uad.reviewer_compliance_region_id))
LEFT JOIN 
    gds_grdm_int.FinancialInterestSubType fist 
    ON LOWER(TRIM(fist.FinancialInterestSubTypeNumber)) = LOWER(TRIM(uad.financial_interest_sub_type_id))
 LEFT JOIN 
    gds_grdm_int.FinancialInterestType fit 
    ON LOWER(TRIM(fit.FinancialInterestTypeNumber)) = LOWER(TRIM(fist.ParentFinancialInterestSubTypeListCodeNumber))  
LEFT JOIN 
    gds_grdm_int.FinancialInterestType fitp 
    ON TRIM(LOWER(fitp.FinancialInterestTypeNumber)) = TRIM(LOWER(uad.financial_interest_sub_type_id))
LEFT JOIN 
    gds_grdm_int.AccountType at 
    ON LOWER(TRIM(at.AccountTypeNumber)) = LOWER(TRIM(uad.account_type_id))
LEFT JOIN 
    gds_grdm_int.Brokerage b 
    ON LOWER(TRIM(b.BrokerageNumber)) = LOWER(TRIM(uad.brokerage_import_entity_id))
LEFT JOIN 
    gds_ref_int.Country c 
    ON LOWER(TRIM(c.CountryISOCode)) = LOWER(TRIM(uad.country_id_of_origin))
LEFT JOIN 
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE 
    uad.gds_batch_id = wid_GDSBatchID 
    AND u.userID IS NOT NULL ----> Raw table can't join to the User table .. because some UserID's missing 

