SELECT 
    coalesce(TRIM(qgsr.question_group_submission_review_id), 'N/A') as QuestionGroupSubmissionReviewNumber,
    uec.UserEntityComplianceID as EntityComplianceID,
    s.SecurityID as SecurityID,
    u.UserID as UserID,
    cr1.ComplianceRegionID as PrimaryComplianceRegionID,
    cr2.ComplianceRegionID as SecondaryComplianceRegionID,
    el.EscalationLevelID as EscalationLevelID,
    coalesce(TRIM(qgsr.discipline_level_id), NULL) as EscalationDisciplineLevelID,
    h.HoldingID as HoldingID,
    h2.HoldingID as ReviewHoldingID,
    coalesce(TRIM(qgsr.question_group_submission_review_action_type), 'N/A') as QuestionGroupSubmissionReviewActionType,
    qgsr.escalation_time as QuestionGroupSubmissionReviewEscalationTime,
    qgsr.extension_expiration_date as QuestionGroupSubmissionReviewExtensionExpirationTime,
    qgsr.conflict_of_interest_message_record_start_monitoring_time as QuestionGroupSubmissionReviewConflictMonitoringTime,
    qgsr.extension_granted_date as QuestionGroupSubmissionReviewExtensionGrantedTime,
    qgsr.comment_saved_time as QuestionGroupSubmissionReviewCommentSaveTime,
    coalesce(TRIM(qgsr.reviewer_comments), 'N/A') as QuestionGroupSubmissionReviewComment,
    coalesce(TRIM(qgsr.admin_action), 'N/A') as QuestionGroupSubmissionReviewAdminAction,
    qgsr.admin_action_time as QuestionGroupSubmissionReviewAdminActionTime,
    qgsr.disciplined_time as QuestionGroupSubmissionReviewDisciplinedTime,
    coalesce(TRIM(qgsr.status), 'N/A') as QuestionGroupSubmissionReviewStatus,
    trim(qgsr.entity_security_type) as QuestionGroupSubmissionReviewEntitySecurityType,
    NULL as SourceCreatedDate,
    qgsr.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    coalesce(TRIM(qgsr.last_change_user), NULL) as SourceUpdatedBy,
    sss.SourceSystemID as SourceSystemID
FROM
    gds_grdm_raw.v_kics_question_group_submission_review_v1 qgsr
LEFT JOIN
    gds_grdm_int.QuestionGroupSubmission qgs ON TRIM(LOWER(qgs.QuestionGroupSubmissionNumber)) = TRIM(LOWER(qgsr.question_group_submission_review_case_id))
LEFT JOIN
    gds_grdm_int.UserEntityCompliance uec ON TRIM(LOWER(uec.UserEntityComplianceNumber)) = TRIM(LOWER(qgsr.entity_security_id))
LEFT JOIN
    gds_grdm_int.Security s ON TRIM(LOWER(s.SecurityNumber)) = TRIM(LOWER(qgsr.entity_security_id))
LEFT JOIN
    gds_grdm_int.User u ON TRIM(LOWER(u.UserNumber)) = TRIM(LOWER(qgsr.tracking_system_user_id))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr1 ON TRIM(LOWER(cr1.ComplianceRegionNumber)) = TRIM(LOWER(qgsr.current_assigned_compliance_region_id))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr2 ON TRIM(LOWER(cr2.ComplianceRegionNumber)) = TRIM(LOWER(qgsr.current_secondary_compliance_region_id))
LEFT JOIN
    gds_grdm_int.EscalationLevel el ON TRIM(LOWER(el.EscalationLevelNumber)) = TRIM(LOWER(qgsr.escalation_level_id))
LEFT JOIN
    gds_grdm_int.Holding h ON TRIM(LOWER(h.HoldingNumber)) = TRIM(LOWER(qgsr.holding_case_id))
LEFT JOIN
    gds_grdm_int.Holding h2 ON TRIM(LOWER(h2.HoldingNumber)) = TRIM(LOWER(qgsr.question_group_submission_review_case_id))
LEFT JOIN
    gds.MetaSourceSystem sss ON sss.SourceSystemName = 'KICS'
WHERE
    qgsr.gds_batch_id = wid_GDSBatchID