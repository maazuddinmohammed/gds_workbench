SELECT
    TRIM(qgacd.decision_tree_answer_id) AS QuestionGroupAnswerTreeNumber,
    cr.ComplianceRegionID, 
    q.QuestionID AS QuestionID,
    q2.QuestionID AS NextQuestionID,
    l2.LanguageID AS LanguageID,
    qgacd.answer_description_id AS QuestionGroupAnswerDescriptionID,
    TRIM(qgacd.decision_tree_answer_identifier) AS QuestionGroupAnswerTreeChosenID,
    TRIM(qgacd.action_if_chosen) AS QuestionGroupAnswerTreeChosenAction,
    TRIM(qgacd.answer_choice_type) AS QuestionGroupAnswerTreeChoiceType,
    TRIM(qgacd.answer_choice_number) AS QuestionGroupAnswerTreeChoiceOrder,
    TRIM(qgacd.answer_choice_text) AS QuestionGroupAnswerTreeChoiceText,
    TRIM(qgacd.supplemental_data_section_id) AS QuestionGroupAnswerTreeSupplementalDataSectionID,
    TRIM(qgacd.answer_description_style) AS QuestionGroupAnswerTreeStyle,
    TRIM(qgacd.answer_description_status) AS QuestionGroupAnswerTreeStatus,
    TRIM(qgacd.answer_description_name) AS QuestionGroupAnswerTreeName,
    TRIM(qgacd.answer_description_modification_number) AS QuestionGroupAnswerTreeModificationNumber,
    TRIM(qgacd.answer_description_identifier) AS QuestionGroupAnswerTreeIdentifier,
    TRIM(qgacd.answer_description_move_to_production_time) AS QuestionGroupAnswerTreeProductionTime,
    TRIM(qgacd.answer_description_move_to_production_user_id) AS QuestionGroupAnswerTreeProductionUserID,    
    TRIM(qgacd.answer_description_move_to_archive_time) AS QuestionGroupAnswerTreeArchiveTime,
    TRIM(qgacd.answer_description_move_to_archive_user_id) AS QuestionGroupAnswerTreeArchiveUserID,    
    TRIM(qgacd.is_supplemental_data_enabled) AS IsSupplementalDataEnabled,
    TRIM(qgacd.is_system_query_comparison_enabled) AS IsSystemQueryComparisonEnabled,
    NULL AS SourceCreatedDate,
    qgacd.last_change_time AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    s.SourceSystemID AS SourceSystemID
  FROM
    gds_grdm_raw.kics_question_group_answer_choice_and_decision_tree_v1 qgacd
  LEFT JOIN
    gds_grdm_int.Question q
    ON TRIM(LOWER(q.QuestionNumber)) = TRIM(LOWER(qgacd.question_id))
  LEFT JOIN
    gds_grdm_int.Question q2
    ON TRIM(LOWER(q2.QuestionNumber)) = TRIM(LOWER(qgacd.next_question_id))
  LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr
    ON LOWER(TRIM(cr.ComplianceRegionNumber)) = LOWER(TRIM(qgacd.answer_description_compliance_region_id)) 
  LEFT JOIN
    gds_grdm_raw.kics_language_v1 l1
    ON TRIM(LOWER(l1.language_id)) = TRIM(LOWER(qgacd.answer_description_language_id)) AND l1.gds_batch_id=qgacd.gds_batch_id
  LEFT JOIN
    gds_ref_int.Language l2
    ON TRIM(LOWER(l2.LanguageISO1)) = TRIM(LOWER(l1.identifier))
  LEFT JOIN
    gds.MetaSourceSystem s
    ON s.SourceSystemName = 'KICS'
  WHERE
    qgacd.gds_batch_id = wid_GDSBatchID 