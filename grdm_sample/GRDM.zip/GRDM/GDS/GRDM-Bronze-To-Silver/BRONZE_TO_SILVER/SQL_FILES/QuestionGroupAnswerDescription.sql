SELECT 
    coalesce(TRIM(qgad.answer_description_id), 'N/A') as QuestionGroupAnswerDescriptionNumber,
    coalesce(TRIM(qgad.answer_description_name), 'N/A') as QuestionGroupAnswerDescription,
    coalesce(TRIM(qgad.answer_description_style), 'N/A') as QuestionGroupAnswerDescriptionStyle,
    coalesce(TRIM(qgad.answer_description_status), 'N/A') as QuestionGroupAnswerDescriptionStatus,
    coalesce(TRIM(qgad.answer_description_modification_number), 'N/A') as QuestionGroupAnswerDescriptionModifications,
    l2.LanguageID as LanguageID,
    cr.ComplianceRegionID as ComplianceRegionID,
    u1.UserID as QuestionGroupAnswerDescriptionProductionUserID,
    qgad.answer_description_move_to_production_time as QuestionGroupAnswerDescriptionProductionTime,
    u2.UserID as QuestionGroupAnswerDescriptionArchiveUserID,
    qgad.answer_description_move_to_archive_time as QuestionGroupAnswerDescriptionArchiveTime,
    NULL as SourceCreatedDate,
    qgad.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    s.SourceSystemID as SourceSystemID
FROM
    gds_grdm_raw.kics_question_group_answer_description_v1 qgad
LEFT JOIN
    gds_grdm_raw.kics_language_v1 l1 ON TRIM(LOWER(l1.language_id)) = TRIM(LOWER(qgad.answer_description_language_id))
    and qgad.gds_batch_id=l1.gds_batch_id
LEFT JOIN
    gds_ref_int.language l2 ON TRIM(LOWER(l2.LanguageISO1)) = TRIM(LOWER(l1.identifier))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr ON TRIM(LOWER(cr.ComplianceRegionNumber)) = TRIM(LOWER(qgad.answer_description_compliance_region_id))
LEFT JOIN
    gds_grdm_int.User u1 ON TRIM(LOWER(u1.UserNumber)) = TRIM(LOWER(qgad.answer_description_move_to_production_user_id))
LEFT JOIN
    gds_grdm_int.User u2 ON TRIM(LOWER(u2.UserNumber)) = TRIM(LOWER(qgad.answer_description_move_to_archive_user_id))
LEFT JOIN
    gds.MetaSourceSystem s ON s.SourceSystemName = 'KICS'
WHERE
    qgad.gds_batch_id = wid_GDSBatchID