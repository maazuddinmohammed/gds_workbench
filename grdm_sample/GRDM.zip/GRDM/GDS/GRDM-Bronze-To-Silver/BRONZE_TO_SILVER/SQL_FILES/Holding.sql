SELECT
    TRIM(h.case_id) AS HoldingNumber,    
    u.UserID AS UserID,
    ht.HoldingTypeID AS HoldingTypeID,
    rbht.HoldingTypeID AS ReplacedByHoldingTypeID,
    rht.HoldingTypeID AS ReplacedHoldingTypeID,
    s.SecurityID AS SecurityID,
    ec.EntityComplianceID as EntityComplianceID,                                                  
    uec.UserEntityComplianceID as UserEntityComplianceID,
    up.UserProfileID AS UserProfileID,
    cr1.ComplianceRegionID AS PrimaryComplianceRegionID,
    cr2.ComplianceRegionID AS SecondaryComplianceRegionID,
    eca.EntityComplianceAcquisitionID AS EntityComplianceAcquisitionID,
    ecd.EntityComplianceDisposalID AS EntityComplianceDisposalID,
    ba.BondAcquisitionID AS BondAcquisitionID,
    bd.BondDisposalID AS BondDisposalID,
    sa.StockAcquisitionID AS StockAcquisitionID,
    sd.StockDisposalID AS StockDisposalID,
    mfa.MutualFundAcquisitionID AS MutualFundAcquisitionID,
    mfd.MutualFundDisposalID AS MutualFundDisposalID,
    uta.UnitInvestmentTrustAcquisitionID AS UnitInvestmentTrustAcquisitionID,
    utd.UnitInvestmentTrustDisposalID AS UnitInvestmentTrustDisposalID,
    fia.FinancialInterestAcquisitionID AS FinancialInterestAcquisitionID,
    fid.FinancialInterestDisposalID AS FinancialInterestDisposalID,
    TRIM(h.merge_record_insert_id) AS HoldingMergeRecordInsertID, 
    TRIM(h.merge_record_disposal_id) AS HoldingMergeRecordDisposalID,
    coalesce(fit.FinancialInterestTypeID,fitp.FinancialInterestTypeID) AS FinancialInterestTypeID,
    fist.FinancialInterestSubTypeID AS FinancialInterestSubTypeID,
    at.AccountTypeID AS AccountTypeID,
    TRIM(h.parent_user_added_holding_case_id) AS ParentHoldingUserID,
    h.acquisition_date  AS HoldingAcquisitionDate,
    try_cast(h.acquisition_entry_time as timestamp) AS HoldingAqusitionEntryTime,
    TRIM(h.disposal_date) AS HoldingDisposalDate,
    try_cast(h.disposal_entry_time  as timestamp) AS HoldingDisposalEntryTime,
    TRIM(h.action) AS HoldingAction,
    TRIM(h.disposal_comments) AS HoldingDisposalComment,
    h1.HoldingID AS ReplacementHoldingID,
    h3.HoldingID AS ReplacedByHoldingID,
    h2.HoldingID AS ParentHoldingID,
    TRIM(h.financial_interest_identifier) AS HoldingFinancialInterestIdentifier,
    TRIM(h.financial_interest_and_external_account_description) AS HoldingFinancialInterestExternalAccountDescription,
    try_cast(h.financial_interest_and_external_account_merge_declined_time  as timestamp) AS HoldingFinancialInterestExternalAccountDeclineTime,
    TRIM(h.financial_interest_comments) AS HoldingFinancialInterestComment,
    TRIM(h.external_account_account_identifier) AS HoldingExternalAccountID,
    TRIM(h.external_account_ownership) AS HoldingExternalAccountOwnership,
    try_cast (h.external_account_last_enable_auto_import_time  as timestamp) AS HoldingExternalAccountLastEnabledAutoImportTime,
    try_cast(h.external_account_waiver_expiration_date  as timestamp) AS HoldingExternalAccountWaiverExpirationDate,
    TRIM(h.external_account_waiver_wvcomments) AS HoldingExternalAccountWaiverComment,
    TRIM(h.external_account_disable_brokerage_import_review_comment) AS HoldingExternalAccountDisableBrokerImportReviewComment,
    try_cast(h.external_account_user_notification_send_time as timestamp) AS HoldingExternalAccountUserNotificationSendTime,
    try_cast(h.external_account_first_brokerage_import_time  as timestamp) AS HoldingExternalAccountFirstBrokerageImportTime,
    try_cast(h.external_account_last_brokerage_import_time  as timestamp) AS HoldingExternalAccountLastBrokerageImportTime,
    TRIM(h.external_account_normalized_identification) AS HoldingExternalAccountNormalizedIdentification,
    TRIM(h.brokerage_authorization_submission_state) AS HoldingBrokerageAuthorizationSubmitState,
    try_cast(h.brokerage_authorization_submission_submit_time  as timestamp) AS HoldingBrokerageAuthorizationSubmitTime,
    TRIM(h.brokerage_authorization_submission_reviewer_comment) AS HoldingBrokerageAuthorizationSubmitReviewerComment,
    TRIM(h.brokerage_authorization_submission_user_submit_comment) AS HoldingBrokerageAuthorizationUserSubmitComment,
    try_cast(h.brokerage_authorization_submission_approved_time  as timestamp) AS HoldingBrokerageAuthorizationSubmitApprovedTime,
    try_cast(h.brokerage_authorization_submission_submitted_to_broker_time  as timestamp) AS HoldingBrokerageAuthorizationSubmitToBrokerTime,
    TRIM(h.brokerage_authorization_submission_attachment_filename_array) AS HoldingBrokerageAuthorizationSubmitAttachmentFileArray,
    TRIM(h.brokerage_authorization_submission_attachment_add_date_array) AS HoldingBrokerageAuthorizationAttachmentAddDateArray,
    TRIM(h.brokerage_authorization_submission_attachment_service_center_provided_array) AS HoldingBrokerageAuthoizationSubmitAttachmentServiceCenterProvidedArray,
    TRIM(h.holding_attachment_filename_array) AS HoldingAttachmentFileArray,
    TRIM(h.holding_attachment_add_date_array) AS HoldingAttachmentAddDateArray,
    TRIM(h.holding_attachment_service_center_provided_array) AS HoldingAttachmentServiceCenterProvidedArray,
    '-1' AS HoldingLastChangedUserID,
    TRIM(h.is_third_party_user_update) AS IsThirdPartyUserUpdate,
    TRIM(h.is_third_party_user_update_attachment_array) AS IsThirdPartyUserUpdateAttachmentArray,
    TRIM(h.is_originated_from_preclear) AS HasOriginatedFromPreclear,
    TRIM(h.external_account_is_dropped_from_brokerage_import_file) AS IsDroppedFromBrokerageImportFile,
    TRIM(h.external_account_is_auto_update_enabled) AS IsAutoUpdateEnabled,
    TRIM(h.is_updated_by_service_center) AS IsServiceCenterUpdater,
    current_timestamp AS SourceCreatedDate,
    h.last_change_time AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    TRIM(h.last_change_user) AS SourceUpdatedBy,
    m.SourceSystemID AS SourceSystemID
  FROM gds_grdm_raw.v_kics_holding_v1 h
  LEFT JOIN gds.MetaSourceSystem m ON m.SourceSystemName = 'KICS'
  LEFT JOIN gds_grdm_int.User u ON TRIM(LOWER(u.UserNumber)) = TRIM(LOWER(h.tracking_system_user_id))
  LEFT JOIN gds_grdm_int.HoldingType ht ON TRIM(LOWER(ht.HoldingTypeNumber)) = TRIM(LOWER(h.holding_type))
  LEFT JOIN gds_grdm_int.HoldingType rht ON TRIM(LOWER(rht.HoldingTypeNumber)) = TRIM(LOWER(h.replaced_holding_type))
  LEFT JOIN gds_grdm_int.HoldingType rbht ON TRIM(LOWER(rbht.HoldingTypeNumber)) = TRIM(LOWER(h.replaced_by_holding_type))
  LEFT JOIN gds_grdm_int.Security s ON TRIM(LOWER(s.SecurityNumber)) = TRIM(LOWER(h.entity_security_id))
  LEFT JOIN gds_ref_int.Entity e ON e.EntityNumber = h.entity_security_id AND e.SourceSystemID = m.SourceSystemID
  LEFT JOIN gds_grdm_int.EntityCompliance ec ON ec.EntityID = e.EntityID
  LEFT JOIN gds_grdm_int.UserEntityCompliance uec ON uec.UserEntityComplianceNumber = h.entity_security_id AND uec.UserID  = u.UserID 
  LEFT JOIN gds_grdm_int.UserProfile up ON TRIM(LOWER(up.UserProfileNumber)) = TRIM(LOWER(h.profile_id))
  LEFT JOIN gds_grdm_int.ComplianceRegion cr1 ON TRIM(LOWER(cr1.ComplianceRegionNumber)) = TRIM(LOWER(h.current_assigned_compliance_region_id))
  LEFT JOIN gds_grdm_int.ComplianceRegion cr2 ON TRIM(LOWER(cr2.ComplianceRegionNumber)) = TRIM(LOWER(h.current_secondary_compliance_region_id))
  LEFT JOIN gds_grdm_int.StockAcquisition sa ON TRIM(LOWER(sa.StockAcquisitionNumber)) = TRIM(LOWER(h.acquisition_code_id))
  LEFT JOIN gds_grdm_int.StockDisposal sd ON TRIM(LOWER(sd.StockDisposalNumber)) = TRIM(LOWER(h.disposal_code_id))
  LEFT JOIN gds_grdm_int.MutualFundAcquisition mfa ON TRIM(LOWER(mfa.MutualFundAcquisitionNumber)) = TRIM(LOWER(h.acquisition_code_id))
  LEFT JOIN gds_grdm_int.MutualFundDisposal mfd ON TRIM(LOWER(mfd.MutualFundDisposalNumber)) = TRIM(LOWER(h.disposal_code_id))
  LEFT JOIN gds_grdm_int.UnitInvestmentTrustAcquisition uta ON TRIM(LOWER(uta.UnitInvestmentTrustAcquisitionNumber)) = TRIM(LOWER(h.acquisition_code_id))
  LEFT JOIN gds_grdm_int.UnitInvestmentTrustDisposal utd ON TRIM(LOWER(utd.UnitInvestmentTrustDisposalNumber)) = TRIM(LOWER(h.disposal_code_id))
  LEFT JOIN gds_grdm_int.FinancialInterestDisposal fid ON TRIM(LOWER(fid.FinancialInterestDisposalNumber)) = TRIM(LOWER(h.disposal_code_id))
  LEFT JOIN gds_grdm_int.FinancialInterestAcquisition fia ON TRIM(LOWER(fia.FinancialInterestAcquisitionNumber)) = TRIM(LOWER(h.acquisition_code_id))
  LEFT JOIN gds_grdm_int.FinancialInterestSubType fist ON TRIM(LOWER(fist.FinancialInterestSubTypeNumber)) = TRIM(LOWER(h.financial_interest_type_id))
  LEFT JOIN gds_grdm_int.FinancialInterestType fit ON TRIM(LOWER(fit.FinancialInterestTypeNumber))= fist.ParentFinancialInterestSubTypeListCodeNumber
  LEFT JOIN gds_grdm_int.FinancialInterestType fitp ON TRIM(LOWER(fitp.FinancialInterestTypeNumber)) = TRIM(LOWER(h.financial_interest_type_id))
  LEFT JOIN gds_grdm_int.AccountType at ON TRIM(LOWER(at.AccountTypeNumber)) = TRIM(LOWER(h.external_account_type_id))
  LEFT JOIN gds_grdm_int.Holding h1 ON TRIM(LOWER(h1.HoldingNumber)) = TRIM(LOWER(h.replaced_holding_case_id)) 
  LEFT JOIN gds_grdm_int.Holding h2 ON TRIM(LOWER(h2.HoldingNumber)) = TRIM(LOWER(h.parent_holding_case_id)) 
  LEFT JOIN gds_grdm_int.Holding h3 ON TRIM(LOWER(h3.HoldingNumber)) = TRIM(LOWER(h.replaced_by_holding_case_id)) 
  LEFT JOIN gds_grdm_int.EntityComplianceAcquisition eca ON eca.EntityComplianceAcquisitionNumber=h.acquisition_code_id
  LEFT JOIN gds_grdm_int.EntityComplianceDisposal ecd ON ecd.EntityComplianceDisposalNumber=h.disposal_code_id
  LEFT JOIN gds_grdm_int.BondAcquisition ba ON ba.BondAcquisitionNumber=h.acquisition_code_id
  LEFT JOIN gds_grdm_int.BondDisposal bd ON bd.BondDisposalNumber=h.disposal_code_id
  Where  h.gds_batch_id = wid_GDSBatchID   