SELECT 
    coalesce(cm.ConflictMessageID, -1) as ConflictMessageID,
    coalesce(sec.SECRoleID, -1) as SECRoleID,
    NULL as SourceCreatedDate, 
    NULL as SourceUpdatedDate, 
    NULL as SourceCreatedBy, 
    NULL as SourceUpdatedBy, 
    coalesce(s.SourceSystemID, -1) as SourceSystemID
FROM 
    gds_grdm_raw.kics_question_group_submission_description_v1 qgsd
LEFT JOIN 
    gds_grdm_int.ConflictMessage cm 
    ON LOWER(TRIM(cm.ConflictMessageNumber)) = LOWER(TRIM(qgsd.question_group_submission_description_id))
LEFT JOIN 
    gds_grdm_int.SECRole sec 
    ON LOWER(TRIM(sec.SECRoleNumber)) = LOWER(TRIM(qgsd.sec_role))
LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
WHERE 
    qgsd.gds_batch_id = wid_GDSBatchID