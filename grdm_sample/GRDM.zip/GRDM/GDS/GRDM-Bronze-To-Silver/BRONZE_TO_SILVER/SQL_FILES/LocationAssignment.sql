SELECT 
    TRIM(la.location_engagement_assignment_case_id) AS LocationAssignmentNumber,
    s.SecurityID AS SecurityID,
    ec.EntityComplianceID,
    l.LocationID AS LocationID,
    TRIM(la.assignment_status) AS LocationAssignmentStatus,
    TRIM(la.entity_security_type) AS LocationAssignmentEntitySecurityType,
    TRIM(la.engagement_location_type) AS EngagementLocationType,
    TRIM(la.engagement_comments) AS LocationAssignmentComment,
    current_timestamp AS SourceCreatedDate,
    NULL AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
FROM 
    gds_grdm_raw.kics_location_engagement_assignment_v1 la
LEFT JOIN 
    gds.MetaSourceSystem ms ON ms.SourceSystemName = 'KICS'    
LEFT JOIN 
    gds_ref_int.Entity e ON LOWER(TRIM(e.EntityNumber)) = LOWER(TRIM(la.entity_security_id)) AND e.SourceSystemID = ms.SourceSystemID
LEFT JOIN 
    gds_grdm_int.EntityCompliance ec ON e.EntityID = ec.EntityID
LEFT JOIN 
    gds_grdm_int.Security s ON LOWER(TRIM(s.SecurityNumber)) = LOWER(TRIM(la.entity_security_id))
LEFT JOIN 
    gds_grdm_int.Location l ON LOWER(TRIM(l.LocationNumber)) = LOWER(TRIM(la.location_id))
WHERE 
    la.gds_batch_id =  wid_GDSBatchID
    