SELECT 
dent.EntityId	as EntityId,
dena.AddressType	as AddressType,
dena.CountryCode	as CountryCode,
dena.CountryName	as CountryName,
dena.AddressLineOne	 as AddressLineOne,
dena.AddressLineTwo	as AddressLineTwo,
dena.PostalCode	as PostalCode,
dena.City	as City,
dena.StateProvinceCode	as StateProvinceCode,
dena.StateProvinceName	as StateProvinceName,
current_timestamp() as SourceCreatedDate ,
current_timestamp() as SourceUpdatedDate ,
current_user() as SourceCreatedBy ,
current_user() as SourceUpdatedBy ,
dena.source_system_id as SourceSystemID 
FROM gds_grdm_raw.dms_entityaddress as dena 
JOIN gds_grdm_int.dmsentity as dent ON dena.EntityId = dent.SourceSystemEntityID
WHERE dena.gds_batch_id = wid_GDSBatchID
