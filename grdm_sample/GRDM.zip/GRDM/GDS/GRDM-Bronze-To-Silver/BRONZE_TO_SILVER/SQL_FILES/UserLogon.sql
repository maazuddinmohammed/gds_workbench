SELECT DISTINCT
    u.UserID AS UserID,
    coalesce(ul.logon_time,ul.service_center_logon_time) AS UserLogonTime,
    CAST(coalesce(ul.logon_time,ul.service_center_logon_time) AS DATE) AS UserLogonDate,
    ul.service_center_logon_time AS UserLogonServiceCenterTime,
    ul.user_agent_string AS UserLogonAgentString,
    COALESCE(cr.ComplianceRegionID, -1) AS PrimaryComplianceRegionID,
    COALESCE(cr2.ComplianceRegionID, -1) AS SecondaryComplianceRegionID,
    NULL AS SourceCreatedDate,
    NULL AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
FROM gds_grdm_raw.v_kics_user_logon_history_v1 ul
LEFT JOIN 
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'    
LEFT JOIN 
    gds_grdm_int.User u 
    ON LOWER(TRIM(u.UserNumber)) = LOWER(TRIM(ul.tracking_system_user_id)) 
LEFT JOIN gds_grdm_int.ComplianceRegion cr 
    ON LOWER(TRIM(cr.ComplianceRegionNumber)) = LOWER(TRIM(ul.current_assigned_compliance_region_id))  
LEFT JOIN gds_grdm_int.ComplianceRegion cr2 
    ON LOWER(TRIM(cr2.ComplianceRegionNumber)) = LOWER(TRIM(ul.current_secondary_compliance_region_id))      
WHERE 
    ul.gds_batch_id = wid_GDSBatchID
    AND u.UserID IS NOT NULL