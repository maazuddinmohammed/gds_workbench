SELECT 

    trim(lc.list_code_id) as FinancialInterestAcquisitionNumber,
    trim(lc.short_name) as FinancialInterestAcquisitionName,
    coalesce(fia.FinancialInterestAcquisitionBusinessName, lc.short_name) as FinancialInterestAcquisitionBusinessName,
    trim(lc.description) as FinancialInterestAcquisitionDescription,
    coalesce(cr.ComplianceRegionID, -1) as ComplianceRegionID,
	lc.start_effective_date AS	FinancialInterestAcquisitionEffectiveStartDate,
	lc.end_effective_date AS FinancialInterestAcquisitionEffectiveEndDate,
	lc.identifier AS FinancialInterestAcquisitionIdentifier,
	lc.parent_list_code_id AS ParentFinancialInterestAcquisitionListCodeNumber,
	lc.associated_security_type AS	FinancialInterestAcquisitionAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS FinancialInterestAcquisitionIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	FinancialInterestAcquisitionSICCode,
	lc.show_acknowledgement_checkbox AS	FinancialInterestAcquisitionShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS FinancialInterestAcquisitionRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS FinancialInterestAcquisitionFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	FinancialInterestAcquisitionIsAccountTypeEligibleForBrokerageImport,    
    NULL as SourceCreatedDate,
    lc.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(s.SourceSystemID, -1) as SourceSystemID
FROM 
    gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
    gds_grdm_int.FinancialInterestAcquisition fia 
    ON trim(lower(lc.list_code_id)) = trim(lower(fia.FinancialInterestAcquisitionNumber))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON trim(lower(lc.compliance_region_id)) = trim(lower(cr.ComplianceRegionNumber))
LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
WHERE 
    lc.gds_batch_id = wid_GDSBatchID
    AND lc.list_code_type = 'Financial Interest Acquired'