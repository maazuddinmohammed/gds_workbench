SELECT 
  trim(fala.location_engagement_by_firm_action_id) as FirmActionLocationAssignmentNumber,
  fa.FirmActionID as FirmActionID,
  la.LocationAssignmentID as LocationAssignmentID,
  fala.last_change_time as SourceCreatedDate,
  NULL as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  sys.SourceSystemID as SourceSystemID
FROM 
  gds_grdm_raw.kics_location_engagement_by_firm_action_v1 fala
LEFT JOIN 
  gds_grdm_int.FirmAction fa 
  ON LOWER(TRIM(fa.FirmActionNumber)) = LOWER(TRIM(fala.firm_action_case_id))
LEFT JOIN 
  gds_grdm_int.LocationAssignment la 
  ON LOWER(TRIM(la.LocationAssignmentNumber)) = LOWER(TRIM(fala.location_engagement_assignment_case_id))
LEFT JOIN 
  gds.MetaSourceSystem sys 
  ON sys.SourceSystemName = 'KICS'
WHERE 
  fala.gds_batch_id = wid_GDSBatchID
