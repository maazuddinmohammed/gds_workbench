SELECT 
  trim(qgurs.user_answer_id) as QuestionGroupUserResponseSupplementNumber,
  u.UserID as UserID,
  q1.QuestionID as QuestionID,
  q3.QuestionID as UserQuestionID,
  q2.QuestionID as NextQuestionID,
  cr.ComplianceRegionID as ComplianceRegionID,
  crs.ComplianceRegionID as CurrentSecondaryComplianceRegionID,
  trim(qgurs.answer_choice_and_decision_tree_id) as QuestionGroupAnswerTreeID,
  qgs.QuestionGroupSubmissionID as QuestionGroupSubmissionID,
  h.HoldingID as HoldingID,
  qs.QuestionSetID as QuestionSetID,
  trim(user_question_set_case_id) as QuestionSetCaseID,
  trim(qgurs.user_answer_text) as QuestionGroupUserResponseSupplementText,
  trim(qgurs.reviewer_comment_on_user_answer) as QuestionGroupUserResponseSupplementReviewerComment,
  qgurs.review_time as QuestionGroupUserResponseSupplementReviewTime,
  trim(qgurs.self_clear_attempt_count) as QuestionGroupUserResponseSupplementSelfClearAttempts,
  trim(qgurs.question_set_question_type) as QuestionGroupUserResponseSupplementQuestionType,
  trim(qgurs.response_type) as QuestionGroupUserResponseSupplementResponseType,
  trim(qgurs.first_user_question_in_question_set) as QuestionGroupUserResponseSupplementFirstUserQuestionInQuestionSet,
  trim(qgurs.is_question_set_skipped) as IsQuestionSetSkipped,
  NULL as SourceCreatedDate,
  qgurs.last_change_time as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  trim(qgurs.last_change_user) as SourceUpdatedBy,
  sys.SourceSystemID as SourceSystemID
FROM 
  gds_grdm_raw.kics_question_group_user_response_for_supplemental_data_v1 qgurs
LEFT JOIN 
  gds_grdm_int.User u 
  ON LOWER(TRIM(u.UserNumber)) = LOWER(TRIM(qgurs.tracking_system_user_id))
LEFT JOIN 
  gds_grdm_int.Question q1 
  ON LOWER(TRIM(q1.QuestionNumber)) = LOWER(TRIM(qgurs.question_id))
LEFT JOIN 
  gds_grdm_int.Question q2 
  ON LOWER(TRIM(q2.QuestionNumber)) = LOWER(TRIM(qgurs.next_user_question_id))
LEFT JOIN 
  gds_grdm_int.Question q3 
  ON LOWER(TRIM(q3.QuestionNumber)) = LOWER(TRIM(qgurs.user_question_id))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON LOWER(TRIM(cr.ComplianceRegionNumber)) = LOWER(TRIM(qgurs.current_assigned_compliance_region_id))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion crs 
  ON LOWER(TRIM(crs.ComplianceRegionNumber)) = LOWER(TRIM(qgurs.current_secondary_compliance_region_id))
LEFT JOIN 
  gds_grdm_int.Holding h 
  ON LOWER(TRIM(h.HoldingNumber)) = LOWER(TRIM(qgurs.holding_case_id))
LEFT JOIN gds_grdm_int.QuestionGroupAnswerTree qga
    on LOWER(TRIM(qga.QuestionGroupAnswerTreeNumber)) = LOWER(TRIM(qgurs.answer_choice_and_decision_tree_id))
LEFT JOIN gds_grdm_int.QuestionGroupSubmission qgs
    on LOWER(TRIM(qgs.QuestionGroupSubmissionNumber)) = LOWER(TRIM(qgurs.question_group_submission_case_id))
LEFT JOIN gds_grdm_int.QuestionSet qs
  ON LOWER(TRIM(qs.QuestionSetNumber)) = LOWER(TRIM(qgurs.question_set_id))
LEFT JOIN 
  gds.MetaSourceSystem sys 
  ON sys.SourceSystemName = 'KICS'
WHERE 
  qgurs.gds_batch_id = wid_GDSBatchID