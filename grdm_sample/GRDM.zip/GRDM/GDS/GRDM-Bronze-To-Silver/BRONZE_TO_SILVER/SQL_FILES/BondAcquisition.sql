SELECT 

    trim(lc.list_code_id) as BondAcquisitionNumber,
    trim(lc.short_name) as BondAcquisitionName,
    coalesce(b.BondAcquisitionBusinessName, lc.short_name) as BondAcquisitionBusinessName,
    trim(lc.description) as BondAcquisitionDescription,
    coalesce(cr.ComplianceRegionID, -1) as ComplianceRegionID,
	lc.start_effective_date AS	BondAcquisitionEffectiveStartDate,
	lc.end_effective_date AS BondAcquisitionEffectiveEndDate,
	lc.identifier AS BondAcquisitionIdentifier,
	lc.parent_list_code_id AS ParentBondAcquisitionListCodeNumber,
	lc.associated_security_type AS	BondAcquisitionAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS BondAcquisitionIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	BondAcquisitionSICCode,
	lc.show_acknowledgement_checkbox AS	BondAcquisitionShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS BondAcquisitionRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS BondAcquisitionFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	BondAcquisitionIsAccountTypeEligibleForBrokerageImport,    
    NULL as SourceCreatedDate,
    lc.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(s.SourceSystemID, -1) as SourceSystemID
FROM 
    gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
    gds_grdm_int.BondAcquisition b 
    ON trim(lower(lc.list_code_id)) = trim(lower(b.BondAcquisitionNumber))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON trim(lower(lc.compliance_region_id)) = trim(lower(cr.ComplianceRegionNumber))
LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
WHERE 
    lc.gds_batch_id = wid_GDSBatchID
    AND lc.list_code_type = 'Bond Acquired'