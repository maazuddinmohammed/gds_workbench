SELECT 
    TRIM(ppi.personal_profile_information_id) as PersonalProfileNumber,
    TRIM(ppi.personal_profile_information_attribute) as PersonalProfileAttribute,
    TRIM(ppi.personal_profile_information_text) as PersonalProfileDescription,
    TRIM(ppi.personal_profile_information_long)as PersonalProfileInformationLong,
    usr.UserID as UserID,
    ppt.PersonalProfileTypeID as PersonalProfileTypeID,
    cr1.ComplianceRegionID as PrimaryComplianceRegionID,
    cr2.ComplianceRegionID as SecondaryComplianceRegionID,
    current_timestamp as SourceCreatedDate,
    ppi.last_change_time as SourceUpdatedDate,
    TRIM(ppi.last_change_user) as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    ms.SourceSystemID as SourceSystemID
FROM
    gds_grdm_raw.v_kics_personal_profile_information_v1 ppi
LEFT JOIN
    gds.MetaSourceSystem ms
    ON ms.SourceSystemName = 'KICS'    
LEFT JOIN
    gds_grdm_int.User usr
    ON LOWER(TRIM(ppi.tracking_system_user_id)) = LOWER(TRIM(usr.UserNumber)) AND usr.SourceSystemID = ms.SourceSystemID
LEFT JOIN
    gds_grdm_int.PersonalProfileType ppt
    ON LOWER(TRIM(ppi.personal_profile_information_type)) = LOWER(TRIM(ppt.PersonalProfileTypeNumber)) 
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr1
    ON LOWER(TRIM(cr1.ComplianceRegionNumber)) = LOWER(TRIM(ppi.current_assigned_compliance_region_id)) 
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr2
    ON LOWER(TRIM(cr2.ComplianceRegionNumber)) = LOWER(TRIM(ppi.current_secondary_compliance_region_id)) 
WHERE
    ppi.gds_batch_id = wid_GDSBatchID
    