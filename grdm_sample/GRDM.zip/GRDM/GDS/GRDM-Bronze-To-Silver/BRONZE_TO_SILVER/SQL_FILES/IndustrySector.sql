     SELECT 
        TRIM(is.SectorID) AS IndustrySectorNumber, 
        TRIM(is.IndustrySector) AS IndustrySectorName,
        COALESCE(sb.IndustrySectorBusinessName, is.IndustrySector) AS IndustrySectorBusinessName,
        TRIM(is.IndustrySector) AS IndustrySectorDescription,
        is.IsActive AS IndustrySectorIsActive,
        NULL AS SourceCreatedDate,
        NULL AS SourceUpdatedDate,
        NULL AS SourceCreatedBy,
        NULL AS SourceUpdatedBy,
        s.SourceSystemID AS SourceSystemID
    FROM 
        gds_grdm_raw.sntl_x_industrysector is
    LEFT JOIN 
        gds_grdm_int.IndustrySector sb ON sb.IndustrySectorNumber = is.SectorId
    LEFT JOIN 
        gds.MetaSourceSystem s ON s.SourceSystemCode = 'SNTL'
    WHERE 
        is.gds_batch_id =  wid_GDSBatchID AND is.SectorId IS NOT NULL
 