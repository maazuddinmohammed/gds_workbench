SELECT 
    TRIM(kv.identifier) as LanguageISO1, 
    TRIM(kv.identifier2) as LanguageISO2, 
    TRIM(kv.language_name) as LanguageName, 
    COALESCE(l.LanguageName, TRIM(kv.language_name)) as LanguageBusinessName, 
    TRIM(kv.language_status) AS LanguageStatus,
    NULL as SourceCreatedDate, 
    kv.last_change_time as SourceUpdatedDate, 
    NULL as SourceCreatedBy, 
    NULL as SourceUpdatedBy, 
    s.SourceSystemID as SourceSystemID
FROM 
     (select * from gds_grdm_raw.kics_language_v1
 qualify row_number() over(partition by identifier,gds_batch_id order by last_change_time desc) = 1) kv
LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
LEFT JOIN 
    gds_ref_int.Language l 
    ON TRIM(LOWER(l.LanguageISO1)) = TRIM(LOWER(kv.identifier))
WHERE 
    kv.gds_batch_id = wid_GDSBatchID