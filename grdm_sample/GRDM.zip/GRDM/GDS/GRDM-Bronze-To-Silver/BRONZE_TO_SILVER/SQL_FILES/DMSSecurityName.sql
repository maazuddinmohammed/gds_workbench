SELECT * except(RN) FROM (
SELECT 
dsec.SecurityId           AS SecurityID,
coalesce(dsn.Active,true)              AS SecurityNameIsActive,
dsn.NameType              AS NameType,
dsn.NameValue             AS NameValue,
dsn.Transactionid as Transactionid,
current_timestamp()       AS SourceCreatedDate,
current_timestamp()       AS SourceUpdatedDate,
current_user()            AS SourceCreatedBy,
current_user()            AS SourceUpdatedBy,
dsn.source_system_id      AS SourceSystemID,
ROW_NUMBER() OVER(PARTITION BY dsn.TransactionId,dsn.NameType,dsn.NameValue,dsec.SecurityId,coalesce(dsn.Active,true) order by dsn.SecurityNameId desc) AS RN
FROM gds_grdm_raw.dms_securityname AS dsn
JOIN gds_grdm_int.DMSSecurity AS dsec ON dsn.SecurityId = dsec.SourceSystemSecurityId
WHERE dsn.gds_batch_id = wid_GDSBatchID
)
WHERE RN = 1