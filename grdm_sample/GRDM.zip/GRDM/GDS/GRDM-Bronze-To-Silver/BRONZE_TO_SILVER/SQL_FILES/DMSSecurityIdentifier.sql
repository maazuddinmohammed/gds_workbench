SELECT 
dsec.SecurityId           AS SecurityID,
dsi.IdentifierType        AS IdentifierType,
dsi.IdentifierValue       AS IdentifierValue,
current_timestamp()       AS SourceCreatedDate,
current_timestamp()       AS SourceUpdatedDate,
current_user()            AS SourceCreatedBy,
current_user()            AS SourceUpdatedBy,
dsi.source_system_id      AS SourceSystemID
FROM gds_grdm_raw.dms_securityidentifier AS dsi
JOIN gds_grdm_int.DMSSecurity AS dsec ON dsi.SecurityId = dsec.SourceSystemSecurityId
WHERE dsi.gds_batch_id = wid_GDSBatchID
