SELECT * except(RN) FROM (
SELECT 
Region	,
RestrictionType	,
RestrictionReason	,
AppliedFirmAction	,
en.EngagementID	as EngagementID,
RegionCode	,
coalesce(deng.IsActive,true) as EngagementRegionIsActive,
current_timestamp() as SourceCreatedDate ,
current_timestamp() as SourceUpdatedDate ,
current_user() as SourceCreatedBy ,
current_user() as SourceUpdatedBy ,
deng.source_system_id as SourceSystemID,
ROW_NUMBER() OVER(PARTITION BY deng.Region,deng.RestrictionType,deng.RestrictionReason,deng.AppliedFirmAction,deng.EntityID,deng.RegionCode,deng.IsActive order by deng.EngagementRegionId desc) AS RN
FROM gds_grdm_raw.dms_engagementregion as deng 
LEFT JOIN gds_grdm_int.dmsentity as e ON deng.EntityID = e.SourceSystemEntityID
LEFT JOIN gds_grdm_int.dmsengagement as en  ON en.EntityId = e.EntityId AND coalesce(en.RMDId,-1) = coalesce(deng.RMDId,-1)
WHERE deng.gds_batch_id = wid_GDSBatchID AND deng.EntityID IS NOT NULL AND deng.IsActive = true) WHERE RN = 1
UNION ALL
SELECT 
Region	,
RestrictionType	,
RestrictionReason	,
AppliedFirmAction	,
en.EngagementID	as EngagementID,
RegionCode	,
coalesce(deng.IsActive,true) as EngagementRegionIsActive,
current_timestamp() as SourceCreatedDate ,
current_timestamp() as SourceUpdatedDate ,
current_user() as SourceCreatedBy ,
current_user() as SourceUpdatedBy ,
deng.source_system_id as SourceSystemID
FROM gds_grdm_raw.dms_engagementregion as deng 
LEFT JOIN gds_grdm_int.dmsentity as e ON deng.EntityID = e.SourceSystemEntityID
LEFT JOIN gds_grdm_int.dmsengagement as en  ON en.EntityId = e.EntityId AND coalesce(en.RMDId,-1) = coalesce(deng.RMDId,-1)
WHERE deng.gds_batch_id = wid_GDSBatchID AND deng.EntityID IS NOT NULL AND deng.IsActive = false
UNION ALL
SELECT * except(RN) FROM (
SELECT 
Region	,
RestrictionType	,
RestrictionReason	,
AppliedFirmAction	,
en.EngagementID	as EngagementID,
RegionCode	,
coalesce(deng.IsActive,true) as EngagementRegionIsActive,
current_timestamp() as SourceCreatedDate ,
current_timestamp() as SourceUpdatedDate ,
current_user() as SourceCreatedBy ,
current_user() as SourceUpdatedBy ,
deng.source_system_id as SourceSystemID,
ROW_NUMBER() OVER(PARTITION BY deng.Region,deng.RestrictionType,deng.RestrictionReason,deng.AppliedFirmAction,deng.SecurityID,deng.RegionCode,deng.IsActive order by deng.EngagementRegionId desc) AS RN
FROM gds_grdm_raw.dms_engagementregion as deng 
LEFT JOIN gds_grdm_int.dmssecurity as s ON deng.SecurityID = s.SourceSystemSecurityId
LEFT JOIN gds_grdm_int.dmsengagement as en  ON en.SecurityId = s.SecurityId AND coalesce(en.RMDId,-1) = coalesce(deng.RMDId,-1)
WHERE deng.gds_batch_id = wid_GDSBatchID AND deng.SecurityID IS NOT NULL AND deng.IsActive = true)
WHERE RN = 1
UNION ALL
SELECT 
Region	,
RestrictionType	,
RestrictionReason	,
AppliedFirmAction	,
en.EngagementID	as EngagementID,
RegionCode	,
coalesce(deng.IsActive,true) as EngagementRegionIsActive,
current_timestamp() as SourceCreatedDate ,
current_timestamp() as SourceUpdatedDate ,
current_user() as SourceCreatedBy ,
current_user() as SourceUpdatedBy ,
deng.source_system_id as SourceSystemID 
FROM gds_grdm_raw.dms_engagementregion as deng 
LEFT JOIN gds_grdm_int.dmssecurity as s ON deng.SecurityID = s.SourceSystemSecurityId
LEFT JOIN gds_grdm_int.dmsengagement as en  ON en.SecurityId = s.SecurityId AND coalesce(en.RMDId,-1) = coalesce(deng.RMDId,-1)
WHERE deng.gds_batch_id = wid_GDSBatchID AND deng.SecurityID IS NOT NULL AND deng.IsActive = false
