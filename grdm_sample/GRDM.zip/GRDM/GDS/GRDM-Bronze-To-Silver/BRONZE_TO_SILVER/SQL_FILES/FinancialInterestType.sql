SELECT 
  trim(lc.list_code_id) as FinancialInterestTypeNumber,
  trim(lc.short_name) as FinancialInterestTypeName,
  coalesce(fit.FinancialInterestTypeBusinessName, trim(lc.short_name)) as FinancialInterestTypeBusinessName,
  trim(lc.description) as FinancialInterestTypeDescription,
  cr.ComplianceRegionID as ComplianceRegionID,
	lc.start_effective_date AS	FinancialInterestTypeEffectiveStartDate,
	lc.end_effective_date AS FinancialInterestTypeEffectiveEndDate,
	lc.identifier AS FinancialInterestTypeIdentifier,
	lc.parent_list_code_id AS ParentFinancialInterestTypeListCodeNumber,
	lc.associated_security_type AS	FinancialInterestTypeAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS FinancialInterestTypeIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	FinancialInterestTypeSICCode,
	lc.show_acknowledgement_checkbox AS	FinancialInterestTypeShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS FinancialInterestTypeRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS FinancialInterestTypeFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	FinancialInterestTypeIsAccountTypeEligibleForBrokerageImport,  
  NULL as SourceCreatedDate,
  lc.last_change_time as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  ms.SourceSystemID as SourceSystemID
FROM 
  gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
  gds_grdm_int.FinancialInterestType fit 
  ON trim(lower(lc.list_code_id)) = trim(lower(fit.FinancialInterestTypeNumber))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON trim(lower(lc.compliance_region_id)) = trim(lower(cr.ComplianceRegionNumber))
LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
WHERE 
  lc.gds_batch_id = wid_GDSBatchID
    AND lc.list_code_type = 'Financial Interest'