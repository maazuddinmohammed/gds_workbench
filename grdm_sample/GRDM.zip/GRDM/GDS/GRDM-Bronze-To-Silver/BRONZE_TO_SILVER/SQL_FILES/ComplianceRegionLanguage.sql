SELECT  
  trim(la.language_assignment_id) as ComplianceRegionLanguageNumber, 
  trim(la.language_assignment_name) as ComplianceRegionLanguageName, 
  cr.ComplianceRegionID as ComplianceRegionID,
  l2.LanguageID as LanguageID,
  trim(la.move_to_production_time) as ComplianceRegionLanguageProductionTime,
  trim(la.archived_time) as ComplianceRegionLanguageArchivedTime,
  TRIM(la.check_in_check_out_time) AS ComplianceRegionLanguageCheckInCheckOutTime, 
  TRIM(la.check_in_check_out_status) AS ComplianceRegionLanguageCheckInCheckOutStatus, 
  u.UserID AS ComplianceRegionLanguageCheckInCheckOutUserID,   
  trim(la.status) as ComplianceRegionLanguageStatus,
  TRIM(la.copied_from) AS ComplianceRegionLanguageCopiedFrom,
  pcr.ComplianceRegionLanguageID AS ParentComplianceRegionLanguageID,
  trim(la.is_default) as IsDefault,
  trim(la.system_enabled) as IsSystemEnabled,
  NULL as SourceCreatedDate,
  NULL as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  ms.SourceSystemID as SourceSystemID
FROM 
  gds_grdm_raw.kics_language_assignment_v1 la
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON LOWER(TRIM(la.compliance_region_id)) = LOWER(TRIM(cr.ComplianceRegionNumber)) 
LEFT JOIN 
  gds_grdm_int.ComplianceRegionLanguage pcr 
  ON LOWER(TRIM(la.parent_language_assignment_id)) = LOWER(TRIM(pcr.ComplianceRegionLanguageNumber))   
LEFT JOIN gds_grdm_raw.kics_language_v1 l 
  ON LOWER(TRIM(l.language_id)) = LOWER(TRIM(la.language_id))  AND l.gds_batch_id=la.gds_batch_id
   AND l.gds_batch_id = la.gds_batch_id   
LEFT JOIN gds_ref_int.Language l2 
  ON LOWER(TRIM(l2.LanguageISO1))= LOWER(TRIM(l.identifier))
LEFT JOIN gds_grdm_int.User u 
  ON LOWER(TRIM(u.UserNumber))= LOWER(TRIM(la.check_in_check_out_user_id))  
LEFT JOIN 
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE 
  la.gds_batch_id = wid_GDSBatchID