SELECT 
    TRIM(uc.user_capability_id) AS UserCapabilityNumber,
    TRIM(u.userID) AS UserID,
    TRIM(uc.created_by_tracking_system_user_id) AS CreatedByUserID,
    TRIM(uc.status) AS UserCapabilityStatus,
    TRIM(uc.is_granted) AS IsUserCapabilityGranted,
    TRIM(c.CapabilityID) AS CapabilityID,
    TRIM(cr1.ComplianceRegionID) AS CurrentAssignedComplianceRegionID,
    TRIM(cr2.ComplianceRegionID) AS CurrentSecondaryComplianceRegionID,
    null AS SourceCreatedDate,
    TRIM(uc.last_change_time) AS SourceUpdatedDate,
    TRIM(uc.last_change_user) AS SourceCreatedBy,     
    TRIM(uc.last_change_user) AS SourceUpdatedBy,  
    TRIM(ms.SourceSystemID) as SourceSystemID
    FROM
    gds_grdm_raw.kics_user_capability uc
    LEFT JOIN gds_grdm_int.User u
       ON TRIM(LOWER(uc.tracking_system_user_id)) = TRIM(LOWER(u.UserNumber))
    LEFT JOIN gds_grdm_int.capability c
       ON TRIM(LOWER(uc.capability_name)) = TRIM(LOWER(c.CapabilityName))
    LEFT JOIN gds_grdm_int.ComplianceRegion cr1
       ON TRIM(LOWER(uc.current_assigned_compliance_region_id))  = TRIM(LOWER(cr1.ComplianceRegionNumber))
    LEFT JOIN gds_grdm_int.ComplianceRegion cr2
       ON TRIM(LOWER(uc.current_secondary_compliance_region_id)) = TRIM(LOWER(cr2.ComplianceRegionNumber))
   LEFT JOIN
       meta.MetaSourceSystem ms 
       ON ms.SourceSystemName = 'KICS'
    WHERE
       uc.gds_batch_id = wid_GDSBatchID