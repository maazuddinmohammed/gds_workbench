SELECT * 
FROM (
SELECT
     trim(es.entity_status_code) as EntityStatusNumber,
     trim(es.entity_status_description) as EntityStatusName,
     COALESCE(ref_es.EntityStatusBusinessName, trim(es.entity_status_description)) as EntityStatusBusinessName,
     trim(es.entity_status_description) as EntityStatusDescription,
     es.is_entity_active as EntityIsActive,
     NULL as SourceCreatedDate,
     NULL as SourceUpdatedDate,
     NULL as SourceCreatedBy,
     NULL as SourceUpdatedBy,
     s.SourceSystemID as SourceSystemID
FROM
  gds_grdm_raw.sntl_x_entitystatus es
LEFT JOIN
  gds.MetaSourceSystem s ON s.SourceSystemCode = 'SNTL'
LEFT JOIN
  gds_ref_int.EntityStatus ref_es ON trim(lower(ref_es.EntityStatusNumber)) = trim(lower(es.entity_status_code))
WHERE
  es.gds_batch_id = wid_GDSBatchID
)