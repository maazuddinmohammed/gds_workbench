SELECT  * 
FROM (
SELECT

     TRIM(ks.stock_type) as StockTypeNumber,
     TRIM(ks.stock_type) as StockTypeName,
    coalesce(st.StockTypeBusinessName,TRIM(ks.stock_type)) as StockTypeBusinessName,
     TRIM(ks.stock_type) as StockTypeDescription,
     NULL as SourceCreatedDate,
     NULL as SourceUpdatedDate,
     NULL as SourceCreatedBy,
     NULL as SourceUpdatedBy,
     s.SourceSystemID as SourceSystemID
FROM
 (SELECT DISTINCT stock_type,gds_batch_id FROM gds_grdm_raw.kics_security_v1 WHERE stock_type IS NOT NULL) ks
LEFT JOIN
  gds.MetaSourceSystem s ON s.SourceSystemName = 'KICS'
LEFT JOIN
 gds_grdm_int.StockType st ON TRIM(LOWER(st.StockTypeNumber)) = TRIM(LOWER(ks.stock_type))

WHERE 
  ks.gds_batch_id = wid_GDSBatchID
)