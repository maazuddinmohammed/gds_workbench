SELECT
    pph.last_change_time AS PersonalProfileHistoryTime,
    TRIM(pph.personal_profile_information_id) AS PersonalProfileNumber,    
    pp.PersonalProfileID AS PersonalProfileID,
    TRIM(pph.personal_profile_information_attribute) AS PersonalProfileAttribute,
    TRIM(pph.personal_profile_information_text) AS PersonalProfileDescription,
    TRIM(pph.personal_profile_information_long) AS PersonalProfileInformationLong,
    u.UserID AS UserID,
    ppt.PersonalProfileTypeID AS PersonalProfileTypeID,
    cr1.ComplianceRegionID AS PrimaryComplianceRegionID,
    cr2.ComplianceRegionID AS SecondaryComplianceRegionID,
    NULL AS SourceCreatedDate,
    pph.last_change_time AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    TRIM(pph.last_change_user) AS SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
   FROM 
    gds_grdm_raw.v_kics_personal_profile_information_history_v1 pph
  LEFT JOIN 
    gds_grdm_int.PersonalProfile pp 
    ON TRIM(pp.PersonalProfileNumber) = TRIM(pph.personal_profile_information_id)
  LEFT JOIN 
    gds_grdm_int.User u 
    ON TRIM(u.UserNumber) = TRIM(pph.tracking_system_user_id)
  LEFT JOIN 
    gds_grdm_int.PersonalProfileType ppt 
    ON TRIM(ppt.PersonalProfileTypeName) = TRIM(pph.personal_profile_information_type)
  LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr1 
    ON TRIM(cr1.ComplianceRegionNumber) = TRIM(pph.current_assigned_compliance_region_id)
  LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr2 
    ON TRIM(cr2.ComplianceRegionNumber) = TRIM(pph.current_secondary_compliance_region_id)
  LEFT JOIN 
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
  WHERE   pph.gds_batch_id = wid_GDSBatchID 





