
SELECT
    TRIM(fas.firm_action_situation_id) AS FirmActionSituationNumber,
    TRIM(fas.situation_type) AS FirmActionSituationType,
    TRIM(fas.situation_state) AS FirmActionSituationState,
    fa.FirmActionID AS FirmActionID,
    usr.UserID AS UserID,
    up.UserProfileID AS UserProfileID,
    l.LocationID AS LocationID,
    cr1.ComplianceRegionID AS PrimaryComplianceRegionID,
    cr2.ComplianceRegionID AS SecondaryComplianceRegionID,
    cm.ConflictMessageID AS ConflictMessageID,
    h.HoldingID AS HoldingID,
    fas.email_sent_time AS FirmActionSituationEmailSentTime,
    TRIM(fas.email_from_user) AS FirmActionSituationEmailFromUser,
    TRIM(fas.email_state) AS FirmActionSituationEmailState,
    TRIM(fas.situation_add_type) AS FirmActionSituationAddType,
    TRIM(fas.compliance_survey_id) AS FirmActionSituationComplianceSurveyID,
    NULL AS SourceCreatedDate,
    fas.last_change_time AS SourceUpdatedDate,
    TRIM(fas.last_change_user) AS SourceUpdatedBy,
    NULL AS SourceCreatedBy,
    ms.SourceSystemID AS SourceSystemID
   FROM gds_grdm_raw.v_kics_firm_action_situation_v1 fas
  LEFT JOIN gds_grdm_int.FirmAction fa 
    ON TRIM(LOWER(fa.FirmActionNumber)) = TRIM(LOWER(fas.firm_action_case_id))
  LEFT JOIN gds_grdm_int.User usr 
    ON TRIM(LOWER(usr.UserNumber)) = TRIM(LOWER(fas.tracking_system_user_id))
  LEFT JOIN gds_grdm_int.UserProfile up 
    ON TRIM(LOWER(up.UserProfileNumber)) = TRIM(LOWER(fas.profile_id))
  LEFT JOIN gds_grdm_int.Location l 
    ON TRIM(LOWER(l.LocationNumber)) = TRIM(LOWER(fas.location_id))
  LEFT JOIN gds_grdm_int.ComplianceRegion cr1 
    ON TRIM(LOWER(cr1.ComplianceRegionNumber)) = TRIM(LOWER(fas.current_assigned_compliance_region_id))
  LEFT JOIN gds_grdm_int.ComplianceRegion cr2 
    ON TRIM(LOWER(cr2.ComplianceRegionNumber)) = TRIM(LOWER(fas.current_secondary_compliance_region_id))
  LEFT JOIN gds_grdm_int.ConflictMessage cm 
    ON TRIM(LOWER(cm.ConflictMessageNumber)) = TRIM(LOWER(fas.question_group_submission_description_id))
  LEFT JOIN gds_grdm_int.Holding h 
    ON TRIM(LOWER(h.HoldingNumber)) = TRIM(LOWER(fas.holding_case_id))
  LEFT JOIN gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
  WHERE fas.gds_batch_id = wid_GDSBatchID 