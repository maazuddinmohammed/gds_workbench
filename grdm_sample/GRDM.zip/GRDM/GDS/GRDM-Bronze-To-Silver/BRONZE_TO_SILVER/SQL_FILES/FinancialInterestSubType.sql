SELECT 
  trim(lc.list_code_id) as FinancialInterestSubTypeNumber,
  trim(lc.short_name) as FinancialInterestSubTypeName,
  coalesce(fst.FinancialInterestSubTypeBusinessName, trim(lc.short_name)) as FinancialInterestSubTypeBusinessName,
  trim(lc.description) as FinancialInterestSubTypeDescription,
  cr.ComplianceRegionID as ComplianceRegionID,
	lc.start_effective_date AS	FinancialInterestSubTypeEffectiveStartDate,
	lc.end_effective_date AS FinancialInterestSubTypeEffectiveEndDate,
	lc.identifier AS FinancialInterestSubTypeIdentifier,
	lc.parent_list_code_id AS ParentFinancialInterestSubTypeListCodeNumber,
	lc.associated_security_type AS	FinancialInterestSubTypeAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS FinancialInterestSubTypeIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	FinancialInterestSubTypeSICCode,
	lc.show_acknowledgement_checkbox AS	FinancialInterestSubTypeShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS FinancialInterestSubTypeRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS FinancialInterestSubTypeFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	FinancialInterestSubTypeIsAccountTypeEligibleForBrokerageImport,  
  NULL as SourceCreatedDate,
  lc.last_change_time as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  ms.SourceSystemID as SourceSystemID
FROM 
  gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
  gds_grdm_int.FinancialInterestSubType fst 
  ON trim(lower(lc.list_code_id)) = trim(lower(fst.FinancialInterestSubTypeNumber))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON trim(lower(lc.compliance_region_id)) = trim(lower(cr.ComplianceRegionNumber))
LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
WHERE 
  lc.gds_batch_id = wid_GDSBatchID
  AND lc.list_code_type = 'Financial Interest Subtype'