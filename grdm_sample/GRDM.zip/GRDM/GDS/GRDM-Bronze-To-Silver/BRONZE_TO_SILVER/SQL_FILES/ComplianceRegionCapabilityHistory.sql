SELECT 
    TRIM(c.CapabilityID) AS CapabilityID,
    TRIM(cr1.ComplianceRegionID) AS ComplianceRegionID,
    TRIM(crch.is_admin_enabled) AS IsCapabilityAdminEnabled,
    TRIM(crch.is_compliance_officer_enabled) AS IsCapabilityComplianceOfficerEnabled,
    TRIM(crch.is_reviewer_enabled) AS IsCapabilityReviewerEnabled,
    TRIM(crch.is_superuser_enabled) AS IsCapabilitySuperUserEnabled,
    null AS SourceCreatedDate,
    TRIM(crch.last_change_time) AS SourceUpdatedDate,
    TRIM(crch.last_change_user) AS SourceCreatedBy,     
    TRIM(crch.last_change_user) AS SourceUpdatedBy,  
    TRIM(ms.SourceSystemID) as SourceSystemID
    FROM
    gds_grdm_raw.v_kics_compliance_region_capability_history crch
    LEFT JOIN gds_grdm_int.capability c
       ON TRIM(LOWER(crch.capability_name)) = TRIM(LOWER(c.CapabilityName))
    LEFT JOIN gds_grdm_int.ComplianceRegion cr1
       ON TRIM(LOWER(crch.compliance_region_id))  = TRIM(LOWER(cr1.ComplianceRegionNumber))
   LEFT JOIN
       meta.MetaSourceSystem ms 
       ON ms.SourceSystemName = 'KICS'
    WHERE
       crch.gds_batch_id = wid_GDSBatchID