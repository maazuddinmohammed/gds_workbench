SELECT 
  TRIM(lc.list_code_id) AS StockDisposalNumber,
  TRIM(lc.short_name) AS StockDisposalName,
  COALESCE(sd.StockDisposalBusinessName, lc.short_name) AS StockDisposalBusinessName,
  TRIM(lc.description) AS StockDisposalDescription,
  cr.ComplianceRegionID AS ComplianceRegionID,
	lc.start_effective_date AS	StockDisposalEffectiveStartDate,
	lc.end_effective_date AS StockDisposalEffectiveEndDate,
	lc.identifier AS StockDisposalIdentifier,
	lc.parent_list_code_id AS ParentStockDisposalListCodeNumber,
	lc.associated_security_type AS	StockDisposalAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS StockDisposalIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	StockDisposalSICCode,
	lc.show_acknowledgement_checkbox AS	StockDisposalShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS StockDisposalRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS StockDisposalFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	StockDisposalIsAccountTypeEligibleForBrokerageImport,  
  NULL AS SourceCreatedDate,
  lc.last_change_time AS SourceUpdatedDate,
  NULL AS SourceCreatedBy,
  NULL AS SourceUpdatedBy,
  ms.SourceSystemID AS SourceSystemID
FROM 
  gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
  gds_grdm_int.StockDisposal sd 
  ON TRIM(LOWER(lc.list_code_id)) = TRIM(LOWER(sd.StockDisposalNumber))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON TRIM(LOWER(lc.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
WHERE 
  lc.gds_batch_id = wid_GDSBatchID
  AND lc.list_code_type = 'Stock Disposed'