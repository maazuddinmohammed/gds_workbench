SELECT 
  TRIM(lc.list_code_id) AS StockAcquisitionNumber,
  TRIM(lc.short_name) AS StockAcquisitionName,
  COALESCE(sa.StockAcquisitionBusinessName, lc.short_name) AS StockAcquisitionBusinessName,
  TRIM(lc.description) AS StockAcquisitionDescription,
  cr.ComplianceRegionID AS ComplianceRegionID,
	lc.start_effective_date AS	StockAcquisitionEffectiveStartDate,
	lc.end_effective_date AS StockAcquisitionEffectiveEndDate,
	lc.identifier AS StockAcquisitionIdentifier,
	lc.parent_list_code_id AS ParentStockAcquisitionListCodeNumber,
	lc.associated_security_type AS	StockAcquisitionAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS StockAcquisitionIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	StockAcquisitionSICCode,
	lc.show_acknowledgement_checkbox AS	StockAcquisitionShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS StockAcquisitionRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS StockAcquisitionFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	StockAcquisitionIsAccountTypeEligibleForBrokerageImport,  
  NULL AS SourceCreatedDate,
  lc.last_change_time AS SourceUpdatedDate,
  NULL AS SourceCreatedBy,
  NULL AS SourceUpdatedBy,
  ms.SourceSystemID AS SourceSystemID
FROM 
  gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
  gds_grdm_int.StockAcquisition sa 
  ON TRIM(LOWER(lc.list_code_id)) = TRIM(LOWER(sa.StockAcquisitionNumber))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON TRIM(LOWER(lc.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
WHERE 
  lc.gds_batch_id = wid_GDSBatchID
  AND lc.list_code_type = 'Stock Acquired'