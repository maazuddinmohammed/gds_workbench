SELECT
      TRIM(s.third_party_access_history_id)  AS ThirdPartyAccessHistoryNumber,
      TRIM(s.third_party_user_id) AS ThirdPartyUserNumber,
      TRIM(tp.ThirdPartyID) AS ThirdPartyID,
      TRIM(u.UserID) AS UserID,
      TRIM(s.third_party_access_time) AS ThirdPartyAccessTime,
      TRIM(cr1.ComplianceRegionID) AS CurrentAssignedComplianceRegionID,
      TRIM(cr2.ComplianceRegionID) AS CurrentSecondaryComplianceRegionID,
      NULL AS SourceCreatedDate,
      NULL AS SourceUpdatedDate,
      NULL AS SourceCreatedBy,
      NULL AS SourceUpdatedBy,
      ms.SourceSystemID as SourceSystemID
  FROM gds_grdm_raw.kics_third_party_access_history s

  LEFT JOIN gds_grdm_int.ThirdParty tp
     ON TRIM(LOWER(s.third_party_id)) = TRIM(LOWER(tp.ThirdPartyNumber)) 

  LEFT JOIN gds_grdm_int.User u
       ON TRIM(LOWER(s.tracking_system_user_id)) = TRIM(LOWER(u.UserNumber))  

  LEFT JOIN gds_grdm_int.ComplianceRegion cr1
    ON TRIM(LOWER(s.current_assigned_compliance_region_id)) = TRIM(LOWER(cr1.ComplianceRegionNumber))

  LEFT JOIN gds_grdm_int.ComplianceRegion cr2
    ON TRIM(LOWER(s.current_secondary_compliance_region_id)) = TRIM(LOWER(cr2.ComplianceRegionNumber))

  LEFT JOIN meta.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
  WHERE 
    s.gds_batch_id = wid_GDSBatchID