SELECT
      TRIM(s.third_party_access_control_id)  AS ThirdPartyAccessControlNumber,
      TRIM(s.type) AS ThirdPartyAccessControlType,
      TRIM(tp.ThirdPartyID) AS ThirdPartyID,
      TRIM(up.UserProfileID) AS UserProfileID,
      TRIM(u.UserID) AS UserID,
      TRIM(h.HoldingID) AS HoldingID,
      TRIM(s.data_permission) AS ThirdPartyAccessControlDataPermission,
      TRIM(s.start_time) AS ThirdPartyAccessControlStartTime,
      TRIM(s.end_time) AS ThirdPartyAccessControlEndTime,
      TRIM(s.last_change_time) AS ThirdPartyAccessControlLastChangeTime,
      TRIM(s.last_change_user) AS ThirdPartyAccessControlLastChangeUser,
      TRIM(cr1.ComplianceRegionID) AS CurrentAssignedComplianceRegionID,
      TRIM(cr2.ComplianceRegionID) AS CurrentSecondaryComplianceRegionID,
      Null AS SourceCreatedDate,
      s.last_change_time AS SourceUpdatedDate,
      s.last_change_user AS SourceCreatedBy,
      s.last_change_user AS SourceUpdatedBy,
      ms.SourceSystemID as SourceSystemID
  FROM gds_grdm_raw.kics_third_party_access_control s

  LEFT JOIN gds_grdm_int.ThirdParty tp
     ON TRIM(LOWER(s.third_party_id)) = TRIM(LOWER(tp.ThirdPartyNumber)) 
  
  LEFT JOIN gds_grdm_int.UserProfile up
       ON TRIM(LOWER(s.profile_id)) = TRIM(LOWER(up.UserProfileNumber))

  LEFT JOIN gds_grdm_int.User u
       ON TRIM(LOWER(s.tracking_system_user_id)) = TRIM(LOWER(u.UserNumber)) 

  LEFT JOIN gds_grdm_int.Holding h
       ON TRIM(LOWER(h.HoldingNumber)) = TRIM(LOWER(s.holding_case_id))

  LEFT JOIN gds_grdm_int.ComplianceRegion cr1
    ON TRIM(LOWER(s.current_assigned_compliance_region_id)) = TRIM(LOWER(cr1.ComplianceRegionNumber))

  LEFT JOIN gds_grdm_int.ComplianceRegion cr2
    ON TRIM(LOWER(s.current_secondary_compliance_region_id)) = TRIM(LOWER(cr2.ComplianceRegionNumber))

  LEFT JOIN meta.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
  WHERE 
    s.gds_batch_id = wid_GDSBatchID