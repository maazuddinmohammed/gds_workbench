SELECT 
dsec.SecurityId           AS SecurityID,
dse.EntityIdDMS           AS EntityIdDMS,
dent.EntityId             AS EntityID,
current_timestamp()       AS SourceCreatedDate,
current_timestamp()       AS SourceUpdatedDate,
current_user()            AS SourceCreatedBy,
current_user()            AS SourceUpdatedBy,
dse.source_system_id      AS SourceSystemID
FROM gds_grdm_raw.dms_securityentity AS dse
LEFT JOIN gds_grdm_int.DMSSecurity AS dsec ON dse.SecurityId = dsec.SourceSystemSecurityId
LEFT JOIN gds_grdm_int.DMSEntity AS dent ON dse.EntityId = dent.SourceSystemEntityID
WHERE dse.gds_batch_id = wid_GDSBatchID
