SELECT 
  TRIM(lc.list_code_id) AS SelfInitiatedWizardSubTypeNumber,
  TRIM(lc.short_name) AS SelfInitiatedWizardSubTypeName,
  COALESCE(swst.SelfInitiatedWizardSubTypeBusinessName, lc.short_name) AS SelfInitiatedWizardSubTypeBusinessName,
  TRIM(lc.description) AS SelfInitiatedWizardSubTypeDescription,
  cr.ComplianceRegionID AS ComplianceRegionID,
	lc.start_effective_date AS	SelfInitiatedWizardSubTypeEffectiveStartDate,
	lc.end_effective_date AS SelfInitiatedWizardSubTypeEffectiveEndDate,
	lc.identifier AS SelfInitiatedWizardSubTypeIdentifier,
	lc.parent_list_code_id AS ParentSelfInitiatedWizardSubTypeListCodeNumber,
	lc.associated_security_type AS	SelfInitiatedWizardSubTypeAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS SelfInitiatedWizardSubTypeIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	SelfInitiatedWizardSubTypeSICCode,
	lc.show_acknowledgement_checkbox AS	SelfInitiatedWizardSubTypeShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS SelfInitiatedWizardSubTypeRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS SelfInitiatedWizardSubTypeFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	SelfInitiatedWizardSubTypeIsAccountTypeEligibleForBrokerageImport,  
  NULL AS SourceCreatedDate,
  lc.last_change_time AS SourceUpdatedDate,
  NULL AS SourceCreatedBy,
  NULL AS SourceUpdatedBy,
  ms.SourceSystemID AS SourceSystemID
FROM 
  gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
  gds_grdm_int.SelfInitiatedWizardSubType swst 
  ON TRIM(LOWER(lc.list_code_id)) = TRIM(LOWER(swst.SelfInitiatedWizardSubTypeNumber))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON TRIM(LOWER(lc.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
WHERE 
  lc.gds_batch_id = wid_GDSBatchID
  AND lc.list_code_type = 'Self-Initiated Wizard Sub-Type'