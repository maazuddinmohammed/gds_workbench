SELECT 
    EmailTypeName,   
    NULL AS SourceCreatedDate,
    NULL AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    s.SourceSystemID AS SourceSystemID
    FROM 
    (              
      SELECT "Primary" AS EmailTypeName
      UNION ALL
      SELECT "Secondary" AS EmailTypeName  
    ) AS EmailType
    LEFT JOIN
        gds.MetaSourceSystem s ON s.SourceSystemName = 'KICS'
    

