SELECT    
    TRIM(eo.entity_organization_code)    AS EntityTypeNumber,
    TRIM(eo.entity_organization_desc)  AS EntityTypeName,
    COALESCE(et.EntityTypeBusinessName,eo.entity_organization_desc) AS EntityTypeBusinessName,
    TRIM(eo.entity_organization_desc)  AS EntityTypeDescription,
    NULL AS SourceCreatedDate,
    NULL AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,              
    s.SourceSystemID AS SourceSystemID         
                           
FROM
   gds_grdm_raw.sntl_x_entityorganization eo
LEFT JOIN
    gds.MetaSourceSystem s ON s.SourceSystemCode = 'SNTL'
LEFT JOIN
    gds_ref_int.EntityType et ON eo.entity_organization_code = et.EntityTypeNumber
WHERE
    eo.gds_batch_id = 'wid_GDSBatchID'