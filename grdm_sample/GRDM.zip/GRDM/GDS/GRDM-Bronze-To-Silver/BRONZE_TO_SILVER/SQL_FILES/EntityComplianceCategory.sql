SELECT 
    DISTINCT
    trim(le.category) as EntityComplianceCategoryNumber,
    trim(le.category) as EntityComplianceCategoryName,
    coalesce(ecc.EntityComplianceCategoryBusinessName, le.category) as EntityComplianceCategoryBusinessName,
    trim(le.category) as EntityComplianceCategoryDescription,
    NULL as SourceCreatedDate,
    NULL as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(s.SourceSystemID, -1) as SourceSystemID
FROM  gds_grdm_raw.kics_entity_v1 le
LEFT JOIN 
    gds_grdm_int.EntityComplianceCategory ecc 
    ON trim(lower(le.category)) = trim(lower(ecc.EntityComplianceCategoryNumber))
LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
WHERE 
    le.gds_batch_id = wid_GDSBatchID