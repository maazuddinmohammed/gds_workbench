SELECT Distinct
  trim(ppi.personal_profile_information_type) as PersonalProfileTypeNumber,
  trim(ppi.personal_profile_information_type) as PersonalProfileTypeName,
  coalesce(ppt.PersonalProfileTypeBusinessName, trim(ppi.personal_profile_information_type)) as PersonalProfileTypeBusinessName,
  trim(ppi.personal_profile_information_type) as PersonalProfileTypeDescription,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  ms.SourceSystemID as SourceSystemID,
  NULL as SourceCreatedDate,
  NULL as SourceUpdatedDate
FROM 
  gds_grdm_raw.v_kics_personal_profile_information_v1 ppi
LEFT JOIN 
  gds_grdm_int.PersonalProfileType ppt 
  ON trim(lower(ppi.personal_profile_information_type)) = trim(lower(ppt.PersonalProfileTypeNumber))
LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
WHERE 
  ppi.gds_batch_id = wid_GDSBatchID