SELECT 
    cpb.last_change_time as SecurityRelationHistoryTime,
    TRIM(cpb.child_to_parent_bridge_id) as SecurityRelationNumber,
    sr.SecurityRelationID as SecurityRelationID,    
    pec.EntityComplianceID as ParentEntityComplianceID,
    cs.SecurityID as ChildSecurityID,
    cec.EntityComplianceID as ChildEntityComplianceID,
    srt.SecurityRelationTypeID as SecurityRelationTypeID,
    st.StatusID as SecurityRelationStatusID,
    TRIM(cpb.is_restriction_flow_down) as IsRestrictionFlowDown,
    NULL as SourceCreatedDate,
    cpb.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    mss.SourceSystemID as SourceSystemID
FROM 
    gds_grdm_raw.v_kics_child_to_parent_bridge_history_v1 cpb
LEFT JOIN 
    gds_grdm_int.SecurityRelation sr ON trim(lower(sr.SecurityRelationNumber)) = trim(lower(cpb.child_to_parent_bridge_id))
LEFT JOIN 
    gds.MetaSourceSystem mss ON mss.SourceSystemName = 'KICS'
LEFT JOIN
    gds_grdm_int.Security cs ON LOWER(TRIM(cs.SecurityNumber)) = LOWER(TRIM(cpb.child_entity_security_id))
LEFT JOIN
   gds_ref_int.Entity pe ON LOWER(TRIM(pe.EntityNumber)) = LOWER(TRIM(cpb.parent_entity_security_id)) 
    AND pe.SourceSystemID = mss.SourceSystemID
LEFT JOIN 
    gds_grdm_int.EntityCompliance pec ON pec.EntityID = pe.EntityID
LEFT JOIN
    gds_ref_int.Entity ce ON LOWER(TRIM(ce.EntityNumber)) = LOWER(TRIM(cpb.child_entity_security_id)) 
    AND ce.SourceSystemID = mss.SourceSystemID
LEFT JOIN 
    gds_grdm_int.EntityCompliance cec ON cec.EntityID = ce.EntityID
LEFT JOIN 
    gds_grdm_int.SecurityRelationType srt ON trim(lower(srt.SecurityRelationTypeNumber)) = trim(lower(cpb.relationship_type))
LEFT JOIN 
    gds_ref_int.Status st ON LOWER(TRIM(st.StatusName)) = LOWER(TRIM(cpb.relationship_status))
WHERE 
    cpb.gds_batch_id = wid_GDSBatchID
    -- and sr.SecurityRelationID is not null -- TO BE REMOVED

