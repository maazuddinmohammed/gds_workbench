SELECT 
    coalesce(TRIM(lc.list_code_id), 'N/A') as OverdraftProtectionTypeNumber,
    coalesce(TRIM(lc.short_name), 'N/A') as OverdraftProtectionTypeName,
    coalesce(odt.OverdraftProtectionTypeBusinessName, TRIM(lc.short_name)) as OverdraftProtectionTypeBusinessName,
    TRIM(lc.description) as OverdraftProtectionTypeDescription,
    coalesce(cr.ComplianceRegionID, -1) as ComplianceRegionID,
	lc.start_effective_date AS	OverdraftProtectionTypeEffectiveStartDate,
	lc.end_effective_date AS OverdraftProtectionTypeEffectiveEndDate,
	lc.identifier AS OverdraftProtectionTypeIdentifier,
	lc.parent_list_code_id AS ParentOverdraftProtectionTypeListCodeNumber,
	lc.associated_security_type AS	OverdraftProtectionTypeAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS OverdraftProtectionTypeIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	OverdraftProtectionTypeSICCode,
	lc.show_acknowledgement_checkbox AS	OverdraftProtectionTypeShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS OverdraftProtectionTypeRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS OverdraftProtectionTypeFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	OverdraftProtectionTypeIsAccountTypeEligibleForBrokerageImport,    
    NULL as SourceCreatedDate,
    lc.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(ms.SourceSystemID, -1) as SourceSystemID
FROM
    gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN
    gds_grdm_int.OverdraftProtectionType odt 
    ON TRIM(LOWER(lc.list_code_id)) = TRIM(LOWER(odt.OverdraftProtectionTypeNumber))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr 
    ON TRIM(LOWER(lc.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
LEFT JOIN
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE
    lc.gds_batch_id = wid_GDSBatchID
AND lc.list_code_type = 'Overdraft Protection'
 