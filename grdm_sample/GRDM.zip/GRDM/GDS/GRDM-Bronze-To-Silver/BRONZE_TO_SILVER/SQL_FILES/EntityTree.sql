TRUNCATE TABLE gds_ref_int.EntityTree;
SELECT 
  e1.EntityID as GlobalUltimateParentEntityID,
  e2.EntityID as ParentEntityID,
  e3.EntityID as EntityID,
  at.AffiliateTypeID as AffiliateTypeID,
  st.relation_code as EntityTreeRelationCode,
  rc.relation_abbreviation as EntityTreeRelationAbbreviation,
  rc.relation_description as EntityTreeRelationDescription,  
  NULL as SourceCreatedDate,
  NULL as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  ms.SourceSystemID as SourceSystemID
FROM 
 gds_grdm_raw.sntl_x_tree st
 LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'SENTINEL'
LEFT JOIN 
  gds_ref_int.Entity e1  
  ON LOWER(TRIM(st.gup_entity_id)) = LOWER(TRIM(e1.EntityNumber)) AND e1.SourceSystemID = ms.SourceSystemID
LEFT JOIN 
  gds_ref_int.Entity e2  
  ON LOWER(TRIM(st.parent_entity_id)) = LOWER(TRIM(e2.EntityNumber)) AND e2.SourceSystemID = ms.SourceSystemID
LEFT JOIN 
   gds_ref_int.Entity e3  
  ON LOWER(TRIM(st.entity_id)) = LOWER(TRIM(e3.EntityNumber)) AND e3.SourceSystemID = ms.SourceSystemID
LEFT JOIN 
 gds_grdm_int.AffiliateType at 
  ON LOWER(TRIM(st.affiliate_type_code)) = LOWER(TRIM(at.AffiliateTypeCode))
LEFT JOIN gds_grdm_raw.sntl_x_relationcode rc ON rc.relation_code = st.relation_code 
         and st.gds_batch_id = rc.gds_batch_id  
WHERE 
  st.gds_batch_id = wid_GDSBatchID
  AND e3.EntityID IS NOT NULL 