SELECT 
    TRIM(ku.tracking_system_user_id) as UserNumber,
    TRIM(ku.first_name) as UserFirstName,
    TRIM(ku.middle_name) as UserMiddleName,
    TRIM(ku.last_name) as UserLastName,
    TRIM(ku.marital_status) as UserMaritalStatus,
    TRIM(ku.ssn) AS UserSSN,
    TRIM(ku.job_title) as UserJobTitle,
    TRIM(ku.job_service) as UserJobService,
    TRIM(ku.job_class) as UserJobClass,
    TRIM(ku.employment_status) as UserEmploymentStatus,
    TRIM(ku.phone_number) AS UserPhoneNumber,
    TRIM(ku.email) as UserEmailAddress,
    atyp.AddressTypeID as AddressTypeID,
    TRIM(ku.address_line_1) as UserAddressLine1,
    TRIM(ku.address_line_2) as UserAddressLine2,
    TRIM(ku.address_line_3) as UserAddressLine3,
    TRIM(ku.address_line_4) as UserAddressLine4,
    TRIM(ku.city) as UserAddressCity,
    TRIM(ku.state) as UserAddressState,
    TRIM(ku.zip_code) as UserAddressPostalCode,
    -1 as CountryID,  -- Kingland doesn't have Country information for the address
    TRIM(ku.userid) as UserIdentifier,
    TRIM(ku.employee_identifier) as UserEmployeeIdentifier,
    TRIM(ku.global_person_unique_identifier) as UserGlobalIdentifier,
    TRIM(ku.status) as UserStatus,
    TRIM(ku.external_identifier) AS UserExternalIdentifier,
    TRIM(ku.supervisor_employee_identifier) AS UserSupervisorEmployeeIdentifier,
    TRIM(ku.supervisor_first_name) AS UserSupervisorFirstName,
    TRIM(ku.supervisor_last_name) AS UserSupervisorLastName,
    TRIM(ku.supervisor_email_address) AS UserSupervisorEmailAddress, 
    cra.ComplianceRegionID as AuthorizedComplianceRegionID,
    crp.ComplianceRegionID as PrimaryComplianceRegionID,
    NULL as SecondaryComplianceRegionID,  -- This ComplianceRegionId only exists in history for Kingland
    cscr.ComplianceRegionID as CurrentSecondaryComplianceRegionID,
    l.LocationID as LocationID,
    crl.LanguageID as LanguageID,
    crl.ComplianceRegionLanguageID as ComplianceRegionLanguageID,
    TRIM(ku.business_unit) as UserBusinessUnit,
    TRIM(ku.department_code) as UserDepartmentCode,
    TRIM(ku.department_name) as UserDepartmentName,
    TRIM(ku.department_number) as UserDepartmentNumber,
    TRIM(ku.cost_center) as UserCostCenter,
    TRIM(ku.cost_center_description) as UserCostCenterDescription,   
    TRIM(ku.hired_date) as UserHireDate,
    TRIM(ku.last_hire_date) as UserLastHireDate,
    TRIM(ku.service_center_logon_time) as UserServiceCenterLogonTime,
    TRIM(ku.affirmed_time) as UserAffirmedTime,
    TRIM(ku.affirmed_uncheck_time) as UserAffirmedUncheckedTime,
    TRIM(ku.monitored_time) as UserMonitoredTime,
    TRIM(ku.closed_time) as UserClosedTime,
    TRIM(ku.reopen_time) as UserReopenTime,
    TRIM(ku.designated_month) as UserDesignatedMonth,
    TRIM(ku.office_number) as UserOfficeNumber,
    TRIM(ku.effective_date) as UserEffectiveDate,
    TRIM(ku.bdi_role) as UserBDIRole,
    TRIM(ku.primary_segment) as UserPrimarySegment,
    TRIM(ku.secondary_segment) as UserSecondarySegment,
    TRIM(ku.primary_industry_sector) as UserPrimaryIndustrySector,
    TRIM(ku.additional_sec_role) as UserAdditionalSECRole,
    TRIM(ku.leave_of_absence_start_date) as UserLeaveOfAbsenceStartDate,
    TRIM(ku.leave_of_absence_planned_return_date) as UserLeaveOfAbsensePlannedReturnDate,
    TRIM(ku.portfolio_view) as UserPortfolioView,
    TRIM(ku.service_center_authorization) as UserServiceCenterAuthorization,
    TRIM(ku.monitoring_tab_default_action_type) as UserMonitoringTabDefaultActionType,
    TRIM(ku.menu_layout) as UserMenuLayout,
    TRIM(ku.show_training_modal_at_login) as UserShowTrainingModalAtLogin,
    TRIM(ku.portfolio_affirmed) as IsPortfolioAffirmed,
    TRIM(ku.allow_mapping_update) as AllowMappingUpdate,
    CASE WHEN LOWER(TRIM(ku.bulk_self_clear_enabled)) = 'enabled' THEN 'Yes' WHEN LOWER(TRIM(ku.bulk_self_clear_enabled)) = 'disabled' THEN 'No' ELSE ku.bulk_self_clear_enabled     END as BulkSelfClearEnabled,
    TRIM(ku.can_review_all_locations) as CanReviewAllLocations,
    TRIM(ku.has_investment) as HasInvestments,
    TRIM(ku.has_insurance) as HasInsurance,
    TRIM(ku.is_monitored_employee) as IsMonitoredUser,
    TRIM(ku.monitored_user_flag) as IsMonitoredUserFlag,
    TRIM(ku.is_compliance_officer) as IsComplianceOfficer,
    TRIM(ku.is_monitored_employee) as IsMonitoredEmployee,
    TRIM(ku.is_application_administrator) as IsApplicationAdministrator,
    TRIM(ku.is_reviewer) as IsReviewer,
    TRIM(ku.is_superuser) as IsSuperUser,
    TRIM(ku.is_reviewer_of_partners) as IsReviewerOfPartner,
    TRIM(ku.is_reviewer_of_managers) as IsReviewerOfManagers,
    TRIM(ku.is_reviewer_of_professional_staff) as IsReviewerOfProfessionalStaff,
    TRIM(ku.is_reviewer_of_firm_holdings) as IsReviewerOfFirmHoldings,
    TRIM(ku.is_reviewer_of_pension_holdings) as IsReviewerOfPensionHoldings,
    TRIM(ku.is_unmonitored_employee) as IsUnmonitoredEmployee,
    TRIM(ku.is_reviewer_of_admins) as IsReviewerOfAdmins,
    TRIM(ku.is_text_editor) as IsTextEditor,
    TRIM(ku.is_text_reviewer) as IsTextReviewer,
    TRIM(ku.is_assigned_to_mapping) as IsAssignedToMapping,   -- Added on 10/29/25
    TRIM(ku.is_privacy_statement_viewed) as IsPrivacyStatementViewed, -- Added on 10/29/25
    TRIM(ku.is_sec_role_professional) as IsSECRoleProfessional,
    TRIM(ku.is_sec_role_partner) as IsSECRolePartner,
    TRIM(ku.is_sec_role_manager) as IsSECRoleManager,
    TRIM(ku.is_sec_role_firm) as IsSECRoleFirm,
    TRIM(ku.is_sec_role_pension) as IsSECRolePension,
    TRIM(ku.is_sec_role_admin) as IsSECRoleAdmin,
    TRIM(ku.add_type) as UserAddType,
    TRIM(ku.add_time) as UserAddTime,
    TRIM(ku.last_info_update_time) as UserLastInformationUpdateTime,
    TRIM(ku.last_info_update_user) as UserLastInformationUpdateUser,
    TRIM(ku.last_change_time) as UserLastChangeTime, -- Updated to reflect right columny
    TRIM(ku.last_change_user) as UserLastChangeUser,-- Updated to reflect right column
    current_timestamp as SourceCreatedDate,
    TRIM(ku.last_info_update_time) as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    ms.sourcesystemid as SourceSystemID
FROM 
    gds_grdm_raw.v_kics_user_info_v1 ku
LEFT JOIN 
   gds_ref_int.AddressType atyp
   ON atyp.AddressTypeName = 'Primary'
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cra 
    ON LOWER(TRIM(cra.ComplianceRegionNumber)) = LOWER(TRIM(ku.authorized_compliance_region_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion crp 
    ON LOWER(TRIM(crp.ComplianceRegionNumber)) = LOWER(TRIM(ku.current_assigned_compliance_region_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cscr 
    ON LOWER(TRIM(cscr.ComplianceRegionNumber)) = LOWER(TRIM(ku.current_secondary_compliance_region_id))
LEFT JOIN 
    gds_grdm_int.Location l 
    ON LOWER(TRIM(l.LocationNumber)) = LOWER(TRIM(ku.location_id))
LEFT JOIN 
    gds_grdm_int.IndustrySector isec 
    ON isec.IndustrySectorNumber = ku.primary_industry_sector
LEFT JOIN gds_grdm_int.ComplianceRegionLanguage crl
    ON LOWER(TRIM(crl.ComplianceRegionLanguageNumber)) = LOWER(TRIM(ku.preferred_language_assignment_id))
LEFT JOIN
    gds.metasourcesystem ms
    ON ms.SourceSystemName = 'KICS'
WHERE 
    ku.gds_batch_id = wid_GDSBatchID