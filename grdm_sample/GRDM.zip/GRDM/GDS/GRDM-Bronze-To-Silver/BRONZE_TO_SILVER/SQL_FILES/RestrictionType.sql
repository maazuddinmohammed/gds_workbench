SELECT DISTINCT
  src.RestrictionTypeNumber,
  src.RestrictionTypeName,
  COALESCE(rt.RestrictionTypeBusinessName, src.RestrictionTypeName) AS RestrictionTypeBusinessName,
  src.RestrictionTypeDescription,
  NULL AS ComplianceRegionID,
  NULL AS SourceCreatedDate,
  NULL AS SourceUpdatedDate,
  NULL AS SourceCreatedBy,
  NULL AS SourceUpdatedBy,
  ms.SourceSystemID AS SourceSystemID
FROM
(
SELECT DISTINCT
  TRIM(lc.restriction_type) AS RestrictionTypeNumber,
  TRIM(lc.restriction_type) AS RestrictionTypeName,
  TRIM(lc.restriction_type) AS RestrictionTypeDescription
FROM 
  gds_grdm_raw.kics_security_restriction_v1 lc
WHERE lc.gds_batch_id = wid_GDSBatchID
UNION
SELECT DISTINCT
  TRIM(lc.restriction_type) AS RestrictionTypeNumber,
  TRIM(lc.restriction_type) AS RestrictionTypeName,
  TRIM(lc.restriction_type) AS RestrictionTypeDescription
FROM 
  gds_grdm_raw.kics_security_restriction_history_v1 lc
WHERE lc.gds_batch_id = wid_GDSBatchID
UNION
SELECT DISTINCT
  TRIM(lc.restriction_type) AS RestrictionTypeNumber,
  TRIM(lc.restriction_type) AS RestrictionTypeName,
  TRIM(lc.restriction_type) AS RestrictionTypeDescription
FROM 
  gds_grdm_raw.kics_entity_restriction_v1 lc
WHERE lc.gds_batch_id = wid_GDSBatchID
UNION
SELECT DISTINCT
  TRIM(lc.restriction_type) AS RestrictionTypeNumber,
  TRIM(lc.restriction_type) AS RestrictionTypeName,
  TRIM(lc.restriction_type) AS RestrictionTypeDescription
FROM 
  gds_grdm_raw.kics_entity_restriction_history_v1 lc
WHERE lc.gds_batch_id = wid_GDSBatchID
) AS src
LEFT JOIN 
  gds_grdm_int.RestrictionType rt 
  ON TRIM(LOWER(src.RestrictionTypeName)) = TRIM(LOWER(rt.RestrictionTypeName))
LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'