SELECT 

    trim(lc.list_code_id) as FinancialInterestDisposalNumber,
    trim(lc.short_name) as FinancialInterestDisposalName,
    coalesce(fid.FinancialInterestDisposalBusinessName, lc.short_name) as FinancialInterestDisposalBusinessName,
    trim(lc.description) as FinancialInterestDisposalDescription,
    coalesce(cr.ComplianceRegionID, -1) as ComplianceRegionID,
	lc.start_effective_date AS	FinancialInterestDisposalEffectiveStartDate,
	lc.end_effective_date AS FinancialInterestDisposalEffectiveEndDate,
	lc.identifier AS FinancialInterestDisposalIdentifier,
	lc.parent_list_code_id AS ParentFinancialInterestDisposalListCodeNumber,
	lc.associated_security_type AS	FinancialInterestDisposalAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS FinancialInterestDisposalIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	FinancialInterestDisposalSICCode,
	lc.show_acknowledgement_checkbox AS	FinancialInterestDisposalShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS FinancialInterestDisposalRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS FinancialInterestDisposalFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	FinancialInterestDisposalIsAccountTypeEligibleForBrokerageImport,    
    NULL as SourceCreatedDate,
    lc.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(s.SourceSystemID, -1) as SourceSystemID
FROM 
    gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
    gds_grdm_int.FinancialInterestDisposal fid 
    ON trim(lower(lc.list_code_id)) = trim(lower(fid.FinancialInterestDisposalNumber))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON lower(trim(lc.compliance_region_id)) = lower(trim(cr.ComplianceRegionNumber))
LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
WHERE 
    lc.gds_batch_id = wid_GDSBatchID
    AND lc.list_code_type = 'Financial Interest Disposed'