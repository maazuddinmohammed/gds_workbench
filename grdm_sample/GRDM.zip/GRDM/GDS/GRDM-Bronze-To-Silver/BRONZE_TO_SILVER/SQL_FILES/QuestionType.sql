SELECT DISTINCT
    coalesce(TRIM(qgs.question_type), 'N/A') as QuestionTypeNumber,
    coalesce(TRIM(qgs.question_type), 'N/A') as QuestionTypeName,
    coalesce(qt.QuestionTypeName, TRIM(qgs.question_type)) as QuestionTypeBusinessName,
    TRIM(qgs.question_type) as QuestionTypeDescription,
    NULL as SourceCreatedDate,
    NULL as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(ms.SourceSystemID, -1) as SourceSystemID
FROM  gds_grdm_raw.V_kics_question_group_submission_v1 qgs
LEFT JOIN
    gds.MetaSourceSystem ms
    ON ms.SourceSystemName = 'KICS'     
LEFT JOIN
    gds_grdm_int.questiontype qt
    ON TRIM(LOWER(qt.QuestionTypeNumber)) = TRIM(LOWER(qgs.question_type))
WHERE
    qgs.gds_batch_id = wid_GDSBatchID