SELECT DISTINCT
  trim(a.holding_action_type) as HoldingReviewActionNumber,
  trim(a.holding_action_type) as HoldingReviewActionName,
  coalesce(hra.HoldingReviewActionBusinessName, trim(a.holding_action_type)) as HoldingReviewActionBusinessName,
  trim(a.holding_action_type) as HoldingReviewActionDescription,
  NULL as SourceCreatedDate,
  NULL as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  sys.SourceSystemID as SourceSystemID
FROM gds_grdm_raw.v_kics_holding_review_v1 a
LEFT JOIN 
  gds_grdm_int.HoldingReviewAction hra 
  ON LOWER(TRIM(hra.HoldingReviewActionNumber)) = LOWER(TRIM(a.holding_action_type))
LEFT JOIN 
  gds.MetaSourceSystem sys 
  ON sys.SourceSystemName = 'KICS'
WHERE 
  a.gds_batch_id = wid_GDSBatchID