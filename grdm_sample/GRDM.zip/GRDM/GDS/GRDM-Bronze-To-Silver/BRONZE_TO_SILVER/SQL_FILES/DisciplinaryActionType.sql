SELECT 
    trim(lc.list_code_id) as DisciplinaryActionTypeNumber,
    trim(lc.short_name) as DisciplinaryActionTypeName,
    coalesce(dat.DisciplinaryActionTypeBusinessName, lc.short_name) as DisciplinaryActionTypeBusinessName,
    trim(lc.description) as DisciplinaryActionTypeDescription,
    coalesce(cr.ComplianceRegionID, -1) as ComplianceRegionID,
	lc.start_effective_date AS	DisciplinaryActionTypeEffectiveStartDate,
	lc.end_effective_date AS DisciplinaryActionTypeEffectiveEndDate,
	lc.identifier AS DisciplinaryActionTypeIdentifier,
	lc.parent_list_code_id AS ParentDisciplinaryActionTypeListCodeNumber,
	lc.associated_security_type AS	DisciplinaryActionTypeAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS DisciplinaryActionTypeIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	DisciplinaryActionTypeSICCode,
	lc.show_acknowledgement_checkbox AS	DisciplinaryActionTypeShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS DisciplinaryActionTypeRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS DisciplinaryActionTypeFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	DisciplinaryActionTypeIsAccountTypeEligibleForBrokerageImport,  
    NULL as SourceCreatedDate,
    lc.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(s.SourceSystemID, -1) as SourceSystemID
FROM 
    gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
    gds_grdm_int.DisciplinaryActionType dat 
    ON trim(lower(lc.list_code_id)) = trim(lower(dat.DisciplinaryActionTypeNumber))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON trim(lower(lc.compliance_region_id)) = trim(lower(cr.ComplianceRegionNumber))
LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
WHERE 
    lc.gds_batch_id = wid_GDSBatchID
    AND lc.list_code_type = 'Primary Disciplinary Actions'
