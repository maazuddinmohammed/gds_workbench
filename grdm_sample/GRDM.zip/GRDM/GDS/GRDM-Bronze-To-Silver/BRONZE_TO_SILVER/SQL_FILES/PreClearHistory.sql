SELECT 
    ph.last_change_time as PreClearHistoryTime,
    TRIM(ph.preclear_history_id) as PreClearHistoryNumber,
    u.UserID as UserID,    
    ph.holding_case_id as HoldingNumber,
    pc.PreClearID as PreClearID,
    h.HoldingID as HoldingID,
    cr1.ComplianceRegionID as PrimaryComplianceRegionID, 
    cr2.ComplianceRegionID as SecondaryComplianceRegionID,
    cm.ConflictMessageID as ConflictMessageID,
    l.LocationID as LocationID,
    trim(ph.current_preclear_status) as PreClearStatus,
    trim(ph.preclear_result) as PreClearResult,
    date_format(ph.preclear_creation_time, 'yyyy-MM-dd') as PreClearCreationDate,
    date_format(ph.preclear_creation_time, 'HH:mm:ss') as PreClearCreationTime,
    date_format(ph.preclear_complete_time, 'yyyy-MM-dd') as PreClearCompletionDate,
    date_format(ph.preclear_complete_time, 'HH:mm:ss') as PreClearCompletionTime,
    date_format(ph.preclear_expiration_time, 'yyyy-MM-dd') as PreClearExpirationDate,
    date_format(ph.preclear_expiration_time, 'HH:mm:ss') as PreClearExpirationTime,
    trim(ph.preclear_expiration_reason) as PreClearExpirationReason,
    trim(ph.preclear_comments) as PreClearComment,
    trim(ph.is_service_center_update) as IsServiceCenterUpdate,
    trim(ph.is_third_party_user_update) as IsThirdPartyUserUpdate,
    NULL as SourceCreatedDate,
    ph.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    trim(ph.last_change_user) as SourceUpdatedBy,
    mss.SourceSystemID as SourceSystemID
FROM 
    gds_grdm_raw.v_kics_preclear_history_v1 ph
LEFT JOIN 
    gds_grdm_int.Holding h ON trim(lower(h.HoldingNumber)) = trim(lower(ph.holding_case_id))
LEFT JOIN 
    gds_grdm_int.PreClear pc ON pc.HoldingID = h.HoldingID
LEFT JOIN 
    gds_grdm_int.Location l ON trim(lower(l.LocationNumber)) = trim(lower(ph.location_id))
LEFT JOIN 
    gds_grdm_int.User u ON trim(lower(u.UserNumber)) = trim(lower(ph.tracking_system_user_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr1 ON trim(lower(cr1.ComplianceRegionNumber)) = trim(lower(ph.current_assigned_compliance_region_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr2 ON trim(lower(cr2.ComplianceRegionNumber)) = trim(lower(ph.current_secondary_compliance_region_id))
 LEFT JOIN 
     gds_grdm_int.ConflictMessage cm ON cm.ConflictMessageNumber = ph.question_group_submission_description_id
LEFT JOIN 
    gds.MetaSourceSystem mss ON mss.SourceSystemName = 'KICS'
WHERE 
    ph.gds_batch_id = wid_GDSBatchID
