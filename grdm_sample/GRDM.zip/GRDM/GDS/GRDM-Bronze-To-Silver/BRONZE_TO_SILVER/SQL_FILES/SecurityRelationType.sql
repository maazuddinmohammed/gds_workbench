SELECT DISTINCT
    TRIM(a.relationship_type) AS SecurityRelationTypeNumber,
    TRIM(a.relationship_type) AS SecurityRelationTypeName,
    COALESCE(srt.SecurityRelationTypeBusinessName, TRIM(a.relationship_type)) AS SecurityRelationTypeBusinessName,
    NULL AS SecurityRelationTypeDescription,
    current_timestamp AS SourceCreatedDate,
    NULL AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
FROM gds_grdm_raw.kics_child_to_parent_bridge_v1 a
LEFT JOIN 
    gds_grdm_int.SecurityRelationType srt 
    ON LOWER(TRIM(srt.SecurityRelationTypeNumber)) = LOWER(TRIM(a.relationship_type))
LEFT JOIN 
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE 
    a.gds_batch_id = wid_GDSBatchID