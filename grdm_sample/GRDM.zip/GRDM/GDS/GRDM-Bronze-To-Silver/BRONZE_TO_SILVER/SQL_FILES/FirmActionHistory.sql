SELECT
    fa.last_change_time AS FirmActionHistoryTime,
    f.FirmActionID AS FirmActionID,    
    TRIM(fa.firm_action_case_id) AS FirmActionNumber,
    ec2.EntityComplianceID AS EntityComplianceID,
    ec.EntityComplianceID AS PendingEntityComplianceID,
    l.LocationID AS LocationID,
    fa.pending_user_location_id AS PendingUserLocationID,
    cr.ComplianceRegionID AS ComplianceRegionID,
    cr2.ComplianceRegionID AS PendingComplianceRegionID,
    fa.current_affected_compliance_region_id as CurrentAffectedComplianceRegionID,
    s.SecurityID AS SecurityID,
    u.UserID AS UserID,
    fg.FirmActionGroupID AS FirmActionGroupID,
    sr.SecurityRestrictionID AS PendingSecurityRestrictionID,
    ecr.EntityComplianceRestrictionID AS PendingEntityComplianceRestrictionID,   
    TRIM(fa.current_action) AS FirmActionCurrentAction,
    TRIM(fa.entity_type) AS FirmActionEntityType,
    TRIM(fa.pending_new_value) AS FirmActionPendingNewValue,
    TRIM(fa.firm_action_applicability) AS FirmActionApplicability,
    TRIM(fa.firm_action_state) AS FirmActionState,
    TRIM(fa.auto_process_to) AS FirmActionAutoProcessFinalState,
    TRIM(fa.review_status) AS FirmActionReviewStatus,
    TRIM(fa.review_comments) AS FirmActionReviewComment,
    TRIM(fa.sec_registrant_comments) AS FirmActionSECRegistrantComment,
    TRIM(fa.auto_process) AS IsAutoProcess,
    TRIM(fa.override_auto_self_clear_settings) AS OverrideAutoSelfClearSetting,
    TRIM(fa.is_firm_action_require_review) AS RequireReview,
    TRIM(fa.has_been_analyzed) AS IsAnalyzed,
    NULL AS SourceCreatedDate,
    fa.last_change_time AS SourceUpdatedDate,
    TRIM(fa.created_by) AS SourceCreatedBy,
    TRIM(fa.last_change_user) AS SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
  FROM 
    gds_grdm_raw.v_kics_firm_action_history_v1 fa
  LEFT JOIN 
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
  LEFT JOIN 
    gds_ref_int.Entity e 
    ON LOWER(TRIM(e.EntityNumber)) = LOWER(TRIM(fa.pending_entity_id)) 
       AND e.SourceSystemID = ms.SourceSystemID
  LEFT JOIN 
    gds_grdm_int.EntityCompliance ec 
    ON LOWER(TRIM(ec.EntityID)) = LOWER(TRIM(e.EntityID))
  LEFT JOIN 
    gds_ref_int.Entity e2 
    ON LOWER(TRIM(e2.EntityNumber)) = LOWER(TRIM(fa.current_affected_entity_id)) 
       AND e2.SourceSystemID = ms.SourceSystemID
  LEFT JOIN 
    gds_grdm_int.EntityCompliance ec2 
    ON LOWER(TRIM(ec2.EntityID)) = LOWER(TRIM(e2.EntityID))
  LEFT JOIN 
    gds_grdm_int.Location l 
    ON LOWER(TRIM(l.LocationNumber)) = LOWER(TRIM(fa.pending_user_location_id))
  LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON LOWER(TRIM(cr.ComplianceRegionNumber)) = LOWER(TRIM(fa.compliance_region_id))
  LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr2 
    ON LOWER(TRIM(cr2.ComplianceRegionNumber)) = LOWER(TRIM(fa.pending_user_compliance_region_id))
  LEFT JOIN 
     gds_grdm_int.Security s 
    ON LOWER(TRIM(s.SecurityNumber)) = LOWER(TRIM(fa.current_affected_security_id))
  LEFT JOIN 
    gds_grdm_int.User u 
    ON LOWER(TRIM(u.UserNumber)) = LOWER(TRIM(fa.current_affected_user_id))
  LEFT JOIN 
    gds_grdm_int.FirmAction f 
    ON LOWER(TRIM(f.FirmActionNumber)) = LOWER(TRIM(fa.firm_action_case_id))
  LEFT JOIN 
    gds_grdm_int.FirmActionGroup fg 
    ON LOWER(TRIM(fg.FirmActionGroupNumber)) = LOWER(TRIM(fa.firm_action_group_id)) 
  LEFT JOIN 
    gds_grdm_int.EntityComplianceRestriction ecr
    ON LOWER(TRIM(ecr.EntityComplianceRestrictionNumber)) = LOWER(TRIM(fa.pending_entity_restriction_id))  
    AND LOWER(TRIM(ecr.ComplianceRegionID)) = LOWER(TRIM(cr.ComplianceRegionID))  
  LEFT JOIN 
    gds_grdm_int.SecurityRestriction sr
    ON LOWER(TRIM(sr.SecurityRestrictionNumber)) = LOWER(TRIM(fa.pending_security_restriction_id))
    AND LOWER(TRIM(sr.ComplianceRegionID)) = LOWER(TRIM(cr.ComplianceRegionID))
 WHERE fa.gds_batch_id = wid_GDSBatchID

