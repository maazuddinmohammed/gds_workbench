SELECT 
    TRIM(ks.security_id) AS SecurityNumber,
    st.SecurityTypeID AS SecurityTypeID,
    TRIM(ks.name) AS SecurityName,
    ks.Status AS SecurityStatus,
    TRIM(ks.primary_alias_text) AS SecurityPrimaryAliasText,
    TRIM(SUBSTRING(ks.symbol_exchange_array,3,(CHARINDEX('~',ks.symbol_exchange_array)-3))) AS SecuritySymbol,
    se.SecurityExchangeID,
    stt.StockTypeID AS StockTypeID,
    cr.ComplianceRegionID AS ComplianceRegionID,
    srep.SecurityID as SecurityReplacedID,
    sret.SecurityID as SecurityRetainedID,
    TRIM(ks.client_number) AS SecurityClientNumber,
    TRIM(ks.administrative_comments) AS SecurityAdministrativeComment,
    TRIM(ks.gmfid) AS SecurityGlobalMasterFileID,
    TRIM(ks.external_identifier) AS SecurityExternalID,
    TRIM(ks.mutual_fund_advisor_company_name) AS SecurityMutualFundAdvisorCompanyName,
    TRIM(ks.mutual_fund_sub_advisor_company_name) AS SecurityMutualFundSubAdvisorCompanyName,
    TRIM(ks.mutual_fund_auditor_company_name) AS SecurityMutualFundAuditorCompanyName,
    TRIM(ks.mutual_fund_external_data_source_number) AS SecurityMutualFundExternalDataSourceNumber,
    TRIM(ks.mutual_fund_sec_registrant_comment) AS SecurityMutualFundSECRegistrantComment,
    ks.mutual_fund_partially_restricted_time AS SecurityMutualFundPartiallyRestrictedTime,
    mff.MutualFundFamilyID AS MutualFundFamilyID,
    TRIM(ks.mutual_fund_gisid) AS SecurityMutualFundGISID,
    TRIM(ks.primary_symbol_exchange) AS SecurityPrimarySymbolExchange,
    TRIM(ks.primary_cusip) AS SecurityPrimaryCUSIPArray,
    TRIM(ks.primary_isin) AS SecurityPrimaryISINArray,
    TRIM(ks.primary_sedol) AS SecurityPrimarySEDOLArray,
    TRIM(ks.parent_entity_security_name_array) AS SecurityParentEntitySecurityNameArray,
    TRIM(ks.isin_array) AS SecurityISINArray,
    TRIM(ks.parent_entity_security_type_array) AS SecurityParentEntitySecurityTypeArray,
    TRIM(ks.cusip_array) AS SecurityCUSIPArray,
    TRIM(ks.sedol_array) AS SecuritySEDOLArray,
    TRIM(m.selected_acquisition_date) AS SecuritySelectedAcquisitionDate,
    TRIM(m.entity_security_replaced_type) AS SecurityEntitySecurityReplacedType,
    TRIM(m.entity_security_retained_type) AS SecurityEntitySecurityRetainedType,
    TRIM(ks.is_restriction_flow_down_array) AS SecurityRestrictionFlowDownArray,
    TRIM(ks.relationship_type_array) AS SecurityRelationshipTypeArray,
    TRIM(ks.alias_value_array) AS SecurityAliasArray,
    TRIM(ks.add_type) AS SecurityAddType,
    ks.inactivated_date AS SecurityInactivatedTime,
    TRIM(ks.mutual_fund_is_fund_family) AS IsFundFamily,
    TRIM(ks.is_sec_registrant) AS IsSECRegistrant,
    TRIM(ks.is_non_diversified) AS IsNonDiversified,
    TRIM(ks.is_non_public) AS IsNonPublic,
    TRIM(ks.is_in_watchlist) AS IsInWatchList,
    TRIM(ks.is_mapping_program_allowed_to_update) AS CanMappingProgramUpdate,
    m.merge_time as SecurityMergeTime,
    m.last_change_time as SecurityMergeLastChangeTime,
    m.retained_security_acquisition_date_source as SecurityMergeDataSource,
    m.merge_comment as SecurityMergeComment,
    m.is_confirmation_required as IsConfirmationRequired,
    m.is_send_notification_selected as IsSendNotification,
    ks.created_time AS SourceCreatedDate,
    ks.last_change_time AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
FROM 
    gds_grdm_raw.kics_security_v1 ks
LEFT JOIN 
    gds_grdm_int.SecurityType st
    ON LOWER(TRIM(st.SecurityTypeNumber)) = LOWER(TRIM(ks.security_type))  
LEFT JOIN 
    gds_grdm_int.StockType stt 
    ON LOWER(TRIM(stt.StockTypeName)) = LOWER(TRIM(ks.stock_type))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON LOWER(TRIM(cr.ComplianceRegionNumber)) = LOWER(TRIM(ks.compliance_region_id))
LEFT JOIN 
    gds_grdm_int.MutualFundFamily mff 
    ON LOWER(TRIM(mff.MutualFundFamilyNumber)) = LOWER(TRIM(ks.list_code_mutual_fund_fund_family_id))
LEFT JOIN gds_grdm_raw.v_kics_entity_security_merge_record_v1 m ON m.entity_security_retained_id = ks.security_id 
         AND ks.gds_batch_id = m.gds_batch_id
LEFT JOIN gds_grdm_int.Security srep ON LOWER(TRIM(srep.SecurityNumber)) = LOWER(TRIM(m.entity_security_replaced_id))
LEFT JOIN gds_grdm_int.Security sret ON LOWER(TRIM(sret.SecurityNumber)) = LOWER(TRIM(m.entity_security_retained_id))
LEFT JOIN gds_grdm_int.SecurityExchange se ON LOWER(TRIM(se.SecurityExchangeSymbol)) =LOWER(TRIM(SUBSTRING(ks.symbol_exchange_array,CHARINDEX('~',ks.symbol_exchange_array)+2,(CHARINDEX('"',ks.symbol_exchange_array,3)-CHARINDEX('~',ks.symbol_exchange_array)-2))))
LEFT JOIN 
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE 
    ks.gds_batch_id = wid_GDSBatchID
