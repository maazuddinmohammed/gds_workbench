SELECT * except(RN) FROM (
SELECT 
dent.EntityId as EntityId,
denn.Transactionid as Transactionid,
denn.NameType	as NameType,
denn.NameValue	as NameValue,
coalesce(denn.IsActive,true) as EntityNameIsActive,
current_timestamp() as SourceCreatedDate ,
current_timestamp() as SourceUpdatedDate ,
current_user() as SourceCreatedBy ,
current_user() as SourceUpdatedBy ,
denn.source_system_id as SourceSystemID,
ROW_NUMBER() OVER(PARTITION BY denn.TransactionId,denn.NameType,denn.NameValue,dent.EntityId,coalesce(denn.IsActive,true) order by denn.EntityNameId desc) AS RN
FROM gds_grdm_raw.dms_entityname as denn 
JOIN gds_grdm_int.dmsentity as dent ON denn.EntityId = dent.SourceSystemEntityID
WHERE denn.gds_batch_id = wid_GDSBatchID
) 
WHERE RN = 1