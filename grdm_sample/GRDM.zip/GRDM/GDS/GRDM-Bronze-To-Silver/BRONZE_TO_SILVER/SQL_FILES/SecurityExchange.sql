SELECT 
  TRIM(se.exchange_id) AS SecurityExchangeNumber,
  TRIM(se.exchange_name) AS SecurityExchangeName,
  TRIM(se.symbol) AS SecurityExchangeSymbol,
  se.start_effective_date AS SecurityExchangeEffectiveDate,
  se.end_effective_date AS SecurityExchangeExpirationDate,
  cr.ComplianceRegionID AS ComplianceRegionID,
  TRIM(se.is_available_for_stock) AS IsStockAvailable,
  TRIM(se.is_available_for_mutual_fund) AS IsMutualFundAvailable,
  TRIM(se.is_available_for_bond) AS IsBondAvailable,
  TRIM(se.is_available_for_uit) AS IsUnitInvestmentTrustAvailable,
  se.last_change_time AS SourceCreatedDate,
  NULL AS SourceUpdatedDate,
  NULL AS SourceCreatedBy,
  NULL AS SourceUpdatedBy,
  ms.SourceSystemID AS SourceSystemID
FROM 
  gds_grdm_raw.kics_security_exchange_v1 se
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON TRIM(LOWER(se.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
WHERE 
  se.gds_batch_id = wid_GDSBatchID