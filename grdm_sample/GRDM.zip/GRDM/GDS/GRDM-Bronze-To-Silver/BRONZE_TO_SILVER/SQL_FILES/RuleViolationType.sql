SELECT 
  TRIM(lc.list_code_id) AS RuleViolationTypeNumber,
  TRIM(lc.short_name) AS RuleViolationTypeName,
  COALESCE(rvt.RuleViolationTypeBusinessName, lc.short_name) AS RuleViolationTypeBusinessName,
  TRIM(lc.description) AS RuleViolationTypeDescription,
  cr.ComplianceRegionID AS ComplianceRegionID,
	lc.start_effective_date AS	RuleViolationTypeEffectiveStartDate,
	lc.end_effective_date AS RuleViolationTypeEffectiveEndDate,
	lc.identifier AS RuleViolationTypeIdentifier,
	lc.parent_list_code_id AS ParentRuleViolationTypeListCodeNumber,
	lc.associated_security_type AS	RuleViolationTypeAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS RuleViolationTypeIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	RuleViolationTypeSICCode,
	lc.show_acknowledgement_checkbox AS	RuleViolationTypeShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS RuleViolationTypeRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS RuleViolationTypeFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	RuleViolationTypeIsAccountTypeEligibleForBrokerageImport,  
  NULL AS SourceCreatedDate,
  lc.last_change_time AS SourceUpdatedDate,
  NULL AS SourceCreatedBy,
  NULL AS SourceUpdatedBy,
  ms.SourceSystemID AS SourceSystemID
FROM 
  gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
  gds_grdm_int.RuleViolationType rvt 
  ON TRIM(LOWER(lc.list_code_id)) = TRIM(LOWER(rvt.RuleViolationTypeNumber))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr 
  ON TRIM(LOWER(lc.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
WHERE 
  lc.gds_batch_id =  wid_GDSBatchID
  AND lc.list_code_type = 'Violation Code'