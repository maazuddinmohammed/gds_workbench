SELECT  
    TRIM(el.escalation_level_id) AS EscalationLevelNumber,
    TRIM(el.level_number) AS EscalationLevel,
    TRIM(el.level_description) AS EscalationLevelName,
    COALESCE(els.EscalationLevelBusinessName, TRIM(el.level_description)) AS EscalationLevelBusinessName,
    TRIM(el.level_description) AS EscalationLevelDescription,
    elt.EscalationLevelTypeID AS EscalationLevelTypeID,
    els2.EscalationLevelID AS NextEscalationLevelID,
    s.StatusID AS EscalationLevelStatusID,
    cr.ComplianceRegionID AS ComplianceRegionID,
    NULL AS SourceCreatedDate,
    el.last_change_time AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    ms.SourceSystemID AS SourceSystemID
FROM 
    gds_grdm_raw.kics_escalation_level_v1 el
LEFT JOIN 
    gds_grdm_int.EscalationLevel els 
    ON TRIM(LOWER(el.escalation_level_id)) = TRIM(LOWER(els.EscalationLevelNumber))
LEFT JOIN 
    gds_grdm_int.EscalationLevelType elt 
    ON TRIM(LOWER(el.level_type)) = TRIM(LOWER(elt.EscalationLevelTypeNumber))
LEFT JOIN 
    gds_grdm_int.EscalationLevel els2 
    ON TRIM(LOWER(el.next_escalation_level_id)) = TRIM(LOWER(els2.EscalationLevelNumber))
LEFT JOIN 
    gds_ref_int.Status s 
    ON TRIM(LOWER(el.status)) = TRIM(LOWER(s.StatusName))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON TRIM(LOWER(el.compliance_region_id)) = TRIM(LOWER(cr.ComplianceRegionNumber))
LEFT JOIN 
    gds.MetaSourceSystem ms 
    ON ms.SourceSystemName = 'KICS'
WHERE 
    el.gds_batch_id = wid_GDSBatchID