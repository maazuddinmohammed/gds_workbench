SELECT 

    trim(lc.list_code_id) as EmploymentRelationshipTypeNumber,
    trim(lc.short_name) as EmploymentRelationshipTypeName,
    coalesce(ert.EmploymentRelationshipTypeBusinessName, lc.short_name) as EmploymentRelationshipTypeBusinessName,
    trim(lc.description) as EmploymentRelationshipTypeDescription,
    coalesce(cr.ComplianceRegionID, -1) as ComplianceRegionID,
	lc.start_effective_date AS	EmploymentRelationshipTypeEffectiveStartDate,
	lc.end_effective_date AS EmploymentRelationshipTypeEffectiveEndDate,
	lc.identifier AS EmploymentRelationshipTypeIdentifier,
	lc.parent_list_code_id AS ParentEmploymentRelationshipTypeListCodeNumber,
	lc.associated_security_type AS	EmploymentRelationshipTypeAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS EmploymentRelationshipTypeIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	EmploymentRelationshipTypeSICCode,
	lc.show_acknowledgement_checkbox AS	EmploymentRelationshipTypeShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS EmploymentRelationshipTypeRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS EmploymentRelationshipTypeFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	EmploymentRelationshipTypeIsAccountTypeEligibleForBrokerageImport,    
    NULL as SourceCreatedDate,
    lc.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(s.SourceSystemID, -1) as SourceSystemID
FROM 
    gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
    gds_grdm_int.EmploymentRelationshipType ert 
    ON trim(lower(lc.list_code_id)) = trim(lower(ert.EmploymentRelationshipTypeNumber))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON lower(trim(lc.compliance_region_id)) = lower(trim(cr.ComplianceRegionNumber))
LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
WHERE 
    lc.gds_batch_id = wid_GDSBatchID
    AND lc.list_code_type = 'Employment Relationship Type'
