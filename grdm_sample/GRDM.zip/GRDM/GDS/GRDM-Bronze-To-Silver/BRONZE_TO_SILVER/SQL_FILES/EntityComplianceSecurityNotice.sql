SELECT 
    TRIM(ksn.entity_security_notice_id) as EntityComplianceSecurityNoticeNumber,
    ksn.notice_created_time as EntityComplianceSecurityNoticeDate,
    ksn.notice_created_time as EntityComplianceSecurityNoticeTime,
    usr.UserID as UserID,
    ec.EntityComplianceID AS EntityComplianceID,
    s.SecurityID as SecurityID,
    cr.ComplianceRegionID as ComplianceRegionID,
    cr2.ComplianceRegionID as AuthorizedComplianceRegionID,
    TRIM(ksn.notice_types) as EntityComplianceSecurityNoticeType,
    TRIM(ksn.notice_reason) as EntityComplianceSecurityNoticeReason,
    TRIM(ksn.state) as EntityComplianceSecurityNoticeState,
    TRIM(ksn.comments) as EntityComplianceSecurityNoticeComment,
    TRIM(ksn.operation_process_type) as EntityComplianceSecurityNoticeProcessType,
    TRIM(ksn.entity_security_type) AS EntityComplianceSecurityNoticeEntitySecurityType,
    NULL as SourceCreatedDate,
    ksn.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
     ms.SourceSystemID as SourceSystemID
FROM
    gds_grdm_raw.kics_entity_security_notice_v1 ksn
LEFT JOIN
    gds.MetaSourceSystem ms
    ON ms.SourceSystemName = 'KICS'    
LEFT JOIN
    gds_grdm_int.User usr
    ON LOWER(TRIM(ksn.operator_user_id)) = LOWER(TRIM(usr.UserNumber))
LEFT JOIN gds_ref_int.Entity et 
    ON LOWER(TRIM(et.EntityNumber)) = LOWER(TRIM(ksn.entity_security_id)) AND ms.SourceSystemID=et.SourceSystemID
LEFT JOIN gds_grdm_int.EntityCompliance ec
    ON LOWER(TRIM(ec.EntityID)) = LOWER(TRIM(et.EntityID))
LEFT JOIN
    gds_grdm_int.Security s
    ON LOWER(TRIM(ksn.entity_security_id)) = LOWER(TRIM(s.SecurityNumber))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr
    ON LOWER(TRIM(cr.ComplianceRegionNumber)) = LOWER(TRIM(ksn.compliance_region_id))
LEFT JOIN
    gds_grdm_int.ComplianceRegion cr2
    ON LOWER(TRIM(cr2.ComplianceRegionNumber)) = LOWER(TRIM(ksn.operator_authorized_compliance_region))
WHERE
    ksn.gds_batch_id = wid_GDSBatchID