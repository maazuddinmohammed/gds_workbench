SELECT 
    trim(hr.holding_review_id) as HoldingReviewNumber,
    h1.HoldingID as HoldingID,
    h2.HoldingID as OriginalHoldingID,
    u.UserID as UserID,
    cr1.ComplianceRegionID as PrimaryComplianceRegionID,
    cr2.ComplianceRegionID as SecondaryComplianceRegionID,
    s.SecurityID as SecurityID,
    el.EscalationLevelID as EscalationLevelID,
    trim(hr.discipline_level_id) as EscalationDisciplineLevelID,
    hr.escalation_time as HoldingReviewEscalationTime,
    hr.extension_granted_date as HoldingReviewExtensionGrantedDate,
    hr.extension_expiration_date as HoldingReviewExtensionExpirationDate,
    hra.HoldingReviewActionID as HoldingReviewActionID,
    hraa.HoldingReviewAdminActionID as HoldingReviewAdminActionID,
    hr.admin_action_time as HoldingReviewAdminActionTime,
    hr.disciplined_time as HoldingReviewDisciplinedTime,
    hr.holding_record_start_monitoring_time as HoldingReviewMonitoringStartTime,
    hr.reviewer_comments as HoldingReviewComment,
    hr.comment_saved_time as HoldingReviewCommentTime,
    trim(hr.status) as HoldingReviewStatus,
    TRIM(hr.entity_security_type) AS HoldingReviewEntitySecurityType,
    NULL as SourceCreatedDate,
    hr.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    trim(hr.last_change_user) as SourceUpdatedBy,
    mss.SourceSystemID as SourceSystemID
FROM 
    gds_grdm_raw.V_kics_holding_review_v1 hr
LEFT JOIN 
    gds_grdm_int.Holding h1 ON trim(lower(h1.HoldingNumber)) = trim(lower(hr.holding_case_id))
LEFT JOIN 
    gds_grdm_int.Holding h2 ON trim(lower(h2.HoldingNumber)) = trim(lower(hr.holding_review_case_id))
LEFT JOIN 
    gds_grdm_int.User u ON trim(lower(u.UserNumber)) = trim(lower(hr.tracking_system_user_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr1 ON trim(lower(cr1.ComplianceRegionNumber)) = trim(lower(hr.current_assigned_compliance_region_id))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr2 ON trim(lower(cr2.ComplianceRegionNumber)) = trim(lower(hr.current_secondary_compliance_region_id))
LEFT JOIN 
    gds_grdm_int.Security s ON trim(lower(s.SecurityNumber)) = trim(lower(hr.entity_security_id))
LEFT JOIN 
    gds_grdm_int.EscalationLevel el ON trim(lower(el.EscalationLevelNumber)) = trim(lower(hr.escalation_level_id))
LEFT JOIN 
    gds_grdm_int.HoldingReviewAction hra ON trim(lower(hra.HoldingReviewActionNumber)) = trim(lower(hr.holding_action_type))
LEFT JOIN 
    gds_grdm_int.HoldingReviewAdminAction hraa ON trim(lower(hraa.HoldingReviewAdminActionNumber)) = trim(lower(hr.admin_action))
LEFT JOIN 
    gds.MetaSourceSystem mss ON mss.SourceSystemName = 'KICS'
WHERE 
    hr.gds_batch_id = wid_GDSBatchID