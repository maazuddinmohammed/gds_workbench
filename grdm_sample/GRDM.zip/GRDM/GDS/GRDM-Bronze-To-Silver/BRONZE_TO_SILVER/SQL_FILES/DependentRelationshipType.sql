SELECT 
    trim(lc.list_code_id) as DependentRelationshipTypeNumber,
    trim(lc.short_name) as DependentRelationshipTypeName,
    coalesce(drt.DependentRelationshipTypeBusinessName, lc.short_name) as DependentRelationshipTypeBusinessName,
    trim(lc.description) as DependentRelationshipTypeDescription,
    coalesce(cr.ComplianceRegionID, -1) as ComplianceRegionID,
	lc.start_effective_date AS	DependentRelationshipTypeEffectiveStartDate,
	lc.end_effective_date AS DependentRelationshipTypeEffectiveEndDate,
	lc.identifier AS DependentRelationshipTypeIdentifier,
	lc.parent_list_code_id AS ParentDependentRelationshipTypeListCodeNumber,
	lc.associated_security_type AS	DependentRelationshipTypeAssociatedSecurityType,
	lc.can_financial_interest_be_reassigned_issuer AS DependentRelationshipTypeIsFinancialInterestBeReassignedIssuer,
	lc.sic_codes AS	DependentRelationshipTypeSICCode,
	lc.show_acknowledgement_checkbox AS	DependentRelationshipTypeShowAcknowledgementCheckbox,
	lc.require_comment_field_when_add_holding AS DependentRelationshipTypeRequireCommentFieldWhenAddHolding,
	lc.financial_interest_display_type AS DependentRelationshipTypeFinancialInterestDisplayType,
	lc.is_account_type_eligible_for_brokerage_import AS	DependentRelationshipTypeIsAccountTypeEligibleForBrokerageImport,    
    NULL as SourceCreatedDate,
    lc.last_change_time as SourceUpdatedDate,
    NULL as SourceCreatedBy,
    NULL as SourceUpdatedBy,
    coalesce(s.SourceSystemID, -1) as SourceSystemID
FROM 
    gds_grdm_raw.kics_list_code_v1 lc
LEFT JOIN 
    gds_grdm_int.DependentRelationshipType drt 
    ON trim(lower(lc.list_code_id)) = trim(lower(drt.DependentRelationshipTypeNumber))
LEFT JOIN 
    gds_grdm_int.ComplianceRegion cr 
    ON trim(lower(lc.compliance_region_id)) = trim(lower(cr.ComplianceRegionNumber))
LEFT JOIN 
    gds.MetaSourceSystem s 
    ON s.SourceSystemName = 'KICS'
WHERE 
    lc.gds_batch_id = wid_GDSBatchID
    AND lc.list_code_type = 'Dependent Relationship'
