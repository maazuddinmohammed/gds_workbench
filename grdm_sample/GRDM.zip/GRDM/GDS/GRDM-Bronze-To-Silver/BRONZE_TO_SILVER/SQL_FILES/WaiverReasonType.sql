SELECT DISTINCT
  trim(kr.type) as WaiverReasonTypeNumber,
  trim(kr.type) as WaiverReasonTypeName,
  coalesce(wrt.WaiverReasonTypeBusinessName, trim(kr.type)) as WaiverReasonTypeBusinessName,
  trim(kr.type) as WaiverReasonTypeDescription,
  NULL as SourceCreatedDate,
  NULL as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  ms.SourceSystemID as SourceSystemID
FROM  gds_grdm_raw.kics_reason_v1 kr
LEFT JOIN 
  gds_grdm_int.WaiverReasonType wrt 
  ON trim(lower(kr.type)) = trim(lower(wrt.WaiverReasonTypeNumber))
LEFT JOIN 
  gds.MetaSourceSystem ms 
  ON ms.SourceSystemName = 'KICS'
WHERE 
  kr.gds_batch_id = wid_GDSBatchID