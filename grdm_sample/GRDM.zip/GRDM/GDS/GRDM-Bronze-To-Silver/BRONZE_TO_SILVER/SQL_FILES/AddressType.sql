SELECT Distinct
    AddressTypeName,   
    NULL AS SourceCreatedDate,
    NULL AS SourceUpdatedDate,
    NULL AS SourceCreatedBy,
    NULL AS SourceUpdatedBy,
    s.SourceSystemID AS SourceSystemID
    FROM 
    (
        SELECT "Primary" AS AddressTypeName
        UNION ALL
        SELECT "Secondary" AS AddressTypeName  
    ) AS AddressTypeName
    LEFT JOIN
        gds.MetaSourceSystem s ON s.SourceSystemName = 'KICS'    
