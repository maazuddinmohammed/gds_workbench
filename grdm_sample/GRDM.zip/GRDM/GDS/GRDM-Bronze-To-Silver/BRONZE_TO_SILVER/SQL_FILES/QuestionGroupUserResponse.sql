SELECT 
  trim(qgur.user_answer_id) as QuestionGroupUserResponseNumber,
  trim(qgur.answer_choice_and_decision_tree_id) as QuestionGroupAnswerTreeID,
  cr1.ComplianceRegionID as PrimaryComplianceRegionID,
  cr2.ComplianceRegionID as SecondaryComplianceRegionID,
  u.UserID as UserID,
  q1.QuestionID as QuestionID,
  q3.QuestionID AS UserQuestionID,
  q2.QuestionID as NextQuestionID,
  h.HoldingID as HoldingID,
  qs.QuestionSetID as QuestionSetID,
  trim(qgur.user_question_set_case_id) as QuestionSetCaseID,
  trim(qgur.user_supplemental_data_question_set_case_id) as SupplementalQuestionSetID,
  cm.ConflictMessageID,
  trim(qgur.user_answer_text) as QuestionGroupUserResponseAnswerText,
  qgur.review_time as QuestionGroupUserResponseReviewTime,
  trim(qgur.reviewer_comment_on_user_answer) as QuestionGroupUserResponseAnswerReviewerComment,
  trim(qgur.self_clear_attempt_count) as QuestionGroupUserResponseSelfClearAttemptCount,
  trim(qgur.question_set_question_type) as QuestionGroupUserResponseQuestionType,
  trim(qgur.response_type) as QuestionGroupUserResponseType,
  trim(qgur.first_user_question_in_question_set) as QuestionGroupUserResponseFirstQuestionInQuestionSet,
  trim(qgur.is_question_set_skipped) as IsQuestionSetSkipped,
  current_timestamp as SourceCreatedDate,
  qgur.last_change_time as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  trim(qgur.last_change_user) as SourceUpdatedBy,
  sys.SourceSystemID as SourceSystemID
FROM 
  gds_grdm_raw.v_kics_question_group_user_response_v1 qgur
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr1 
  ON LOWER(TRIM(cr1.ComplianceRegionNumber)) = LOWER(TRIM(qgur.current_assigned_compliance_region_id))
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr2 
  ON LOWER(TRIM(cr2.ComplianceRegionNumber)) = LOWER(TRIM(qgur.current_secondary_compliance_region_id))
LEFT JOIN 
  gds_grdm_int.User u 
  ON LOWER(TRIM(u.UserNumber)) = LOWER(TRIM(qgur.tracking_system_user_id))
LEFT JOIN 
  gds_grdm_int.Question q1 
  ON LOWER(TRIM(q1.QuestionNumber)) = LOWER(TRIM(qgur.question_id))
LEFT JOIN 
  gds_grdm_int.Question q2 
  ON LOWER(TRIM(q2.QuestionNumber)) = LOWER(TRIM(qgur.next_user_question_id))
LEFT JOIN 
  gds_grdm_int.Question q3 
  ON LOWER(TRIM(q3.QuestionNumber)) = LOWER(TRIM(qgur.user_question_id))
LEFT JOIN 
  gds_grdm_int.QuestionSet qs 
  ON LOWER(TRIM(qs.QuestionSetNumber)) = LOWER(TRIM(qgur.question_set_id))
LEFT JOIN 
  gds_grdm_int.Holding h 
  ON LOWER(TRIM(h.HoldingNumber)) = LOWER(TRIM(qgur.holding_case_id))
LEFT JOIN 
  gds_grdm_int.ConflictMessage cm 
  ON LOWER(TRIM(cm.ConflictMessageNumber)) = LOWER(TRIM(qgur.question_group_submission_case_id))  
LEFT JOIN 
  gds.MetaSourceSystem sys 
  ON sys.SourceSystemName = 'KICS'
WHERE 
  qgur.gds_batch_id = wid_GDSBatchID