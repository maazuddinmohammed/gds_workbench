SELECT 
  ker.last_change_time as EntityComplianceRestrictionHistoryTime,
  ecr.EntityComplianceRestrictionID as EntityComplianceRestrictionID,
  trim(ker.entity_restriction_id) as EntityComplianceRestrictionNumber,
  ec.EntityComplianceID as EntityComplianceID,
  cr.ComplianceRegionID as ComplianceRegionID,
  cr2.ComplianceRegionID as ParentComplianceRegionID,
  rt.RestrictionTypeID as RestrictionTypeID,
  rs.RestrictionStateID as RestrictionStateID,
  trim(ker.restriction_applied) as EntityComplianceRestriction,
  ker.restriction_reason as EntityComplianceRestrictionReason,
  TRIM(ker.entity_type) AS EntityComplianceRestrictionEntityType,
  TRIM(ker.engagement_partner_assignment_array) AS EntityComplianceRestrictionEngagementPartnerAssignmentArray,
  TRIM(ker.covered_person_restriction_attribute_array) AS EntityComplianceRestrictionCoveredPersonRestrictionAttributeArray,
  ker.is_restricted as IsRestricted,
  ker.is_applicable as IsApplicable,
  NULL as SourceCreatedDate,
  ker.last_change_time as SourceUpdatedDate,
  NULL as SourceCreatedBy,
  NULL as SourceUpdatedBy,
  sys.SourceSystemID as SourceSystemID
FROM 
  gds_grdm_raw.v_kics_entity_restriction_history_v1 ker
LEFT JOIN 
  gds.MetaSourceSystem sys 
  ON sys.SourceSystemName = 'KICS'
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr
  ON LOWER(TRIM(cr.ComplianceRegionNumber)) = LOWER(TRIM(ker.restricted_compliance_region_id))
LEFT JOIN 
  gds_grdm_int.EntityComplianceRestriction ecr 
  ON LOWER(TRIM(ecr.EntityComplianceRestrictionNumber)) = LOWER(TRIM(ker.entity_restriction_id))
  AND LOWER(TRIM(ecr.ComplianceRegionID)) = LOWER(TRIM(cr.ComplianceRegionID))
LEFT JOIN 
  gds_ref_int.Entity e 
  ON LOWER(TRIM(e.EntityNumber)) = LOWER(TRIM(ker.entity_id)) 
  AND e.SourceSystemID = sys.SourceSystemID
LEFT JOIN 
  gds_grdm_int.EntityCompliance ec 
  ON ec.EntityID = e.EntityID
LEFT JOIN 
  gds_grdm_int.ComplianceRegion cr2 
  ON LOWER(TRIM(cr2.ComplianceRegionNumber)) = LOWER(TRIM(ker.inherited_from_parent_compliance_region_id))
LEFT JOIN 
  gds_grdm_int.RestrictionType rt 
  ON LOWER(TRIM(ker.restriction_type)) = LOWER(TRIM(rt.RestrictionTypeNumber))
LEFT JOIN 
  gds_grdm_int.RestrictionState rs 
  ON LOWER(TRIM(ker.restriction_state)) = LOWER(TRIM(rs.RestrictionStateNumber))
WHERE 
  ker.gds_batch_id = wid_GDSBatchID