# Databricks notebook source
dbutils.widgets.text("TargetSchema", "", "TargetSchema")
dbutils.widgets.text("TargetTable", "", "TargetTable")
dbutils.widgets.text("GDSBatchID", "", "GDSBatchID")
dbutils.widgets.text("MasterPipelineRunID", "", "MasterPipelineRunID")
dbutils.widgets.text("PipelineRunID", "", "PipelineRunID")
dbutils.widgets.text("GDSCatalog", "", "GDSCatalog")

# Capturing the Input Parameters
wid_TargetSchema = dbutils.widgets.get("TargetSchema")
wid_TargetTable = dbutils.widgets.get("TargetTable")
wid_GDSBatchID = dbutils.widgets.get("GDSBatchID")
wid_MasterPipelineRunId=dbutils.widgets.get("MasterPipelineRunID")
wid_ChildPipelineRunId=dbutils.widgets.get("PipelineRunID")
wid_Catalog=dbutils.widgets.get("GDSCatalog")


# COMMAND ----------

# DBTITLE 1,Cell 4
from pyspark.sql.functions import col, array_contains, lit, collect_set
from pyspark.sql import DataFrame
from datetime import datetime
import pandas as pd

val_StartDate = datetime.now()

# 1. Load your table into a DataFrame.
# Cache it as it will be used multiple times in the loop.

regions_df = spark.table(f"{wid_Catalog}.{wid_TargetSchema}.ComplianceRegion") 

# 2. Create the initial set of paths.
# We start by considering every region to be its own ancestor. This ensures we include top-level regions.
# This dataframe will accumulate all discovered ancestor-descendant pairs.

all_paths = regions_df.select(
    col("ComplianceRegionID").alias("AncestorID"),
    col("ComplianceRegionID").alias("DependentID"),
    col("ComplianceRegionIdentifier").alias("AncestorComplianceRegionIdentifier"),
    col("ComplianceRegionIdentifier").alias("DependentComplianceRegionIdentifier")
)

# 3. This dataframe will hold only the newly discovered paths in each iteration.
# We initialize it with the same self-references to kick off the loop.

new_paths = all_paths

# 4. Iteratively discover new descendant paths until no more can be found.

print("Starting iterative hierarchy build...")
root_path = new_paths
iteration = 1
#display(new_paths)
while new_paths.count() > 0:
    print(f"Iteration {iteration}: Found {new_paths.count()} new paths to process.")   
    # Prepare the next join by aliasing columns to avoid ambiguity
    # 'paths_to_join' represents the last set of newly discovered relationships
    paths_to_join = new_paths.select(
        col("AncestorID"),
        col("DependentID"),
        col("AncestorComplianceRegionIdentifier")
    ).alias("paths")

    # 'child_links' represents the table of direct parent-child relationships
    child_links = regions_df.select(
        col("ParentComplianceregionID"),
        col("ComplianceRegionID"),
        col("ComplianceRegionIdentifier")
    ).alias("links")

    # Join the last set of paths with the direct links to find the next level of descendants
    newly_discovered_paths = paths_to_join.join(
        child_links,
        col("paths.DependentID") == col("links.ParentComplianceregionID"),
        "inner"
    ).select(
        col("paths.AncestorID"),
        col("links.ComplianceRegionID").alias("DependentID"),
        col("paths.AncestorComplianceRegionIdentifier"),
        col("links.ComplianceRegionIdentifier").alias("DependentComplianceRegionIdentifier")
    )

    # Use subtract to keep only the paths that we haven't already found in `all_paths`
    new_paths = newly_discovered_paths.subtract(all_paths)

    # Add the brand new paths to our cumulative result set for the next iteration's `subtract`
    all_paths = all_paths.union(new_paths)   
    iteration += 1

print("Finished building hierarchy.")

# 5. The 'all_paths' DataFrame now contains the complete hierarchy.
# Filter out the self-references where a region is its own dependent and rename columns.
final_results_df = all_paths.filter(col("AncestorID") != col("DependentID")) \
                            .withColumnRenamed("AncestorID", "ParentId") \
                            .orderBy("ParentId", "DependentID")


final_results_df = final_results_df.union(root_path).distinct()

# 6. Display the final results
display(final_results_df)
#display(root_path)
final_results_df.createOrReplaceTempView("AllComplianceRegions")

spark.sql(f"""TRUNCATE TABLE {wid_Catalog}.{wid_TargetSchema}.{wid_TargetTable}""")

spark.sql(f"""INSERT INTO {wid_Catalog}.{wid_TargetSchema}.{wid_TargetTable} (ComplianceRegionID, 
ComplianceRegionName,ComplianceRegionIdentifier,ParentComplianceRegionID,ParentComplianceRegionName, ParentComplianceRegionIdentifier,SourceCreatedDate,SourceUpdatedDate,SourceCreatedBy,SourceUpdatedBy,  SourceSystemID,IsDataValid,HashKey,IsActive,GDSBatchID,PipelineRunID,CreatedDate,UpdatedDate,CreatedBy,UpdatedBy)
SELECT DISTINCT A.DependentID AS ComplianceRegionID,A.DependentComplianceRegionIdentifier AS ComplianceRegionName,A.DependentComplianceRegionIdentifier AS ComplianceRegionIdentifier,A.ParentId AS ParentComplianceRegionID,A.AncestorComplianceRegionIdentifier AS ParentComplianceRegionName,A.AncestorComplianceRegionIdentifier AS ParentComplianceRegionIdentifier,current_timestamp() AS SourceCreatedDate,current_timestamp() AS SourceUpdatedDate,current_user() AS SourceCreatedBy,current_user() AS SourceUpdatedBy,1 AS SourceSystemID,true AS IsDataValid,'NA' AS HashKey,true AS IsActive,{wid_GDSBatchID} AS GDSBatchID,'{wid_ChildPipelineRunId}' AS PipelineRunID,current_timestamp() AS CreatedDate,current_timestamp() AS UpdatedDate,current_user() AS CreatedBy,current_user() AS UpdatedBy  FROM AllComplianceRegions AS A  """)
