# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC # Bronze to Silver Notebook - CalendarDate
# MAGIC ---
# MAGIC
# MAGIC ###### The purpose of this template is to transfer data from Bronze to Silver zone.
# MAGIC
# MAGIC **The Pre-requisites for this template are:**
# MAGIC * Source and Target delta tables should be created.
# MAGIC * This Databricks notebook should be integrated to ADF.
# MAGIC * ADF should pass the widget values to this notebook.
# MAGIC * The Configuration section should be updated.

# COMMAND ----------

# Creating widgets for the Input Parameters
dbutils.widgets.text("TargetSchema", "", "TargetSchema")
dbutils.widgets.text("TargetTable", "", "TargetTable")
dbutils.widgets.text("GDSBatchID", "", "GDSBatchID")
dbutils.widgets.text("MasterPipelineRunID", "", "MasterPipelineRunID")
dbutils.widgets.text("PipelineRunID", "", "PipelineRunID")
dbutils.widgets.text("GDSCatalog", "", "GDSCatalog")

# Capturing the Input Parameters
wid_TargetSchema = dbutils.widgets.get("TargetSchema")
wid_TargetTable = dbutils.widgets.get("TargetTable")
wid_GDSBatchID = dbutils.widgets.get("GDSBatchID")
wid_MasterPipelineRunId=dbutils.widgets.get("MasterPipelineRunID")
wid_ChildPipelineRunId=dbutils.widgets.get("PipelineRunID")
wid_Catalog=dbutils.widgets.get("GDSCatalog")

# COMMAND ----------

conf_TimeoutSeconds = 600

# COMMAND ----------

conf_DataBase="gds"

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #####Imports

# COMMAND ----------

from datetime import datetime
import pandas as pd

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC #####Core Logic

# COMMAND ----------

try:
    #wid_LoggingPath = "/GDS/Logging_Framework/DB_GDSKIG_Logging"
    
    from datetime import datetime
    import pandas as pd

    val_StartDate = datetime.now()
    
    df = pd.DataFrame({"date": pd.date_range(start='1990-01-01', end='2089-12-31')})
    df['year'] = df['date'].dt.year
    df['quarter'] = df['date'].dt.quarter
    df['quarterId'] = df['date'].apply(lambda x: f'{x.strftime("%Y")}{x.quarter}')
    df['month'] = df['date'].dt.month
    df['MonthName'] = df['date'].dt.strftime("%B")
    df['FirstDayOfMonth'] = df['date'].to_numpy().astype('datetime64[M]')
    df['DayOfMonth'] = df['date'].dt.day
    df['DayOfWeek'] =  df['date'].dt.dayofweek
    df['DayName'] = df['date'].dt.strftime("%A")
    df['EndDateOfMonth'] =  df['date'] + pd.offsets.MonthEnd()
    df['StartDateofFiscalYear'] = pd.PeriodIndex(df['date'],freq='A-SEP').asfreq('D','s').astype('datetime64[M]')
    df['EndDateofFiscalYear'] = pd.PeriodIndex(df['date'],freq='A-SEP').asfreq('D','e').astype('datetime64[M]')
    df['FiscalQuarter'] = pd.PeriodIndex(df['date'],freq='Q-SEP').strftime('%q')

    tempdf=spark.createDataFrame(df) 
    tempdf.createOrReplaceTempView("temp_date")

    spark.sql(f""" 
        CREATE OR REPLACE TEMPORARY VIEW temp_target AS
        select date,
            year,
            quarter,
            quarterId,
            month,
            MonthName,
            FirstDayOfMonth,
            DayOfMonth,
            DayOfWeek,
            DayName,
            EndDateOfMonth,
            StartDateofFiscalYear,
            EndDateofFiscalYear,
            FiscalQuarter
        from temp_date
        """)
 
    val_RecordsRead = spark.sql("SELECT COUNT(*) FROM temp_date").collect()[0][0]

    wid_SourceSystemID = spark.sql(f"""select SourceSystemID from {wid_Catalog}.meta.MetaSourceSystem where SourceSystemcode = 'KICS'; """).collect()[0][0]
   
    df_AuditParams = spark.sql(
        f"""MERGE INTO {wid_Catalog}.gds_ref_int.CalendarDate as t
            USING temp_date as s
            ON t.CalendarDate = s.date
            WHEN MATCHED THEN UPDATE SET t.CalendarYear = s.year, 
                                         t.CalendarQuarter = s.quarter, 
                                         t.CalendarMonth = s.month,
                                         t.SourceCreatedDate = current_timestamp(), 
                                         t.SourceUpdatedDate = current_timestamp(), 
                                         t.SourceCreatedBy = current_user(), 
                                         t.SourceUpdatedBy = current_user(),   
                                         t.IsDataValid = True,
                                         t.IsActive = True,
                                         t.GDSBatchID = CAST(0 AS INT), 
                                         t.SourceSystemID = '{wid_SourceSystemID}',
                                         t.PipelineRunID = '{wid_ChildPipelineRunId}',
                                         t.CreatedDate = current_timestamp(),
                                         t.UpdatedDate = current_timestamp(), 
                                         t.CreatedBy = current_user(),
                                         t.UpdatedBy = current_user()
            WHEN NOT MATCHED THEN INSERT (CalendarDate,CalendarYear,CalendarQuarter,CalendarMonth,
                                          SourceCreatedDate,SourceUpdatedDate,SourceCreatedBy,SourceUpdatedBy,
                                         IsDataValid,IsActive,GDSBatchID,SourceSystemID,PipelineRunID,CreatedDate,UpdatedDate,CreatedBy,UpdatedBy)
            VALUES (s.date,s.year,s.quarter,s.month,
                   current_timestamp(),current_timestamp(),current_user(),current_user(),
                   True,True,CAST(0 AS INT),'{wid_SourceSystemID}','{wid_ChildPipelineRunId}',
                    current_timestamp(),current_timestamp(),current_user(),current_user()
                     )"""
    )
    val_RecordsInserted = df_AuditParams.collect()[0][1]
    val_RecordsUpdated = 0
    val_RecordsRejected = 0
            
    # Calling the Logging Framework - Success Path

    LoggingParameters = {
        'MasterPipelineRunId':wid_MasterPipelineRunId,
        'ChildPipelineRunId':wid_ChildPipelineRunId,
        "StartDate": val_StartDate,
        "EndDate": datetime.now(),
        "Status": "Successful",
        "StatusMessage": "Completed",
        "TargetTableName": "CalenderDate",
        "RecordsInserted": val_RecordsInserted,
        "RecordsUpdated": val_RecordsUpdated,
        "RecordsRejected": val_RecordsRejected,
        "RecordsRead": val_RecordsRead,
        "Mode": "ChildPipelineLogDetail-Insert",
    }
    #dbutils.notebook.run(wid_LoggingPath,conf_TimeoutSeconds,LoggingParameters)
    
    

except Exception as val_StatusMessage:

    # Calling the Logging Framework - Failure Path

    LoggingParameters = {
        'MasterPipelineRunId':wid_MasterPipelineRunId,
        'ChildPipelineRunId':wid_ChildPipelineRunId,
        "StartDate": val_StartDate,
        "EndDate": datetime.now(),
        "Status": "Failed",
        "StatusMessage": str(val_StatusMessage),
        "TargetTableName": "CalenderDate",
        "Mode": "ChildPipelineLogDetail-Insert",
    }
   #dbutils.notebook.run(wid_LoggingPath,conf_TimeoutSeconds,LoggingParameters)
    
    
    raise Exception(str(val_StatusMessage))