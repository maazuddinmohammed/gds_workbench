# Databricks notebook source
dbutils.widgets.text("Tenant", "", "Tenant")
dbutils.widgets.text("System", "", "System")
dbutils.widgets.text("SystemID", "", "SystemID")
dbutils.widgets.text("BatchID", "", "BatchID")
dbutils.widgets.text("PipelineRunID", "Test", "PipelineRunID")
dbutils.widgets.text("Catalog", "", "Catalog")

wid_Tenant = dbutils.widgets.get("Tenant")
wid_System = dbutils.widgets.get("System")
wid_SystemID = dbutils.widgets.get("SystemID")
wid_BatchID = dbutils.widgets.get("BatchID")
wid_PipelineRunID = dbutils.widgets.get("PipelineRunID")
wid_Catalog = dbutils.widgets.get("Catalog")

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode, regexp_extract, input_file_name, current_timestamp
from datetime import datetime
import pytz

timezone = pytz.timezone('US/Eastern')

set_context = spark.sql(f'USE CATALOG {wid_Catalog};')

# COMMAND ----------

row=spark.sql(f"""SELECT
  cl.ConnectionLocationStorageAccount,cl.ConnectionLocationSecret,cl.ConnectionLocationContainer,cl.ConnectionLocationPath
FROM
  meta.connectionlocation cl
    JOIN meta.connection ct
      on ct.ConnectionID = cl.ConnectionID
    JOIN meta.system s
      on s.SystemID = ct.SystemID
    JOIN meta.tenant t
      on t.TenantID = ct.TenantID
WHERE
  S.SystemCode = '{wid_System}';""").collect()[0]

# COMMAND ----------

# DBTITLE 1,Build ADLS Path and List JSON Files
#Storage details fetch
storage_account = row.ConnectionLocationStorageAccount
container = row.ConnectionLocationContainer
path = row.ConnectionLocationPath
storage_key = row.ConnectionLocationSecret
landing_key = dbutils.secrets.get(scope="keyvault-scope", key=storage_key)

# Build path with BatchID subdirectory
base_dir = f"abfss://{container}@{storage_account}.dfs.core.windows.net/{path}/{wid_BatchID}"
print(f"ADLS base directory: {base_dir}")
spark.conf.set(f"fs.azure.account.key.{storage_account}.dfs.core.windows.net", landing_key)
# Recursively list ALL JSON files (including subdirectories)
def list_json_files_recursive(path):
    json_files = []
    try:
        items = dbutils.fs.ls(path)
    except Exception as e:
        print(f"  WARNING: Could not list {path}: {e}")
        return json_files
    for item in items:
        if item.path.endswith("/"):
            # It's a subdirectory — recurse into it
            json_files.extend(list_json_files_recursive(item.path))
        elif item.name.endswith(".json"):
            json_files.append(item)
    return json_files

json_files = list_json_files_recursive(base_dir)
print(f"Found {len(json_files)} JSON file(s) across all subdirectories:")
for f in json_files[:20]:
    print(f"  {f.path}")
if len(json_files) > 20:
    print(f"  ... and {len(json_files) - 20} more")


# COMMAND ----------

# DBTITLE 1,Entity Domain - JSON Flattening
# 1. Read ALL JSON files recursively from ADLS (with source file name)
df_raw = spark.read.option("recursiveFileLookup", "true").option(f"fs.azure.account.key.{storage_account}.dfs.core.windows.net", landing_key).json(base_dir)

# Show which files are being read and full content of df_raw
print("=== Source Files Being Read ===")
df_with_file = df_raw.withColumn("_source_file", col("_metadata.file_path"))
df_with_file.select("_source_file").distinct().show(truncate=False)

# 2. Explode the 'value' array from Graph API
df_entity = df_raw.select(explode("legalEntityList").alias("entity"))

# Deduplicate by entityid so only distinct entities flow through all staging views
df_entity_distinct = df_entity.withColumn("_eid", col("entity.entityid")).dropDuplicates(["_eid"]).drop("_eid")
print(f"Total exploded entities: {df_entity.count()}, Distinct entities: {df_entity_distinct.count()}")

# Helper: safely access nested struct fields — returns lit(None) if field is missing from JSON
from pyspark.sql.functions import lit
from pyspark.sql.types import StructType

def safe_cols(df):
    """Return a function sc(col_path, alias) that safely resolves struct fields in df."""
    schema = df.schema
    def _safe(col_path, alias_name):
        parts = col_path.split(".")
        current = schema
        for part in parts:
            if isinstance(current, StructType):
                # Case-insensitive lookup to match Spark's default behavior
                match = next((f.name for f in current.fields if f.name.lower() == part.lower()), None)
                if match:
                    current = current[match].dataType
                else:
                    return lit(None).alias(alias_name)
            else:
                return lit(None).alias(alias_name)
        return col(col_path).alias(alias_name)
    return _safe

def empty_view(view_name, schema_str):
    """Create an empty staging view with the given schema."""
    spark.createDataFrame([], schema=schema_str).createOrReplaceTempView(view_name)

def has_nested_field(df, field_path):
    """Check if a nested struct field path exists in df's schema."""
    parts = field_path.split(".")
    current = df.schema
    for part in parts:
        if isinstance(current, StructType):
            match = next((f.name for f in current.fields if f.name.lower() == part.lower()), None)
            if match:
                current = current[match].dataType
            else:
                return False
        else:
            return False
    return True

# Entity struct fields for existence checks (lowercase for case-insensitive matching)
_entity_fields = {f.name.lower() for f in df_entity_distinct.schema["entity"].dataType.fields}

# 3. Flatten relevant fields with correct mapping
sc = safe_cols(df_entity_distinct)
df_fent = df_entity_distinct.select(
    sc("entity.entityId", "entityId"),
    sc("entity.isActive", "isActive"),
    sc("entity.entityType", "entityType"),
    sc("entity.lastUpdatedDate", "lastUpdatedDate"),
    sc("entity.lastUpdatedUser", "lastUpdatedUser"),
    sc("entity.brokerageHolderCount", "brokerageHolderCount"),
    sc("entity.published", "published"),
    sc("entity.diversified", "diversified"),
    sc("entity.entityId", "entityIdDMS"),
    sc("entity.pending", "pending"),
    sc("entity.holderCount", "holderCount"),
    sc("entity.stockHolderCount", "stockHolderCount"),
    sc("entity.bondHolderCount", "bondHolderCount"),
    sc("entity.cryptoHolderCount", "cryptoHolderCount")
)

#Create entity staging view
df_fent.createOrReplaceTempView("staging_entity")

# addressList is nested inside each entity, so explode legalEntityList first, then explode addressList from it
if "addresslist" in _entity_fields:
    df_entityaddress = df_entity_distinct \
        .select(
            col("entity.entityId").alias("entityId"),
            explode(col("entity.addressList")).alias("entityaddress")
        )

    sc = safe_cols(df_entityaddress)
    df_fadd = df_entityaddress.select(
        col("entityId").alias("entityId"),
        sc("entityaddress.addressLineOne", "addressLineOne"),
        sc("entityaddress.addressLineTwo", "addressLineTwo"),
        sc("entityaddress.addressType", "addressType"),
        sc("entityaddress.city", "city"),
        sc("entityaddress.countryCode", "countryCode"),
        sc("entityaddress.countryName", "countryName"),
        sc("entityaddress.postalCode", "postalCode"),
        sc("entityaddress.stateProvinceCode", "stateProvinceCode"),
        sc("entityaddress.stateProvinceName", "stateProvinceName")
    )

    #Create entityaddress staging view
    df_fadd.createOrReplaceTempView("staging_entityaddress")
else:
    empty_view("staging_entityaddress", "entityId STRING, addressLineOne STRING, addressLineTwo STRING, addressType STRING, city STRING, countryCode STRING, countryName STRING, postalCode STRING, stateProvinceCode STRING, stateProvinceName STRING")

if "identifierlist" in _entity_fields:
    df_entityidentifier = df_entity_distinct \
        .select(
            col("entity.entityid").alias("entityid"),
            explode(col("entity.identifierList")).alias("entityidentitfier")
        )

    sc = safe_cols(df_entityidentifier)
    df_fide = df_entityidentifier.select(
        col("entityId").alias("entityId"),
        sc("entityidentitfier.identifierType", "identifierType"),
        sc("entityidentitfier.identifierValue", "identifierValue")
    )

    #Create entityidentitfier staging view
    df_fide.createOrReplaceTempView("staging_entityidentitfier")
else:
    empty_view("staging_entityidentitfier", "entityId STRING, identifierType STRING, identifierValue STRING")

if "namelist" in _entity_fields:
    df_entityname = df_entity_distinct \
        .select(
            col("entity.entityid").alias("entityid"),
            explode(col("entity.nameList")).alias("entityname")
        )

    sc = safe_cols(df_entityname)
    df_fena = df_entityname.select(
        col("entityId").alias("entityId"),
        sc("entityname.isActive", "isActive"),
        sc("entityname.transactionId", "transactionId"),
        sc("entityname.nameType", "nameType"),
        sc("entityname.nameValue", "nameValue")
    )#.dropDuplicates(["entityId", "transactionId", "isActive", "nameType", "nameValue"])

    #Create entityname staging view
    df_fena.createOrReplaceTempView("staging_entityname")
else:
    empty_view("staging_entityname", "entityId STRING, isActive STRING, transactionId STRING, nameType STRING, nameValue STRING")

if "engagement" in _entity_fields:  # already lowercase
    df_engagement = df_entity_distinct \
        .select(
            col("entity.entityid").alias("entityid"),
            col("entity.engagement").alias("engagement")
        )

    sc = safe_cols(df_engagement)
    df_feng = df_engagement.select(
        col("entityId").alias("entityId"),
        col("entityid").alias("entityIdDMS"),
        sc("engagement.restricted", "restricted"),
        sc("engagement.rmdId", "rmdId"),
        sc("engagement.name", "name")
    )#.dropDuplicates(["entityId", "entityIdDMS", "restricted", "rmdId", "name"])

    #Create engagement staging view
    df_feng.createOrReplaceTempView("staging_engagement")
else:
    empty_view("staging_engagement", "entityId STRING, entityIdDMS STRING, restricted STRING, rmdId STRING, name STRING")

# --- dms_EngagementRegion (Entity side) ---
if has_nested_field(df_entity_distinct, "entity.engagement.regionList"):
    df_engregion_entity = df_entity_distinct \
        .select(
            col("entity.entityId").alias("entityId"),
            col("entity.engagement.rmdId").alias("rmdId"),
            explode(col("entity.engagement.regionList")).alias("region")
        )

    sc = safe_cols(df_engregion_entity)
    df_fengregion_entity = df_engregion_entity.select(
        col("entityId").alias("entityId"),
        col("rmdId").alias("rmdId"),
        sc("region.appliedFirmAction", "appliedFirmAction"),
        sc("region.isActive", "isActive"),
        sc("region.region", "region"),
        sc("region.regionCode", "regionCode"),
        sc("region.restrictionReason", "restrictionReason"),
        sc("region.restrictionType", "restrictionType")
    )#.dropDuplicates(["entityId", "rmdId", "appliedFirmAction", "isActive", "region", "regionCode", "restrictionReason", "restrictionType"])

    #Create engagementregion staging view (Entity side)
    df_fengregion_entity.createOrReplaceTempView("staging_engagementregion_entity")
else:
    empty_view("staging_engagementregion_entity", "entityId STRING, rmdId STRING, appliedFirmAction STRING, isActive STRING, region STRING, regionCode STRING, restrictionReason STRING, restrictionType STRING")

# --- dms_RegionOffice (Entity side) ---
if has_nested_field(df_entity_distinct, "entity.engagement.regionList"):
    df_regionoffice_entity = df_entity_distinct \
        .select(
            col("entity.entityId").alias("entityId"),
            col("entity.engagement.rmdId").alias("rmdId"),
            explode(col("entity.engagement.regionList")).alias("region")
        ) \
        .select(
            col("entityId"),
            col("rmdId"),
            col("region"),
            explode(col("region.officeList")).alias("office")
        )

    sc = safe_cols(df_regionoffice_entity)
    df_fregoffice_entity = df_regionoffice_entity.select(
        col("entityId").alias("entityId"),
        col("rmdId").alias("rmdId"),
        sc("region.region", "region"),
        sc("region.regionCode", "regionCode"),
        sc("office.id", "locationOIDH"),
        sc("office.officeNumber", "officeNumber"),
        sc("office.city", "city"),
        sc("office.state", "state"),
        sc("office.country", "country"),
        sc("office.count", "count")
    )#.dropDuplicates(["entityId", "rmdId", "locationOIDH", "officeNumber", "city", "state", "country", "count"])

    #Create regionoffice staging view (Entity side)
    df_fregoffice_entity.createOrReplaceTempView("staging_regionoffice_entity")
else:
    empty_view("staging_regionoffice_entity", "entityId STRING, rmdId STRING, region STRING, regionCode STRING, locationOIDH STRING, officeNumber STRING, city STRING, state STRING, country STRING, count STRING")


# COMMAND ----------

# DBTITLE 1,Security Domain - JSON Flattening
# =============================================
# SECURITY DOMAIN (from securityList)
# =============================================

if "securityList" not in df_raw.columns:
    print("INFO: 'securityList' not found in source JSON data — creating empty staging views with proper schemas.")

    # --- Empty dms_Security ---
    df_fsec = spark.createDataFrame([], schema="securityIdDMS STRING, securityId STRING, isActive STRING, lastUpdatedDate STRING, lastUpdatedUser STRING, securityType STRING, securitySubType STRING, countryCode STRING, countryName STRING, underlyingFund STRING, pending STRING, holderCount STRING, Diversified STRING, Public STRING, Published STRING")
    df_fsec.createOrReplaceTempView("staging_security")

    # --- Empty dms_SecurityEntity ---
    df_fsecent = spark.createDataFrame([], schema="securityId STRING, entityIdDMS STRING, entityId STRING")
    df_fsecent.createOrReplaceTempView("staging_securityentity")

    # --- Empty dms_SecurityIdentifier ---
    df_fsecide = spark.createDataFrame([], schema="securityId STRING, identifierType STRING, identifierValue STRING")
    df_fsecide.createOrReplaceTempView("staging_securityidentifier")

    # --- Empty dms_SecurityName ---
    df_fsecname = spark.createDataFrame([], schema="securityId STRING, active STRING,TransactionId STRING, nameType STRING, nameValue STRING")
    df_fsecname.createOrReplaceTempView("staging_securityname")

    # --- Empty dms_SecuritySymbolExchange ---
    df_fsecsymex = spark.createDataFrame([], schema="securityId STRING, exchange STRING, symbol STRING")
    df_fsecsymex.createOrReplaceTempView("staging_securitysymbolexchange")

    # --- Empty dms_Engagement (Security side) ---
    df_fengsec = spark.createDataFrame([], schema="securityId STRING, securityIdDMS STRING, restricted STRING, rmdId STRING, name STRING")
    df_fengsec.createOrReplaceTempView("staging_engagement_security")

    # --- Empty dms_EngagementRegion (Security side) ---
    df_fengregion_sec = spark.createDataFrame([], schema="Engagementid STRING, rmdId STRING, appliedFirmAction STRING, isActive STRING, region STRING, regionCode STRING, restrictionReason STRING, restrictionType STRING")
    df_fengregion_sec.createOrReplaceTempView("staging_engagementregion_security")

    # --- Empty dms_RegionOffice (Security side) ---
    df_fregoffice_sec = spark.createDataFrame([], schema="securityId STRING, rmdId STRING, region STRING, regionCode STRING, locationOIDH STRING, officeNumber STRING, city STRING, state STRING, country STRING,count BIGINT")
    df_fregoffice_sec.createOrReplaceTempView("staging_regionoffice_security")

else:

    # --- dms_Security ---
    df_security = df_raw.select(explode("securityList").alias("security"))

    # Deduplicate by securityId so only distinct securities flow through all staging views
    df_security_distinct = df_security.withColumn("_sid", col("security.securityId")).dropDuplicates(["_sid"]).drop("_sid")
    print(f"Total exploded securities: {df_security.count()}, Distinct securities: {df_security_distinct.count()}")

    # Security struct fields for existence checks (lowercase for case-insensitive matching)
    _security_fields = {f.name.lower() for f in df_security_distinct.schema["security"].dataType.fields}

    sc = safe_cols(df_security_distinct)
    df_fsec = df_security_distinct.select(
        sc("security.securityId", "securityIdDMS"),
        sc("security.securityId", "securityId"),
        sc("security.isActive", "isActive"),
        sc("security.lastUpdatedDate", "lastUpdatedDate"),
        sc("security.lastUpdatedUser", "lastUpdatedUser"),
        sc("security.securityType", "securityType"),
        sc("security.securitySubType", "securitySubType"),
        sc("security.countryCode", "countryCode"),
        sc("security.countryName", "countryName"),
        sc("security.underlyingFund", "underlyingFund"),
        sc("security.pending", "pending"),
        sc("security.holderCount", "holderCount"),
        sc("security.diversified", "Diversified"),
        sc("security.public", "Public"),
        sc("security.published", "Published")
    )

    #Create security staging view
    df_fsec.createOrReplaceTempView("staging_security")

    # --- dms_SecurityEntity ---
    if "entityidlist" in _security_fields:
        df_securityentity = df_security_distinct \
            .select(
                col("security.securityId").alias("securityId"),
                explode(col("security.entityIdList")).alias("entityIdValue")
            )

        df_fsecent = df_securityentity.select(
            col("securityId"),
            col("entityIdValue").alias("entityIdDMS"),
            col("entityIdValue").alias("entityId")
        )

        #Create securityentity staging view
        df_fsecent.createOrReplaceTempView("staging_securityentity")
    else:
        empty_view("staging_securityentity", "securityId STRING, entityIdDMS STRING, entityId STRING")

    # --- dms_SecurityIdentifier ---
    if "identifierlist" in _security_fields:
        df_securityidentifier = df_security_distinct \
            .select(
                col("security.securityId").alias("securityId"),
                explode(col("security.identifierList")).alias("secidentifier")
            )

        sc = safe_cols(df_securityidentifier)
        df_fsecide = df_securityidentifier.select(
            col("securityId"),
            sc("secidentifier.identifierType", "identifierType"),
            sc("secidentifier.identifierValue", "identifierValue")
        )

        #Create securityidentifier staging view
        df_fsecide.createOrReplaceTempView("staging_securityidentifier")
    else:
        empty_view("staging_securityidentifier", "securityId STRING, identifierType STRING, identifierValue STRING")

    # --- dms_SecurityName ---
    if "namelist" in _security_fields:
        df_securityname = df_security_distinct \
            .select(
                col("security.securityId").alias("securityId"),
                explode(col("security.nameList")).alias("secname")
            )

        sc = safe_cols(df_securityname)
        df_fsecname = df_securityname.select(
            col("securityId"),
            sc("secname.active", "active"),
            sc("secname.transactionId", "transactionId"),
            sc("secname.nameType", "nameType"),
            sc("secname.nameValue", "nameValue")
        )#.dropDuplicates(["securityId", "transactionId", "active", "nameType", "nameValue"])

        #Create securityname staging view
        df_fsecname.createOrReplaceTempView("staging_securityname")
    else:
        empty_view("staging_securityname", "securityId STRING, active STRING, transactionId STRING, nameType STRING, nameValue STRING")

    # --- dms_SecuritySymbolExchange ---
    if "symbolexchangelist" in _security_fields:
        df_securitysymbolexchange = df_security_distinct \
            .select(
                col("security.securityId").alias("securityId"),
                explode(col("security.symbolExchangeList")).alias("symbolexchange")
            )

        sc = safe_cols(df_securitysymbolexchange)
        df_fsecsymex = df_securitysymbolexchange.select(
            col("securityId"),
            sc("symbolexchange.exchange", "exchange"),
            sc("symbolexchange.symbol", "symbol")
        )

        #Create securitysymbolexchange staging view
        df_fsecsymex.createOrReplaceTempView("staging_securitysymbolexchange")
    else:
        empty_view("staging_securitysymbolexchange", "securityId STRING, exchange STRING, symbol STRING")

    # --- dms_Engagement (Security side) ---
    if "engagement" in _security_fields:  # already lowercase
        df_engagement_sec = df_security_distinct \
            .select(
                col("security.securityId").alias("securityId"),
                col("security.securityId").alias("securityIdDMS"),
                col("security.engagement").alias("engagement")
            )

        sc = safe_cols(df_engagement_sec)
        df_fengsec = df_engagement_sec.select(
            col("securityId"),
            col("securityIdDMS"),
            sc("engagement.restricted", "restricted"),
            sc("engagement.rmdId", "rmdId"),
            sc("engagement.name", "name")
        )#.dropDuplicates(["securityId", "securityIdDMS", "restricted", "rmdId", "name"])

        #Create engagement staging view (Security side)
        df_fengsec.createOrReplaceTempView("staging_engagement_security")
    else:
        empty_view("staging_engagement_security", "securityId STRING, securityIdDMS STRING, restricted STRING, rmdId STRING, name STRING")

    # --- dms_EngagementRegion (Security side) ---
    if has_nested_field(df_security_distinct, "security.engagement.regionList"):
        df_engregion_sec = df_security_distinct \
            .select(
                col("security.securityId").alias("securityId"),
                col("security.engagement.rmdId").alias("rmdId"),
                explode(col("security.engagement.regionList")).alias("region")
            )

        sc = safe_cols(df_engregion_sec)
        df_fengregion_sec = df_engregion_sec.select(
            col("securityId").alias("securityId"),
            col("rmdId").alias("rmdId"),
            sc("region.appliedFirmAction", "appliedFirmAction"),
            sc("region.isActive", "isActive"),
            sc("region.region", "region"),
            sc("region.regionCode", "regionCode"),
            sc("region.restrictionReason", "restrictionReason"),
            sc("region.restrictionType", "restrictionType")
        )#.dropDuplicates(["securityId", "rmdId", "appliedFirmAction", "isActive", "region", "regionCode", "restrictionReason", "restrictionType"])

        #Create engagementregion staging view (Security side)
        df_fengregion_sec.createOrReplaceTempView("staging_engagementregion_security")
    else:
        empty_view("staging_engagementregion_security", "securityId STRING, rmdId STRING, appliedFirmAction STRING, isActive STRING, region STRING, regionCode STRING, restrictionReason STRING, restrictionType STRING")

    # --- dms_RegionOffice (Security side) ---
    if has_nested_field(df_security_distinct, "security.engagement.regionList"):
        df_regionoffice_sec = df_security_distinct \
            .select(
                col("security.securityId").alias("securityId"),
                col("security.engagement.rmdId").alias("rmdId"),
                explode(col("security.engagement.regionList")).alias("region")
            ) \
            .select(
                col("securityId"),
                col("rmdId"),
                col("region"),
                explode(col("region.officeList")).alias("office")
            )

        sc = safe_cols(df_regionoffice_sec)
        df_fregoffice_sec = df_regionoffice_sec.select(
            col("securityId").alias("securityId"),
            col("rmdId").alias("rmdId"),
            sc("region.region", "region"),
            sc("region.regionCode", "regionCode"),
            sc("office.id", "locationOIDH"),
            sc("office.officeNumber", "officeNumber"),
            sc("office.city", "city"),
            sc("office.state", "state"),
            sc("office.country", "country"),
            sc("office.count", "count")
        )#.dropDuplicates(["securityId", "rmdId", "locationOIDH", "officeNumber", "city", "state", "country", "count"])

        #Create regionoffice staging view (Security side)
        df_fregoffice_sec.createOrReplaceTempView("staging_regionoffice_security")
    else:
        empty_view("staging_regionoffice_security", "securityId STRING, rmdId STRING, region STRING, regionCode STRING, locationOIDH STRING, officeNumber STRING, city STRING, state STRING, country STRING, count BIGINT")

# COMMAND ----------

# DBTITLE 1,Dynamic Load: Staging Views to Target Tables
# =============================================
# Dynamic Load: Staging Views → Target Tables
# =============================================

# --- Combine Entity + Security EngagementRegion staging views (distinct union) ---
# _engregion_entity = spark.table("staging_engagementregion_entity")
# _engregion_security = spark.table("staging_engagementregion_security")
# _engregion_entity.unionByName(_engregion_security).distinct().createOrReplaceTempView("staging_engagementregion_combined")

# --- Load Plans: target table ↔ staging view ---
LOAD_PLANS = [
    # Entity Domain
    {"domain": "Entity", "target_table": "dms_Entity", "view_name": "staging_entity"},
    {"domain": "Entity", "target_table": "dms_EntityAddress", "view_name": "staging_entityaddress"},
    {"domain": "Entity", "target_table": "dms_EntityIdentifier", "view_name": "staging_entityidentitfier"},
    {"domain": "Entity", "target_table": "dms_EntityName", "view_name": "staging_entityname"},
    {"domain": "Entity", "target_table": "dms_Engagement", "view_name": "staging_engagement"},
    {"domain": "Entity", "target_table": "dms_EngagementRegion", "view_name": "staging_engagementregion_entity"},
    {"domain": "Entity", "target_table": "dms_RegionOffice", "view_name": "staging_regionoffice_entity"},
    # Security Domain
    {"domain": "Security", "target_table": "dms_Security", "view_name": "staging_security"},
    {"domain": "Security", "target_table": "dms_SecurityEntity", "view_name": "staging_securityentity"},
    {"domain": "Security", "target_table": "dms_SecurityIdentifier", "view_name": "staging_securityidentifier"},
    {"domain": "Security", "target_table": "dms_SecurityName", "view_name": "staging_securityname"},
    {"domain": "Security", "target_table": "dms_SecuritySymbolExchange", "view_name": "staging_securitysymbolexchange"},
    {"domain": "Security", "target_table": "dms_Engagement", "view_name": "staging_engagement_security"},
    {"domain": "Security", "target_table": "dms_EngagementRegion", "view_name": "staging_engagementregion_security"},
    {"domain": "Security", "target_table": "dms_RegionOffice", "view_name": "staging_regionoffice_security"},
]
# LOAD_PLANS = [
#     # Entity Domain
#     {"domain": "Entity", "target_table": "dms_Entity", "view_name": "staging_entity"},
#     {"domain": "Entity", "target_table": "dms_EntityAddress", "view_name": "staging_entityaddress"},
#     {"domain": "Entity", "target_table": "dms_EntityIdentifier", "view_name": "staging_entityidentitfier"},
#     {"domain": "Entity", "target_table": "dms_EntityName", "view_name": "staging_entityname"},
#     {"domain": "Entity", "target_table": "dms_Engagement", "view_name": "staging_engagement"},
#     {"domain": "Entity+Security", "target_table": "dms_EngagementRegion", "view_name": "staging_engagementregion_combined"},
#     {"domain": "Entity", "target_table": "dms_RegionOffice", "view_name": "staging_regionoffice_entity"},
#     # Security Domain
#     {"domain": "Security", "target_table": "dms_Security", "view_name": "staging_security"},
#     {"domain": "Security", "target_table": "dms_SecurityEntity", "view_name": "staging_securityentity"},
#     {"domain": "Security", "target_table": "dms_SecurityIdentifier", "view_name": "staging_securityidentifier"},
#     {"domain": "Security", "target_table": "dms_SecurityName", "view_name": "staging_securityname"},
#     {"domain": "Security", "target_table": "dms_SecuritySymbolExchange", "view_name": "staging_securitysymbolexchange"},
#     {"domain": "Security", "target_table": "dms_Engagement", "view_name": "staging_engagement_security"},
#     {"domain": "Security", "target_table": "dms_RegionOffice", "view_name": "staging_regionoffice_security"},
# ]

# --- Audit Columns ---
audit_columns = [
    ("is_data_valid", "boolean", True),
    ("gds_batch_id", "int", wid_BatchID),
    ("pipeline_run_id", "string", wid_PipelineRunID),
    ("source_system_id", "int", wid_SystemID),
    ("ingested_date", "timestamp", datetime.now(timezone).strftime("%Y-%m-%d %H:%M:%S")),
]

AUDIT_SQL_EXPRESSIONS = {
    ac[0].lower(): (
        f"CAST('{ac[2]}' AS {ac[1]})"
        if isinstance(ac[2], str)
        else f"CAST({ac[2]} AS {ac[1]})"
    )
    for ac in audit_columns
}

# --- Special Target Expressions (hardcoded values for columns not in source) ---
# Note: Identity columns (AddressId, IdentifierId, EntityNameId, EngagementId)
# are GENERATED ALWAYS AS IDENTITY in Delta — omit them so they auto-generate.
SPECIAL_TARGET_EXPRESSIONS = {
    "dms_entity": {
        "issecregistrant": "CAST(TRUE AS BOOLEAN)",
    },
    "dms_engagement": {
        "isactive": "CAST(TRUE AS BOOLEAN)",
        "mutualfundcomments": "CAST('NA' AS STRING)",
    },
}

# --- Special Source Expressions (transformations on source columns) ---
SPECIAL_SOURCE_EXPRESSIONS = {
    "dms_entityaddress": {
        "city": "COALESCE(`city`, 'NA')",
    },
    "dms_engagement": {
        "name": "COALESCE(`name`, 'NA')",
    },
}

# --- Execute Dynamic Loads ---
load_results = []

for plan in LOAD_PLANS:
    target_table = plan["target_table"]
    staging_view_name = plan["view_name"]

    # Check if staging view exists
    try:
        staging_df = spark.table(staging_view_name)
        source_row_count = staging_df.count()
    except Exception:
        load_results.append((plan["domain"], target_table, staging_view_name, 0, 0, "skipped", "staging view not found"))
        continue
    if source_row_count == 0:
        load_results.append((plan["domain"], target_table, staging_view_name, 0, 0, "skipped", "no rows to load"))
        continue

    full_table_name = f"gds_grdm_raw.{target_table}"

    try:
        target_fields = spark.table(full_table_name).schema.fields
    except Exception as exc:
        load_results.append((plan["domain"], target_table, staging_view_name, source_row_count, 0, "error", str(exc)[:250]))
        continue

    # Build case-insensitive source column map
    source_col_map = {c.lower(): c for c in staging_df.columns}

    insert_columns = []
    select_expressions = []

    for field in target_fields:
        target_col = field.name
        target_col_lower = target_col.lower()

        if target_col_lower in source_col_map:
            actual_src_col = source_col_map[target_col_lower]
            custom_expr = SPECIAL_SOURCE_EXPRESSIONS.get(target_table.lower(), {}).get(target_col_lower)
            insert_columns.append(target_col)
            select_expressions.append(custom_expr if custom_expr else f"`{actual_src_col}`")
        elif target_col_lower in AUDIT_SQL_EXPRESSIONS:
            insert_columns.append(target_col)
            select_expressions.append(AUDIT_SQL_EXPRESSIONS[target_col_lower])
        elif target_col_lower in SPECIAL_TARGET_EXPRESSIONS.get(target_table.lower(), {}):
            insert_columns.append(target_col)
            select_expressions.append(SPECIAL_TARGET_EXPRESSIONS[target_table.lower()][target_col_lower])

    if not insert_columns:
        load_results.append((plan["domain"], target_table, staging_view_name, source_row_count, 0, "skipped", "no matching columns"))
        continue

    # Build WHERE clause to block inserts when gds_batch_id is NULL
    batch_id_expr = AUDIT_SQL_EXPRESSIONS.get("gds_batch_id")
    where_clause = f"WHERE {batch_id_expr} IS NOT NULL" if batch_id_expr else ""

    insert_sql = f"""
    INSERT INTO {full_table_name}
    ({', '.join([f'`{c}`' for c in insert_columns])})
    SELECT {', '.join(select_expressions)}
    FROM {staging_view_name}
    {where_clause}
    """

    try:
        spark.sql(insert_sql)
        load_results.append((plan["domain"], target_table, staging_view_name, source_row_count, len(insert_columns), "loaded", "success"))
    except Exception as exc:
        load_results.append((plan["domain"], target_table, staging_view_name, source_row_count, len(insert_columns), "error", str(exc)[:250]))

# --- Display Load Results ---
result_df = spark.createDataFrame(
    load_results,
    ["Domain", "TargetTable", "StagingView", "SourceRows", "InsertedColumns", "Status", "Details"]
)
display(result_df)