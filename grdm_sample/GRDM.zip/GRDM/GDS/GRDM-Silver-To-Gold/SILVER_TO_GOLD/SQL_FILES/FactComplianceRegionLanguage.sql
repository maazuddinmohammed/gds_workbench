SELECT 
   src.ComplianceRegionLanguageID,
   src.ComplianceRegionLanguageNumber,
   src.ComplianceRegionLanguageName,
   dcr.ComplianceRegionKey,
   l.LanguageKey,
   src.ComplianceRegionLanguageProductionTime,
   src.ComplianceRegionLanguageArchivedTime,
   src.ComplianceRegionLanguageCheckInCheckOutTime,
   src.ComplianceRegionLanguageCheckInCheckOutStatus,
   ds.UserKey AS ComplianceRegionLanguageCheckInCheckOutUserKey,
   src.ComplianceRegionLanguageStatus,
   src.ComplianceRegionLanguageCopiedFrom,
   fcl.ComplianceRegionLanguageKey AS ParentComplianceRegionLanguageKey,
   src.IsDefault,
   src.IsSystemEnabled,
   src.SourceCreatedDate,
   src.SourceUpdatedDate,
   src.SourceCreatedBy,
   src.SourceUpdatedBy,
   src.SourceSystemId 
FROM gds_grdm_int.ComplianceRegionLanguage src
LEFT JOIN gds_grdm.DimComplianceRegion dcr ON 
  src.ComplianceRegionID = dcr.ComplianceRegionID
LEFT JOIN gds_ref.DimLanguage l ON
  l.LanguageID = src.LanguageID
LEFT JOIN gds_grdm.DimUser ds ON
  ds.UserID = src.ComplianceRegionLanguageCheckInCheckOutUserID AND ds.IsHistory = False 
LEFT JOIN gds_grdm.FactComplianceRegionLanguage fcl ON
  fcl.ComplianceRegionLanguageID = src.ParentComplianceRegionLanguageID    
WHERE 
  src.GDSBatchID = wid_GDSBatchID