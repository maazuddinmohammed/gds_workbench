select 
 src.QuestionGroupAnswerTreeID as QuestionGroupAnswerTreeID,  
  src.QuestionGroupAnswerTreeNumber,
  cr.ComplianceRegionKey,
  q.QuestionKey,
  q2.QuestionKey as NextQuestionKey,
  l.LanguageKey,
  qd.QuestionGroupAnswerDescriptionKey,
  src.QuestionGroupAnswerTreeChosenID,
  src.QuestionGroupAnswerTreeChosenAction,
  src.QuestionGroupAnswerTreeChoiceType,
  src.QuestionGroupAnswerTreeChoiceOrder,
  src.QuestionGroupAnswerTreeChoiceText ,
  src.QuestionGroupAnswerTreeSupplementalDataSectionID,
  src.QuestionGroupAnswerTreeStyle,
  src.QuestionGroupAnswerTreeStatus,
  src.QuestionGroupAnswerTreeName,
  src.QuestionGroupAnswerTreeModificationNumber,
  src.QuestionGroupAnswerTreeIdentifier,
  src.QuestionGroupAnswerTreeProductionTime,
  ds1.Userkey AS QuestionGroupAnswerTreeProductionUserKey,
  src.QuestionGroupAnswerTreeArchiveTime,
  ds.Userkey AS QuestionGroupAnswerTreeArchiveUserKey,
  src.IsSupplementalDataEnabled,
  src.IsSystemQueryComparisonEnabled, 
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
  FROM gds_grdm_int.QuestionGroupAnswerTree src  
  LEFT JOIN gds_grdm.DimComplianceRegion cr ON 
  cr.ComplianceRegionID = src.ComplianceRegionID
  LEFT JOIN gds_grdm.DimQuestion q ON
   src.QuestionId= q.QuestionId
  LEFT JOIN gds_ref.DimLanguage l ON
   src.languageid=l.languageid
  LEFT JOIN gds_grdm.FactQuestionGroupAnswerDescription qd ON 
   src.QuestionGroupAnswerDescriptionID = qd.QuestionGroupAnswerDescriptionID
  LEFT JOIN gds_grdm.DimUser ds ON 
   ds.UserID = src.QuestionGroupAnswerTreeArchiveUserID AND ds.IsHistory= false
  LEFT JOIN gds_grdm.DimUser ds1 ON 
   ds1.UserID = src.QuestionGroupAnswerTreeProductionUserID AND ds1.IsHistory= false
  LEFT JOIN gds_grdm.DimQuestion q2 ON 
   q2.QuestionID = src.NextQuestionID
 WHERE src.GDSBatchID = wid_GDSBatchID 