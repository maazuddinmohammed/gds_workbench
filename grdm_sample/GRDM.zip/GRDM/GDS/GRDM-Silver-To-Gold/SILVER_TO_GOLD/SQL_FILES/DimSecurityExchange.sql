SELECT 
  src.SecurityExchangeID,
  src.SecurityExchangeNumber,
  src.SecurityExchangeName,
  src.SecurityExchangeSymbol,
  src.SecurityExchangeEffectiveDate,
  src.SecurityExchangeExpirationDate,
  dcr.ComplianceRegionKey,
  src.IsStockAvailable,
  src.IsMutualFundAvailable,
  src.IsBondAvailable,
  src.IsUnitInvestmentTrustAvailable,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.securityexchange src
LEFT JOIN 
  gds_grdm.dimcomplianceregion dcr ON src.ComplianceRegionID=dcr.ComplianceRegionID
WHERE
  src.GDSBatchID = wid_GDSBatchID
