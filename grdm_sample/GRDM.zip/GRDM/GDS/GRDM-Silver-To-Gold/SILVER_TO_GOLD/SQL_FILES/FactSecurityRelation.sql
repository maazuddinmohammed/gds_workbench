SELECT
  src.SecurityRelationID,
  src.SecurityRelationTime,
  src.SecurityRelationNumber,
  Coalesce(de1.EntityKey,-1) AS ParentEntityKey, 
  ds.SecurityKey AS ChildSecurityKey,
  de2.EntityKey AS ChildEntityKey,
  srt.SecurityRelationTypeNumber,
  srt.SecurityRelationTypeName,
  srt.SecurityRelationTypeBusinessName,
  srt.SecurityRelationTypeDescription,
  s.StatusName AS SecurityRelationStatus,
  src.IsRestrictionFlowDown,
  src.IsHistory,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM
(
SELECT
  SecurityRelationID,
  CreatedDate AS SecurityRelationTime,
  SecurityRelationNumber,
  ParentEntityComplianceID,
  ChildSecurityID,
  ChildEntityComplianceID,
  SecurityRelationTypeID,
  SecurityRelationStatusID,
  IsRestrictionFlowDown,
  cast(0 AS Boolean ) AS IsHistory,
  SourceCreatedDate,
  SourceUpdatedDate,
  SourceCreatedBy,
  SourceUpdatedBy,
  SourceSystemID
FROM gds_grdm_int.securityrelation
WHERE GDSBatchID = wid_GDSBatchID

UNION ALL 

SELECT
  SecurityRelationID,
  SecurityRelationHistoryTime AS SecurityRelationTime,
  SecurityRelationNumber,
  ParentEntityComplianceID,
  ChildSecurityID,
  ChildEntityComplianceID,
  SecurityRelationTypeID,
  SecurityRelationStatusID,
  IsRestrictionFlowDown,
  cast(1 AS Boolean ) AS IsHistory,
  SourceCreatedDate,
  SourceUpdatedDate,
  SourceCreatedBy,
  SourceUpdatedBy,
  SourceSystemID
FROM gds_grdm_int.securityrelationhistory 
WHERE GDSBatchID = wid_GDSBatchID
) src
LEFT JOIN gds_grdm_int.securityrelationtype srt ON src.SecurityRelationTypeID=srt.SecurityRelationTypeID
LEFT JOIN gds_ref_int.status s ON src.SecurityRelationStatusID=s.StatusID 
LEFT JOIN gds_grdm_int.EntityCompliance erp ON erp.entitycomplianceid = src.ParentEntityComplianceID  
LEFT JOIN gds_grdm_int.EntityCompliance erc ON erc.entitycomplianceid = src.ChildEntityComplianceID  
LEFT JOIN gds_grdm.dimentity de1 ON erp.EntityID=de1.EntityID
LEFT JOIN gds_grdm.dimentity de2 ON erc.EntityID=de2.EntityID
LEFT JOIN gds_grdm.dimsecurity ds ON src.ChildSecurityID=ds.SecurityID AND ds.IsHistory=false 