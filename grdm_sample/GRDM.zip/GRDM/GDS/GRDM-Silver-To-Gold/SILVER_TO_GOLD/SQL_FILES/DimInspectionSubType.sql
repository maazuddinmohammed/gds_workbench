SELECT 
   src.InspectionSubTypeID AS InspectionSubTypeID,
   src.InspectionSubTypeNumber AS InspectionSubTypeNumber,
   src.InspectionSubTypeName AS InspectionSubTypeName,
   src.InspectionSubTypeBusinessName AS InspectionSubTypeBusinessName,
   src.InspectionSubTypeDescription AS InspectionSubTypeDescription,
   dcr.ComplianceRegionKey,
   src.InspectionSubTypeEffectiveStartDate,
   src.InspectionSubTypeEffectiveEndDate,
   src.InspectionSubTypeIdentifier,
   src.ParentInspectionSubTypeListCodeNumber,
   src.InspectionSubTypeAssociatedSecurityType,
   src.InspectionSubTypeIsFinancialInterestBeReassignedIssuer,
   src.InspectionSubTypeSICCode,
   src.InspectionSubTypeShowAcknowledgementCheckbox,
   src.InspectionSubTypeRequireCommentFieldWhenAddHolding,
   src.InspectionSubTypeFinancialInterestDisplayType,
   src.InspectionSubTypeIsAccountTypeEligibleForBrokerageImport,   
   src.SourceCreatedDate,
   src.SourceUpdatedDate,
   src.SourceCreatedBy,
   src.SourceUpdatedBy,
   src.SourceSystemId 
FROM gds_grdm_int.InspectionSubType src
LEFT JOIN 
   gds_grdm.DimComplianceRegion dcr ON src.ComplianceRegionID = dcr.ComplianceRegionID
WHERE 
  src.GDSBatchID = wid_GDSBatchID