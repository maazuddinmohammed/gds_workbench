SELECT 
   src.DependentRelationshipTypeID,
   src.DependentRelationshipTypeNumber,
   src.DependentRelationshipTypeName,
   src.DependentRelationshipTypeBusinessName,
   src.DependentRelationshipTypeDescription,
   dcr.ComplianceRegionKey,
   src.DependentRelationshipTypeEffectiveStartDate,
   src.DependentRelationshipTypeEffectiveEndDate,
   src.DependentRelationshipTypeIdentifier,
   src.ParentDependentRelationshipTypeListCodeNumber,
   src.DependentRelationshipTypeAssociatedSecurityType,
   src.DependentRelationshipTypeIsFinancialInterestBeReassignedIssuer,
   src.DependentRelationshipTypeSICCode,
   src.DependentRelationshipTypeShowAcknowledgementCheckbox,
   src.DependentRelationshipTypeRequireCommentFieldWhenAddHolding,
   src.DependentRelationshipTypeFinancialInterestDisplayType,
   src.DependentRelationshipTypeIsAccountTypeEligibleForBrokerageImport,   
   src.SourceCreatedDate,
   src.SourceUpdatedDate,
   src.SourceCreatedBy,
   src.SourceUpdatedBy,
   src.SourceSystemId 
FROM gds_grdm_int.DependentRelationshipType src
LEFT JOIN 
   gds_grdm.DimComplianceRegion dcr ON src.ComplianceRegionID = dcr.ComplianceRegionID
WHERE 
  src.GDSBatchID = wid_GDSBatchID