SELECT   
  src.SecurityRestrictionID,
  src.SecurityRestrictionTime,
  src.SecurityRestrictionNumber,
  ds.SecurityKey,
  dcc.ComplianceRegionKey,
  dcp.ComplianceRegionKey AS ParentComplianceRegionKey,
  drt.RestrictionTypeKey,
  drs.RestrictionStateKey,
  src.SecurityRestriction,
  src.SecurityRestrictionReason,
  src.SecurityRestrictionEngagementPartnerAssignmentArray,
  src.SecurityRestrictionCoveredPersonAttributeArray,
  src.IsRestricted,
  src.IsApplicable,
  src.IsHistory,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM (
  SELECT 
    SecurityRestrictionID,
    CreatedDate AS SecurityRestrictionTime,
    SecurityRestrictionNumber,
    SecurityID,
    ParentComplianceRegionID,
    SecurityRestriction,
    ComplianceRegionID,
    RestrictionTypeID,
    RestrictionStateID,
    SecurityRestrictionReason,
    SecurityRestrictionEngagementPartnerAssignmentArray,
    SecurityRestrictionCoveredPersonAttributeArray,
    IsRestricted,
    IsApplicable,
    CAST(0 AS boolean) AS IsHistory,
    SourceCreatedDate,
    SourceUpdatedDate,
    SourceCreatedBy,
    SourceUpdatedBy,
    SourceSystemID
  FROM gds_grdm_int.securityrestriction
  WHERE GDSBatchID = wid_GDSBatchID 

  UNION ALL

  SELECT 
    SecurityRestrictionHistoryID AS SecurityRestrictionID,
    SecurityRestrictionHistoryTime AS SecurityRestrictionTime,
    SecurityRestrictionNumber,
    SecurityID,
    ParentComplianceRegionID,
    SecurityRestriction,
    ComplianceRegionID,
    RestrictionTypeID,
    RestrictionStateID,
    SecurityRestrictionReason,
    SecurityRestrictionEngagementPartnerAssignmentArray,
    SecurityRestrictionCoveredPersonAttributeArray,
    IsRestricted,
    IsApplicable,
    CAST(1 AS boolean) AS IsHistory,
    SourceCreatedDate,
    SourceUpdatedDate,
    SourceCreatedBy,
    SourceUpdatedBy,
    SourceSystemID
  FROM gds_grdm_int.securityrestrictionhistory 
  WHERE GDSBatchID = wid_GDSBatchID
) src
LEFT JOIN gds_grdm.DimSecurity ds 
  ON src.SecurityID = ds.SecurityID 
  AND ds.IsHistory = 'false'  
LEFT JOIN gds_grdm.DimComplianceRegion dcp 
  ON src.ParentComplianceRegionID = dcp.ComplianceRegionID 
LEFT JOIN gds_grdm.DimComplianceRegion dcc 
  ON src.ComplianceRegionID = dcc.ComplianceRegionID 
LEFT JOIN gds_grdm.DimRestrictionType drt 
  ON src.RestrictionTypeID = drt.RestrictionTypeID
LEFT JOIN gds_grdm.DimRestrictionState drs 
  ON src.RestrictionStateID = drs.RestrictionStateID