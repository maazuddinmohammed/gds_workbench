SELECT 
  src.QuestionSetAssignmentID,
  src.QuestionSetAssignmentStatus,
  src.QuestionSetID,
  qs.QuestionSetNumber,
  qs.QuestionSetName,
  qs.QuestionSetBusinessName,
  qs.QuestionSetDescription,
  src.QuestionSetQuestionType,
  qg.QuestionGroupId AS QuestionGroupKey,
  src.IsDefaultQuestionSet,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.QuestionGroupQuestionBridge src
LEFT JOIN gds_grdm_int.QuestionSet qs ON
  qs.QuestionSetID = src.QuestionSetID
LEFT JOIN gds_grdm_int.QuestionGroup qg ON
  qg.QuestionGroupID = src.QuestionGroupID
WHERE
  src.GDSBatchID = wid_GDSBatchID