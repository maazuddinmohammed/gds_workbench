SELECT 
   src.PropertyTypeID AS PropertyTypeID,
   src.PropertyTypeNumber AS PropertyTypeNumber,
   src.PropertyTypeName AS PropertyTypeName,
   src.PropertyTypeBusinessName AS PropertyTypeBusinessName,
   src.PropertyTypeDescription AS PropertyTypeDescription,
   dcr.ComplianceRegionKey,
   src.PropertyTypeEffectiveStartDate,
   src.PropertyTypeEffectiveEndDate,
   src.PropertyTypeIdentifier,
   src.ParentPropertyTypeListCodeNumber,
   src.PropertyTypeAssociatedSecurityType,
   src.PropertyTypeIsFinancialInterestBeReassignedIssuer,
   src.PropertyTypeSICCode,
   src.PropertyTypeShowAcknowledgementCheckbox,
   src.PropertyTypeRequireCommentFieldWhenAddHolding,
   src.PropertyTypeFinancialInterestDisplayType,
   src.PropertyTypeIsAccountTypeEligibleForBrokerageImport,   
   src.SourceCreatedDate,
   src.SourceUpdatedDate,
   src.SourceCreatedBy,
   src.SourceUpdatedBy,
   src.SourceSystemId 
FROM gds_grdm_int.PropertyType src
LEFT JOIN 
   gds_grdm.DimComplianceRegion dcr ON src.ComplianceRegionID = dcr.ComplianceRegionID
WHERE 
  src.GDSBatchID = wid_GDSBatchID