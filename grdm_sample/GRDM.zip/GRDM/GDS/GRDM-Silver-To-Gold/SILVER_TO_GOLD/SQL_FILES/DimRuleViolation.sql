SELECT 
   src.RuleViolationID AS RuleViolationID,
   src.RuleViolationNumber AS RuleViolationNumber,
   src.RuleViolationName AS RuleViolationName,
   src.RuleViolationBusinessName AS RuleViolationBusinessName,
   src.RuleViolationDescription AS RuleViolationDescription,
   dcr.ComplianceRegionKey,
   src.RuleViolationEffectiveStartDate,
   src.RuleViolationEffectiveEndDate,
   src.RuleViolationIdentifier,
   src.ParentRuleViolationListCodeNumber,
   src.RuleViolationAssociatedSecurityType,
   src.RuleViolationIsFinancialInterestBeReassignedIssuer,
   src.RuleViolationSICCode,
   src.RuleViolationShowAcknowledgementCheckbox,
   src.RuleViolationRequireCommentFieldWhenAddHolding,
   src.RuleViolationFinancialInterestDisplayType,
   src.RuleViolationIsAccountTypeEligibleForBrokerageImport,   
   src.SourceCreatedDate,
   src.SourceUpdatedDate,
   src.SourceCreatedBy,
   src.SourceUpdatedBy,
   src.SourceSystemId 
FROM gds_grdm_int.RuleViolation src
LEFT JOIN 
   gds_grdm.DimComplianceRegion dcr ON src.ComplianceRegionID = dcr.ComplianceRegionID
WHERE 
  src.GDSBatchID = wid_GDSBatchID