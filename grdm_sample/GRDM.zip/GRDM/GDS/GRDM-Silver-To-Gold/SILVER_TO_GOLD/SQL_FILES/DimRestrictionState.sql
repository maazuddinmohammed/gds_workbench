SELECT 
  src.RestrictionStateID,
  src.RestrictionStateNumber,
  src.RestrictionStateName,
  src.RestrictionStateBusinessName,
  src.RestrictionStateDescription,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.restrictionstate src
WHERE
  src.GDSBatchID = wid_GDSBatchID