SELECT
  tplh.ThirdPartyLoginHistoryId,
  tplh.ThirdPartyLoginHistoryNumber,
  tplh.ThirdPartyUserNumber,
  tp.ThirdPartyKey,
  du.UserKey,
  tplh.ThirdPartyLoginTime,
  tplh.ThirdPartyLoginUserAgentString,
  TRIM(dcr1.ComplianceRegionKey) AS CurrentAssignedComplianceRegionKey,
  TRIM(dcr2.ComplianceRegionKey) AS CurrentSecondaryComplianceRegionKey,
  TRUE AS IsHistory,
  tplh.SourceCreatedDate,
  tplh.SourceUpdatedDate,
  tplh.SourceCreatedBy,
  tplh.SourceUpdatedBy,
  tplh.SourceSystemId
FROM gds_grdm_int.thirdpartyloginhistory tplh
LEFT JOIN gds_grdm.DimThirdParty tp
  ON tp.ThirdPartyID = tplh.ThirdPartyID and tp.isHistory = FALSE
LEFT JOIN gds_grdm.DimUser du
  ON du.UserID = tplh.UserID and du.isHistory = FALSE
LEFT JOIN gds_grdm.DimComplianceRegion dcr1
  ON dcr1.ComplianceRegionID = tplh.CurrentAssignedComplianceRegionID
LEFT JOIN gds_grdm.DimComplianceRegion dcr2
  ON dcr2.ComplianceRegionID = tplh.CurrentSecondaryComplianceRegionID
WHERE 
  tplh.GDSBatchID = wid_GDSBatchID