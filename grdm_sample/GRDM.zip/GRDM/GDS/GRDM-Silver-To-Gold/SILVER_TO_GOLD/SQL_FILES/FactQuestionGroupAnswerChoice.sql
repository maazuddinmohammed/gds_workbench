SELECT 
  src.QuestionGroupAnswerChoiceID,
  src.QuestionGroupAnswerChoiceNumber,
  src.QuestionGroupAnswerChoiceOrder,
  src.QuestionGroupAnswerChoiceType,
  src.QuestionGroupAnswerChoiceStatus,
  src.QuestionGroupAnswerChoiceText,
  src.QuestionGroupAnswerChoiceDescriptionStyle,
  src.IsSystemQueryComparisonEnabled,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.QuestionGroupAnswerChoice src
WHERE
  src.GDSBatchID = wid_GDSBatchID