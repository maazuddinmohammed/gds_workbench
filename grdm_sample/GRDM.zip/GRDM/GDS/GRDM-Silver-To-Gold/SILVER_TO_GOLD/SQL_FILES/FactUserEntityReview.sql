SELECT
  src.UserEntityComplianceReviewID as UserEntityReviewID,
  src.UserEntityComplianceReviewNumber as UserEntityReviewNumber,
  ue.UserEntityKey as UserEntityKey,
  cr.ComplianceRegionKey as ComplianceRegionKey,
  src.UserEntityComplianceReviewActionType as UserEntityReviewActionType,
  del.EscalationLevelKey as EscalationLevelKey,
  del2.EscalationLevelKey as EscalationDisciplineLevelKey,
  src.UserEntityComplianceReviewCaseID as UserEntityReviewCaseID,
  src.UserEntityComplianceReviewComment as UserEntityReviewComment,
  src.UserEntityComplianceReviewStartMonitoringTime as UserEntityReviewStartMonitoringTime,
  src.UserEntityComplianceReviewExtensionExpirationTime as UserEntityReviewExtensionExpirationTime,
  src.UserEntityComplianceReviewEscalationTime as UserEntityReviewEscalationTime,
  src.UserEntityComplianceReviewExtensionGrantedTime as UserEntityReviewExtensionGrantedTime,
  src.UserEntityComplianceReviewCommentSaveTime as UserEntityReviewCommentSaveTime,
  src.UserEntityComplianceReviewAdminAction as UserEntityReviewAdminAction,
  src.UserEntityComplianceReviewAdminActionTime as UserEntityReviewAdminActionTime,
  src.UserEntityComplianceReviewDisciplinedTime as UserEntityReviewDisciplinedTime,
  src.UserEntityComplianceReviewStatus as UserEntityReviewStatus,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.UserEntityComplianceReview src
  LEFT JOIN gds_grdm.FactUserEntity ue ON
    ue.UserEntityID = src.UserEntityComplianceID AND ue.IsHistory = False
  LEFT JOIN gds_grdm.DimComplianceRegion cr ON
    cr.ComplianceRegionID = src.ComplianceRegionID
  LEFT JOIN gds_grdm.DimEscalationLevel del ON
    del.EscalationLevelID = src.EscalationLevelID
  LEFT JOIN gds_grdm.DimEscalationLevel del2 ON
    del2.EscalationLevelID = src.EscalationDisciplineLevelID
WHERE src.GDSBatchID = wid_GDSBatchID