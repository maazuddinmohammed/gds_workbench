SELECT 
  src.QuestionID,
  src.QuestionNumber,
  src.QuestionNumberOrder,
  qs.QuestionSetNumber,
  qs.QuestionSetName,
  qs.QuestionSetBusinessName,
  qs.QuestionSetDescription,
  src.QuestionSetIdentifier,
  src.QuestionSetText,
  src.QuestionText,
  cr.ComplianceRegionKey,
  src.QuestionSystemQueryIdentifier,
  src.QuestionSystemQuerySourceCategory,
  src.QuestionSetProductionTime,
  src.QuestionSetArchiveTime,
  src.QuestionSystemQueryAction,
  src.QuestionSystemQueryTargetField,
  src.QuestionSystemQueryComparedValue,
  src.QuestionSetStatus,
  src.QuestionSystemQueryProductionTime,
  src.QuestionSystemQueryArchiveTime,
  src.QuestionSetModificationNumber,
  src.QuestionSystemQueryStatus,
  src.QuestionSystemQueryName,
  src.QuestionSystemQuerySourceField,
  src.QuestionSystemQueryCondition,
  src.QuestionSystemQueryDescription,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.question src
LEFT JOIN 
  gds_grdm_int.questionset qs ON src.QuestionSetID = qs.QuestionSetID
LEFT JOIN 
  gds_grdm.DimComplianceRegion cr ON cr.ComplianceRegionID = qs.ComplianceRegionID
WHERE
  src.GDSBatchID = wid_GDSBatchID
