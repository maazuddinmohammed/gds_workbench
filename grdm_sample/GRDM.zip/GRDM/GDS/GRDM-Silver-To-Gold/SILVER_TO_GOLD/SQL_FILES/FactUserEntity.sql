SELECT
  src.UserEntityComplianceID as UserEntityID,
  src.UserEntityTime,
  src.UserEntityComplianceNumber as UserEntityNumber,
  du.UserKey as UserKey,
  du2.UserKey as RequestUserKey,
  de.EntityKey as EntityKey,
  de2.EntityKey as PendingTransferEntityKey,
  ds.SecurityKey as SecurityKey,
  s2.SecurityKey as PendingTransferSecurityKey,
  dse.SecurityExchangeKey as SecurityExchangeKey,
  cr1.ComplianceRegionKey as ComplianceRegionKey,
  cr2.ComplianceRegionKey as PrimaryComplianceRegionKey,
  cr3.ComplianceRegionKey as SecondaryComplianceRegionKey,
  cr4.ComplianceRegionKey as TransferredComplianceRegionKey,
  cr5.ComplianceRegionKey as ReviewerComplianceRegionKey,
  fit.FinancialInterestTypeName,
  f.FinancialInterestSubTypeKey as FinancialInterestSubTypeKey,
  da.AccountTypeKey as AccountTypeKey,
  db.BrokerageKey as BrokerageKey,
  src.UserEntityComplianceActionTime as UserEntityActionTime,
  src.UserEntityComplianceCompany as UserEntityCompany,
  src.UserEntityComplianceSymbol as UserEntitySymbol,
  src.UserEntityComplianceIdentifier as UserEntityIdentifier,
  src.UserEntityCompliancePendingEntitySecurityType as UserEntityPendingEntitySecurityType,
  src.UserEntityComplianceUserAssignmentStatus as UserEntityUserAssignmentStatus,
  src.UserEntityComplianceType as UserEntityType,
  src.UserEntityComplianceStatus as UserEntityStatus,
  src.UserEntityComplianceDescription as UserEntityDescription,
  src.UserEntityComplianceStatusComment as UserEntityStatusComment,
  src.UserEntityComplianceComment as UserEntityComment,
  src.UserEntityComplianceAddress as UserEntityAddress,
  src.UserEntityComplianceCity as UserEntityCity,
  src.UserEntityComplianceState as UserEntityState,
  src.UserEntityCompliancePostalCode as UserEntityPostalCode,
  dc.CountryKey as CountryKey,
  dc.CountryISOCode,
  dc.CountryUNCode,
  dc.CountryName,
  src.UserEntityComplianceCUSIP as UserEntityCUSIP,
  src.UserEntityComplianceISIN as UserEntityISIN,
  src.UserEntityComplianceSEDOL as UserEntitySEDOL,
  src.UserEntityComplianceReplacementAcquisitionDate as UserEntityReplacementAcquisitionDate,
  src.UserEntityComplianceAcquisitionDateOption as UserEntityAcquisitionDateOption,
  src.UserEntityComplianceIsActive as UserEntityIsActive,
  src.AttachmentRequiredTime,
  src.IsHistory,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM
(
SELECT
  UserEntityComplianceID,
  CreatedDate as UserEntityTime,
  UserEntityComplianceNumber,
  UserID,
  PendingTransferEntityComplianceID, 
  PendingTransferSecurityID,
  RequestUserID,
  EntityComplianceID,
  SecurityID,
  SecurityExchangeID,
  ComplianceRegionID,
  PrimaryComplianceRegionID,
  SecondaryComplianceRegionID,
  TransferredComplianceRegionID,
  ReviewerComplianceRegionID,
  FinancialInterestTypeID,
  FinancialInterestSubTypeID,
  AccountTypeID,
  BrokerageID,
  UserEntityComplianceActionTime,
  UserEntityComplianceCompany,
  UserEntityComplianceSymbol,
  UserEntityComplianceIdentifier,
  UserEntityCompliancePendingEntitySecurityType,
  UserEntityComplianceUserAssignmentStatus,
  UserEntityComplianceType,
  UserEntityComplianceStatus,
  UserEntityComplianceDescription,
  UserEntityComplianceStatusComment,
  UserEntityComplianceComment,
  UserEntityComplianceAddress,
  UserEntityComplianceCity,
  UserEntityComplianceState,
  UserEntityCompliancePostalCode,
  CountryID,
  UserEntityComplianceCUSIP,
  UserEntityComplianceISIN,
  UserEntityComplianceSEDOL,
  UserEntityComplianceReplacementAcquisitionDate,
  UserEntityComplianceAcquisitionDateOption,
  UserEntityComplianceIsActive,
  AttachmentRequiredTime,
  False as IsHistory,
  SourceCreatedDate,
  SourceUpdatedDate,
  SourceCreatedBy,
  SourceUpdatedBy,
  SourceSystemID
FROM gds_grdm_int.UserEntityCompliance src
WHERE GDSBatchID = wid_GDSBatchID
UNION ALL
SELECT
  UserEntityComplianceHistoryID AS UserEntityComplianceID,
  UserEntityComplianceHistoryTime as UserEntityTime,
  UserEntityComplianceNumber,
  UserID,
  PendingTransferEntityComplianceID, 
  PendingTransferSecurityID,
  RequestUserID,
  EntityComplianceID,
  SecurityID,
  SecurityExchangeID,
  ComplianceRegionID,
  PrimaryComplianceRegionID,
  SecondaryComplianceRegionID,
  TransferredComplianceRegionID,
  ReviewerComplianceRegionID,
  FinancialInterestTypeID,
  FinancialInterestSubTypeID,
  AccountTypeID,
  BrokerageID,
  UserEntityComplianceActionTime,
  UserEntityComplianceCompany,
  UserEntityComplianceSymbol,
  UserEntityComplianceIdentifier,
  UserEntityCompliancePendingEntitySecurityType,
  UserEntityComplianceUserAssignmentStatus,
  UserEntityComplianceType,
  UserEntityComplianceStatus,
  UserEntityComplianceDescription,
  UserEntityComplianceStatusComment,
  UserEntityComplianceComment,
  UserEntityComplianceAddress,
  UserEntityComplianceCity,
  UserEntityComplianceState,
  UserEntityCompliancePostalCode,
  CountryID,
  UserEntityComplianceCUSIP,
  UserEntityComplianceISIN,
  UserEntityComplianceSEDOL,
  UserEntityComplianceReplacementAcquisitionDate,
  UserEntityComplianceAcquisitionDateOption,
  UserEntityComplianceIsActive,
  AttachmentRequiredTime,
  True as IsHistory,
  SourceCreatedDate,
  SourceUpdatedDate,
  SourceCreatedBy,
  SourceUpdatedBy,
  SourceSystemID
FROM gds_grdm_int.UserEntityComplianceHistory
WHERE GDSBatchID = wid_GDSBatchID
 ) AS src
LEFT JOIN gds_grdm.DimUser du ON
  du.UserID = src.UserID AND du.IsHistory = False
LEFT JOIN gds_grdm_int.EntityCompliance ec ON
  ec.EntityComplianceID = src.EntityComplianceID
LEFT JOIN gds_grdm.DimEntity de ON
  de.EntityID = ec.EntityID
LEFT JOIN gds_grdm.DimSecurity ds ON
  ds.SecurityID = src.SecurityID AND ds.IsHistory = False
LEFT JOIN gds_grdm.DimSecurityExchange dse ON
  dse.SecurityExchangeID = src.SecurityExchangeID
LEFT JOIN gds_grdm.DimComplianceRegion cr1 ON
  cr1.ComplianceRegionID = src.ComplianceRegionID
LEFT JOIN gds_grdm.DimComplianceRegion cr2 ON
  cr2.ComplianceRegionID = src.PrimaryComplianceRegionID
LEFT JOIN gds_grdm.DimComplianceRegion cr3 ON
  cr3.ComplianceRegionID = src.SecondaryComplianceRegionID
LEFT JOIN gds_grdm.DimComplianceRegion cr4 ON
  cr4.ComplianceRegionID = src.TransferredComplianceRegionID
LEFT JOIN gds_grdm.DimComplianceRegion cr5 ON
  cr5.ComplianceRegionID = src.ReviewerComplianceRegionID
LEFT JOIN gds_grdm_int.FinancialInterestType fit ON 
  src.FinancialInterestTypeID = fit.FinancialInterestTypeID
LEFT JOIN gds_grdm.DimFinancialInterestSubType f ON
  f.FinancialInterestSubTypeID = src.FinancialInterestSubTypeID
LEFT JOIN gds_grdm.DimAccountType da ON
  da.AccountTypeID = src.AccountTypeID
LEFT JOIN gds_grdm.DimBrokerage db ON
  db.BrokerageID = src.BrokerageID
LEFT JOIN gds_ref.dimcountry dc ON
  dc.CountryID = src.CountryID
LEFT JOIN gds_grdm_int.EntityCompliance ec2 ON
  ec2.EntityComplianceID = src.PendingTransferEntityComplianceID
LEFT JOIN gds_grdm.DimEntity de2 ON
  de2.EntityID = ec2.EntityID
LEFT JOIN gds_grdm.DimSecurity s2 ON
  s2.SecurityID = src.PendingTransferSecurityID AND s2.IsHistory = False
LEFT JOIN gds_grdm.DimUser du2 ON
  du2.UserID = src.RequestUserID AND du2.IsHistory = False
/*
LEFT JOIN gds_grdm.FactUserEntity fuep ON
  fuep.PendingTransferEntityComplianceID = src.PendingTransferEntityComplianceID
LEFT JOIN gds_grdm.FactUserEntity fues ON
  fues.PendingTransferSecurityID = src.PendingTransferSecurityID
*/