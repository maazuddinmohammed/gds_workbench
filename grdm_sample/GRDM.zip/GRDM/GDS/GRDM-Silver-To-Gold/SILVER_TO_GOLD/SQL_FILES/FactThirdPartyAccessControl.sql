SELECT
    tpac.ThirdPartyAccessControlID,
    tp.ThirdPartyKey,
    du.UserKey,
    dp.PersonalProfileKey,
    tpac.HoldingID,
    tpac.ThirdPartyAccessControlNumber,
    tpac.ThirdPartyAccessControlType,
    tpac.ThirdPartyAccessControlDataPermission,
    tpac.ThirdPartyAccessControlStartTime,
    tpac.ThirdPartyAccessControlEndTime,
    tpac.ThirdPartyAccessControlLastChangeTime,
    tpac.ThirdPartyAccessControlLastChangeUser,
    dcr1.ComplianceRegionKey AS CurrentAssignedComplianceRegionKey,
    dcr2.ComplianceRegionKey AS CurrentSecondaryComplianceRegionKey,
    tpac.IsHistory,
    tpac.SourceCreatedDate,
    tpac.SourceUpdatedDate,
    tpac.SourceCreatedBy,
    tpac.SourceUpdatedBy,
    tpac.SourceSystemId
FROM (
    SELECT
        ThirdPartyAccessControlID,
        ThirdPartyAccessControlNumber,
        ThirdPartyAccessControlType,
        ThirdPartyID,
        UserProfileID,
        UserID,
        HoldingID,
        ThirdPartyAccessControlDataPermission,
        ThirdPartyAccessControlStartTime,
        ThirdPartyAccessControlEndTime,
        ThirdPartyAccessControlLastChangeTime,
        ThirdPartyAccessControlLastChangeUser,
        CurrentAssignedComplianceRegionID,
        CurrentSecondaryComplianceRegionID,
        False AS IsHistory,
        SourceCreatedDate,
        SourceUpdatedDate,
        SourceCreatedBy,
        SourceUpdatedBy,
        SourceSystemID
    FROM gds_grdm_int.thirdpartyaccesscontrol
    WHERE GDSBatchID = wid_GDSBatchID

    UNION ALL

    SELECT
        ThirdPartyAccessControlHistoryID AS ThirdPartyAccessControlID,
        ThirdPartyAccessControlHistoryNumber AS ThirdPartyAccessControlNumber,
        ThirdPartyAccessControlType,
        ThirdPartyID,
        UserProfileID,
        UserID,
        HoldingID,
        ThirdPartyAccessControlDataPermission,
        ThirdPartyAccessControlStartTime,
        ThirdPartyAccessControlEndTime,
        ThirdPartyAccessControlLastChangeTime,
        ThirdPartyAccessControlLastChangeUser,
        CurrentAssignedComplianceRegionID,
        CurrentSecondaryComplianceRegionID,
        True AS IsHistory,
        SourceCreatedDate,
        SourceUpdatedDate,
        SourceCreatedBy,
        SourceUpdatedBy,
        SourceSystemID
    FROM gds_grdm_int.thirdpartyaccesscontrolhistory
    WHERE GDSBatchID = wid_GDSBatchID
) tpac
LEFT JOIN gds_grdm.DimThirdParty tp
    ON tp.ThirdPartyID = tpac.ThirdPartyID and tp.isHistory = FALSE
LEFT JOIN gds_grdm.DimUser du
    ON du.UserID = tpac.UserID and du.isHistory = FALSE
    LEFT JOIN gds_grdm.dimpersonalprofile dp
    ON dp.personalprofileid = tpac.userprofileid
LEFT JOIN gds_grdm.dimcomplianceregion dcr1
    ON dcr1.ComplianceRegionID = tpac.CurrentAssignedComplianceRegionID
LEFT JOIN gds_grdm.dimcomplianceregion dcr2
    ON dcr2.ComplianceRegionID = tpac.CurrentSecondaryComplianceRegionID