SELECT
  src.FinancialInterestSubTypeID,
  src.FinancialInterestSubTypeNumber,
  src.FinancialInterestSubTypeName,
  src.FinancialInterestSubTypeBusinessName,
  src.FinancialInterestSubTypeDescription,
  dcr.ComplianceRegionKey,
   src.FinancialInterestSubTypeEffectiveStartDate,
   src.FinancialInterestSubTypeEffectiveEndDate,
   src.FinancialInterestSubTypeIdentifier,
   src.ParentFinancialInterestSubTypeListCodeNumber,
   src.FinancialInterestSubTypeAssociatedSecurityType,
   src.FinancialInterestSubTypeIsFinancialInterestBeReassignedIssuer,
   src.FinancialInterestSubTypeSICCode,
   src.FinancialInterestSubTypeShowAcknowledgementCheckbox,
   src.FinancialInterestSubTypeRequireCommentFieldWhenAddHolding,
   src.FinancialInterestSubTypeFinancialInterestDisplayType,
   src.FinancialInterestSubTypeIsAccountTypeEligibleForBrokerageImport,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM 
gds_grdm_int.financialinterestsubtype src
LEFT JOIN 
   gds_grdm.dimcomplianceregion dcr ON src.ComplianceRegionID=dcr.ComplianceRegionID
WHERE 
  src.GDSBatchID = wid_GDSBatchID