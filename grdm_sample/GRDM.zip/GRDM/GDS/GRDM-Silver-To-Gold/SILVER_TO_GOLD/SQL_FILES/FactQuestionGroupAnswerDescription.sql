SELECT
  src.QuestionGroupAnswerDescriptionID,
  src.QuestionGroupAnswerDescriptionNumber,
  src.QuestionGroupAnswerDescription,
  src.QuestionGroupAnswerDescriptionStyle,
  src.QuestionGroupAnswerDescriptionStatus,
  src.QuestionGroupAnswerDescriptionModifications,
  dl.LanguageKey,
  dcr.ComplianceRegionKey,
  du1.UserKey as QuestionGroupAnswerDescriptionProductionUserKey,
  src.QuestionGroupAnswerDescriptionProductionTime,
  du2.UserKey as QuestionGroupAnswerDescriptionArchiveUserKey,
  src.QuestionGroupAnswerDescriptionArchiveTime,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.questiongroupanswerdescription src
LEFT JOIN gds_ref.DimLanguage dl ON src.LanguageID=dl.LanguageID  
LEFT JOIN gds_grdm.DimComplianceRegion dcr ON src.ComplianceRegionID=dcr.ComplianceRegionID
LEFT JOIN gds_grdm.DimUser du1 ON du1.UserID = src.QuestionGroupAnswerDescriptionProductionUserID AND du1.IsHistory = 'false'
LEFT JOIN gds_grdm.DimUser du2 ON du2.UserID = src.QuestionGroupAnswerDescriptionArchiveUserID AND du2.IsHistory = 'false'
WHERE
  src.GDSBatchID = wid_GDSBatchID

