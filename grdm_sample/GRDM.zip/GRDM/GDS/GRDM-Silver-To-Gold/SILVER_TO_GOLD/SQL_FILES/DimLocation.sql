SELECT
  src.LocationID,
  src.LocationNumber,
  src.LocationName,
  src.LocationAddressLine1,
  src.LocationAddressLine2,
  src.LocationAddressCity,
  src.LocationAddressState,
  src.LocationAddressPostalCode,
  dc.CountryKey,
  dcr.ComplianceRegionKey,
  src.LocationStatus,
  src.LocationOverrideAutoSelfClearConfiguration,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.location src
LEFT JOIN 
  gds_ref.dimcountry dc ON dc.CountryID=src.CountryID
LEFT JOIN 
  gds_grdm.dimcomplianceregion dcr ON src.ComplianceRegionID=dcr.ComplianceRegionID
WHERE
  src.GDSBatchID = wid_GDSBatchID