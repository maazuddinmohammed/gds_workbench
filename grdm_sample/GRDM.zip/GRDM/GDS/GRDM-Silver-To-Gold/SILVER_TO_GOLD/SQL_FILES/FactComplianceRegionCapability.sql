

SELECT crc.ComplianceRegionCapabilityID,
    crc.ComplianceRegionCapabilityNumber ,
    dcp.CapabilityKey ,
    dc.ComplianceRegionKey,
    crc.IsCapabilityAdminEnabled,
    crc.IsCapabilityComplianceOfficerEnabled,
    crc.IsCapabilityReviewerEnabled ,
    crc.IsCapabilitySuperUserEnabled ,
    false AS IsHistory ,
    crc.SourceCreatedDate ,
    crc.SourceUpdatedDate ,
    crc.SourceCreatedBy,
    crc.SourceUpdatedBy ,
    crc.SourceSystemID
FROM gds_grdm_int.complianceregioncapability crc
LEFT JOIN gds_grdm.dimcomplianceregion dc ON crc.ComplianceRegionID = dc.ComplianceRegionID
LEFT JOIN gds_grdm.dimcapability dcp ON crc.CapabilityID = dcp.CapabilityID
WHERE crc.GDSBatchID = wid_GDSBatchID
UNION ALL
SELECT crch.ComplianceRegionCapabilityHistoryID as ComplianceRegionCapabilityID,
    CONCAT_WS('',dcp.CapabilityKey,'-',dc.ComplianceRegionKey,'-',crch.SourceUpdatedDate) as ComplianceRegionCapabilityNumber ,
    dcp.CapabilityKey ,
    dc.ComplianceRegionKey,
    crch.IsCapabilityAdminEnabled,
    crch.IsCapabilityComplianceOfficerEnabled,
    crch.IsCapabilityReviewerEnabled ,
    crch.IsCapabilitySuperUserEnabled ,
    true AS IsHistory ,
    crch.SourceCreatedDate ,
    crch.SourceUpdatedDate ,
    crch.SourceCreatedBy,
    crch.SourceUpdatedBy ,
    crch.SourceSystemID
FROM gds_grdm_int.complianceregioncapabilityhistory crch
LEFT JOIN gds_grdm.dimcomplianceregion dc ON crch.ComplianceRegionID = dc.ComplianceRegionID
LEFT JOIN gds_grdm.dimcapability dcp ON crch.CapabilityID = dcp.CapabilityID
WHERE crch.GDSBatchID = wid_GDSBatchID
    



