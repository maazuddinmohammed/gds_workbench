SELECT 
  src.EscalationLevelID,
  src.EscalationLevelNumber,
  src.EscalationLevel,
  src.EscalationLevelName,
  src.EscalationLevelBusinessName,
  src.EscalationLevelDescription,
  src.EscalationLevelTypeID,
  elt.EscalationLevelTypeNumber,
  elt.EscalationLevelTypeName,
  elt.EscalationLevelTypeBusinessName,
  elt.EscalationLevelTypeDescription,
  s.StatusBusinessName as EscalationLevelStatus,
  el.NextEscalationLevelKey,
  dcr.ComplianceRegionKey,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.escalationlevel src
LEFT JOIN 
  gds_grdm_int.escalationleveltype elt on src.escalationleveltypeid=elt.EscalationLevelTypeID
LEFT JOIN 
  gds_grdm.dimcomplianceregion dcr ON src.ComplianceRegionID=dcr.ComplianceRegionID
LEFT JOIN 
  gds_ref_int.status s ON src.EscalationLevelStatusID=s.StatusID
LEFT JOIN gds_grdm.DimEscalationLevel el ON el.EscalationLevelID = src.NextEscalationLevelID
WHERE
  src.GDSBatchID = wid_GDSBatchID
