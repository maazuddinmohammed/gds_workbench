SELECT 
  src.PreClearID,
  src.PreClearTime,
  src.PreClearHistoryNumber,
  fh.HoldingKey,
  du.UserKey,
  cr1.ComplianceRegionKey as PrimaryComplianceRegionKey,
  cr2.ComplianceRegionKey as SecondaryComplianceRegionKey,
  fcm.ConflictMessageKey,
  dl.LocationKey,
  src.PreClearStatus,
  src.PreClearResult,
  src.PreClearCreationDate,
  src.PreClearCreationTime,
  src.PreClearCompletionDate,
  src.PreClearCompletionTime,
  src.PreClearExpirationDate,
  src.PreClearExpirationTime,
  src.PreClearExpirationReason,
  src.PreClearComment,
  src.IsServiceCenterUpdate,
  src.IsThirdPartyUserUpdate,
  src.IsHistory,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM
(
  SELECT 
  PreClearID,
  NULL as PreClearHistoryNumber,
  HoldingID,
  UserID,
  ConflictMessageID,
  LocationID,
  PrimaryComplianceRegionID,
  SecondaryComplianceRegionID,
  CreatedDate AS PreClearTime,
  PreClearStatus,
  PreClearResult,
  PreClearCreationDate,
  PreClearCreationTime,
  PreClearCompletionDate,
  PreClearCompletionTime,
  PreClearExpirationDate,
  PreClearExpirationTime,
  PreClearExpirationReason,
  PreClearComment,
  IsServiceCenterUpdate,
  IsThirdPartyUserUpdate,
  CAST(0 AS boolean ) AS IsHistory,
  SourceCreatedDate,
  SourceUpdatedDate,
  SourceCreatedBy,
  SourceUpdatedBy,
  SourceSystemID
FROM gds_grdm_int.preclear 
WHERE
  GDSBatchID = wid_GDSBatchID
  
UNION ALL

SELECT 
  PreClearHistoryID  AS PreClearID,
  PreClearHistoryNumber,
  HoldingID,
  UserID,
  ConflictMessageID,
  LocationID,
  PrimaryComplianceRegionID,
  SecondaryComplianceRegionID,
  PreClearHistoryTime AS PreClearTime,
  PreClearStatus,
  PreClearResult,
  PreClearCreationDate,
  PreClearCreationTime,
  PreClearCompletionDate,
  PreClearCompletionTime,
  PreClearExpirationDate,
  PreClearExpirationTime,
  PreClearExpirationReason,
  PreClearComment,
  IsServiceCenterUpdate,
  IsThirdPartyUserUpdate,
  CAST(1 AS boolean ) AS IsHistory,
  SourceCreatedDate,
  SourceUpdatedDate,
  SourceCreatedBy,
  SourceUpdatedBy,
  SourceSystemID
FROM gds_grdm_int.preclearhistory 
WHERE
  GDSBatchID = wid_GDSBatchID
) src
LEFT JOIN gds_grdm.FactHolding fh ON src.HoldingID=fh.HoldingID AND fh.ishistory='false'
LEFT JOIN gds_grdm.DimUser du ON src.UserID=du.UserID AND du.ishistory='false'
LEFT JOIN gds_grdm.FactConflictMessage fcm ON src.ConflictMessageID=fcm.ConflictMessageID
LEFT JOIN gds_grdm.DimComplianceRegion cr1 ON cr1.ComplianceRegionID = src.PrimaryComplianceRegionID
LEFT JOIN gds_grdm.DimComplianceRegion cr2 ON cr2.ComplianceRegionID = src.SecondaryComplianceRegionID
LEFT JOIN gds_grdm.DimLocation dl ON dl.LocationID = src.LocationID