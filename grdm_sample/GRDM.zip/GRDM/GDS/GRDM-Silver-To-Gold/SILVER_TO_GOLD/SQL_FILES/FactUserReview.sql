SELECT
  src.UserReviewID,
  src.UserReviewNumber,
  du.UserKey as UserKey,
  src.UserReviewCaseNumber,
  src.UserReviewActionType,
  cr1.ComplianceRegionKey as PrimaryComplianceRegionKey,
  cr2.ComplianceRegionKey as SecondaryComplianceRegionKey,
  del.EscalationLevelKey,
  src.ExtensionGrantedDate,
  src.UserReviewExtensionGrantedDate,
  src.UserReviewStartTime,
  src.UserReviewEscalationTime,
  src.UserReviewComment,
  src.UserReviewCommentSaveTime,
  src.UserReviewAdministrativeAction,
  src.UserReviewAdministrativeActionTime,
  src.UserReviewDisciplineLevel,
  src.UserReviewDisciplinedTime,
  src.UserReviewStatus,
  src.UserReviewLastChangeTime,
  src.UserReviewLastChangeUser,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.UserReview src
LEFT JOIN gds_grdm.DimUser du ON
  du.UserID = src.UserID AND du.IsHistory = False
LEFT JOIN gds_grdm.DimComplianceRegion cr1 ON
  cr1.ComplianceRegionID = src.PrimaryComplianceRegionID
LEFT JOIN gds_grdm.DimComplianceRegion cr2 ON
  cr2.ComplianceRegionID = src.SecondaryComplianceRegionID  
LEFT JOIN gds_grdm.DimEscalationLevel del ON
  del.EscalationLevelID = src.EscalationLevelID
WHERE src.GDSBatchID = wid_GDSBatchID