

SELECT usc.UserCapabilityID as UserCapabilityID,
    usc.UserCapabilityNumber as UserCapabilityNumber,
    ud.UserKey as UserKey,
    ud2.UserKey as CreatedByUserKey ,
    usc.UserCapabilityStatus as UserCapabilityStatus,
    usc.IsUserCapabilityGranted as IsUserCapabilityGranted,
    dcp.CapabilityKey  as CapabilityKey,
    cr1.ComplianceRegionKey as CurrentAssignedComplianceRegionKey ,
    cr2.ComplianceRegionKey as CurrentSecondaryComplianceRegionKey,
    false as IsHistory ,
    usc.SourceCreatedDate as SourceCreatedDate,
    usc.SourceUpdatedDate as SourceUpdatedDate,
    usc.SourceCreatedBy as SourceCreatedBy,
    usc.SourceUpdatedBy as SourceUpdatedBy,
    usc.SourceSystemID  as SourceSystemID
    FROM gds_grdm_int.usercapability usc
    LEFT JOIN gds_grdm.dimuser ud ON usc.UserID = ud.UserID AND ud.IsHistory = false
    LEFT JOIN gds_grdm.dimuser ud2 ON ud2.UserNumber = usc.CreatedByUserID AND ud2.IsHistory = false
    LEFT JOIN gds_grdm.dimcapability dcp ON usc.CapabilityID = dcp.CapabilityID
    LEFT JOIN gds_grdm.dimcomplianceregion cr1 ON usc.CurrentAssignedComplianceRegionID = cr1.ComplianceRegionID
    LEFT JOIN gds_grdm.dimcomplianceregion cr2 ON usc.CurrentSecondaryComplianceRegionID = cr2.ComplianceRegionID
WHERE usc.GDSBatchID = wid_GDSBatchID
UNION ALL 
SELECT usch.UserCapabilityHistoryID as UserCapabilityID ,
    CONCAT_WS('',ud.UserKey,'-',dcp.CapabilityKey,'-',usch.SourceUpdatedDate)  as UserCapabilityNumber,
    ud.UserKey  as UserKey,
    ud2.UserKey as CreatedByUserKey ,
    usch.UserCapabilityStatus as UserCapabilityStatus,
    usch.IsUserCapabilityGranted as IsUserCapabilityGranted,
    dcp.CapabilityKey  as CapabilityKey,
    cr1.ComplianceRegionKey as CurrentAssignedComplianceRegionKey ,
    cr2.ComplianceRegionKey as CurrentSecondaryComplianceRegionKey,
    true as IsHistory ,
    usch.SourceCreatedDate as SourceCreatedDate,
    usch.SourceUpdatedDate as SourceUpdatedDate,
    usch.SourceCreatedBy as SourceCreatedBy,
    usch.SourceUpdatedBy as SourceUpdatedBy,
    usch.SourceSystemID  as SourceSystemID
    FROM gds_grdm_int.usercapabilityhistory usch
    LEFT JOIN gds_grdm.dimuser ud ON usch.UserID = ud.UserID AND ud.IsHistory = false
    LEFT JOIN gds_grdm.dimuser ud2 ON ud2.UserNumber = usch.CreatedByUserID AND ud2.IsHistory = false
    LEFT JOIN gds_grdm.dimcapability dcp ON usch.CapabilityID = dcp.CapabilityID
    LEFT JOIN gds_grdm.dimcomplianceregion cr1 ON usch.CurrentAssignedComplianceRegionID = cr1.ComplianceRegionID
    LEFT JOIN gds_grdm.dimcomplianceregion cr2 ON usch.CurrentSecondaryComplianceRegionID = cr2.ComplianceRegionID
WHERE usch.GDSBatchID = wid_GDSBatchID
