SELECT 
   src.SelfInitiatedWizardSubTypeID AS SelfInitiatedWizardSubTypeID,
   src.SelfInitiatedWizardSubTypeNumber AS SelfInitiatedWizardSubTypeNumber,
   src.SelfInitiatedWizardSubTypeName AS SelfInitiatedWizardSubTypeName,
   src.SelfInitiatedWizardSubTypeBusinessName AS SelfInitiatedWizardSubTypeBusinessName,
   src.SelfInitiatedWizardSubTypeDescription AS SelfInitiatedWizardSubTypeDescription,
   dcr.ComplianceRegionKey,
   src.SelfInitiatedWizardSubTypeEffectiveStartDate,
   src.SelfInitiatedWizardSubTypeEffectiveEndDate,
   src.SelfInitiatedWizardSubTypeIdentifier,
   src.ParentSelfInitiatedWizardSubTypeListCodeNumber,
   src.SelfInitiatedWizardSubTypeAssociatedSecurityType,
   src.SelfInitiatedWizardSubTypeIsFinancialInterestBeReassignedIssuer,
   src.SelfInitiatedWizardSubTypeSICCode,
   src.SelfInitiatedWizardSubTypeShowAcknowledgementCheckbox,
   src.SelfInitiatedWizardSubTypeRequireCommentFieldWhenAddHolding,
   src.SelfInitiatedWizardSubTypeFinancialInterestDisplayType,
   src.SelfInitiatedWizardSubTypeIsAccountTypeEligibleForBrokerageImport,   
   src.SourceCreatedDate,
   src.SourceUpdatedDate,
   src.SourceCreatedBy,
   src.SourceUpdatedBy,
   src.SourceSystemId 
FROM gds_grdm_int.SelfInitiatedWizardSubType src
LEFT JOIN 
   gds_grdm.DimComplianceRegion dcr ON src.ComplianceRegionID = dcr.ComplianceRegionID
WHERE 
  src.GDSBatchID = wid_GDSBatchID