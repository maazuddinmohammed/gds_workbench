  SELECT 
   src.AccountTypeID,
   src.AccountTypeNumber,
   src.AccountTypeName,
   src.AccountTypeBusinessName,
   src.AccountTypeDescription,
   dcr.ComplianceRegionKey,
   src.AccountTypeEffectiveStartDate,
   src.AccountTypeEffectiveEndDate,
   src.AccountTypeIdentifier,
   src.ParentAccountTypeListCodeNumber,
   src.AccountTypeAssociatedSecurityType,
   src.AccountTypeIsFinancialInterestBeReassignedIssuer,
   src.AccountTypeSICCode,
   src.AccountTypeShowAcknowledgementCheckbox,
   src.AccountTypeRequireCommentFieldWhenAddHolding,
   src.AccountTypeFinancialInterestDisplayType,
   src.AccountTypeIsAccountTypeEligibleForBrokerageImport,  
   src.SourceCreatedDate,
   src.SourceUpdatedDate,
   src.SourceCreatedBy,
   src.SourceUpdatedBy,
   src.SourceSystemId 
FROM gds_grdm_int.AccountType src
LEFT JOIN 
   gds_grdm.DimComplianceRegion dcr ON src.ComplianceRegionID = dcr.ComplianceRegionID
WHERE 
  src.GDSBatchID = wid_GDSBatchID