SELECT
  src.FirmActionLocationAssignmentID,
  src.FirmActionLocationAssignmentNumber,
  fa.FirmActionKey,
  la.LocationAssignmentKey,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.FirmActionLocationAssignment src
LEFT JOIN gds_grdm.FactFirmAction fa ON
  fa.FirmActionID = src.FirmActionID AND fa.IsHistory = 'false'
LEFT JOIN gds_grdm.FactLocationAssignment la ON
  la.LocationAssignmentID = src.LocationAssignmentID AND la.IsHistory = 'false'
WHERE src.GDSBatchID = wid_GDSBatchID