SELECT 
  src.HoldingTypeID,
  src.HoldingTypeNumber,
  src.HoldingTypeName,
  src.HoldingTypeBusinessName,
  src.HoldingTypeDescription,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.holdingtype src
WHERE
  src.GDSBatchID = wid_GDSBatchID

