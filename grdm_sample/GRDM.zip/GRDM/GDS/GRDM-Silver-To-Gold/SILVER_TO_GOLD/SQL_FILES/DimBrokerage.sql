SELECT
  src.BrokerageID,
  src.BrokerageNumber,
  e.EntityKey,
  dcr.ComplianceRegionKey,
  dcr2.ComplianceRegionKey as BDIAuthorizedComplianceRegionKey,
  src.BrokerageBDIEnableChangeTime,
  src.BrokerageBDIExemptChangeTime,
  src.IsBDIEnable,
  src.IsBDIExempt,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.brokerage src
LEFT JOIN 
  gds_grdm.dimcomplianceregion dcr ON src.ComplianceRegionID=dcr.ComplianceRegionID
LEFT JOIN 
  gds_grdm.dimcomplianceregion dcr2 ON src.BDIAuthorizedComplianceRegionID=dcr2.ComplianceRegionID 
LEFT JOIN 
  gds_grdm_int.EntityCompliance ec ON ec.EntityComplianceID = src.EntityComplianceID
LEFT JOIN 
  gds_grdm.DimEntity e ON e.EntityID = ec.EntityID AND IsHistory = False 
WHERE
  src.GDSBatchID = wid_GDSBatchID