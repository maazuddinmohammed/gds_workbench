SELECT 
   src.AcknowledgementID,
   src.AcknowledgementNumber,
   e.EntityKey,
   dcr.ComplianceRegionKey,
   l.LanguageKey,
   src.AcknowledgementStatus,
   src.AcknowledgementName,
   src.AcknowledgementHeading,
   src.AcknowledgementText,
   src.AcknowledgementBrokerageInstruction,
   src.AcknowledgementExampleAccountID,
   src.SourceCreatedDate,
   src.SourceUpdatedDate,
   src.SourceCreatedBy,
   src.SourceUpdatedBy,
   src.SourceSystemId 
FROM gds_grdm_int.Acknowledgement src
LEFT JOIN gds_grdm_int.EntityCompliance ec ON
  ec.EntityComplianceID = src.EntityComplianceID
LEFT JOIN gds_grdm.DimEntity e ON
  e.EntityID = ec.EntityID AND IsHistory = 'False'
LEFT JOIN gds_grdm.DimComplianceRegion dcr ON 
  src.ComplianceRegionID = dcr.ComplianceRegionID
LEFT JOIN gds_ref.DimLanguage l ON
  l.LanguageID = src.LanguageID
WHERE 
  src.GDSBatchID = wid_GDSBatchID