SELECT 
   src.SurveySubTypeID,
   src.SurveySubTypeNumber,
   src.SurveySubTypeName,
   src.SurveySubTypeBusinessName,
   src.SurveySubTypeDescription,
   dcr.ComplianceRegionKey,
   src.SurveySubTypeEffectiveStartDate,
   src.SurveySubTypeEffectiveEndDate,
   src.SurveySubTypeIdentifier,
   src.ParentSurveySubTypeListCodeNumber,
   src.SurveySubTypeAssociatedSecurityType,
   src.SurveySubTypeIsFinancialInterestBeReassignedIssuer,
   src.SurveySubTypeSICCode,
   src.SurveySubTypeShowAcknowledgementCheckbox,
   src.SurveySubTypeRequireCommentFieldWhenAddHolding,
   src.SurveySubTypeFinancialInterestDisplayType,
   src.SurveySubTypeIsAccountTypeEligibleForBrokerageImport,   
   src.SourceCreatedDate,
   src.SourceUpdatedDate,
   src.SourceCreatedBy,
   src.SourceUpdatedBy,
   src.SourceSystemId 
FROM gds_grdm_int.SurveySubType src
LEFT JOIN 
   gds_grdm.DimComplianceRegion dcr ON src.ComplianceRegionID = dcr.ComplianceRegionID
WHERE 
  src.GDSBatchID = wid_GDSBatchID