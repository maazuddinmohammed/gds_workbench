SELECT 
   src.OverdraftProtectionTypeID AS OverdraftProtectionTypeID,
   src.OverdraftProtectionTypeNumber AS OverdraftProtectionTypeNumber,
   src.OverdraftProtectionTypeName AS OverdraftProtectionTypeName,
   src.OverdraftProtectionTypeBusinessName AS OverdraftProtectionTypeBusinessName,
   src.OverdraftProtectionTypeDescription AS OverdraftProtectionTypeDescription,
   dcr.ComplianceRegionKey,
   src.OverdraftProtectionTypeEffectiveStartDate,
   src.OverdraftProtectionTypeEffectiveEndDate,
   src.OverdraftProtectionTypeIdentifier,
   src.ParentOverdraftProtectionTypeListCodeNumber,
   src.OverdraftProtectionTypeAssociatedSecurityType,
   src.OverdraftProtectionTypeIsFinancialInterestBeReassignedIssuer,
   src.OverdraftProtectionTypeSICCode,
   src.OverdraftProtectionTypeShowAcknowledgementCheckbox,
   src.OverdraftProtectionTypeRequireCommentFieldWhenAddHolding,
   src.OverdraftProtectionTypeFinancialInterestDisplayType,
   src.OverdraftProtectionTypeIsAccountTypeEligibleForBrokerageImport,   
   src.SourceCreatedDate,
   src.SourceUpdatedDate,
   src.SourceCreatedBy,
   src.SourceUpdatedBy,
   src.SourceSystemId 
FROM gds_grdm_int.OverdraftProtectionType src
LEFT JOIN 
   gds_grdm.DimComplianceRegion dcr ON src.ComplianceRegionID = dcr.ComplianceRegionID
WHERE 
  src.GDSBatchID = wid_GDSBatchID