SELECT 
   src.EmploymentRelationshipTypeID AS EmploymentRelationshipTypeID,
   src.EmploymentRelationshipTypeNumber AS EmploymentRelationshipTypeNumber,
   src.EmploymentRelationshipTypeName AS EmploymentRelationshipTypeName,
   src.EmploymentRelationshipTypeBusinessName AS EmploymentRelationshipTypeBusinessName,
   src.EmploymentRelationshipTypeDescription AS EmploymentRelationshipTypeDescription,
   dcr.ComplianceRegionKey,
   src.EmploymentRelationshipTypeEffectiveStartDate,
   src.EmploymentRelationshipTypeEffectiveEndDate,
   src.EmploymentRelationshipTypeIdentifier,
   src.ParentEmploymentRelationshipTypeListCodeNumber,
   src.EmploymentRelationshipTypeAssociatedSecurityType,
   src.EmploymentRelationshipTypeIsFinancialInterestBeReassignedIssuer,
   src.EmploymentRelationshipTypeSICCode,
   src.EmploymentRelationshipTypeShowAcknowledgementCheckbox,
   src.EmploymentRelationshipTypeRequireCommentFieldWhenAddHolding,
   src.EmploymentRelationshipTypeFinancialInterestDisplayType,
   src.EmploymentRelationshipTypeIsAccountTypeEligibleForBrokerageImport,   
   src.SourceCreatedDate,
   src.SourceUpdatedDate,
   src.SourceCreatedBy,
   src.SourceUpdatedBy,
   src.SourceSystemId 
FROM gds_grdm_int.EmploymentRelationshipType src
LEFT JOIN 
   gds_grdm.DimComplianceRegion dcr ON src.ComplianceRegionID = dcr.ComplianceRegionID
WHERE 
  src.GDSBatchID = wid_GDSBatchID