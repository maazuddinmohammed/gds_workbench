SELECT 
   src.OwnershipTypeID AS OwnershipTypeID,
   src.OwnershipTypeNumber AS OwnershipTypeNumber,
   src.OwnershipTypeName AS OwnershipTypeName,
   src.OwnershipTypeBusinessName AS OwnershipTypeBusinessName,
   src.OwnershipTypeDescription AS OwnershipTypeDescription,
   dcr.ComplianceRegionKey,
   src.OwnershipTypeEffectiveStartDate,
   src.OwnershipTypeEffectiveEndDate,
   src.OwnershipTypeIdentifier,
   src.ParentOwnershipTypeListCodeNumber,
   src.OwnershipTypeAssociatedSecurityType,
   src.OwnershipTypeIsFinancialInterestBeReassignedIssuer,
   src.OwnershipTypeSICCode,
   src.OwnershipTypeShowAcknowledgementCheckbox,
   src.OwnershipTypeRequireCommentFieldWhenAddHolding,
   src.OwnershipTypeFinancialInterestDisplayType,
   src.OwnershipTypeIsAccountTypeEligibleForBrokerageImport,   
   src.SourceCreatedDate,
   src.SourceUpdatedDate,
   src.SourceCreatedBy,
   src.SourceUpdatedBy,
   src.SourceSystemId 
FROM gds_grdm_int.OwnershipType src
LEFT JOIN 
   gds_grdm.DimComplianceRegion dcr ON src.ComplianceRegionID = dcr.ComplianceRegionID
WHERE 
  src.GDSBatchID = wid_GDSBatchID