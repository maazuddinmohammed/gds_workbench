SELECT
  src.QuestionGroupQuestionID,
  src.QuestionGroupQuestionNumber,
  src.QuestionGroupQuestionOrder,
  src.QuestionGroupQuestionType,
  src.QuestionGroupQuestionStatus,
  cr1.ComplianceRegionKey as QuestionSetComplianceRegionKey,
  cr2.ComplianceRegionKey as QuestionSetProductionUserKey,
  u1.UserKey as QuestionSetArchiveUserKey,
  u2.UserKey as SystemQueryComplianceRegionKey,
  u3.UserKey as SystemQueryProductionUserKey,
  u4.UserKey as SystemQueryArchiveUserKey,
  l.LanguageKey,
  src.IsDefault,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.questiongroupquestion src
LEFT JOIN gds_grdm.DimComplianceRegion cr1 ON
  cr1.ComplianceRegionID = src.QuestionSetComplianceRegionID
LEFT JOIN gds_grdm.DimComplianceRegion cr2 ON
  cr2.ComplianceRegionID = src.SystemQueryComplianceRegionID
LEFT JOIN gds_grdm.DimUser u1 ON
  u1.UserID = src.QuestionSetProductionUserID AND u1.IsHistory = false
LEFT JOIN gds_grdm.DimUser u2 ON
  u2.UserID = src.QuestionSetArchiveUserID AND u2.IsHistory = false
LEFT JOIN gds_grdm.DimUser u3 ON
  u3.UserID = src.SystemQueryProductionUserID AND u3.IsHistory = false
LEFT JOIN gds_grdm.DimUser u4 ON
  u4.UserID = src.SystemQueryArchiveUserID AND u4.IsHistory = false
LEFT JOIN gds_ref.DimLanguage l ON
  l.LanguageID = src.LanguageID
WHERE 
  src.GDSBatchID = wid_GDSBatchID