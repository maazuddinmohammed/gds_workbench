SELECT
  src.UserProfileID,
  src.UserProfileNumber,
  du.UserKey as UserKey,
  cr1.ComplianceRegionKey as PrimaryComplianceRegionKey,
  cr2.ComplianceRegionKey as SecondaryComplianceRegionKey,
  upt.UserProfileTypeNumber,
  src.UserProfileFirstName,
  src.UserProfileMiddleName,
  src.UserProfileLastName,
  src.UserProfileSSN,
  upt.UserProfileTypeName,
  upt.UserProfileTypeBusinessName,
  upt.UserProfileTypeDescription,
  s.StatusBusinessName as UserProfileStatus,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.UserProfile src
LEFT JOIN gds_grdm.DimUser du ON 
  du.UserID = src.UserID AND du.IsHistory = false
LEFT JOIN gds_grdm.DimComplianceRegion cr1 ON
  cr1.ComplianceRegionID = src.PrimaryComplianceRegionID
LEFT JOIN gds_grdm.DimComplianceRegion cr2 ON
  cr2.ComplianceRegionID = src.SecondaryComplianceRegionID  
LEFT JOIN gds_grdm_int.UserProfileType upt ON
  upt.UserProfileTypeID = src.UserProfileTypeID
LEFT JOIN gds_ref_int.Status s ON
  s.StatusID = src.UserProfileStatusID
WHERE src.GDSBatchID = wid_GDSBatchID