select 
  src.FirmActionHoldingResetID,
  src.FirmActionHoldingResetNumber ,
  fa.FirmActionKey,
  h.HoldingKey,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
 from gds_grdm_int.FirmActionHoldingReset src
 left join gds_grdm.FactFirmAction fa on src.FirmActionId=fa.FirmActionId and fa.IsHistory=false
 left join gds_grdm.FactHolding h on src.HoldingId=h.HoldingId and h.IsHistory=false
 WHERE src.GDSBatchID = wid_GDSBatchID