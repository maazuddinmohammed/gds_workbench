SELECT
  src.QuestionGroupSubmissionReviewID,
  src.QuestionGroupSubmissionReviewNumber,
  ds.SecurityKey,
  du.UserKey,
  cr1.ComplianceRegionKey as PrimaryComplianceRegionKey,
  cr2.ComplianceRegionKey as SecondaryComplianceRegionKey,
  del.EscalationLevelKey,
  el.EscalationLevelKey as EscalationDisciplineLevelKey,
  fh.HoldingKey,
  fh2.HoldingKey as ReviewHoldingKey,
  src.QuestionGroupSubmissionReviewActionType,
  src.QuestionGroupSubmissionReviewEscalationTime,
  src.QuestionGroupSubmissionReviewExtensionExpirationTime,
  src.QuestionGroupSubmissionReviewConflictMonitoringTime,
  src.QuestionGroupSubmissionReviewExtensionGrantedTime,
  src.QuestionGroupSubmissionReviewCommentSaveTime,
  src.QuestionGroupSubmissionReviewComment,
  src.QuestionGroupSubmissionReviewAdminAction,
  src.QuestionGroupSubmissionReviewAdminActionTime,
  src.QuestionGroupSubmissionReviewDisciplinedTime,
  src.QuestionGroupSubmissionReviewStatus,
  src.QuestionGroupSubmissionReviewEntitySecurityType,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.questiongroupsubmissionreview src
LEFT JOIN gds_grdm.DimSecurity ds ON src.SecurityID=ds.SecurityID AND ds.IsHistory=false
LEFT JOIN gds_grdm.DimUser du ON src.UserID=du.UserID AND du.IsHistory=false
LEFT JOIN gds_grdm.DimEscalationLevel del ON src.EscalationLevelID=del.EscalationLevelID
LEFT JOIN gds_grdm.FactHolding fh ON src.HoldingID=fh.HoldingID AND fh.IsHistory=false
LEFT JOIN gds_grdm.DimComplianceRegion cr1 ON cr1.ComplianceRegionID = src.PrimaryComplianceRegionID
LEFT JOIN gds_grdm.DimComplianceRegion cr2 ON cr2.ComplianceRegionID = src.SecondaryComplianceRegionID
LEFT JOIN gds_grdm.DimEscalationLevel el ON el.EscalationLevelID = src.EscalationDisciplineLevelID
LEFT JOIN gds_grdm.FactHolding fh2 ON src.HoldingID=fh2.HoldingID AND fh2.IsHistory=false
WHERE
  src.GDSBatchID = wid_GDSBatchID