WITH cte_FactQuestionGroupUserResponse AS (
SELECT 
  QuestionGroupUserResponseID,
  CreatedDate AS QuestionGroupUserResponseTime, 
  QuestionGroupUserResponseNumber, 
  QuestionGroupAnswerTreeID,
  UserID,
  QuestionID,
  NextQuestionID,
  HoldingID,
  ConflictMessageID,
  UserQuestionID,
  NULL AS QuestionGroupSubmissionID,
  SupplementalQuestionSetID,
  QuestionSetID,
  QuestionSetCaseID,
  PrimaryComplianceRegionID,
  SecondaryComplianceRegionID,
  QuestionGroupUserResponseAnswerText,
  QuestionGroupUserResponseReviewTime,
  QuestionGroupUserResponseAnswerReviewerComment,
  QuestionGroupUserResponseSelfClearAttemptCount,
  QuestionGroupUserResponseQuestionType,
  NULL AS QuestionGroupUserResponseQuestionStatus,
  NULL AS QuestionGroupUserResponseAnswerStatus,
  NULL AS QuestionGroupUserResponseSubmissionStatus,
  QuestionGroupUserResponseType,
  QuestionGroupUserResponseFirstQuestionInQuestionSet,
  IsQuestionSetSkipped,
  False as IsHistory,
  SourceCreatedDate,
  SourceUpdatedDate,
  SourceCreatedBy,
  SourceUpdatedBy,
  SourceSystemID
  FROM gds_grdm_int.QuestionGroupUserResponse 
  WHERE GDSBatchID = wid_GDSBatchID

UNION ALL

SELECT
  QuestionGroupUserResponseHistoryID AS QuestionGroupUserResponseID,
  QuestionGroupUserResponseHistoryTime AS QuestionGroupUserResponseTime, 
  QuestionGroupUserResponseNumber, 
  QuestionGroupAnswerTreeID,
  UserID,
  QuestionID,
  NextQuestionID,
  HoldingID,
  ConflictMessageID,
  UserQuestionID,
  QuestionGroupSubmissionID,
  SupplementalQuestionSetID,
  QuestionSetID,
  QuestionSetCaseID,
  PrimaryComplianceRegionID,
  SecondaryComplianceRegionID,
  QuestionGroupUserResponseAnswerText,
  QuestionGroupUserResponseReviewTime,
  QuestionGroupUserResponseAnswerReviewerComment,
  QuestionGroupUserResponseSelfClearAttemptCount,
  QuestionGroupUserResponseQuestionType,
  QuestionGroupUserResponseQuestionStatus,
  QuestionGroupUserResponseAnswerStatus,
  QuestionGroupUserResponseSubmissionStatus,
  QuestionGroupUserResponseType,
  QuestionGroupUserResponseFirstQuestionInQuestionSet,
  IsQuestionSetSkipped,
  True as IsHistory,
  SourceCreatedDate,
  SourceUpdatedDate,
  SourceCreatedBy,
  SourceUpdatedBy,
  SourceSystemID
  FROM gds_grdm_int.QuestionGroupUserResponseHistory 
  WHERE GDSBatchID = wid_GDSBatchID
)
SELECT 
  src.QuestionGroupUserResponseID,
  src.QuestionGroupUserResponseTime,
  src.QuestionGroupUserResponseNumber, 
  qgat.QuestionGroupAnswerTreeKey,
  cr1.ComplianceRegionKey as PrimaryComplianceRegionKey,
  cr2.ComplianceRegionKey as SecondaryComplianceRegionKey,
  u.UserKey AS UserKey,
  q.QuestionKey AS QuestionKey,
  uq.QuestionKey AS UserQuestionKey,
  nq.QuestionKey AS NextQuestionKey , 
  h.HoldingKey AS HoldingKey,
  qgs.QuestionGroupSubmissionKey,
  fcm.ConflictMessageKey, 
  src.QuestionSetID,
  src.QuestionSetCaseID,
  qs.QuestionSetNumber,
  qs.QuestionSetName,
  qs.QuestionSetBusinessName,
  qs.QuestionSetDescription,
  src.QuestionSetID AS SupplementalQuestionSetID,    
  sqs.QuestionSetNumber AS SupplementalQuestionSetNumber,
  sqs.QuestionSetName AS SupplementalQuestionSetName,
  sqs.QuestionSetBusinessName AS SupplementalQuestionSetBusinessName,
  sqs.QuestionSetDescription AS SupplementalQuestionSetDescription,  
  src.QuestionGroupUserResponseAnswerText,
  src.QuestionGroupUserResponseReviewTime,
  src.QuestionGroupUserResponseAnswerReviewerComment,
  src.QuestionGroupUserResponseSelfClearAttemptCount,
  src.QuestionGroupUserResponseQuestionType,
  src.QuestionGroupUserResponseQuestionStatus,
  src.QuestionGroupUserResponseAnswerStatus,
  src.QuestionGroupUserResponseSubmissionStatus,
  src.QuestionGroupUserResponseType,
  src.QuestionGroupUserResponseFirstQuestionInQuestionSet,
  src.IsQuestionSetSkipped,
  src.IsHistory,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
  FROM 
  cte_FactQuestionGroupUserResponse src
  LEFT JOIN gds_grdm.FactQuestionGroupAnswerTree qgat ON src.QuestionGroupAnswerTreeId = qgat.QuestionGroupAnswerTreeID
  LEFT JOIN gds_grdm.DimUser u ON src.UserId=u.UserID AND u.IsHistory='false'
  LEFT JOIN gds_grdm.DimQuestion q ON src.QuestionId=q.QuestionId
  LEFT JOIN gds_grdm.DimQuestion uq ON src.UserQuestionID=uq.QuestionId ---->
  LEFT JOIN gds_grdm.DimQuestion nq ON src.NextQuestionId=nq.QuestionId
  LEFT JOIN gds_grdm.FactHolding h ON src.HoldingId=h.HoldingId AND h.IsHistory='false'
  LEFT JOIN gds_grdm.DimComplianceRegion cr1 ON cr1.ComplianceRegionID = src.PrimaryComplianceRegionID
  LEFT JOIN gds_grdm.DimComplianceRegion cr2 ON cr2.ComplianceRegionID = src.SecondaryComplianceRegionID
  LEFT JOIN gds_grdm_int.QuestionSet qs ON src.QuestionSetID = qs.QuestionSetID
  LEFT JOIN gds_grdm_int.QuestionSet sqs ON src.QuestionSetID = sqs.QuestionSetID  
  LEFT JOIN gds_grdm.FactQuestionGroupSubmission qgs ON qgs.QuestionGroupSubmissionID = src.QuestionGroupSubmissionID AND qgs.IsHistory='false' 
  LEFT JOIN gds_grdm.FactConflictMessage fcm ON fcm.ConflictMessageID = src.ConflictMessageID  ---->
