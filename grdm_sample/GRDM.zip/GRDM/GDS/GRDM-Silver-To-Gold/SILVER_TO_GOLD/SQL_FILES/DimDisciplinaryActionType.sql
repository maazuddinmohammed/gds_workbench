SELECT 
   src.DisciplinaryActionTypeID,
   src.DisciplinaryActionTypeNumber,
   src.DisciplinaryActionTypeName,
   src.DisciplinaryActionTypeBusinessName,
   src.DisciplinaryActionTypeDescription,
   dcr.ComplianceRegionKey,
   src.DisciplinaryActionTypeEffectiveStartDate,
   src.DisciplinaryActionTypeEffectiveEndDate,
   src.DisciplinaryActionTypeIdentifier,
   src.ParentDisciplinaryActionTypeListCodeNumber,
   src.DisciplinaryActionTypeAssociatedSecurityType,
   src.DisciplinaryActionTypeIsFinancialInterestBeReassignedIssuer,
   src.DisciplinaryActionTypeSICCode,
   src.DisciplinaryActionTypeShowAcknowledgementCheckbox,
   src.DisciplinaryActionTypeRequireCommentFieldWhenAddHolding,
   src.DisciplinaryActionTypeFinancialInterestDisplayType,
   src.DisciplinaryActionTypeIsAccountTypeEligibleForBrokerageImport,   
   src.SourceCreatedDate,
   src.SourceUpdatedDate,
   src.SourceCreatedBy,
   src.SourceUpdatedBy,
   src.SourceSystemId 
FROM gds_grdm_int.DisciplinaryActionType src
LEFT JOIN 
   gds_grdm.DimComplianceRegion dcr ON src.ComplianceRegionID = dcr.ComplianceRegionID
WHERE 
  src.GDSBatchID = wid_GDSBatchID