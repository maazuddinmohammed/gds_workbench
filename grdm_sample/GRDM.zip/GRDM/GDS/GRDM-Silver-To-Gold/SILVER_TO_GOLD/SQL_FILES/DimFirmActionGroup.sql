SELECT
  src.FirmActionGroupID,
  src.CreatedDate AS FirmActionGroupTime,
  src.FirmActionGroupNumber,
  src.FirmActionGroupState,
  src.FirmActionGroupAutoProcessFinalState,
  src.FirmActionGroupCurrentAction,
  src.FirmActionGroupReviewerComment,
  dcr.ComplianceRegionKey,
  src.IsAutoProcess,
  src.IsRetroactive,
  0 AS IsHistory,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.FirmActionGroup src
LEFT JOIN gds_grdm.DimComplianceRegion dcr ON dcr.ComplianceRegionID = src.ComplianceRegionID
WHERE src.GDSBatchID = wid_GDSBatchID

UNION ALL 

SELECT
  src.FirmActionGroupID,
  src.FirmActionGroupHistoryTime AS FirmActionGroupTime,
  src.FirmActionGroupNumber,
  src.FirmActionGroupState,
  src.FirmActionGroupAutoProcessFinalState,
  src.FirmActionGroupCurrentAction,
  src.FirmActionGroupReviewerComment,
  dcr.ComplianceRegionKey,
  src.IsAutoProcess,
  src.IsRetroactive,
  1 AS IsHistory,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.FirmActionGroupHistory src
LEFT JOIN gds_grdm.DimComplianceRegion dcr ON dcr.ComplianceRegionID = src.ComplianceRegionID
WHERE src.GDSBatchID = wid_GDSBatchID