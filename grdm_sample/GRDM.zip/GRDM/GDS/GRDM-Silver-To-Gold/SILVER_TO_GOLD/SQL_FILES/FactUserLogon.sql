SELECT
  src.UserLogonID,
  du.UserKey as UserKey,
  src.UserLogonTime,
  src.UserLogonDate,
  src.UserLogonServiceCenterTime,
  src.UserLogonAgentString,
  cr1.ComplianceRegionKey as PrimaryComplianceRegionKey,
  cr2.ComplianceRegionKey as SecondaryComplianceRegionKey,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.UserLogon src
LEFT JOIN gds_grdm.DimUser du ON
  du.UserID = src.UserID AND du.IsHistory = False
LEFT JOIN gds_grdm.DimComplianceRegion cr1 ON
  cr1.ComplianceRegionID = src.PrimaryComplianceRegionID
LEFT JOIN gds_grdm.DimComplianceRegion cr2 ON
  cr2.ComplianceRegionID = src.SecondaryComplianceRegionID  
WHERE src.GDSBatchID = wid_GDSBatchID