

SELECT cp.CapabilityID as CapabilityID,
    cp.CapabilityNumber as CapabilityNumber,
    cp.CapabilityName as CapabilityName,
    cp.IsCapabilityAdminEnabled as IsCapabilityAdminEnabled,
    cp.IsCapabilityComplianceOfficerEnabled as IsCapabilityComplianceOfficerEnabled,
    cp.IsCapabilityReviewerEnabled as IsCapabilityReviewerEnabled,
    cp.IsCapabilitySuperUserEnabled as IsCapabilitySuperUserEnabled,
    cp.SourceCreatedDate as SourceCreatedDate,
    cp.SourceUpdatedDate as SourceUpdatedDate,
    cp.SourceCreatedBy as SourceCreatedBy,
    cp.SourceUpdatedBy as SourceUpdatedBy,
    cp.SourceSystemID  as SourceSystemID
    FROM gds_grdm_int.capability cp
WHERE cp.GDSBatchID = wid_GDSBatchID