with cte_personalProfile as (
  SELECT 
    PersonalProfileID, 
    PersonalProfileNumber,
    PersonalProfileAttribute,
    PersonalProfileDescription,
    PersonalProfileInformationLong,
    UserID,
    PersonalProfileTypeID,
    PrimaryComplianceRegionID,
    SecondaryComplianceRegionID,
    SourceCreatedDate,
    SourceUpdatedDate,
    SourceCreatedBy,
    SourceUpdatedBy,
    SourceSystemID,
    CreatedDate as PersonalProfileTime,
    0 AS IsHistory,
    GDSBatchID
  FROM gds_grdm_int.PersonalProfile 
 WHERE GDSBatchID = wid_GDSBatchID 

  UNION ALL 

  SELECT 
    PersonalProfileHistoryID AS PersonalProfileID, 
    PersonalProfileNumber,
    PersonalProfileAttribute,
    PersonalProfileDescription,
    PersonalProfileInformationLong,
    UserID,
    PersonalProfileTypeID,
    PrimaryComplianceRegionID,
    SecondaryComplianceRegionID,
    SourceCreatedDate,
    SourceUpdatedDate,
    SourceCreatedBy,
    SourceUpdatedBy,
    SourceSystemID,
    PersonalProfileHistoryTime as PersonalProfileTime, 
    1 AS IsHistory,
    GDSBatchID
  FROM gds_grdm_int.PersonalProfileHistory
  WHERE GDSBatchID = wid_GDSBatchID 

)
SELECT
  src.PersonalProfileID,
  src.PersonalProfileTime,
  src.PersonalProfileNumber,
  src.PersonalProfileAttribute,
  src.PersonalProfileDescription,
  src.PersonalProfileInformationLong,
  u.UserKey,
  pt.PersonalProfileTypeNumber,
  pt.PersonalProfileTypeName,
  pt.PersonalProfileTypeBusinessName,
  pt.PersonalProfileTypeDescription,
  cr1.ComplianceRegionKey as PrimaryComplianceRegionKey,
  cr2.ComplianceRegionKey as SecondaryComplianceRegionKey,
  src.IsHistory,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM cte_personalProfile src
LEFT JOIN gds_grdm_int.PersonalProfileType pt on src.PersonalProfileTypeID = pt.PersonalProfileTypeID
LEFT JOIN gds_grdm.dimUser u on src.UserID = u.UserID AND u.IsHistory='false'
LEFT JOIN gds_grdm.DimComplianceRegion cr1 ON cr1.ComplianceRegionID = src.PrimaryComplianceRegionID
LEFT JOIN gds_grdm.DimComplianceRegion cr2 ON cr2.ComplianceRegionID = src.SecondaryComplianceRegionID
