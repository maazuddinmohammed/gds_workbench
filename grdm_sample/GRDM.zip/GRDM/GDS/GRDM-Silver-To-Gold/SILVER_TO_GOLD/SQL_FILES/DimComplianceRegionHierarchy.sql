-------------------------------------------------------
-- Refresh DimComplianceRegionHierarchy
-------------------------------------------------------

TRUNCATE TABLE gds_grdm.DimComplianceRegionHierarchy;

SELECT  
  crh.ComplianceRegionHierarchyID,
  dcrc.ComplianceRegionKey,
  crh.ComplianceRegionName,
  crh.ComplianceRegionIdentifier, 
  dcrp.ComplianceRegionKey as ParentComplianceRegionKey,
  crh.ParentComplianceRegionName,
  crh.ParentComplianceRegionIdentifier,
  crh.SourceCreatedDate,
  crh.SourceUpdatedDate,
  crh.SourceCreatedBy,
  crh.SourceUpdatedBy,
  crh.SourceSystemID 
FROM gds_grdm_int.ComplianceRegionHierarchy crh
LEFT JOIN gds_grdm.DimComplianceRegion dcrc ON
  dcrc.ComplianceRegionID = crh.ComplianceRegionID
LEFT JOIN gds_grdm.DimComplianceRegion dcrp ON
  dcrp.ComplianceRegionID = crh.ParentComplianceRegionID
  