SELECT 
  src.RestrictionReasonID,
  src.RestrictionReasonNumber,
  src.RestrictionReasonName,
  src.RestrictionReasonBusinessName,
  src.RestrictionReasonDescription,
  src.ComplianceRegionID,
  src.RestrictionReasonEffectiveStartDate,
  src.RestrictionReasonEffectiveEndDate,
  src.RestrictionReasonIdentifier,
  src.ParentRestrictionReasonListCodeNumber,
  src.RestrictionReasonAssociatedSecurityType,
  src.RestrictionReasonIsFinancialInterestBeReassignedIssuer,
  src.RestrictionReasonSICCode,
  src.RestrictionReasonShowAcknowledgementCheckbox,
  src.RestrictionReasonRequireCommentFieldWhenAddHolding,
  src.RestrictionReasonFinancialInterestDisplayType,
  src.RestrictionReasonIsAccountTypeEligibleForBrokerageImport,    
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.RestrictionReason src
WHERE
  src.GDSBatchID = wid_GDSBatchID