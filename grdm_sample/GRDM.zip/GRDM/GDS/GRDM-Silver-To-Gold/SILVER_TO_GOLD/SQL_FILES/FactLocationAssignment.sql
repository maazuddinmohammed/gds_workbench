SELECT  la.LocationAssignmentID,  
     la.LocationAssignmentTime,
     la.LocationAssignmentNumber,
     ds.SecurityKey AS SecurityKey,
     de.EntityKey AS EntityKey,
     dl.LocationKey AS LocationKey,
     la.LocationAssignmentStatus,
     la.LocationAssignmentEntitySecurityType,
     la.EngagementLocationType,
     la.LocationAssignmentComment,
     la.IsHistory,
     la.SourceCreatedDate,
     la.SourceUpdatedDate,
     la.SourceCreatedBy,
     la.SourceUpdatedBy,
     la.SourceSystemID
 FROM 
(
SELECT 
     la.LocationAssignmentID,
     la.CreatedDate AS LocationAssignmentTime,
     la.LocationAssignmentNumber,
     la.SecurityID AS SecurityID,
     la.EntityComplianceID,
     la.LocationID AS LocationID,
     la.LocationAssignmentStatus,
     la.LocationAssignmentEntitySecurityType,
     la.EngagementLocationType,
     la.LocationAssignmentComment,
     0 AS IsHistory,
     la.SourceCreatedDate,
     la.SourceUpdatedDate,
     la.SourceCreatedBy,
     la.SourceUpdatedBy,
     la.SourceSystemID
FROM gds_grdm_int.LocationAssignment la
WHERE 
  la.GDSBatchID = wid_GDSBatchID

UNION ALL

SELECT 
     la.LocationAssignmentHistoryID,  
     la.LocationAssignmentHistoryTime AS LocationAssignmentTime,
     la.LocationAssignmentNumber,
     la.SecurityID AS SecurityID,
     la.EntityComplianceID,
     la.LocationID AS LocationID,
     la.LocationAssignmentStatus,
     la.LocationAssignmentEntitySecurityType,
     la.EngagementLocationType,
     la.LocationAssignmentComment,
     1 AS IsHistory,
     la.SourceCreatedDate,
     la.SourceUpdatedDate,
     la.SourceCreatedBy,
     la.SourceUpdatedBy,
     la.SourceSystemID
FROM gds_grdm_int.LocationAssignmentHistory la
WHERE 
  la.GDSBatchID = wid_GDSBatchID
) as la 
LEFT JOIN gds_grdm.DimSecurity ds ON la.SecurityID = ds.SecurityID AND ds.IsHistory='false'
LEFT JOIN gds_grdm.DimLocation dl ON la.LocationID = dl.LocationID
LEFT JOIN gds_grdm_int.EntityCompliance ec ON la.EntityComplianceID = ec.EntityComplianceID
LEFT JOIN gds_grdm.DimEntity de ON ec.EntityID = de.EntityID AND de.IsHistory='false'
