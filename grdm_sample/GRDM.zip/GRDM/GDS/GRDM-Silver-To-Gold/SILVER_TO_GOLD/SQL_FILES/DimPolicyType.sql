SELECT 
   src.PolicyTypeID,
   src.PolicyTypeNumber,
   src.PolicyTypeName,
   src.PolicyTypeBusinessName,
   src.PolicyTypeDescription,
   dcr.ComplianceRegionKey,
   src.PolicyTypeEffectiveStartDate,
   src.PolicyTypeEffectiveEndDate,
   src.PolicyTypeIdentifier,
   src.ParentPolicyTypeListCodeNumber,
   src.PolicyTypeAssociatedSecurityType,
   src.PolicyTypeIsFinancialInterestBeReassignedIssuer,
   src.PolicyTypeSICCode,
   src.PolicyTypeShowAcknowledgementCheckbox,
   src.PolicyTypeRequireCommentFieldWhenAddHolding,
   src.PolicyTypeFinancialInterestDisplayType,
   src.PolicyTypeIsAccountTypeEligibleForBrokerageImport,   
   src.SourceCreatedDate,
   src.SourceUpdatedDate,
   src.SourceCreatedBy,
   src.SourceUpdatedBy,
   src.SourceSystemId 
FROM gds_grdm_int.PolicyType src
LEFT JOIN 
   gds_grdm.DimComplianceRegion dcr ON src.ComplianceRegionID = dcr.ComplianceRegionID
WHERE 
  src.GDSBatchID = wid_GDSBatchID