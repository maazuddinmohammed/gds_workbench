SELECT
  tp.ThirdPartyID,
  tp.ThirdPartyNumber,
  tp.ThirdPartyUserNumber,
  tp.ThirdPartyUserEmail,
  tp.ThirdPartyCreatedTime,
  tp.ThirdPartyUserID,
  tp.ThirdPartyUserFirstName,
  tp.ThirdPartyUserLastName,
  du.UserKey,
  tp.ThirdPartyUserStatus,
  tp.ThirdPartyUserCreationTime,
  tp.ThirdPartyAgreementAcknowledgementTime,
  tp.ThirdPartyUserModificationTime,
  tp.ThirdPartyUserRemovalTime,
  tp.ThirdPartyLastChangeTime,
  tp.ThirdPartyLastChangeUser,
  tp.IdentityProviderStatus,                                  
  tp.IdentityProviderStatusCode,
  tp.IdentityProviderUserID,
  dcr1.ComplianceRegionKey AS CurrentAssignedComplianceRegionKey,
  dcr2.ComplianceRegionKey AS CurrentSecondaryComplianceRegionKey,
  tpu.ThirdPartyUserName,
  tpu.ThirdPartyUserBusinessName,
  tpu.ThirdPartyUserDescription,
  dcr3.ComplianceRegionKey AS ThirdPartyUserComplianceRegionKey,
  tpu.ThirdPartyUserEffectiveStartDate,
  tpu.ThirdPartyUserEffectiveEndDate,
  tpu.ThirdPartyUserIdentifier,
  tpu.ParentThirdPartyUserListCodeNumber,
  tpu.ThirdPartyUserAssociatedSecurityType,
  tpu.ThirdPartyUserIsFinancialInterestBeReassignedIssuer,
  tpu.ThirdPartyUserSICCode,
  tpu.ThirdPartyUserShowAcknowledgementCheckbox,
  tpu.ThirdPartyUserRequireCommentFieldWhenAddHolding,
  tpu.ThirdPartyUserFinancialInterestDisplayType,
  tpu.ThirdPartyUserIsAccountTypeEligibleForBrokerageImport,
  dl.LanguageKey AS ThirdPartyUserLanguageKey,
  tp.IsHistory,
  tp.SourceCreatedDate,
  tp.SourceUpdatedDate,
  tp.SourceCreatedBy,
  tp.SourceUpdatedBy,
  tp.SourceSystemId
FROM (
  SELECT
    ThirdPartyID,
    ThirdPartyNumber,
    ThirdPartyUserNumber,
    UserID,
    ThirdPartyUserEmail,
    ThirdPartyCreatedTime,
    ThirdPartyUserID,
    ThirdPartyUserFirstName,
    ThirdPartyUserLastName,
    ThirdPartyUserStatus,
    ThirdPartyUserCreationTime,
    ThirdPartyAgreementAcknowledgementTime,
    ThirdPartyUserModificationTime,
    ThirdPartyUserRemovalTime,
    ThirdPartyLastChangeTime,
    ThirdPartyLastChangeUser,
    IdentityProviderStatus,                                  
    IdentityProviderStatusCode,
    IdentityProviderUserID,
    CurrentAssignedComplianceRegionID,
    CurrentSecondaryComplianceRegionID,
    ThirdPartyUserLanguageID,
    False AS IsHistory,
    SourceCreatedDate,
    SourceUpdatedDate,
    SourceCreatedBy,
    SourceUpdatedBy,
    SourceSystemID
  FROM gds_grdm_int.thirdparty
  WHERE GDSBatchID = wid_GDSBatchID

  UNION ALL

  SELECT
    ThirdPartyHistoryID AS ThirdPartyID,
    ThirdPartyHistoryNumber AS ThirdPartyNumber,
    ThirdPartyUserHistoryNumber AS ThirdPartyUserNumber,
    UserID,
    ThirdPartyUserEmail,
    ThirdPartyCreatedTime,
    ThirdPartyUserID,
    ThirdPartyUserFirstName,
    ThirdPartyUserLastName,
    ThirdPartyUserStatus,
    ThirdPartyUserCreationTime,
    ThirdPartyAgreementAcknowledgementTime,
    ThirdPartyUserModificationTime,
    ThirdPartyUserRemovalTime,
    ThirdPartyLastChangeTime,
    ThirdPartyLastChangeUser,
    IdentityProviderStatus,                                  
    IdentityProviderStatusCode,
    IdentityProviderUserID,
    CurrentAssignedComplianceRegionID,
    CurrentSecondaryComplianceRegionID,
    ThirdPartyUserLanguageID,
    True AS IsHistory,
    SourceCreatedDate,
    SourceUpdatedDate,
    SourceCreatedBy,
    SourceUpdatedBy,
    SourceSystemID
  FROM gds_grdm_int.thirdpartyhistory
  WHERE GDSBatchID = wid_GDSBatchID
) tp
LEFT JOIN gds_grdm_int.ThirdPartyUser tpu
  ON tpu.ThirdPartyUserID = tp.ThirdPartyUserID
LEFT JOIN gds_grdm.DimUser du
  ON du.UserID = tp.UserID and du.isHistory = false
LEFT JOIN gds_grdm.dimcomplianceregion dcr1
  ON dcr1.ComplianceRegionID = tp.CurrentAssignedComplianceRegionID
LEFT JOIN gds_grdm.dimcomplianceregion dcr2
  ON dcr2.ComplianceRegionID = tp.CurrentSecondaryComplianceRegionID
LEFT JOIN gds_grdm.dimcomplianceregion dcr3
  ON dcr3.ComplianceRegionID = tpu.complianceRegionID
LEFT JOIN gds_ref.dimlanguage dl
  ON dl.LanguageID = tp.ThirdPartyUserLanguageID



  