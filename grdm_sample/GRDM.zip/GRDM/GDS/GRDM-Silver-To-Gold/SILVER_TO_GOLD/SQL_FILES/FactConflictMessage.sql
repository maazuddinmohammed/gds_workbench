SELECT
  src.ConflictMessageID,
  src.ConflictMessageNumber,
  src.ConflictMessageTitle,
  src.ConflictMessage,
  cms.ConflictMessageStatusNumber,
  cms.ConflictMessageStatusName,
  cms.ConflictMessageStatusBusinessName,
  cms.ConflictMessageStatusDescription,
  dcr.ComplianceRegionKey,
  ds.SecurityKey,
  de.EntityKey,  
  dh.HoldingTypeKey,
  dr.RestrictionTypeKey,
  dse.SECRoleKey,
  src.ConflictMessageHoldingTypeArray,
  src.ConflictMessageRestrictionTypeArray,
  src.ConflictMessageSECRoleArray,
  msc.ConflictMessageScopeNumber,
  msc.ConflictMessageScopeName,
  msc.ConflictMessageScopeBusinessName,
  msc.ConflictMessageScopeDescription,
  dl.LanguageKey,
  dfit.FinancialInterestSubTypeKey,
  src.ConflictMessageLimitationDays,
  src.ConflictMessageSelfClearExpirationDays,
  src.ConflictMessageProductionTime,
  src.ConflictMessageArchiveTime,
  src.ConflictMessageLastAction,
  fcm.ConflictMessageKey as ReplacementConflictMessageKey,
  nfcm.ConflictMessageKey as  NewConflictMessageKey,
  src.IsCoveredPersonEligibility,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
  FROM gds_grdm_int.ConflictMessage src
  LEFT JOIN gds_grdm.DimComplianceRegion dcr ON dcr.ComplianceRegionID = src.ComplianceRegionID
  LEFT JOIN gds_grdm_int.ConflictMessageStatus cms ON cms.ConflictMessageStatusID = src.ConflictMessageStatusID
  LEFT JOIN gds_grdm_int.ConflictMessageScope msc ON msc.ConflictMessageScopeID = src.ConflictMessageScopeID
  LEFT JOIN gds_ref.DimLanguage dl ON dl.LanguageID = src.LanguageID
  LEFT JOIN gds_grdm.DimFinancialInterestSubType dfit ON dfit.FinancialInterestSubTypeID = src.FinancialInterestSubTypeID
  LEFT JOIN gds_grdm.DimSecurity ds ON ds.SecurityID = src.SecurityID AND ds.IsHistory='false'  
  LEFT JOIN gds_grdm.DimHoldingType dh ON dh.HoldingTypeID = src.HoldingTypeID
  LEFT JOIN gds_grdm.DimRestrictionType dr ON dr.RestrictionTypeID = src.RestrictionTypeID
  LEFT JOIN gds_grdm.DimSECRole dse ON dse.SECRoleID = src.SECRoleID
  LEFT JOIN gds_grdm_int.EntityCompliance er ON er.entitycomplianceid = src.EntityComplianceID  
  LEFT JOIN gds_grdm.DimEntity de on de.EntityID = er.EntityID
  LEFT JOIN gds_grdm.FactConflictMessage fcm ON fcm.ConflictMessageID = src.ConflictMessageID 
  LEFT JOIN gds_grdm.FactConflictMessage nfcm ON nfcm.ConflictMessageID = src.ConflictMessageID 
  WHERE src.GDSBatchID = wid_GDSBatchID 
