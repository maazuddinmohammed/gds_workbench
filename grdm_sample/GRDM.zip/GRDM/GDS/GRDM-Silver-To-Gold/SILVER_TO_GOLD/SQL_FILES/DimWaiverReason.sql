SELECT
  src.WaiverReasonID,
  src.WaiverReasonNumber,
  src.WaiverReasonDescription,
  src.WaiverReasonIdentifier,
  dcr.ComplianceRegionKey,
  wrt.WaiverReasonTypeNumber,
  wrt.WaiverReasonTypeName,
  wrt.WaiverReasonTypeBusinessName,
  wrt.WaiverReasonTypeDescription,
  src.WaiverReasonStatus,
  dl.LanguageISO1,
  dl.LanguageISO2,
  dl.LanguageName,
  dl.LanguageBusinessName,
  src.WaiverReasonLanguageDescriptionStatus,
  src.WaiverReasonLanguageDescription,
  src.WaiverReasonComment,
  src.DefaultDayCountUntlExpiration,
  src.ReasonWaiverMaximumExpirationDays AS WaiverReasonMaximumExpirationDays,
  src.IsDefaultLanguage,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.waiverreason src
LEFT JOIN 
  gds_grdm_int.waiverreasontype wrt ON src.WaiverReasonTypeID=wrt.WaiverReasonTypeID
LEFT JOIN 
  gds_grdm.dimcomplianceregion dcr ON src.ComplianceRegionID=dcr.ComplianceRegionID
LEFT JOIN 
  gds_ref.dimlanguage dl on src.LanguageID=dl.LanguageID
WHERE
  src.GDSBatchID = wid_GDSBatchID
