SELECT 
  src.RestrictionTypeID,
  src.RestrictionTypeNumber,
  src.RestrictionTypeName,
  src.RestrictionTypeBusinessName,
  src.RestrictionTypeDescription,
  dcr.ComplianceRegionKey,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.restrictiontype src
LEFT JOIN 
  gds_grdm.dimcomplianceregion dcr ON src.ComplianceRegionID=dcr.ComplianceRegionID
WHERE
  src.GDSBatchID = wid_GDSBatchID
