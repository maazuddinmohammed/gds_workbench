SELECT  
    qgurs.QuestionGroupUserResponseSupplementID,
    qgurs.QuestionGroupUserResponseSupplementNumber,
    u.UserKey,
    q.QuestionKey,
    uq.QuestionKey AS UserQuestionKey,
    nq.QuestionKey AS NextQuestionKey,
    cr.ComplianceRegionKey,
    crs.ComplianceRegionKey AS CurrentSecondaryComplianceRegionKey,
    qgat.QuestionGroupAnswerTreeKey,
    qgs.QuestionGroupSubmissionKey,
    h.HoldingKey,
    qgurs.QuestionSetID,
    qgurs.QuestionSetCaseID,
    qs.QuestionSetNumber,
    qs.QuestionSetName,
    qs.QuestionSetBusinessName,
    qs.QuestionSetDescription,    
    qgurs.QuestionGroupUserResponseSupplementText,
    qgurs.QuestionGroupUserResponseSupplementReviewerComment,
    qgurs.QuestionGroupUserResponseSupplementReviewTime,
    qgurs.QuestionGroupUserResponseSupplementSelfClearAttempts,
    qgurs.QuestionGroupUserResponseSupplementQuestionType,
    qgurs.QuestionGroupUserResponseSupplementResponseType,
    qgurs.QuestionGroupUserResponseSupplementFirstUserQuestionInQuestionSet,
    qgurs.IsQuestionSetSkipped,
    qgurs.SourceCreatedDate,
    qgurs.SourceUpdatedDate,
    qgurs.SourceCreatedBy,
    qgurs.SourceUpdatedBy,
    qgurs.SourceSystemID
FROM 
    gds_grdm_int.QuestionGroupUserResponseSupplement qgurs
LEFT JOIN 
    gds_grdm.DimUser u ON qgurs.UserID = u.UserID AND u.IsHistory = 'false'
LEFT JOIN 
    gds_grdm.DimQuestion q ON qgurs.QuestionId = q.QuestionId
LEFT JOIN 
    gds_grdm.DimQuestion nq ON qgurs.NextQuestionId = nq.QuestionId
LEFT JOIN 
    gds_grdm.DimComplianceRegion cr ON qgurs.ComplianceRegionId = cr.ComplianceRegionId
LEFT JOIN 
    gds_grdm.DimComplianceRegion crs ON qgurs.CurrentSecondaryComplianceRegionId = crs.ComplianceRegionId
LEFT JOIN 
    gds_grdm.FactQuestionGroupAnswerTree qgat ON qgurs.QuestionGroupAnswerTreeId = qgat.QuestionGroupAnswerTreeID
LEFT JOIN 
    gds_grdm.DimQuestion uq ON qgurs.UserQuestionId = uq.QuestionId 
LEFT JOIN 
    gds_grdm.FactHolding h ON h.HoldingID = qgurs.HoldingID AND h.IsHistory = 'false'
LEFT JOIN 
    gds_grdm_int.QuestionSet qs ON qgurs.QuestionSetID = qs.QuestionSetID 
LEFT JOIN 
    gds_grdm.FactQuestionGroupSubmission qgs ON qgs.QuestionGroupSubmissionID = qgurs.QuestionGroupSubmissionID AND qgs.IsHistory = False   
WHERE 
    qgurs.GDSBatchID = wid_GDSBatchID