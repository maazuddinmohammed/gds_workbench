SELECT 
  src.MutualFundFamilyID,
  src.MutualFundFamilyNumber,
  src.MutualFundFamilyName,
  src.MutualFundFamilyBusinessName,
  src.MutualFundFamilyDescription,
  src.ComplianceRegionID,
	src.MutualFundFamilyEffectiveStartDate,
	src.MutualFundFamilyEffectiveEndDate,
	src.MutualFundFamilyIdentifier,
	src.ParentMutualFundFamilyListCodeNumber,
	src.MutualFundFamilyAssociatedSecurityType,
	src.MutualFundFamilyIsFinancialInterestBeReassignedIssuer,
	src.MutualFundFamilySICCode,
	src.MutualFundFamilyShowAcknowledgementCheckbox,
	src.MutualFundFamilyRequireCommentFieldWhenAddHolding,
	src.MutualFundFamilyFinancialInterestDisplayType,
	src.MutualFundFamilyIsAccountTypeEligibleForBrokerageImport,    
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.MutualFundFamily src
WHERE
  src.GDSBatchID = wid_GDSBatchID