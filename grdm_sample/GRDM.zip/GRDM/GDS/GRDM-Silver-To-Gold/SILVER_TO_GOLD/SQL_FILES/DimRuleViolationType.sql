SELECT 
   src.RuleViolationTypeID AS RuleViolationTypeID,
   src.RuleViolationTypeNumber AS RuleViolationTypeNumber,
   src.RuleViolationTypeName AS RuleViolationTypeName,
   src.RuleViolationTypeBusinessName AS RuleViolationTypeBusinessName,
   src.RuleViolationTypeDescription AS RuleViolationTypeDescription,
   dcr.ComplianceRegionKey,
   src.RuleViolationTypeEffectiveStartDate,
   src.RuleViolationTypeEffectiveEndDate,
   src.RuleViolationTypeIdentifier,
   src.ParentRuleViolationTypeListCodeNumber,
   src.RuleViolationTypeAssociatedSecurityType,
   src.RuleViolationTypeIsFinancialInterestBeReassignedIssuer,
   src.RuleViolationTypeSICCode,
   src.RuleViolationTypeShowAcknowledgementCheckbox,
   src.RuleViolationTypeRequireCommentFieldWhenAddHolding,
   src.RuleViolationTypeFinancialInterestDisplayType,
   src.RuleViolationTypeIsAccountTypeEligibleForBrokerageImport,
   src.SourceCreatedDate,
   src.SourceUpdatedDate,
   src.SourceCreatedBy,
   src.SourceUpdatedBy,
   src.SourceSystemId 
FROM gds_grdm_int.RuleViolationType src
LEFT JOIN 
   gds_grdm.DimComplianceRegion dcr ON src.ComplianceRegionID = dcr.ComplianceRegionID
WHERE 
  src.GDSBatchID = wid_GDSBatchID