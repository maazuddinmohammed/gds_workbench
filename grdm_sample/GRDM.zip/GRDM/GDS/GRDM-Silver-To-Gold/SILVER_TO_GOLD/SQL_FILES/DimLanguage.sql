select 
  src.LanguageID,
  src.LanguageISO1,
  src.LanguageISO2,
  src.LanguageName,
  src.LanguageBusinessName,
  src.LanguageStatus, 
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_ref_int.language src
WHERE 
  src.GDSBatchID = wid_GDSBatchID