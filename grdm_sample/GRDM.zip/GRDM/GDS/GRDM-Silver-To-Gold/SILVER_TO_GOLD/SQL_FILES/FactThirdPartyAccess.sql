SELECT
  tpah.ThirdPartyAccessHistoryId,
  tpah.ThirdPartyAccessHistoryNumber,
  tpah.ThirdPartyUserNumber,
  tp.ThirdPartyKey,
  du.UserKey,
  tpah.ThirdPartyAccessTime,
  TRIM(dcr1.ComplianceRegionKey) AS CurrentAssignedComplianceRegionKey,
  TRIM(dcr2.ComplianceRegionKey) AS CurrentSecondaryComplianceRegionKey,
  True AS IsHistory,
  tpah.SourceCreatedDate,
  tpah.SourceUpdatedDate,
  tpah.SourceCreatedBy,
  tpah.SourceUpdatedBy,
  tpah.SourceSystemId
FROM gds_grdm_int.thirdpartyaccesshistory tpah
LEFT JOIN gds_grdm.dimthirdparty tp
  ON tp.ThirdPartyID = tpah.ThirdPartyID and tp.isHistory = false
LEFT JOIN gds_grdm.dimuser du
  ON du.UserID = tpah.UserID and du.isHistory = false
LEFT JOIN gds_grdm.dimcomplianceregion dcr1
  ON dcr1.ComplianceRegionID = tpah.CurrentAssignedComplianceRegionID
LEFT JOIN gds_grdm.dimcomplianceregion dcr2
  ON dcr2.ComplianceRegionID = tpah.CurrentSecondaryComplianceRegionID
WHERE 
  tpah.GDSBatchID = wid_GDSBatchID