SELECT
  src.HoldingReviewID,
  src.HoldingReviewNumber,
  fh.HoldingKey,
  fho.HoldingKey AS OriginalHoldingKey,
  du.UserKey,
  dcrp.ComplianceRegionKey AS PrimaryComplianceRegionKey,
  dcrs.ComplianceRegionKey AS SecondaryComplianceRegionKey,
  ds.SecurityKey,
  del.EscalationLevelKey,
  del2.EscalationLevelKey AS EscalationDisciplineLevelKey, 
  src.HoldingReviewEscalationTime,
  src.HoldingReviewExtensionGrantedDate,
  src.HoldingReviewExtensionExpirationDate,
  hra.HoldingReviewActionNumber,
  hra.HoldingReviewActionName,
  hra.HoldingReviewActionBusinessName,
  hra.HoldingReviewActionDescription,
  hraa.HoldingReviewAdminActionNumber,
  hraa.HoldingReviewAdminActionName,
  hraa.HoldingReviewAdminActionBusinessName,
  hraa.HoldingReviewAdminActionDescription,
  src.HoldingReviewAdminActionTime,
  src.HoldingReviewDisciplinedTime,
  src.HoldingReviewMonitoringStartTime,
  src.HoldingReviewComment,
  src.HoldingReviewCommentTime,
  src.HoldingReviewStatus,
  src.HoldingReviewEntitySecurityType,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.holdingreview src
LEFT JOIN gds_grdm.FactHolding fh ON src.HoldingID=fh.HoldingID and fh.IsHistory=false
LEFT JOIN gds_grdm.FactHolding fho ON src.OriginalHoldingID=fho.HoldingID and fho.IsHistory=false
LEFT JOIN gds_grdm.DimComplianceRegion dcrp ON src.PrimaryComplianceRegionID=dcrp.ComplianceRegionID 
LEFT JOIN gds_grdm.DimComplianceRegion dcrs ON src.SecondaryComplianceRegionID=dcrs.ComplianceRegionID 
LEFT JOIN gds_grdm.DimUser du ON src.UserID=du.UserID and du.IsHistory=false
LEFT JOIN gds_grdm.DimSecurity ds ON src.SecurityID=ds.SecurityID AND ds.IsHistory=false
LEFT JOIN gds_grdm.DimEscalationLevel del ON src.EscalationLevelID=del.EscalationLevelID
LEFT JOIN gds_grdm.DimEscalationLevel del2 ON src.EscalationDisciplineLevelID=del2.EscalationLevelID
LEFT JOIN gds_grdm_int.holdingreviewaction hra ON src.HoldingReviewActionID=hra.HoldingReviewActionID
LEFT JOIN gds_grdm_int.holdingreviewadminaction hraa ON src.HoldingReviewAdminActionID=hraa.HoldingReviewAdminActionID
WHERE
  src.GDSBatchID = wid_GDSBatchID
