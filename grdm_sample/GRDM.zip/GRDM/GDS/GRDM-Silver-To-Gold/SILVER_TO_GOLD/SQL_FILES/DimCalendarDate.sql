SELECT 
  src.CalendarDate,
  src.CalendarMonth,
  src.CalendarQuarter,
  src.CalendarYear,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_ref_int.calendardate src
WHERE 
  src.GDSBatchID = wid_GDSBatchID