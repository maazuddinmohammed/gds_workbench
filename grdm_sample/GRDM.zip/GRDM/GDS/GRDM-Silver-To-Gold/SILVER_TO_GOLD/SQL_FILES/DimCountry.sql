SELECT 
  src.CountryID,
  src.CountryISOCode,
  src.CountryUNCode,
  src.CountryName,
  src.CountryIsActive,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_ref_int.country src
WHERE 
  src.GDSBatchID = wid_GDSBatchID