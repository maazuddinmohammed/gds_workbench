with cte_FactFirmAction as (
SELECT
  FirmActionID,
  SourceCreatedDate AS FirmActionTime,
  FirmActionNumber,
  LocationID,
  PendingUserLocationID,
  UserID,
  EntityComplianceID,
  PendingEntityComplianceID,
  CurrentAffectedComplianceRegionID,
  ComplianceRegionID,
  PendingComplianceRegionID,
  PendingSecurityRestrictionID,
  PendingEntityComplianceRestrictionID,
  SecurityID,
  FirmActionGroupID,
  FirmActionCurrentAction,
  FirmActionEntityType,
  FirmActionPendingNewValue,
  FirmActionApplicability,
  FirmActionState,
  FirmActionAutoProcessFinalState,
  FirmActionReviewStatus,
  FirmActionReviewComment,
  FirmActionSECRegistrantComment,
  IsAutoProcess,
  OverrideAutoSelfClearSetting,
  RequireReview,
  IsAnalyzed,
  0 AS IsHistory,
  SourceCreatedDate,
  SourceUpdatedDate,
  SourceCreatedBy,
  SourceUpdatedBy,
  SourceSystemID
FROM gds_grdm_int.FirmAction 
WHERE  GDSBatchID = wid_GDSBatchID

UNION ALL 

SELECT 
  FirmActionID,
  FirmActionHistoryTime AS FirmActionTime,
  FirmActionNumber,
  LocationID,
  UserID,
  PendingUserLocationID,
  EntityComplianceID,
  PendingEntityComplianceID,
  CurrentAffectedComplianceRegionID,
  ComplianceRegionID,
  PendingComplianceRegionID,
  PendingSecurityRestrictionID,
  PendingEntityComplianceRestrictionID,
  SecurityID,
  FirmActionGroupID,
  FirmActionCurrentAction,
  FirmActionEntityType,
  FirmActionPendingNewValue,
  FirmActionApplicability,
  FirmActionState,
  FirmActionAutoProcessFinalState,
  FirmActionReviewStatus,
  FirmActionReviewComment,
  FirmActionSECRegistrantComment,
  IsAutoProcess,
  OverrideAutoSelfClearSetting,
  RequireReview,
  IsAnalyzed,
  1 AS IsHistory,
  SourceCreatedDate,
  SourceUpdatedDate,
  SourceCreatedBy,
  SourceUpdatedBy,
  SourceSystemID
FROM gds_grdm_int.FirmActionHistory 
WHERE  GDSBatchID = wid_GDSBatchID
)  
SELECT
  src.FirmActionID,
  src.FirmActionTime,
  src.FirmActionNumber,
  de.EntityKey,
  de2.EntityKey as PendingEntityKey,  
  dl.LocationKey,
  dl2.LocationKey as PendingUserLocationKey,
  dcr.ComplianceRegionKey,
  dcr2.ComplianceRegionKey as PendingComplianceRegionKey,
  dcr3.ComplianceRegionKey as CurrentAffectedComplianceRegionKey,
  ds.SecurityKey, 
  du.UserKey,
  fa.FirmActionGroupKey,
  sr.SecurityRestrictionKey as PendingSecurityRestrictionKey,
  er.EntityRestrictionKey as PendingEntityRestrictionKey,   
  src.FirmActionCurrentAction,
  src.FirmActionEntityType,
  src.FirmActionPendingNewValue,
  src.FirmActionApplicability,
  src.FirmActionState,
  src.FirmActionAutoProcessFinalState,
  src.FirmActionReviewStatus,
  src.FirmActionReviewComment,
  src.FirmActionSECRegistrantComment,
  src.IsAutoProcess,
  src.OverrideAutoSelfClearSetting,
  src.RequireReview,
  src.IsAnalyzed,
  src.IsHistory,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
  FROM cte_FactFirmAction src
LEFT JOIN gds_grdm.DimComplianceRegion dcr ON dcr.ComplianceRegionID = src.ComplianceRegionID
LEFT JOIN gds_grdm.DimComplianceRegion dcr2 ON dcr2.ComplianceRegionID = src.PendingComplianceRegionID
LEFT JOIN gds_grdm.DimComplianceRegion dcr3 ON dcr3.ComplianceRegionID = src.CurrentAffectedComplianceRegionID
LEFT JOIN gds_grdm.DimFirmActionGroup fa ON fa.FirmActionGroupID = src.FirmActionGroupID AND fa.IsHistory=false 
LEFT JOIN gds_grdm.DimSecurity ds ON ds.SecurityID = src.SecurityID AND ds.IsHistory=false
LEFT JOIN gds_grdm_int.EntityCompliance er ON er.entitycomplianceid = src.EntityComplianceID
LEFT JOIN gds_grdm_int.EntityCompliance er2 ON er2.entitycomplianceid = src.PendingEntityComplianceID  
LEFT JOIN gds_grdm.DimEntity de ON de.EntityID = er.EntityID AND de.IsHistory=false 
LEFT JOIN gds_grdm.DimEntity de2 ON de2.EntityID = er2.EntityID AND de2.IsHistory=false 
LEFT JOIN gds_grdm.DimUser du ON du.UserID = src.UserID AND du.IsHistory=false
LEFT JOIN gds_grdm.DimLocation dl ON dl.LocationID = src.LocationID
LEFT JOIN gds_grdm.DimLocation dl2 ON dl2.LocationID = src.PendingUserLocationID
LEFT JOIN gds_grdm.FactSecurityRestriction sr ON sr.SecurityRestrictionID = src.PendingSecurityRestrictionID AND sr.IsHistory=false
LEFT JOIN gds_grdm.FactEntityRestriction er ON er.EntityRestrictionID = src.PendingEntityComplianceRestrictionID AND er.IsHistory=false
