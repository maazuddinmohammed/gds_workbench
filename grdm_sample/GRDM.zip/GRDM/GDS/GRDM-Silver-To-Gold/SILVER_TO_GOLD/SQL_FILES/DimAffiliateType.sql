SELECT 
  src.AffiliateTypeID,
  src.AffiliateTypeNumber,
  src.AffiliateTypeCode,
  src.AffiliateTypeDisplayCode,
  src.AffiliateTypeName,
  src.AffiliateTypeBusinessName,
  src.AffiliateTypeDescription,
  src.AffiliateTypeRank,
  src.AffiliateTypeAlias,
  src.AffiliateTypeOrganizationType,
  src.AffiliateTypeDisplayOrder,
  src.AffiliateTypeIsActive,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.affiliatetype src
WHERE
  src.GDSBatchID = wid_GDSBatchID