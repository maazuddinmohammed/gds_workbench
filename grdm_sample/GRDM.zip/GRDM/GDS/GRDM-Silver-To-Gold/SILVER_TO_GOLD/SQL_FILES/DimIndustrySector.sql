
SELECT 
   src.IndustrySectorID AS IndustrySectorID,
   src.IndustrySectorNumber AS IndustrySectorNumber,   
    src.IndustrySectorName AS IndustrySectorName,
   src.IndustrySectorBusinessName AS IndustrySectorBusinessName,
   src.IndustrySectorDescription AS IndustrySectorDescription, 
   src.IndustrySectorIsActive AS IndustrySectorIsActive,
   src.SourceCreatedDate,
   src.SourceUpdatedDate,
   src.SourceCreatedBy,
   src.SourceUpdatedBy,
   src.SourceSystemId 
FROM gds_grdm_int.IndustrySector src 
WHERE 
  src.GDSBatchID = wid_GDSBatchID