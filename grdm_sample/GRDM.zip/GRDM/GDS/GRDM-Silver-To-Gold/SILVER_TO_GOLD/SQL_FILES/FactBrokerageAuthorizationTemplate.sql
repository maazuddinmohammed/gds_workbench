SELECT 
   src.BrokerageAuthorizationTemplateID,
   src.BrokerageAuthorizationTemplateNumber,
   src.BrokerageAuthorizationTemplateName,
   src.BrokerageAuthorizationTemplateStatus,
   e.EntityKey,
   l.LanguageKey,
   src.BrokerageAuthorizationTemplateProductionTime,
   ds1.UserKey AS BrokerageAuthorizationTemplateProductionUserKey,
   src.BrokerageAuthorizationTemplateArchivedTime,
   ds2.UserKey AS BrokerageAuthorizationTemplateArchivedUserKey,
   src.BrokerageAuthorizationTemplateAttachmentFilename,
   src.BrokerageAuthorizationTemplateAttachmentAddTime,
   src.SourceCreatedDate,
   src.SourceUpdatedDate,
   src.SourceCreatedBy,
   src.SourceUpdatedBy,
   src.SourceSystemID
FROM gds_grdm_int.brokerageauthorizationtemplate src
LEFT JOIN gds_ref.DimLanguage l ON
  l.LanguageID = src.LanguageID
LEFT JOIN gds_grdm.DimUser ds1 ON
  ds1.UserID = src.BrokerageAuthorizationTemplateProductionUserID AND ds1.IsHistory=false  
LEFT JOIN gds_grdm.DimUser ds2 ON
  ds2.UserID = src.BrokerageAuthorizationTemplateArchivedUserID AND ds2.IsHistory=false  
LEFT JOIN 
  gds_grdm_int.EntityCompliance ec ON ec.EntityComplianceID = src.EntityComplianceID
LEFT JOIN 
  gds_grdm.DimEntity e ON e.EntityID = ec.EntityID AND e.IsHistory = False   
WHERE 
  src.GDSBatchID = wid_GDSBatchID