 select 
  src.FirmActionSituationID,
  src.FirmActionSituationNumber,
  src.FirmActionSituationType,
  src.FirmActionSituationState,
  fa.FirmActionKey, 
  u.UserKey,
  up.UserProfileKey,
  l.LocationKey,
  cr1.ComplianceRegionKey as PrimaryComplianceRegionKey,
  cr2.ComplianceRegionKey as SecondaryComplianceRegionKey,
  cm.ConflictMessageKey as ConflictMessageKey,
  h.HoldingKey as HoldingKey,
  src.FirmActionSituationEmailSentTime,
  src.FirmActionSituationEmailFromUser,
  src.FirmActionSituationEmailState,
  src.FirmActionSituationAddType,
  src.FirmActionSituationComplianceSurveyID,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
  from gds_grdm_int.FirmActionSituation src
  left join gds_grdm.FactFirmAction fa on src.FirmActionID=fa.FirmActionID AND fa.IsHistory= false
  left join gds_grdm.DimUser u on src.UserID=u.UserID AND u.IsHistory= false
  left join gds_grdm.FactUserProfile up on src.UserProfileID=up.UserProfileID
  left join gds_grdm.DimLocation l on src.LocationID=l.LocationID
  left join gds_grdm.FactConflictMessage cm on src.ConflictMessageID=cm.ConflictMessageID
  left join gds_grdm.FactHolding h on src.HoldingID=h.HoldingID AND h.IsHistory= false
  LEFT JOIN gds_grdm.DimComplianceRegion cr1 ON cr1.ComplianceRegionID = src.PrimaryComplianceRegionID
  LEFT JOIN gds_grdm.DimComplianceRegion cr2 ON cr2.ComplianceRegionID = src.SecondaryComplianceRegionID
  WHERE src.GDSBatchID = wid_GDSBatchID