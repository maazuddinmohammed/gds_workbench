SELECT 
 ecsn.EntityComplianceSecurityNoticeID AS EntitySecurityNoticeID,
 ecsn.EntityComplianceSecurityNoticeNumber AS EntitySecurityNoticeNumber,
 ecsn.EntityComplianceSecurityNoticeDate AS EntitySecurityNoticeDate,
 ecsn.EntityComplianceSecurityNoticeTime AS EntitySecurityNoticeTime,
 du.Userkey,
 de.EntityKey,
 ds.SecurityKey,
 dcr.ComplianceRegionKey,
 adcr.ComplianceRegionKey AS AuthorizedComplianceRegionKey,
 ecsn.EntityComplianceSecurityNoticeType AS EntitySecurityNoticeType,
 ecsn.EntityComplianceSecurityNoticeReason AS EntitySecurityNoticeReason,
 ecsn.EntityComplianceSecurityNoticeState AS EntitySecurityNoticeState,
 ecsn.EntityComplianceSecurityNoticeComment AS EntitySecurityNoticeComment,
 ecsn.EntityComplianceSecurityNoticeProcessType AS EntitySecurityNoticeProcessType,
 ecsn.EntityComplianceSecurityNoticeEntitySecurityType AS EntitySecurityNoticeEntitySecurityType,
 ecsn.SourceCreatedDate,
 ecsn.SourceUpdatedDate,
 ecsn.SourceCreatedBy,
 ecsn.SourceUpdatedBy,
 ecsn.SourceSystemID 
FROM gds_grdm_int.EntityComplianceSecurityNotice ecsn
LEFT JOIN gds_grdm_int.EntityCompliance ec 
    ON ecsn.EntityComplianceID = ec.EntityComplianceID
LEFT JOIN gds_grdm.DimEntity de
    ON de.EntityID = ec.EntityID AND de.IsHistory = false
LEFT JOIN gds_grdm.DimSecurity ds
    ON ds.SecurityID = ecsn.SecurityID AND ds.IsHistory = false
LEFT JOIN gds_grdm.DimComplianceRegion dcr
    ON dcr.ComplianceRegionID = ecsn.ComplianceRegionID
LEFT JOIN gds_grdm.DimComplianceRegion adcr
    ON adcr.ComplianceRegionID = ecsn.AuthorizedComplianceRegionID    
LEFT JOIN gds_grdm.DimUser du
    ON du.UserID = ecsn.UserID AND du.IsHistory = false
WHERE ecsn.GDSBatchId = wid_GDSBatchID