WITH cte_FactEntityRestriction as (
SELECT
  EntityComplianceRestrictionID AS EntityRestrictionID,
  CreatedDate AS EntityRestrictionTime,
  EntityComplianceRestrictionNumber AS EntityRestrictionNumber,
  ComplianceRegionID,
  ParentComplianceRegionID,
  EntityComplianceRestriction AS EntityRestriction,
  EntityComplianceRestrictionReason AS EntityRestrictionReason,
  EntityComplianceRestrictionEntityType AS EntityRestrictionEntityType,
  EntityComplianceRestrictionEngagementPartnerAssignmentArray AS EntityRestrictionEngagementPartnerAssignmentArray,
  EntityComplianceRestrictionCoveredPersonRestrictionAttributeArray AS EntityRestrictionCoveredPersonRestrictionAttributeArray,
  EntityComplianceID,
  RestrictionTypeID,
  RestrictionStateID,
  EntityComplianceRestriction,
  IsRestricted,
  IsApplicable,
  0 AS IsHistory,
  SourceCreatedDate,
  SourceUpdatedDate,
  SourceCreatedBy,
  SourceUpdatedBy,
  SourceSystemID,
  GDSBatchID  
FROM gds_grdm_int.EntityComplianceRestriction
WHERE  GDSBatchID = wid_GDSBatchID 

UNION ALL 

SELECT
  EntityComplianceRestrictionHistoryID AS EntityRestrictionID,
  EntityComplianceRestrictionHistoryTime AS EntityRestrictionTime,
  EntityComplianceRestrictionNumber AS EntityRestrictionNumber,
  ComplianceRegionID,
  ParentComplianceRegionID,
  EntityComplianceRestriction AS EntityRestriction,
  EntityComplianceRestrictionReason AS EntityRestrictionReason,
  EntityComplianceRestrictionEntityType AS EntityRestrictionEntityType,
  EntityComplianceRestrictionEngagementPartnerAssignmentArray AS EntityRestrictionEngagementPartnerAssignmentArray,
  EntityComplianceRestrictionCoveredPersonRestrictionAttributeArray AS EntityRestrictionCoveredPersonRestrictionAttributeArray,
  EntityComplianceID, 
  RestrictionTypeID,
  RestrictionStateID,
  EntityComplianceRestriction,
  IsRestricted,
  IsApplicable,
  1 AS IsHistory,
  SourceCreatedDate,
  SourceUpdatedDate,
  SourceCreatedBy,
  SourceUpdatedBy,
  SourceSystemID,
  GDSBatchID  
FROM gds_grdm_int.EntityComplianceRestrictionHistory 
WHERE  GDSBatchID = wid_GDSBatchID
 )
SELECT 
  src.EntityRestrictionID,  
  src.EntityRestrictionTime,
  src.EntityRestrictionNumber,
  de.EntityKey,
  cr1.ComplianceRegionKey,
  cr2.ComplianceRegionKey as ParentComplianceRegionKey,
  rt.RestrictionTypeKey,
  rs.RestrictionStateKey,
  src.EntityRestriction,
  src.EntityRestrictionReason,
  src.EntityRestrictionEntityType,
  src.EntityRestrictionEngagementPartnerAssignmentArray,
  src.EntityRestrictionCoveredPersonRestrictionAttributeArray,
  src.IsRestricted,
  src.IsApplicable,
  src.IsHistory,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
  FROM cte_FactEntityRestriction src
LEFT JOIN gds_grdm.DimRestrictionType rt ON rt.RestrictionTypeID = src.RestrictionTypeID
LEFT JOIN gds_grdm.DimRestrictionState rs ON rs.RestrictionStateID = src.RestrictionStateID
LEFT JOIN gds_grdm_int.EntityCompliance er ON er.entitycomplianceid = src.EntityComplianceID  
LEFT JOIN gds_grdm.DimEntity de on de.EntityID = er.EntityID
LEFT JOIN gds_grdm.DimComplianceRegion cr1 ON cr1.ComplianceRegionID = src.ComplianceRegionID
LEFT JOIN gds_grdm.DimComplianceRegion cr2 ON cr2.ComplianceRegionID = src.ParentComplianceRegionID