SELECT 
  src.SECRoleID,
  src.SECRoleNumber,
  src.SECRoleName,
  src.SECRoleBusinessName,
  src.SECRoleDescription,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.secrole src
WHERE
  src.GDSBatchID = wid_GDSBatchID
