SELECT 
  src.UserDeviceID,
  src.UserDeviceTime,
  src.UserDeviceNumber,
  du.UserKey,
  src.UserDeviceNotificationPlatform,
  src.UserDeviceApplicationVersion,
  src.UserDeviceStatus,
  src.UserDeviceRecordType,
  src.UserDeviceLastAccessTime,
  src.UserDeviceLastChangeTime,
  src.IsHistory,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID 
FROM (

SELECT
  UserID,
  UserDeviceID,
  CreatedDate AS UserDeviceTime,
  UserDeviceNumber,
  UserDeviceNotificationPlatform,
  UserDeviceApplicationVersion,
  UserDeviceStatus,
  UserDeviceRecordType,
  UserDeviceLastAccessTime,
  UserDeviceLastChangeTime,
  CAST(0 AS boolean ) AS IsHistory,
  SourceCreatedDate,
  SourceUpdatedDate,
  SourceCreatedBy,
  SourceUpdatedBy,
  SourceSystemID
FROM gds_grdm_int.userdevice 
WHERE 
  GDSBatchID = wid_GDSBatchID

UNION ALL

SELECT
  UserID,
  UserDeviceHistoryID AS UserDeviceID,
  UserDeviceHistoryTime AS UserDeviceTime,
  UserDeviceNumber,
  UserDeviceNotificationPlatform,
  UserDeviceApplicationVersion,
  UserDeviceStatus,
  UserDeviceRecordType,
  UserDeviceLastAccessTime,
  UserDeviceLastChangeTime,
  CAST(1 AS boolean ) AS IsHistory,
  SourceCreatedDate,
  SourceUpdatedDate,
  SourceCreatedBy,
  SourceUpdatedBy,
  SourceSystemID
FROM gds_grdm_int.userdevicehistory
WHERE 
  GDSBatchID = wid_GDSBatchID
)src
LEFT JOIN gds_grdm.dimuser du ON src.UserID=du.UserID and du.IsHistory='false'