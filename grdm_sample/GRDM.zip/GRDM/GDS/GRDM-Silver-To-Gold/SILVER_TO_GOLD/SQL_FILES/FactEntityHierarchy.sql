TRUNCATE TABLE gds_ref.FactEntityHierarchy;
SELECT
  src.EntityTreeID,
  e1.EntityKey as GlobalUltimateParentEntityKey,
  e2.EntityKey as ParentEntityKey,
  e3.EntityKey as EntityKey,
  dat.AffiliateTypeKey as AffiliateTypeKey,
  src.EntityTreeRelationCode as EntityTreeRelationCode,
  src.EntityTreeRelationAbbreviation as EntityTreeRelationAbbreviation,
  src.EntityTreeRelationDescription as EntityTreeRelationDescription,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_ref_int.EntityTree src
  LEFT JOIN gds_grdm.DimEntity e1 ON
    e1.EntityID = src.GlobalUltimateParentEntityID
  LEFT JOIN gds_grdm.DimEntity e2 ON
    e2.EntityID = src.ParentEntityID
  LEFT JOIN gds_grdm.DimEntity e3 ON
    e3.EntityID = src.EntityID
  LEFT JOIN gds_grdm.DimAffiliateType dat ON
    dat.AffiliateTypeID = src.AffiliateTypeID
WHERE src.GDSBatchID = wid_GDSBatchID