SELECT
  src.QuestionGroupID,
  dcr.ComplianceRegionKey,
  src.QuestionGroupNumber,
  src.QuestionGroupStatus,
  ds.SecurityKey,
  de.EntityKey,
  dht.HoldingTypeKey,
  drt.RestrictionTypeKey,
  dsr.SECRoleKey,
  src.QuestionGroupHoldingTypeArray,
  src.QuestionGroupRestrictionTypeArray,
  src.QuestionGroupSECRoleArray,
  dfis.FinancialInterestSubTypeKey,
  src.QuestionGroupHoldingTypeScope,
  src.QuestionGroupProductionTime,
  src.QuestionGroupArchiveTime,
  fqg.QuestionGroupKey AS NewQuestionGroupKey,
  src.SourceCreatedDate,
  src.SourceUpdatedDate,
  src.SourceCreatedBy,
  src.SourceUpdatedBy,
  src.SourceSystemID
FROM gds_grdm_int.QuestionGroup src
LEFT JOIN gds_grdm.DimComplianceRegion dcr ON src.ComplianceRegionID = dcr.ComplianceRegionID
LEFT JOIN gds_grdm.DimSecurity ds ON src.SecurityID = ds.SecurityID AND ds.IsHistory= false
LEFT JOIN gds_grdm.DimEntity de ON src.EntityComplianceID = de.EntityID 
LEFT JOIN gds_grdm.DimHoldingType dht ON src.HoldingTypeID = dht.HoldingTypeID 
LEFT JOIN gds_grdm.DimRestrictionType drt ON src.RestrictionTypeID = drt.RestrictionTypeID 
LEFT JOIN gds_grdm.DimSECRole dsr ON src.SECRoleID = dsr.SECRoleID 
LEFT JOIN gds_grdm.DimFinancialInterestSubType dfis ON src.FinancialInterestSubTypeID = dfis.FinancialInterestSubTypeID
LEFT JOIN gds_grdm.FactQuestionGroup fqg ON src.NewQuestionGroupID = fqg.QuestionGroupID  
WHERE
  src.GDSBatchID = wid_GDSBatchID