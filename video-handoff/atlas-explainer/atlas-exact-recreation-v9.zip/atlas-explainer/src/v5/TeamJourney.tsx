import { AbsoluteFill, Easing, Img, Interactive, interpolate, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { PersonPortrait, SvgIcon } from "../v2/Pictorials";

/** Separate agent sessions share authorized saved knowledge, never a local chat. */
export const TeamJourney = ({standalone=false}:{standalone?:boolean}) => {
  const frame=useCurrentFrame();const {fps}=useVideoConfig();const t=frame/fps;
  const ease={extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.bezier(.22,1,.36,1)} as const;
  const heading=t<10?"Many engineers. One shared Atlas.":t<20?"Access follows the signed-in user.":t<28?"Saved knowledge stays with the project.":"Shared reads. Protected writes.";

  return <AbsoluteFill style={{fontFamily:"Open Sans",color:"#0C233C",backgroundColor:standalone?"#F8FAFD":undefined}}>
    <Interactive.Div name="Shared Atlas story heading" style={{position:"absolute",left:144,top:153,right:144,fontSize:43,fontWeight:600,lineHeight:1.25,letterSpacing:-1,opacity:interpolate(t,[0,.6],[0,1],ease)}}>{heading}</Interactive.Div>

    <Interactive.Svg name="Two Copilot sessions connect to Northwind" width={1920} height={1080} style={{position:"absolute",inset:0,opacity:interpolate(t,[2,3],[0,1],ease)}} fill="none" strokeLinecap="round" strokeLinejoin="round">
      <path d="M505 409h64q25 0 25 25v71h89m-11-8 11 8-11 8" stroke="#A9BADD" strokeWidth={3}/>
      <path d="M505 681h64q25 0 25-25V505" stroke="#A9BADD" strokeWidth={3} pathLength={1} strokeDasharray={1} strokeDashoffset={interpolate(t,[4,5.5],[1,0],ease)}/>
      <circle cx={interpolate(t,[3,4.8],[513,594],ease)} cy={interpolate(t,[3,4,4.8],[409,409,505],ease)} r={7} fill="#1E49E2" stroke="none" opacity={interpolate(t,[2.9,3.2,4.7,5],[0,1,1,0],ease)}/>
    </Interactive.Svg>
    <Interactive.Svg name="Third Copilot session connects to Contoso" width={1920} height={1080} style={{position:"absolute",inset:0,opacity:interpolate(t,[6,7],[0,1],ease)}} fill="none" strokeLinecap="round" strokeLinejoin="round">
      <path d="M1415 543h-54q-25 0-25 25v81h-99m11-8-11 8 11 8" stroke="#90B8BC" strokeWidth={3} pathLength={1} strokeDasharray={1} strokeDashoffset={interpolate(t,[6.2,8],[1,0],ease)}/>
    </Interactive.Svg>

    <Interactive.Div name="Engineer A has an individual Copilot session" style={{position:"absolute",left:155,top:332,width:350,height:183,opacity:interpolate(t,[.7,1.5],[0,1],ease),translate:interpolate(t,[.7,1.5],["-25px 0px","0px 0px"],ease)}}>
      <PersonPortrait variant="first" size={94}/>
      <div style={{position:"absolute",left:113,top:5,fontSize:28,fontWeight:600}}>Engineer A</div>
      <div style={{position:"absolute",left:113,top:47,display:"flex",alignItems:"center",gap:11,fontSize:25}}><Img src={staticFile("icons/copilot.svg")} style={{width:32,height:32}}/>Copilot</div>
      <div style={{position:"absolute",left:5,top:113,fontSize:23,color:"#52677C"}}>Northwind · Architect</div>
      <div style={{position:"absolute",left:5,top:150,fontSize:22,fontWeight:600,color:t<28?"#00338D":"#996A15",opacity:interpolate(t,[20,21],[0,1],ease)}}>{t<28?"Saved project knowledge":"Editing · Tenant Lock held"}</div>
    </Interactive.Div>

    <Interactive.Div name="Engineer B has another Copilot session" style={{position:"absolute",left:155,top:604,width:350,height:194,opacity:interpolate(t,[3.8,4.6],[0,1],ease),translate:interpolate(t,[3.8,4.6],["-25px 0px","0px 0px"],ease)}}>
      <PersonPortrait variant="second" size={94}/>
      <div style={{position:"absolute",left:113,top:5,fontSize:28,fontWeight:600}}>Engineer B</div>
      <div style={{position:"absolute",left:113,top:47,display:"flex",alignItems:"center",gap:11,fontSize:25}}><Img src={staticFile("icons/copilot.svg")} style={{width:32,height:32}}/>Copilot</div>
      <div style={{position:"absolute",left:5,top:113,fontSize:23,color:"#52677C"}}>Northwind · Architect</div>
      <div style={{position:"absolute",left:5,top:150,fontSize:22,fontWeight:600,color:t<28?"#00338D":"#996A15",opacity:interpolate(t,[22,23],[0,1],ease)}}>{t<28?"Continue the Commerce Lakehouse":"Can read · waits to save"}</div>
    </Interactive.Div>

    <Interactive.Div name="Engineer C uses Copilot in a different authorized tenant" style={{position:"absolute",left:1415,top:466,width:350,height:183,opacity:interpolate(t,[5.8,6.6],[0,1],ease),translate:interpolate(t,[5.8,6.6],["25px 0px","0px 0px"],ease)}}>
      <PersonPortrait variant="first" size={94}/>
      <div style={{position:"absolute",left:113,top:5,fontSize:28,fontWeight:600}}>Engineer C</div>
      <div style={{position:"absolute",left:113,top:47,display:"flex",alignItems:"center",gap:11,fontSize:25}}><Img src={staticFile("icons/copilot.svg")} style={{width:32,height:32}}/>Copilot</div>
      <div style={{position:"absolute",left:5,top:113,fontSize:23,color:"#52677C"}}>Contoso · Viewer</div>
      <div style={{position:"absolute",left:5,top:150,fontSize:22,fontWeight:600,color:"#27757C",opacity:interpolate(t,[10.5,11.5],[0,1],ease)}}>Read access in Contoso</div>
    </Interactive.Div>

    <Interactive.Div name="Central Atlas with separate authorized tenant scopes" style={{position:"absolute",left:683,top:306,width:554,height:440,border:"1.5px solid #D7E1EF",borderRadius:24,background:"white",boxShadow:"0 20px 55px rgba(0,51,141,.06)",opacity:interpolate(t,[.2,1],[0,1],ease)}}>
      <div style={{height:91,display:"flex",alignItems:"center",padding:"0 28px",gap:12,borderBottom:"1px solid #E5EAF1"}}><Img src={staticFile("atlas.svg")} style={{width:44,height:44}}/><div style={{fontSize:34,fontWeight:600,color:"#00338D"}}>Atlas</div><div style={{marginLeft:"auto",display:"flex",alignItems:"center",gap:14,color:"#627994"}}><SvgIcon kind="cloud" size={48}/><span style={{fontSize:23}}>MCP</span><span style={{fontSize:24,color:"#A9BADD"}}>↔</span><SvgIcon kind="database" size={48}/></div></div>
      <div style={{position:"absolute",left:28,top:109,fontSize:21,color:"#627994"}}>Shared project knowledge · PostgreSQL</div>

      <Interactive.Div name="Northwind tenant contains Sales saved project" style={{position:"absolute",left:24,top:156,right:24,height:116,border:"1.5px solid #C5D6F1",borderRadius:14,background:"#F4F7FD"}}>
        <SvgIcon kind="folder" size={64} style={{position:"absolute",left:20,top:24}}/>
        <div style={{position:"absolute",left:101,top:17,fontSize:26,fontWeight:600,color:"#00338D"}}>Northwind</div>
        <div style={{position:"absolute",left:101,top:58,fontSize:23,color:"#52677C"}}>Commerce Lakehouse</div>
        <div style={{position:"absolute",right:20,top:29,opacity:interpolate(t,[10,11],[0,1],ease)}}><SvgIcon kind="shield" size={51}/></div>
      </Interactive.Div>
      <Interactive.Div name="Contoso tenant contains a separate saved project" style={{position:"absolute",left:24,top:294,right:24,height:116,border:"1.5px solid #BDD5D8",borderRadius:14,background:"#F3F9F9",opacity:interpolate(t,[6,7],[0,1],ease)}}>
        <SvgIcon kind="folder" size={64} color="#27757C" style={{position:"absolute",left:20,top:24}}/>
        <div style={{position:"absolute",left:101,top:17,fontSize:26,fontWeight:600,color:"#27757C"}}>Contoso</div>
        <div style={{position:"absolute",left:101,top:58,fontSize:23,color:"#52677C"}}>Procurement Modernization</div>
        <div style={{position:"absolute",right:20,top:29,opacity:interpolate(t,[11,12],[0,1],ease)}}><SvgIcon kind="shield" size={51} color="#27757C"/></div>
      </Interactive.Div>
    </Interactive.Div>

    <Interactive.Div name="Server enforces tenant access and role permissions" style={{position:"absolute",left:655,top:789,width:610,display:"flex",alignItems:"center",justifyContent:"center",gap:18,opacity:interpolate(t,[10,11,19.5,20],[0,1,1,0],ease)}}>
      <SvgIcon kind="shield" size={57}/><div><div style={{fontSize:28,fontWeight:600,color:"#00338D"}}>Tenant access · Role permissions</div><div style={{fontSize:23,color:"#627994",marginTop:6}}>Enforced for every signed-in user</div></div>
    </Interactive.Div>

    <Interactive.Div name="Saved project knowledge reaches the next teammate" style={{position:"absolute",left:608,top:482,opacity:interpolate(t,[20.5,21,23.3,23.8],[0,1,1,0],ease),translate:interpolate(t,[21,22,23.5],["0px 0px","-42px 0px","-84px 174px"],ease)}}><SvgIcon kind="document" size={47}/></Interactive.Div>
    <Interactive.Div name="Teammates continue without inheriting another local chat" style={{position:"absolute",left:620,top:795,width:680,textAlign:"center",opacity:interpolate(t,[20,21,27.5,28],[0,1,1,0],ease)}}>
      <div style={{display:"flex",gap:24,justifyContent:"center",alignItems:"center"}}><SvgIcon kind="table" size={48}/><SvgIcon kind="document" size={48}/><SvgIcon kind="code" size={48}/></div>
      <div style={{fontSize:25,color:"#00338D",marginTop:13}}>Continue from saved project knowledge</div>
    </Interactive.Div>

    <Interactive.Div name="Tenant Lock coordinates edits" style={{position:"absolute",left:573,top:463,width:45,height:72,borderRadius:11,background:"#FFF7E6",border:"1.5px solid #D8B26B",display:"flex",alignItems:"center",justifyContent:"center",opacity:interpolate(t,[28,29],[0,1],ease)}}>
      <svg width={29} height={36} viewBox="0 0 29 36" fill="none" stroke="#996A15" strokeWidth={2.3} strokeLinecap="round"><path d="M7 15V9a7.5 7.5 0 0 1 15 0v6"/><rect x="3" y="14" width="23" height="19" rx="4" fill="#FFFFFF"/><path d="M14.5 21v5"/></svg>
    </Interactive.Div>
    <Interactive.Div name="Revision checks reject stale changes" style={{position:"absolute",left:640,top:792,width:660,display:"flex",alignItems:"center",justifyContent:"center",gap:20,opacity:interpolate(t,[29.5,30.5],[0,1],ease)}}>
      <SvgIcon kind="shield" size={62}/><div><div style={{fontSize:28,fontWeight:600,color:"#00338D"}}>Tenant Lock + revision checks</div><div style={{fontSize:23,color:"#627994",marginTop:7}}>Stale changes need a fresh snapshot</div></div>
    </Interactive.Div>
  </AbsoluteFill>;
};
