import { AbsoluteFill, Img, Interactive, interpolate, staticFile, useVideoConfig } from "remotion";
import { DataTray, SvgIcon } from "../v2/Pictorials";

type EnvironmentMapProps={progress?:number;highlight?:"none"|"workspace"|"knowledge"|"gds";standalone?:boolean};

/** Two aligned rows separate project authoring from the physical data route. */
export const EnvironmentMap=({progress=1,highlight="none",standalone=false}:EnvironmentMapProps)=>{
  const {fps}=useVideoConfig();
  const clamp={extrapolateLeft:"clamp",extrapolateRight:"clamp"} as const;
  return <AbsoluteFill style={{fontFamily:"Open Sans",color:"#0C233C",backgroundColor:standalone?"#F8FAFD":undefined}}>
    <Interactive.Div name="Copilot workspace with Atlas Plugin and Bridge" premountFor={fps} style={{position:"absolute",left:144,top:285,width:470,height:270,border:highlight==="workspace"?"2.5px solid #1E49E2":"1.5px solid #DAE2EC",borderRadius:20,background:"#FFFFFF",opacity:interpolate(progress,[0,.12],[0,1],clamp)}}>
      <div style={{height:66,borderBottom:"1px solid #E5EAF1",display:"flex",alignItems:"center",gap:14,padding:"0 27px",background:"#FBFCFE",borderRadius:"20px 20px 0 0"}}><Img src={staticFile("icons/copilot.svg")} style={{width:35,height:35}}/><span style={{fontSize:29,fontWeight:600}}>Copilot</span><span style={{fontSize:20,color:"#66778B"}}>via VS Code</span></div>
      <div style={{position:"absolute",left:30,top:93,display:"flex",alignItems:"center",gap:20}}><Img src={staticFile("atlas.svg")} style={{width:48,height:48}}/><div><div style={{fontSize:27,fontWeight:600,color:"#00338D"}}>Atlas Plugin</div><div style={{fontSize:19,color:"#66778B",marginTop:5}}>Agent skills · local helpers</div></div></div>
      <div style={{position:"absolute",left:30,right:30,top:177,borderTop:"1px solid #E5EAF1",paddingTop:17,display:"flex",alignItems:"center",gap:21}}><SvgIcon kind="shield" size={45}/><div><div style={{fontSize:25,fontWeight:600,color:"#00338D"}}>Atlas Bridge</div><div style={{fontSize:18,color:"#66778B",marginTop:3}}>Sign in · stage approved files</div></div></div>
    </Interactive.Div>
    <Interactive.Div name="Atlas MCP and PostgreSQL shared knowledge" premountFor={fps} style={{position:"absolute",left:725,top:285,width:470,height:270,border:highlight==="knowledge"?"2.5px solid #1E49E2":"1.5px solid #DAE2EC",borderRadius:20,background:"#FFFFFF",opacity:interpolate(progress,[.14,.28],[0,1],clamp)}}>
      <div style={{position:"absolute",left:25,top:22,fontSize:27,fontWeight:600,color:"#00338D"}}>Shared project knowledge</div>
      <div style={{position:"absolute",left:24,top:87,width:175,textAlign:"center"}}><SvgIcon kind="cloud" size={89} style={{margin:"0 auto"}}/><div style={{fontSize:25,fontWeight:600,color:"#00338D",marginTop:9}}>Atlas MCP</div><div style={{fontSize:17,color:"#66778B",marginTop:6}}>Azure App Service</div></div>
      <div style={{position:"absolute",right:18,top:87,width:175,textAlign:"center"}}><SvgIcon kind="database" size={89} style={{margin:"0 auto"}}/><div style={{fontSize:25,fontWeight:600,color:"#00338D",marginTop:9}}>PostgreSQL</div><div style={{fontSize:17,color:"#66778B",marginTop:6}}>Metadata · context</div></div>
      <svg width={470} height={270} fill="none" stroke="#A9BADD" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" style={{position:"absolute",inset:0}}><path d="M200 125h65m-9-6 9 6-9 6M265 147h-65m9-6-9 6 9 6"/></svg>
    </Interactive.Div>
    <Interactive.Div name="Atlas Platform reviews the shared results" premountFor={fps} style={{position:"absolute",left:1306,top:285,width:470,height:270,border:"1.5px solid #DAE2EC",borderRadius:20,background:"#FFFFFF",textAlign:"center",opacity:interpolate(progress,[.34,.47],[0,1],clamp)}}>
      <div style={{fontSize:28,fontWeight:600,color:"#00338D",marginTop:24}}>Atlas Platform</div><SvgIcon kind="checklist" size={89} style={{margin:"25px auto 14px"}}/><div style={{fontSize:23,color:"#66778B"}}>Review · track results</div>
    </Interactive.Div>
    <Interactive.Svg name="Workspace reads and saves shared knowledge" premountFor={fps} width={1920} height={1080} style={{position:"absolute",inset:0,opacity:interpolate(progress,[.2,.3],[0,1],clamp)}} fill="none" stroke="#A9BADD" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><path d="M627 408h84m-11-8 11 8-11 8M711 435h-84m11-8-11 8 11 8"/></Interactive.Svg>
    <Interactive.Svg name="Platform shares the same project context" premountFor={fps} width={1920} height={1080} style={{position:"absolute",inset:0,opacity:interpolate(progress,[.4,.5],[0,1],clamp)}} fill="none" stroke="#A9BADD" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><path d="M1208 408h84m-11-8 11 8-11 8M1292 435h-84m11-8-11 8 11 8"/></Interactive.Svg>
    <Interactive.Svg name="Deliver approved project definitions separately" premountFor={fps} width={1920} height={1080} style={{position:"absolute",inset:0,opacity:interpolate(progress,[.58,.7],[0,1],clamp)}} fill="none" stroke="#8BA6D2" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><path d="M379 569v55q0 25 25 25h531q25 0 25 25v42" strokeDasharray="7 7"/><path d="M951 704l9 12 9-12"/></Interactive.Svg>
    <Interactive.Div name="Approved metadata DDL and SQL delivery" premountFor={fps} style={{position:"absolute",left:505,top:600,width:350,textAlign:"center",background:"#F8FAFD",opacity:interpolate(progress,[.58,.7],[0,1],clamp)}}><div style={{fontSize:23,fontWeight:600,color:"#00338D"}}>Delivery of definitions</div><div style={{fontSize:20,color:"#66778B",marginTop:9}}>Metadata · DDL · SQL</div></Interactive.Div>
    <Interactive.Div name="Source systems" premountFor={fps} style={{position:"absolute",left:144,top:730,width:470,height:225,border:"1.5px solid #DAE2EC",borderRadius:20,background:"#FFFFFF",opacity:interpolate(progress,[.73,.88],[0,1],clamp)}}>
      <div style={{position:"absolute",left:0,right:0,top:23,textAlign:"center",fontSize:27,fontWeight:600,color:"#00338D"}}>Source systems</div>
      <div style={{position:"absolute",left:24,top:86,width:120,textAlign:"center"}}><SvgIcon kind="database" size={60} style={{margin:"0 auto"}}/><div style={{fontSize:19,marginTop:14}}>Databases</div></div>
      <div style={{position:"absolute",left:174,top:86,width:120,textAlign:"center"}}><SvgIcon kind="document" size={60} style={{margin:"0 auto"}}/><div style={{fontSize:19,marginTop:14}}>Files</div></div>
      <div style={{position:"absolute",left:324,top:86,width:120,textAlign:"center"}}><SvgIcon kind="code" size={60} style={{margin:"0 auto"}}/><div style={{fontSize:19,marginTop:14}}>Applications</div></div>
    </Interactive.Div>
    <Interactive.Div name="GDS orchestrator" premountFor={fps} style={{position:"absolute",left:725,top:730,width:470,height:225,border:highlight==="gds"?"2.5px solid #1E49E2":"1.5px solid #DAE2EC",borderRadius:20,background:"#FFFFFF",textAlign:"center",opacity:interpolate(progress,[.53,.65],[0,1],clamp)}}><div style={{fontSize:28,fontWeight:600,color:"#00338D",marginTop:22}}>GDS orchestrator</div><SvgIcon kind="gear" size={81} style={{margin:"20px auto 13px"}}/><div style={{fontSize:21,color:"#66778B"}}>Load · transform</div></Interactive.Div>
    <Interactive.Div name="GDS lakehouse Bronze Silver Gold" premountFor={fps} style={{position:"absolute",left:1306,top:730,width:470,height:225,border:highlight==="gds"?"2.5px solid #1E49E2":"1.5px solid #DAE2EC",borderRadius:20,background:"#FFFFFF",opacity:interpolate(progress,[.73,.88],[0,1],clamp)}}>
      <div style={{position:"absolute",left:0,right:0,top:21,textAlign:"center",fontSize:27,fontWeight:600,color:"#00338D"}}>GDS lakehouse</div>
      <div style={{position:"absolute",left:23,top:71,width:118,textAlign:"center"}}><DataTray tone="bronze" label="" width={118}/><div style={{fontSize:21,fontWeight:600,marginTop:5}}>Bronze</div></div>
      <div style={{position:"absolute",left:176,top:71,width:118,textAlign:"center"}}><DataTray tone="silver" label="" width={118}/><div style={{fontSize:21,fontWeight:600,marginTop:5}}>Silver</div></div>
      <div style={{position:"absolute",left:329,top:71,width:118,textAlign:"center"}}><DataTray tone="gold" label="" width={118}/><div style={{fontSize:21,fontWeight:600,marginTop:5}}>Gold</div></div>
      <svg width={470} height={225} fill="none" stroke="#A9BADD" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" style={{position:"absolute",inset:0}}><path d="M145 115h26m-7-6 7 6-7 6M298 115h26m-7-6 7 6-7 6"/></svg>
    </Interactive.Div>
    <Interactive.Svg name="Sources flow through GDS orchestration into the lakehouse" premountFor={fps} width={1920} height={1080} style={{position:"absolute",inset:0,opacity:interpolate(progress,[.85,1],[0,1],clamp)}} fill="none" stroke="#8BA6D2" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><path d="M627 843h84m-11-8 11 8-11 8M1208 843h84m-11-8 11 8-11 8"/></Interactive.Svg>
  </AbsoluteFill>;
};
