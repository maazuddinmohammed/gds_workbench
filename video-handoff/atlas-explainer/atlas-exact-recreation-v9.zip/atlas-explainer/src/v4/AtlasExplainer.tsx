import { AbsoluteFill, Img, Interactive, interpolate, Sequence, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { IntroJourney } from "./IntroJourney";
import { ClosingJourney } from "./ClosingJourney";
import { OnboardingJourney, AgentMessage, ChatPanel, UserMessage, WorkflowRail } from "./Interface";
import { SnapshotJourney } from "./SnapshotJourney";
import { BuildJourney } from "./BuildJourney";
import { TeamJourney } from "./TeamJourney";
import { EnvironmentMap } from "./EnvironmentMap";
import { ReviewJourney } from "../v2/ReviewJourney";
import { RunJourney } from "../v2/RunJourney";
import { LegacyCopilotChat } from "./LegacyCopilotChat";
import { ReviewNarration, RunNarration } from "../v2/SceneNarration";
import { IntroNarration, OnboardingNarration, SnapshotNarration, BuildNarration, TeamNarration, ClosingNarration } from "./SceneNarration";

export const BuildScene=()=>{
  const f=useCurrentFrame(),{fps}=useVideoConfig(),t=f/fps;
  const response=t<3.8?"Profiling the source evidence.":t<6.8?"Enriching the source descriptions.":t<9.7?"Analyzing keys and relationships.":t<12?"Organizing subject areas.":t<20?"Designing the Silver operational model.":t<26?"Designing the Gold dimensional model.":t<35?"Mapping fields for both layers.":t<44?"Generating code from approved inputs.":"Preparing validation for both layers.";
  return <><div style={{position:"absolute",left:144,top:153,fontSize:48,fontWeight:600,letterSpacing:-1.2}}>From discovery to validated delivery.</div><ChatPanel><UserMessage>Build Sales models, mappings, SQL and validation.</UserMessage><AgentMessage>{response}</AgentMessage></ChatPanel><BuildJourney/></>;
};

const SnapshotScene=()=>{
  const f=useCurrentFrame(),{fps}=useVideoConfig();
  return <><SnapshotJourney/><Interactive.Div name="Locate shared knowledge before opening it" style={{position:"absolute",inset:0,background:"#F8FAFD",opacity:interpolate(f,[2.1*fps,3.1*fps],[1,0],{extrapolateLeft:"clamp",extrapolateRight:"clamp"})}}><div style={{position:"absolute",left:144,top:155,fontSize:44,fontWeight:600,letterSpacing:-1}}>Bring shared knowledge into your workspace.</div><EnvironmentMap highlight="knowledge"/></Interactive.Div></>;
};

const ReviewScene=()=>{
  const f=useCurrentFrame(),{fps}=useVideoConfig();
  return <><div style={{position:"absolute",left:144,top:153,fontSize:48,fontWeight:600,letterSpacing:-1.2}}>Review. Then approve.</div><LegacyCopilotChat timelineSeconds={76+f/fps}/><ReviewJourney/></>;
};
const RunScene=()=>{
  const f=useCurrentFrame(),{fps}=useVideoConfig();
  return <><LegacyCopilotChat timelineSeconds={108+f/fps}/><RunJourney/></>;
};

/** Explicit scene nodes preserve independent Studio editing and reproducible timing. */
export const AtlasExplainerV4=({showCaptions=false}:{showCaptions?:boolean})=><AbsoluteFill style={{fontFamily:"Open Sans",color:"#0C233C",backgroundColor:"#F8FAFD"}}>
  <Sequence name="00 Welcome to Atlas" durationInFrames={1260}><IntroJourney/><IntroNarration showCaptions={showCaptions}/></Sequence>
  <Sequence name="01 Start Atlas and select authorized scope" from={1260} durationInFrames={840}><OnboardingJourney/><WorkflowRail active={0}/><OnboardingNarration showCaptions={showCaptions}/></Sequence>
  <Sequence name="02 Reuse local context and Atlas Bridge" from={2100} durationInFrames={840}><SnapshotScene/><Sequence name="Context progress" from={93}><WorkflowRail active={1}/></Sequence><SnapshotNarration showCaptions={showCaptions}/></Sequence>
  <Sequence name="03 Complete Atlas capability journey" from={2940} durationInFrames={1620}><BuildScene/><WorkflowRail active={2}/><BuildNarration showCaptions={showCaptions}/></Sequence>
  <Sequence name="04 Review Stage and Apply" from={4560} durationInFrames={960}><ReviewScene/><WorkflowRail active={3}/><ReviewNarration showCaptions={showCaptions}/></Sequence>
  <Sequence name="05 Deliver and run GDS" from={5520} durationInFrames={780}><RunScene/><WorkflowRail active={4}/><RunNarration showCaptions={showCaptions}/></Sequence>
  <Sequence name="06 Shared Atlas and protected access" from={6300} durationInFrames={1080}><TeamJourney/><WorkflowRail active={5}/><TeamNarration showCaptions={showCaptions}/></Sequence>
  <Sequence name="07 Return to the environment" from={7380} durationInFrames={600}><ClosingJourney/><ClosingNarration showCaptions={showCaptions}/></Sequence>
  <Interactive.Div name="Atlas identity" style={{position:"absolute",zIndex:5,left:112,top:62,display:"flex",alignItems:"center",gap:12,color:"#00338D",fontSize:31,fontWeight:600}}><Img src={staticFile("atlas.svg")} style={{width:42,height:42}}/>Atlas</Interactive.Div>
  {!showCaptions&&<div style={{position:"absolute",left:112,top:1030,fontSize:17,color:"#8C98A9"}}>Illustrative workflow</div>}
</AbsoluteFill>;
