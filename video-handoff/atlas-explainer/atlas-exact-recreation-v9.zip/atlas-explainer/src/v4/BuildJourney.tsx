import { Easing, Interactive, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { SvgIcon } from "../v2/Pictorials";

/** A complete delivery path, opened one stage at a time beside Copilot. */
export const BuildJourney = ({standalone=false}: {standalone?:boolean}) => {
  const frame=useCurrentFrame();
  const {fps}=useVideoConfig();
  const t=frame/fps;
  const ease={extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.bezier(.22,1,.36,1)} as const;
  const focus=t<12?0:t<26?1:t<35?2:t<44?3:4;

  return <Interactive.Div name="Complete Atlas build workflow" style={{position:"absolute",inset:0,fontFamily:"Open Sans",color:"#00338D",backgroundColor:standalone?"#F8FAFD":undefined}}>
    <Interactive.Div name="Five delivery stages" style={{position:"absolute",left:865,top:275,width:915,height:115}}>
      <svg width={915} height={115} style={{position:"absolute",inset:0}} aria-hidden="true" fill="none" stroke="#CAD7EC" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round"><path d="M119 28h96m-10-7 10 7-10 7M302 28h96m-10-7 10 7-10 7M485 28h96m-10-7 10 7-10 7M668 28h96m-10-7 10 7-10 7"/></svg>
      <Interactive.Div name="Discover stage" style={{position:"absolute",left:0,width:145,textAlign:"center",opacity:focus===0?1:.45}}><SvgIcon kind="magnify" size={56} style={{margin:"0 auto"}}/><div style={{fontSize:23,fontWeight:focus===0?600:400,marginTop:8}}>Discover</div></Interactive.Div>
      <Interactive.Div name="Model stage" style={{position:"absolute",left:183,width:145,textAlign:"center",opacity:focus===1?1:.45}}><SvgIcon kind="table" size={56} style={{margin:"0 auto"}}/><div style={{fontSize:23,fontWeight:focus===1?600:400,marginTop:8}}>Model</div></Interactive.Div>
      <Interactive.Div name="Map stage" style={{position:"absolute",left:366,width:145,textAlign:"center",opacity:focus===2?1:.45}}><SvgIcon kind="document" size={56} style={{margin:"0 auto"}}/><div style={{fontSize:23,fontWeight:focus===2?600:400,marginTop:8}}>Map</div></Interactive.Div>
      <Interactive.Div name="Generate stage" style={{position:"absolute",left:549,width:145,textAlign:"center",opacity:focus===3?1:.45}}><SvgIcon kind="code" size={56} style={{margin:"0 auto"}}/><div style={{fontSize:23,fontWeight:focus===3?600:400,marginTop:8}}>Generate</div></Interactive.Div>
      <Interactive.Div name="Validate stage" style={{position:"absolute",left:732,width:145,textAlign:"center",opacity:focus===4?1:.45}}><SvgIcon kind="checklist" size={56} style={{margin:"0 auto"}}/><div style={{fontSize:23,fontWeight:focus===4?600:400,marginTop:8}}>Validate</div></Interactive.Div>
    </Interactive.Div>

    <Interactive.Div name="Profiling enrichment analysis and subject areas" style={{position:"absolute",inset:0,opacity:interpolate(t,[0,.6,11.6,12],[0,1,1,0],ease)}}>
      <Interactive.Div name="Profiling named stage" style={{position:"absolute",left:875,top:416,width:210,textAlign:"center",fontSize:25,fontWeight:600,opacity:t<3.8?1:.45}}>Profiling<div style={{height:3,margin:"13px 35px",background:t<3.8?"#1E49E2":"transparent"}}/></Interactive.Div>
      <Interactive.Div name="Enrichment named stage" style={{position:"absolute",left:1090,top:416,width:210,textAlign:"center",fontSize:25,fontWeight:600,opacity:t>=3.8&&t<6.8?1:.45}}>Enrichment<div style={{height:3,margin:"13px 35px",background:t>=3.8&&t<6.8?"#1E49E2":"transparent"}}/></Interactive.Div>
      <Interactive.Div name="Analysis named stage" style={{position:"absolute",left:1305,top:416,width:210,textAlign:"center",fontSize:25,fontWeight:600,opacity:t>=6.8&&t<9.7?1:.45}}>Analysis<div style={{height:3,margin:"13px 35px",background:t>=6.8&&t<9.7?"#1E49E2":"transparent"}}/></Interactive.Div>
      <Interactive.Div name="Subject areas named stage" style={{position:"absolute",left:1520,top:416,width:240,textAlign:"center",fontSize:25,fontWeight:600,opacity:t>=9.7?1:.45}}>Subject areas<div style={{height:3,margin:"13px 35px",background:t>=9.7?"#1E49E2":"transparent"}}/></Interactive.Div>
      <div style={{position:"absolute",left:1000,top:500,width:170,textAlign:"center"}}><SvgIcon kind="table" size={158} style={{margin:"0 auto"}}/><div style={{fontSize:28,fontWeight:600,marginTop:13}}>Customers</div></div>
      <div style={{position:"absolute",left:1485,top:500,width:170,textAlign:"center"}}><SvgIcon kind="table" size={158} style={{margin:"0 auto"}}/><div style={{fontSize:28,fontWeight:600,marginTop:13}}>Orders</div></div>
      <Interactive.Div name="Profiling inspects source fields" style={{position:"absolute",left:1080,top:485,translate:interpolate(t,[.8,2.9],["0px 0px","430px 0px"],ease),opacity:interpolate(t,[.5,1,3.2,3.8],[0,1,1,0],ease)}}><SvgIcon kind="magnify" size={115} style={{filter:"drop-shadow(0 8px 14px rgba(0,51,141,.1))"}}/></Interactive.Div>
      <Interactive.Div name="Enrichment adds business meaning" style={{position:"absolute",left:1195,top:528,width:270,textAlign:"center",opacity:interpolate(t,[3.8,4.3,6.4,6.9],[0,1,1,0],ease)}}><SvgIcon kind="document" size={88} style={{margin:"0 auto"}}/><div style={{fontSize:24,marginTop:18,color:"#627994"}}>Business meaning</div></Interactive.Div>
      <Interactive.Svg name="Analysis discovers relationships" width={1920} height={1080} style={{position:"absolute",inset:0,opacity:interpolate(t,[6.8,7.4],[0,1],ease)}} aria-hidden="true"><path d="M1174 575h303m-290-12v24m274-24-16 12 16 12" fill="none" stroke="#1E49E2" strokeWidth={3.5} pathLength={1} strokeDasharray={1} strokeDashoffset={interpolate(t,[7,8.3],[1,0],ease)}/></Interactive.Svg>
      <Interactive.Div name="Subject areas groups related objects" style={{position:"absolute",left:943,top:485,width:775,height:275,border:"2px solid #AFC3E4",borderRadius:22,opacity:interpolate(t,[9.6,10.2],[0,1],ease)}}><div style={{position:"absolute",left:240,top:245,width:295,textAlign:"center",background:"#F8FAFD",fontSize:28,fontWeight:600}}>Sales subject area</div></Interactive.Div>
    </Interactive.Div>

    <Interactive.Div name="Source knowledge becomes Silver and Gold models" style={{position:"absolute",inset:0,opacity:interpolate(t,[12,12.6,25.5,26],[0,1,1,0],ease)}}>
      <div style={{position:"absolute",left:1110,top:408,width:650,textAlign:"center",fontSize:24,color:"#627994"}}>Sales subject area</div>
      <div style={{position:"absolute",left:917,top:518,width:120,textAlign:"center"}}><SvgIcon kind="table" size={120}/><div style={{fontSize:26,fontWeight:600,marginTop:100}}>Source</div></div>
      <svg width={1920} height={1080} style={{position:"absolute",inset:0}} aria-hidden="true" fill="none" stroke="#A9BADD" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><path d="M1045 573h63m-12-9 12 9-12 9" opacity={interpolate(t,[13,14],[0,1],ease)}/><path d="M1381 573h49m-12-9 12 9-12 9" opacity={interpolate(t,[19,20],[0,1],ease)}/></svg>
      <Interactive.Div name="Operational model for Silver" style={{position:"absolute",left:1118,top:465,width:255,height:335,opacity:interpolate(t,[13.4,14.2],[0,1],ease)}}>
        <div style={{position:"absolute",inset:"0 -6px 95px",border:"1.5px solid #C7D3E4",borderRadius:21,background:"#F3F6FA"}}/>
        <svg width={255} height={240} style={{position:"absolute",inset:0}} aria-hidden="true"><path d="M91 108h69m-59-10v20m49-20-13 10 13 10" fill="none" stroke="#1E49E2" strokeWidth={2.8}/></svg>
        <div style={{position:"absolute",left:0,top:61,width:100,textAlign:"center"}}><SvgIcon kind="table" size={94}/><div style={{fontSize:21,marginTop:14}}>Customers</div></div>
        <div style={{position:"absolute",left:155,top:61,width:100,textAlign:"center"}}><SvgIcon kind="table" size={94}/><div style={{fontSize:21,marginTop:14}}>Orders</div></div>
        <div style={{position:"absolute",left:-25,top:263,width:305,textAlign:"center",fontSize:30,fontWeight:600,color:"#627994"}}>Silver</div>
        <div style={{position:"absolute",left:-30,top:306,width:315,textAlign:"center",fontSize:24,color:"#627994"}}>Operational model</div>
      </Interactive.Div>
      <Interactive.Div name="Dimensional model for Gold" style={{position:"absolute",left:1440,top:465,width:310,height:335,opacity:interpolate(t,[19.4,20.2],[0,1],ease),translate:interpolate(t,[19.4,20.2],["18px 0px","0px 0px"],ease)}}>
        <div style={{position:"absolute",inset:"0 -3px 95px",border:"1.5px solid #DFCA93",borderRadius:21,background:"#FFFBEE"}}/>
        <svg width={310} height={240} style={{position:"absolute",inset:0}} aria-hidden="true"><path d="M61 86L145 155M249 86L165 155" fill="none" stroke="#1E49E2" strokeWidth={3} pathLength={1} strokeDasharray={1} strokeDashoffset={interpolate(t,[20.2,21.8],[1,0],ease)}/></svg>
        <div style={{position:"absolute",left:6,top:17,width:110,textAlign:"center"}}><SvgIcon kind="table" size={76} style={{margin:"0 auto"}}/><div style={{fontSize:20,marginTop:2,background:"#FFFBEE"}}>Customer</div></div>
        <div style={{position:"absolute",left:194,top:17,width:110,textAlign:"center"}}><svg width={76} height={76} viewBox="0 0 78 78" aria-hidden="true" fill="white" stroke="#00338D" strokeWidth={3.5}><rect x="8" y="15" width="62" height="55" rx="6"/><path d="M8 30h62M23 7v16M55 7v16M23 43h8m16 0h8M23 56h8" fill="none" strokeLinecap="round"/></svg><div style={{fontSize:20,marginTop:2,background:"#FFFBEE"}}>Date</div></div>
        <div style={{position:"absolute",left:112,top:115,width:86,textAlign:"center",background:"#FFF5D5",borderRadius:12}}><SvgIcon kind="table" size={86}/><div style={{fontSize:20,marginTop:1,width:130,marginLeft:-22,whiteSpace:"nowrap"}}>Sales fact</div></div>
        <div style={{position:"absolute",left:0,top:263,width:310,textAlign:"center",fontSize:30,fontWeight:600,color:"#A47E24"}}>Gold</div>
        <div style={{position:"absolute",left:-5,top:306,width:320,textAlign:"center",fontSize:24,color:"#A47E24"}}>Dimensional model</div>
      </Interactive.Div>
    </Interactive.Div>

    <Interactive.Div name="Operational and dimensional mappings" style={{position:"absolute",left:920,top:422,width:820,height:400,opacity:interpolate(t,[26,26.5,34.5,35],[0,1,1,0],ease)}}>
      <div style={{textAlign:"center",fontSize:23,color:"#627994"}}>Using approved target models</div>
      <Interactive.Div name="Operational mapping source to Silver" style={{position:"absolute",left:0,top:60,width:820,height:135,border:"1.5px solid #CAD7E8",borderRadius:18,background:"#F3F6FA"}}><div style={{position:"absolute",left:25,top:19,fontSize:26,fontWeight:600}}>Operational mapping</div><div style={{position:"absolute",left:25,top:70,fontSize:24,color:"#627994"}}>Source</div><div style={{position:"absolute",left:225,top:70,fontSize:24}}>customer_id</div><SvgIcon kind="arrow" size={48} style={{position:"absolute",left:430,top:63}}/><div style={{position:"absolute",left:525,top:70,fontSize:24}}>CustomerId</div><div style={{position:"absolute",right:25,top:19,fontSize:26,fontWeight:600,color:"#627994"}}>Silver</div></Interactive.Div>
      <Interactive.Div name="Dimensional mapping source to Gold" style={{position:"absolute",left:0,top:220,width:820,height:135,border:"1.5px solid #DFCA93",borderRadius:18,background:"#FFFBEE",opacity:interpolate(t,[29.6,30.2],[0,1],ease),translate:interpolate(t,[29.6,30.2],["0px 18px","0px 0px"],ease)}}><div style={{position:"absolute",left:25,top:19,fontSize:26,fontWeight:600}}>Dimensional mapping</div><div style={{position:"absolute",left:25,top:70,fontSize:24,color:"#627994"}}>Silver</div><div style={{position:"absolute",left:225,top:70,fontSize:24}}>Orders</div><SvgIcon kind="arrow" size={48} style={{position:"absolute",left:430,top:63}}/><div style={{position:"absolute",left:525,top:70,fontSize:24}}>Sales fact</div><div style={{position:"absolute",right:25,top:19,fontSize:26,fontWeight:600,color:"#A47E24"}}>Gold</div></Interactive.Div>
    </Interactive.Div>

    <Interactive.Div name="Generate operational and dimensional code" style={{position:"absolute",left:920,top:422,width:820,height:400,opacity:interpolate(t,[35,35.6,43.5,44],[0,1,1,0],ease)}}>
      <div style={{textAlign:"center",fontSize:23,color:"#627994"}}>Using approved mappings</div>
      <Interactive.Div name="Operational code for Silver" style={{position:"absolute",left:0,top:65,width:380,height:255,border:"1.5px solid #CAD7E8",borderRadius:21,background:"#F3F6FA"}}><div style={{position:"absolute",left:0,top:22,width:380,textAlign:"center",fontSize:29,fontWeight:600,color:"#627994"}}>Silver</div><SvgIcon kind="code" size={113} style={{position:"absolute",left:133,top:65}}/><div style={{position:"absolute",left:0,top:199,width:380,textAlign:"center",fontSize:27,fontWeight:600}}>Operational code</div></Interactive.Div>
      <Interactive.Div name="Dimensional code for Gold" style={{position:"absolute",left:440,top:65,width:380,height:255,border:"1.5px solid #DFCA93",borderRadius:21,background:"#FFFBEE",opacity:interpolate(t,[39.5,40.2],[0,1],ease),translate:interpolate(t,[39.5,40.2],["18px 0px","0px 0px"],ease)}}><div style={{position:"absolute",left:0,top:22,width:380,textAlign:"center",fontSize:29,fontWeight:600,color:"#A47E24"}}>Gold</div><SvgIcon kind="code" size={113} style={{position:"absolute",left:133,top:65}}/><div style={{position:"absolute",left:0,top:199,width:380,textAlign:"center",fontSize:27,fontWeight:600}}>Dimensional code</div></Interactive.Div>
      <div style={{position:"absolute",left:0,top:350,width:820,textAlign:"center",fontSize:27,color:"#627994"}}>DDL + transformation SQL</div>
    </Interactive.Div>

    <Interactive.Div name="Generate operational and dimensional validations" style={{position:"absolute",left:920,top:427,width:820,height:390,opacity:interpolate(t,[44,44.6],[0,1],ease)}}>
      <Interactive.Div name="Operational validation scripts" style={{position:"absolute",left:0,top:40,width:380,height:270,border:"1.5px solid #CAD7E8",borderRadius:21,background:"#F3F6FA"}}><div style={{position:"absolute",left:0,top:21,width:380,textAlign:"center",fontSize:29,fontWeight:600,color:"#627994"}}>Silver</div><SvgIcon kind="checklist" size={112} style={{position:"absolute",left:134,top:63}}/><div style={{position:"absolute",left:0,top:195,width:380,textAlign:"center",fontSize:26,fontWeight:600}}>Operational validation</div></Interactive.Div>
      <Interactive.Div name="Dimensional validation scripts" style={{position:"absolute",left:440,top:40,width:380,height:270,border:"1.5px solid #DFCA93",borderRadius:21,background:"#FFFBEE",opacity:interpolate(t,[47.5,48.2],[0,1],ease),translate:interpolate(t,[47.5,48.2],["18px 0px","0px 0px"],ease)}}><div style={{position:"absolute",left:0,top:21,width:380,textAlign:"center",fontSize:29,fontWeight:600,color:"#A47E24"}}>Gold</div><SvgIcon kind="checklist" size={112} style={{position:"absolute",left:134,top:63}}/><div style={{position:"absolute",left:0,top:195,width:380,textAlign:"center",fontSize:26,fontWeight:600}}>Dimensional validation</div></Interactive.Div>
      <div style={{position:"absolute",left:0,top:340,width:820,textAlign:"center",fontSize:27,color:"#627994"}}>Validation scripts for both layers</div>
    </Interactive.Div>

    <Interactive.Div name="Metadata management supports every section" style={{position:"absolute",left:920,top:857,width:820,height:62,display:"flex",alignItems:"center",justifyContent:"center",gap:14,borderTop:"1.5px solid #D6E0EE",backgroundColor:t>=51?"#EDF2FF":"transparent",borderRadius:12,opacity:interpolate(t,[.3,1],[0,1],ease)}}><SvgIcon kind="database" size={32}/><div style={{fontSize:23,fontWeight:t>=51?600:400,color:t>=51?"#00338D":"#627994"}}>Metadata management throughout</div></Interactive.Div>
  </Interactive.Div>;
};
