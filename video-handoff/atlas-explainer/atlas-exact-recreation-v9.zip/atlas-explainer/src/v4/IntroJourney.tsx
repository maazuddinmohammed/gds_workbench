import { AbsoluteFill, Easing, Img, Interactive, interpolate, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { SvgIcon } from "../v2/Pictorials";
import { EnvironmentMap } from "./EnvironmentMap";

/** Welcome, agent surface, then the complete Atlas / GDS environment. */
export const IntroJourney = ({standalone=false}:{standalone?:boolean}) => {
  const frame=useCurrentFrame();const {fps}=useVideoConfig();const t=frame/fps;
  const ease={extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.bezier(.22,1,.36,1)} as const;
  return <AbsoluteFill style={{fontFamily:"Open Sans",color:"#0C233C",backgroundColor:standalone?"#F8FAFD":undefined}}>
    <Interactive.Div name="Welcome to Atlas" premountFor={fps} style={{position:"absolute",left:260,top:300,width:1400,textAlign:"center",opacity:interpolate(t,[0,.7,5.2,6],[0,1,1,0],ease),translate:interpolate(t,[0,.9],["0px 22px","0px 0px"],ease)}}>
      <Img src={staticFile("atlas.svg")} style={{width:110,height:110,margin:"0 auto 29px"}}/>
      <div style={{fontSize:76,fontWeight:600,letterSpacing:-2,color:"#00338D"}}>Welcome to Atlas.</div>
      <div style={{fontSize:37,marginTop:31,lineHeight:1.4}}>Build and maintain GDS projects.</div>
      <div style={{fontSize:29,color:"#66778B",marginTop:13}}>Keep the knowledge together.</div>
    </Interactive.Div>

    <Interactive.Div name="Atlas agent integration overview" premountFor={fps} style={{position:"absolute",inset:0,opacity:interpolate(t,[5.4,6.2,15.4,16.3],[0,1,1,0],ease)}}>
      <div style={{position:"absolute",left:144,top:155,fontSize:47,fontWeight:600,letterSpacing:-1}}>Your agent. Atlas expertise.</div>
      <div style={{position:"absolute",left:248,top:347,width:460,height:260,border:"1.5px solid #DAE2EC",borderRadius:24,background:"#FFFFFF",textAlign:"center"}}><Img src={staticFile("icons/copilot.svg")} style={{width:84,height:84,margin:"30px auto 15px"}}/><div style={{fontSize:35,fontWeight:600}}>Copilot</div><div style={{fontSize:22,color:"#66778B",marginTop:7}}>Supported today · via VS Code</div></div>
      <svg width={1920} height={1080} style={{position:"absolute",inset:0}} fill="none" stroke="#A9BADD" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><path d="M734 460h261m-13-9 13 9-13 9M995 492H734m13-9-13 9 13 9"/></svg>
      <div style={{position:"absolute",left:1040,top:333,width:490,height:275,textAlign:"center"}}><Img src={staticFile("atlas.svg")} style={{width:94,height:94,margin:"0 auto 18px"}}/><div style={{fontSize:35,fontWeight:600,color:"#00338D"}}>Atlas Plugin</div><div style={{fontSize:25,color:"#66778B",marginTop:9}}>Agent skills · local helpers</div><div style={{display:"flex",alignItems:"center",justifyContent:"center",gap:11,marginTop:25,fontSize:24,color:"#00338D"}}><SvgIcon kind="shield" size={37}/>Atlas Bridge</div></div>
      <Interactive.Div name="Future agent integrations are explicitly planned" premountFor={fps} style={{position:"absolute",left:365,top:720,width:1190,opacity:interpolate(t,[11.4,12.2],[0,1],ease)}}>
        <div style={{fontSize:22,color:"#66778B",textAlign:"center",marginBottom:21}}>Future integrations</div>
        <div style={{display:"flex",gap:100,alignItems:"center",justifyContent:"center",opacity:.72}}>
          <div style={{display:"flex",gap:17,alignItems:"center",fontSize:27}}><Img src={staticFile("icons/v4/codex-openai.png")} style={{width:53,height:53,objectFit:"contain"}}/>Codex</div>
          <div style={{display:"flex",gap:17,alignItems:"center",fontSize:27}}><Img src={staticFile("icons/v4/claude.svg")} style={{width:53,height:53}}/>Claude Code</div>
          <div style={{display:"flex",gap:17,alignItems:"center",fontSize:27}}><Img src={staticFile("icons/v4/cursor.svg")} style={{width:53,height:53}}/>Cursor</div>
        </div>
      </Interactive.Div>
    </Interactive.Div>

    <Interactive.Div name="Open the complete Atlas environment" premountFor={fps} style={{position:"absolute",inset:0,opacity:interpolate(t,[15.6,16.5,38.3,39.2],[0,1,1,0],ease)}}>
      <div style={{position:"absolute",left:144,top:155,fontSize:44,fontWeight:600,letterSpacing:-1}}>Atlas prepares the project. GDS runs the pipeline.</div>
      <EnvironmentMap progress={interpolate(t,[15.6,17,21.8,23.8,27.7,29.5,32.2,35.3],[.12,.29,.34,.5,.53,.73,.85,1],ease)} highlight={t<22?"knowledge":t<27?"none":"gds"}/>
    </Interactive.Div>

    <Interactive.Div name="Enter Atlas through Copilot" premountFor={fps} style={{position:"absolute",left:490,top:285,width:940,height:485,border:"1.5px solid #DAE2EC",borderRadius:24,background:"#FFFFFF",boxShadow:"0 20px 70px rgba(12,35,60,.08)",opacity:interpolate(t,[38.4,39.3],[0,1],ease),scale:interpolate(t,[38.4,39.8],[.94,1],ease)}}>
      <div style={{height:80,borderBottom:"1px solid #E5EAF1",display:"flex",alignItems:"center",gap:17,padding:"0 30px",background:"#FBFCFE",borderRadius:"24px 24px 0 0"}}><Img src={staticFile("icons/copilot.svg")} style={{width:41,height:41}}/><span style={{fontSize:30,fontWeight:600}}>Copilot</span><span style={{fontSize:21,color:"#66778B"}}>via VS Code</span></div>
      <div style={{position:"absolute",left:0,right:0,top:173,textAlign:"center"}}><Img src={staticFile("atlas.svg")} style={{width:62,height:62,margin:"0 auto 20px"}}/><div style={{fontSize:36,fontWeight:600,color:"#00338D"}}>Let’s open Atlas.</div></div>
      <div style={{position:"absolute",left:26,right:26,bottom:25,height:64,border:"1px solid #DCE3ED",borderRadius:15,display:"flex",alignItems:"center",padding:"0 20px",fontSize:25,color:"#8C98A9"}}>Ask Copilot…</div>
    </Interactive.Div>
  </AbsoluteFill>;
};
