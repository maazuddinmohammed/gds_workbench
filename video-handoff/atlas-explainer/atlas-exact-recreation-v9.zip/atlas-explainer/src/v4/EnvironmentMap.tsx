import { AbsoluteFill, Img, Interactive, interpolate, staticFile, useVideoConfig } from "remotion";
import { DataTray, SvgIcon } from "../v2/Pictorials";

type EnvironmentMapProps = { progress?: number; highlight?: "none"|"workspace"|"knowledge"|"gds"; standalone?: boolean };

/** Reusable map: the project definitions travel separately from physical data. */
export const EnvironmentMap = ({progress=1,highlight="none",standalone=false}:EnvironmentMapProps) => {
  const {fps}=useVideoConfig();
  const clamp={extrapolateLeft:"clamp",extrapolateRight:"clamp"} as const;
  return <AbsoluteFill style={{fontFamily:"Open Sans",color:"#0C233C",backgroundColor:standalone?"#F8FAFD":undefined}}>
    <Interactive.Div name="Atlas workspace with Plugin and Bridge" premountFor={fps} style={{position:"absolute",left:130,top:280,width:390,height:300,border:highlight==="workspace"?"2.5px solid #1E49E2":"1.5px solid #DAE2EC",borderRadius:20,background:"#FFFFFF",boxShadow:"0 16px 44px rgba(12,35,60,.05)",opacity:interpolate(progress,[0,.12],[0,1],clamp)}}>
      <div style={{height:70,borderBottom:"1px solid #E5EAF1",display:"flex",alignItems:"center",gap:12,padding:"0 24px",background:"#FBFCFE",borderRadius:"20px 20px 0 0"}}><Img src={staticFile("icons/copilot.svg")} style={{width:35,height:35}}/><span style={{fontSize:29,fontWeight:600}}>Copilot</span><span style={{fontSize:18,color:"#66778B"}}>via VS Code</span></div>
      <div style={{position:"absolute",left:28,top:100,display:"flex",alignItems:"center",gap:17}}><Img src={staticFile("atlas.svg")} style={{width:51,height:51}}/><div><div style={{fontSize:28,fontWeight:600,color:"#00338D"}}>Atlas Plugin</div><div style={{fontSize:20,color:"#66778B",marginTop:4}}>Agent skills · local helpers</div></div></div>
      <div style={{position:"absolute",left:25,right:25,top:205,borderTop:"1px solid #E5EAF1",paddingTop:18,display:"flex",alignItems:"center",gap:15}}><SvgIcon kind="shield" size={39}/><div><div style={{fontSize:25,fontWeight:600,color:"#00338D"}}>Atlas Bridge</div><div style={{fontSize:17,color:"#66778B",marginTop:3}}>Sign in · stage approved changes</div></div></div>
    </Interactive.Div>

    <Interactive.Div name="Atlas MCP and PostgreSQL shared knowledge" premountFor={fps} style={{position:"absolute",left:625,top:280,width:520,height:300,border:highlight==="knowledge"?"2.5px solid #1E49E2":"1.5px solid #DAE2EC",borderRadius:20,background:"#FFFFFF",opacity:interpolate(progress,[.14,.28],[0,1],clamp)}}>
      <div style={{position:"absolute",left:26,top:24,fontSize:28,fontWeight:600,color:"#00338D"}}>Shared project knowledge</div>
      <div style={{position:"absolute",left:30,top:100,width:180,textAlign:"center"}}><SvgIcon kind="cloud" size={100} style={{margin:"0 auto"}}/><div style={{fontSize:26,fontWeight:600,color:"#00338D",marginTop:8}}>Atlas MCP</div><div style={{fontSize:17,color:"#66778B",marginTop:5}}>Azure App Service</div></div>
      <div style={{position:"absolute",right:22,top:100,width:185,textAlign:"center"}}><SvgIcon kind="database" size={100} style={{margin:"0 auto"}}/><div style={{fontSize:26,fontWeight:600,color:"#00338D",marginTop:8}}>PostgreSQL</div><div style={{fontSize:17,color:"#66778B",marginTop:5}}>Metadata · project context</div></div>
      <svg width={520} height={300} fill="none" stroke="#8BA6D2" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" style={{position:"absolute",inset:0}}><path d="M217 145h90m-10-7 10 7-10 7M307 170h-90m10-7-10 7 10 7"/></svg>
    </Interactive.Div>

    <Interactive.Svg name="Agent requests and saves project knowledge" premountFor={fps} width={1920} height={1080} style={{position:"absolute",inset:0,opacity:interpolate(progress,[.2,.3],[0,1],clamp)}} fill="none" stroke="#A9BADD" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><path d="M534 417h77m-10-7 10 7-10 7M611 445h-77m10-7-10 7 10 7"/></Interactive.Svg>

    <Interactive.Div name="Atlas Platform reviews and tracks shared results" premountFor={fps} style={{position:"absolute",left:1280,top:280,width:510,height:128,border:"1.5px solid #DAE2EC",borderRadius:20,background:"#FFFFFF",opacity:interpolate(progress,[.34,.47],[0,1],clamp)}}>
      <div style={{position:"absolute",left:24,top:28}}><SvgIcon kind="checklist" size={67}/></div><div style={{position:"absolute",left:113,top:27,fontSize:28,fontWeight:600,color:"#00338D"}}>Atlas Platform</div><div style={{position:"absolute",left:113,top:70,fontSize:21,color:"#66778B"}}>Review · track results</div>
    </Interactive.Div>
    <Interactive.Svg name="Platform accesses the same project knowledge" premountFor={fps} width={1920} height={1080} style={{position:"absolute",inset:0,opacity:interpolate(progress,[.4,.5],[0,1],clamp)}} fill="none" stroke="#A9BADD" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><path d="M1159 344h107m-10-7 10 7-10 7m-97-7-10 7 10 7"/></Interactive.Svg>

    <Interactive.Div name="GDS orchestrator uses delivered definitions" premountFor={fps} style={{position:"absolute",left:1280,top:470,width:510,height:110,border:highlight==="gds"?"2.5px solid #1E49E2":"1.5px solid #DAE2EC",borderRadius:20,background:"#FFFFFF",opacity:interpolate(progress,[.53,.65],[0,1],clamp)}}><SvgIcon kind="gear" size={64} style={{position:"absolute",left:25,top:22}}/><div style={{position:"absolute",left:113,top:35,fontSize:29,fontWeight:600,color:"#00338D"}}>GDS orchestrator</div></Interactive.Div>

    <Interactive.Svg name="Deliver project artifacts to GDS" premountFor={fps} width={1920} height={1080} style={{position:"absolute",inset:0,opacity:interpolate(progress,[.58,.7],[0,1],clamp)}} fill="none" stroke="#A9BADD" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><path d="M325 595v30q0 28 28 28h854q28 0 28-28v-73q0-27 27-27h4m-10-7 10 7-10 7"/></Interactive.Svg>
    <Interactive.Div name="Metadata DDL and SQL delivery" premountFor={fps} style={{position:"absolute",left:580,top:620,width:490,background:"#F8FAFD",textAlign:"center",opacity:interpolate(progress,[.58,.7],[0,1],clamp)}}><div style={{fontSize:23,fontWeight:600,color:"#00338D"}}>Delivery</div><div style={{fontSize:19,color:"#66778B",marginTop:8}}>Metadata · DDL · transformation SQL</div></Interactive.Div>

    <Interactive.Div name="Source databases files and business systems" premountFor={fps} style={{position:"absolute",left:130,top:735,width:390,height:190,opacity:interpolate(progress,[.73,.88],[0,1],clamp)}}>
      <div style={{fontSize:26,fontWeight:600,color:"#00338D",marginBottom:22}}>Source systems</div>
      <div style={{position:"absolute",left:0,top:65,width:110,textAlign:"center"}}><SvgIcon kind="database" size={61} style={{margin:"0 auto"}}/><div style={{fontSize:18,marginTop:11}}>Databases</div></div>
      <div style={{position:"absolute",left:133,top:65,width:100,textAlign:"center"}}><SvgIcon kind="document" size={61} style={{margin:"0 auto"}}/><div style={{fontSize:18,marginTop:11}}>Files</div></div>
      <div style={{position:"absolute",left:260,top:65,width:125,textAlign:"center"}}><SvgIcon kind="code" size={61} style={{margin:"0 auto"}}/><div style={{fontSize:18,marginTop:11}}>Applications</div></div>
    </Interactive.Div>

    <Interactive.Div name="GDS lakehouse Bronze Silver Gold" premountFor={fps} style={{position:"absolute",left:650,top:725,width:1140,height:220,border:highlight==="gds"?"2.5px solid #1E49E2":"1.5px solid #DAE2EC",borderRadius:22,background:"#FFFFFF",opacity:interpolate(progress,[.73,.88],[0,1],clamp)}}>
      <div style={{position:"absolute",left:25,top:24,fontSize:27,fontWeight:600,color:"#00338D"}}>GDS lakehouse</div><div style={{position:"absolute",left:25,top:66,fontSize:19,color:"#66778B"}}>Data lake · Delta Lake</div>
      <div style={{position:"absolute",left:287,top:20,width:190,textAlign:"center"}}><DataTray tone="bronze" label="" width={190}/><div style={{fontSize:24,fontWeight:600,marginTop:3}}>Bronze</div></div>
      <div style={{position:"absolute",left:566,top:20,width:190,textAlign:"center"}}><DataTray tone="silver" label="" width={190}/><div style={{fontSize:24,fontWeight:600,marginTop:3}}>Silver</div></div>
      <div style={{position:"absolute",left:845,top:20,width:190,textAlign:"center"}}><DataTray tone="gold" label="" width={190}/><div style={{fontSize:24,fontWeight:600,marginTop:3}}>Gold</div></div>
      <svg width={1140} height={220} fill="none" stroke="#A9BADD" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" style={{position:"absolute",inset:0}}><path d="M490 106h61m-10-7 10 7-10 7M769 106h61m-10-7 10 7-10 7"/></svg>
    </Interactive.Div>
    <Interactive.Svg name="Sources load into Bronze and GDS drives the lakehouse" premountFor={fps} width={1920} height={1080} style={{position:"absolute",inset:0,opacity:interpolate(progress,[.85,1],[0,1],clamp)}} fill="none" stroke="#A9BADD" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><path d="M534 836h102m-10-7 10 7-10 7M1535 595v116m-8-11 8 11 8-11"/></Interactive.Svg>
  </AbsoluteFill>;
};
