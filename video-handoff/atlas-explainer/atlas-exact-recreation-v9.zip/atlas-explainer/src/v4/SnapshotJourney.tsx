import { AbsoluteFill, Img, Interactive, interpolate, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { SvgIcon } from "../v2/Pictorials";
import { AgentMessage, blue, ChatPanel, ease, muted, UserMessage } from "./Interface";

export const SnapshotJourney=({standalone=false}:{standalone?:boolean})=>{
  const f=useCurrentFrame(),{fps}=useVideoConfig(),t=f/fps;
  return <AbsoluteFill style={{fontFamily:"Open Sans",color:"#0C233C",background:standalone?"#F8FAFD":undefined}}>
    <div style={{position:"absolute",left:144,top:153,fontSize:48,fontWeight:600,letterSpacing:-1.2}}>Shared knowledge. Focused local work.</div>
    <ChatPanel><UserMessage>Build Sales models, mappings, SQL and validation.</UserMessage><AgentMessage>{t<6?"Reading the saved project context.":t<20?"Working from a local metadata snapshot.":"Using Atlas Bridge for approved file transfers."}</AgentMessage></ChatPanel>
    <Interactive.Div name="Retrieve authorized project snapshot" style={{position:"absolute",left:885,top:320,width:875,height:450}}>
      <div style={{position:"absolute",left:0,top:0,width:210,textAlign:"center"}}><SvgIcon kind="database" size={108} style={{margin:"0 auto"}}/><div style={{fontSize:27,fontWeight:600,color:blue,marginTop:15}}>PostgreSQL</div><div style={{fontSize:20,color:muted,marginTop:8}}>Saved knowledge</div></div>
      <div style={{position:"absolute",left:325,top:0,width:210,textAlign:"center"}}><SvgIcon kind="cloud" size={108} style={{margin:"0 auto"}}/><div style={{fontSize:27,fontWeight:600,color:blue,marginTop:15}}>Atlas MCP</div></div>
      <svg width={875} height={450} style={{position:"absolute",inset:0}} fill="none" stroke="#A9BEDD" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><path d="M195 60h120m-12-9 12 9-12 9"/><path d="M430 190v105h165m-12-9 12 9-12 9" opacity={interpolate(t,[5,6],[0,1],ease)}/></svg>
      <div style={{position:"absolute",left:590,top:220,width:255,textAlign:"center",opacity:interpolate(t,[5.4,6.4],[0,1],ease)}}><SvgIcon kind={t<20?"folder":"document"} size={126} style={{margin:"0 auto"}}/><div style={{fontSize:27,fontWeight:600,color:blue,marginTop:12}}>{t<20?"Local snapshot":"Approved local files"}</div></div>
      <Interactive.Svg name="Reuse local context instead of repeated calls" width={90} height={90} viewBox="0 0 90 90" style={{position:"absolute",left:785,top:230,opacity:interpolate(t,[10,11,19.5,20],[0,1,1,0],ease),rotate:interpolate(t,[11,20],["0deg","35deg"],ease)}} fill="none" stroke="#1E49E2" strokeWidth={4} strokeLinecap="round"><path d="M69 29a30 30 0 1 0 5 28M54 29h16V13"/></Interactive.Svg>
    </Interactive.Div>
    <Interactive.Div name="Snapshot reduces avoidable token work" style={{position:"absolute",left:895,top:760,width:850,textAlign:"center",opacity:interpolate(t,[10,11],[0,1],ease)}}><div style={{fontSize:29,color:blue,fontWeight:600}}>{t<20?"Fewer repeated calls. Less context to resend.":"Atlas Bridge · Direct approved file transfer"}</div><div style={{fontSize:24,color:muted,marginTop:15}}>{t<16?"Focused reads from local files":t<20?"Helps keep token use and costs down":"Small receipts keep large payloads out of chat"}</div></Interactive.Div>
    <Interactive.Div name="Atlas Bridge local transfer" style={{position:"absolute",left:1500,top:310,opacity:interpolate(t,[20,21],[0,1],ease),display:"flex",alignItems:"center",gap:10,fontSize:23,color:blue}}><Img src={staticFile("atlas.svg")} style={{width:34,height:34}}/>Atlas Bridge</Interactive.Div>
    <Interactive.Svg name="Approved files travel directly through Bridge" width={1920} height={1080} style={{position:"absolute",inset:0,opacity:interpolate(t,[20.5,21.5],[0,1],ease)}} fill="none" stroke="#1E49E2" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><path d="M1602 526V411q0-18-18-18h-55v-35m-8 11 8-11 8 11M1482 327h-79m11-8-11 8 11 8" pathLength={1} strokeDasharray={1} strokeDashoffset={interpolate(t,[21,23],[1,0],ease)}/></Interactive.Svg>
  </AbsoluteFill>;
};
