import type { ReactNode, CSSProperties } from "react";
import { Easing, Img, Interactive, interpolate, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { PersonPortrait } from "../v2/Pictorials";

export const blue="#00338D", ink="#0C233C", muted="#66778B";
export const ease={extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.bezier(.22,1,.36,1)} as const;

/** Same recognizable conversation shell as the accepted cut, with authored content. */
export const ChatPanel=({children,style,composer="Ask Copilot…",scope=true}:{children:ReactNode;style?:CSSProperties;composer?:string;scope?:boolean})=><Interactive.Div name="Copilot conversation" style={{position:"absolute",left:144,top:244,width:650,height:590,background:"#fff",border:"1.5px solid #DAE2EC",borderRadius:22,boxShadow:"0 24px 70px rgba(12,35,60,.08)",overflow:"hidden",...style}}>
  <div style={{height:80,padding:"0 27px",display:"flex",alignItems:"center",gap:15,borderBottom:"1px solid #E5EAF1",background:"#FBFCFE"}}><Img src={staticFile("icons/copilot.svg")} style={{width:39,height:39}}/><span style={{fontSize:29,fontWeight:600}}>Copilot</span><span style={{fontSize:20,color:muted}}>via VS Code</span><span style={{marginLeft:"auto",fontSize:28,color:muted}}>···</span></div>
  {scope&&<div style={{padding:"14px 30px 0",fontSize:18,color:muted}}>Northwind <span style={{padding:"0 9px"}}>›</span> Sales</div>}
  <div style={{padding:"22px 30px 0"}}>{children}</div>
  <div style={{position:"absolute",left:25,right:25,bottom:24,height:98,padding:"17px 20px",boxSizing:"border-box",border:"1.5px solid #DCE3ED",borderRadius:15,background:"#FDFEFF"}}><div style={{fontSize:23,color:composer==="Ask Copilot…"?"#8C97A7":ink}}>{composer}</div><div style={{fontSize:18,color:muted,marginTop:12}}>Agent ⌄</div><div style={{position:"absolute",right:15,bottom:14,width:34,height:34,background:"#EAF0F8",borderRadius:9,color:muted,fontSize:27,textAlign:"center"}}>↑</div></div>
</Interactive.Div>;

export const UserMessage=({children}:{children:ReactNode})=><div style={{display:"flex",justifyContent:"flex-end",gap:12,alignItems:"flex-start"}}><div style={{background:"#EDF2FF",padding:"16px 22px",borderRadius:"17px 4px 17px 17px",fontSize:27,lineHeight:1.45,maxWidth:470}}>{children}</div><PersonPortrait variant="first" size={46}/></div>;
export const AgentMessage=({children}:{children:ReactNode})=><div style={{marginTop:25,display:"flex",gap:16,alignItems:"flex-start"}}><Img src={staticFile("icons/copilot.svg")} style={{width:31,height:31,marginTop:5}}/><div style={{fontSize:27,lineHeight:1.45}}>{children}<div style={{display:"flex",gap:9,alignItems:"center",fontSize:19,color:muted,marginTop:14}}><Img src={staticFile("atlas.svg")} style={{width:22,height:22}}/>Atlas Plugin</div></div></div>;

export const WorkflowRail=({active}:{active:number})=><Interactive.Div name="Workflow location" style={{position:"absolute",left:270,top:937,width:1380,height:70,display:"flex",justifyContent:"space-between"}}>{["Start","Context","Build","Review","Run","Team"].map((name,i)=><div key={name} style={{fontSize:23,color:i===active?blue:"#9AA9BC",fontWeight:i===active?600:400,display:"flex",alignItems:"center",gap:12}}><span style={{width:31,height:31,borderRadius:16,display:"inline-flex",alignItems:"center",justifyContent:"center",fontSize:18,color:i===active?"#fff":"#8195B4",background:i===active?"#1E49E2":"#EDF2F9"}}>{i<active?"✓":i+1}</span>{name}</div>)}</Interactive.Div>;

export const OnboardingJourney=({standalone=false}:{standalone?:boolean})=>{
  const f=useCurrentFrame(),{fps}=useVideoConfig(),t=f/fps;
  const shrink=interpolate(t,[26,28],[0,1],ease);
  const phase=t<4?0:t<10?1:t<16?2:t<22?3:4;
  const typed="Start Atlas".slice(0,Math.floor(interpolate(t,[1,3.4],[0,11],ease)));
  const requirement="Build Sales models, mappings, SQL and validation.";
  return <div style={{position:"absolute",inset:0,background:standalone?"#F8FAFD":undefined,fontFamily:"Open Sans",color:ink}}>
    <div style={{position:"absolute",left:144,top:153,fontSize:48,fontWeight:600,letterSpacing:-1.2}}>Start with your access. Then your requirement.</div>
    <ChatPanel scope={phase>=3} style={{left:420-276*shrink,width:1080-430*shrink,top:260-16*shrink}} composer={phase===0?typed:phase===3?requirement.slice(0,Math.floor(interpolate(t,[16.5,20.4],[0,requirement.length],ease))):"Ask Copilot…"}>
      {phase===0?<div style={{fontSize:27,color:muted,paddingTop:65,textAlign:"center"}}>Bring Atlas into the conversation.</div>:phase===1?<><UserMessage>Start Atlas</UserMessage><AgentMessage>Choose a tenant you can access.</AgentMessage><div style={{display:"flex",gap:16,marginTop:18,marginLeft:47}}><div style={{padding:"12px 24px",borderRadius:12,fontSize:25,border:t>8?"2px solid #1E49E2":"1px solid #DCE4EF",background:t>8?"#EDF2FF":"white"}}>Northwind {t>8?"✓":""}</div><div style={{padding:"12px 24px",borderRadius:12,fontSize:25,border:"1px solid #DCE4EF"}}>Fabrikam</div></div></>:phase===2?<><UserMessage>Northwind</UserMessage><AgentMessage>Choose an existing project.</AgentMessage><div style={{display:"flex",gap:16,marginTop:18,marginLeft:47}}><div style={{padding:"12px 24px",borderRadius:12,fontSize:25,border:t>13?"2px solid #1E49E2":"1px solid #DCE4EF",background:t>13?"#EDF2FF":"white"}}>Sales {t>13?"✓":""}</div><div style={{padding:"12px 24px",borderRadius:12,fontSize:25,border:"1px solid #DCE4EF"}}>Inventory</div></div></>:phase===3?<><UserMessage>Start Atlas</UserMessage><AgentMessage>Sales is selected. What would you like to do?</AgentMessage></>:<><UserMessage>{requirement}</UserMessage><AgentMessage>Use customers and orders within the selected project.</AgentMessage></>}
    </ChatPanel>
    <div style={{position:"absolute",top:882,left:420,opacity:interpolate(t,[4,5,25,26],[0,1,1,0],ease),fontSize:22,color:muted}}>Tenant → Existing project → Your requirement</div>
  </div>;
};
