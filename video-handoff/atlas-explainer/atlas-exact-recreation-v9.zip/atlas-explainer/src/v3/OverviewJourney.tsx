import { AbsoluteFill, Easing, Img, Interactive, interpolate, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { DataTray, PersonPortrait, SvgIcon } from "../v2/Pictorials";

/** The three places in the story, before opening the Copilot workspace. */
export const OverviewJourney = ({standalone=false, closing=false}: {standalone?:boolean;closing?:boolean}) => {
  const frame=useCurrentFrame();
  const {fps}=useVideoConfig();
  const t=frame/fps;
  const ease={extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.bezier(.22,1,.36,1)} as const;
  const focus=closing?0:interpolate(t,[15.1,16.6],[0,1],ease);
  const mapOpacity=closing?interpolate(t,[0,1.2],[0,1],ease):1;
  const contextOpacity=interpolate(focus,[0,.35],[1,0],{extrapolateLeft:"clamp",extrapolateRight:"clamp"});

  return <AbsoluteFill style={{fontFamily:"Open Sans",color:"#0C233C",backgroundColor:standalone?"#F8FAFD":undefined}}>
    <Interactive.Div name="Atlas purpose" style={{position:"absolute",left:144,top:153,right:144,fontSize:43,fontWeight:600,lineHeight:1.25,letterSpacing:-1,opacity:closing?mapOpacity:interpolate(t,[0,.7,15.3,16.3],[0,1,1,0],ease)}}>
      {closing?"One project. Shared knowledge.":"Atlas helps teams build and maintain GDS projects."}
    </Interactive.Div>

    <Interactive.Div name="Atlas environment map" style={{position:"absolute",inset:0,transformOrigin:"0 0",transform:`translate(${202*focus}px, ${-416*focus}px) scale(${1+focus})`,opacity:mapOpacity}}>
      <Interactive.Div name="Copilot workspace opens" style={{position:"absolute",left:144,top:330,width:470,height:295,border:`${1.5/(1+focus)}px solid #DAE2EC`,borderRadius:18-7*focus,background:"#FFFFFF",boxShadow:"0 18px 48px rgba(12,35,60,.06)",overflow:"hidden",opacity:closing?1:interpolate(t,[.4,1.2],[0,1],ease)}}>
        <div style={{height:61-21*focus,boxSizing:"border-box",display:"flex",alignItems:"center",gap:13-5.5*focus,padding:`0 ${23-9.5*focus}px`,borderBottom:`${1/(1+focus)}px solid #E5EAF1`,background:"#FBFCFE"}}>
          <Img src={staticFile("icons/copilot.svg")} style={{width:34-14.5*focus,height:34-14.5*focus}}/>
          <div style={{fontSize:28-13.5*focus,fontWeight:600}}>Copilot</div>
          <div style={{fontSize:17-7*focus,color:"#66778B",marginLeft:3-focus}}>via VS Code</div>
        </div>
        <div style={{opacity:contextOpacity}}>
          <div style={{position:"absolute",right:23,top:91,background:"#EDF2FF",borderRadius:"13px 3px 13px 13px",padding:"17px 22px",fontSize:24}}>Build a Sales project.</div>
          <div style={{position:"absolute",left:23,top:193,display:"flex",alignItems:"center",gap:14,fontSize:26,color:"#00338D"}}>
            <Img src={staticFile("atlas.svg")} style={{width:34,height:34}}/>Atlas Plugin
          </div>
        </div>
        <div style={{position:"absolute",left:22-9.5*focus,right:22-9.5*focus,bottom:20-8*focus,height:48+focus,border:`${1-.25*focus}px solid #DCE3ED`,borderRadius:10-2.5*focus,opacity:focus,background:"#FDFEFF"}}/>
      </Interactive.Div>

      <Interactive.Div name="Data engineer drives Copilot" style={{position:"absolute",left:160,top:659,display:"flex",alignItems:"center",gap:18,opacity:(closing?1:interpolate(t,[.8,1.6],[0,1],ease))*contextOpacity}}>
        <PersonPortrait variant="first" size={74}/><div style={{fontSize:26,color:"#52677C"}}>Data engineer</div>
      </Interactive.Div>

      <Interactive.Div name="Shared Atlas project knowledge" style={{position:"absolute",left:725,top:330,width:470,height:295,border:"1.5px solid #DAE2EC",borderRadius:18,background:"#FFFFFF",boxShadow:"0 18px 48px rgba(12,35,60,.04)",opacity:(closing?1:interpolate(t,[4.2,5.2],[0,1],ease))*contextOpacity}}>
        <div style={{position:"absolute",left:24,top:20,fontSize:28,fontWeight:600,color:"#00338D"}}>Shared project knowledge</div>
        <div style={{position:"absolute",left:38,top:84,width:142,textAlign:"center"}}>
          <SvgIcon kind="cloud" size={104} style={{margin:"0 auto"}}/>
          <div style={{fontSize:25,fontWeight:600,marginTop:8,color:"#00338D"}}>Atlas MCP</div>
          <div style={{fontSize:17,color:"#66778B",marginTop:5,whiteSpace:"nowrap"}}>Azure App Service</div>
        </div>
        <div style={{position:"absolute",right:23,top:86,width:162,textAlign:"center"}}>
          <SvgIcon kind="database" size={104} style={{margin:"0 auto"}}/>
          <div style={{fontSize:25,fontWeight:600,marginTop:6,color:"#00338D"}}>PostgreSQL</div>
        </div>
        <svg width={470} height={295} viewBox="0 0 470 295" style={{position:"absolute",inset:0}} fill="none" stroke="#8BA6D2" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
          <path d="M188 131h76m-10-7 10 7-10 7M264 155h-76m10-7-10 7 10 7"/>
        </svg>
      </Interactive.Div>

      <Interactive.Div name="Copilot reads and saves governed context" style={{position:"absolute",inset:0,opacity:(closing?1:interpolate(t,[5.1,6.1],[0,1],ease))*contextOpacity}}>
        <svg width={1920} height={1080} fill="none" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <path d="M627 454h85m-11-8 11 8-11 8M712 484h-85m11-8-11 8 11 8" stroke="#A9BADD" strokeWidth={3}/>
          <path d="M627 454h85" stroke="#1E49E2" strokeWidth={6} pathLength={1} strokeDasharray=".12 1" strokeDashoffset={interpolate(t,[6.2,7.4],[0,-.88],ease)} opacity={closing?0:interpolate(t,[6.1,6.3,7.3,7.5],[0,1,1,0],ease)}/>
        </svg>
      </Interactive.Div>

      <Interactive.Div name="GDS executes the data pipeline" style={{position:"absolute",left:1306,top:330,width:470,height:295,border:"1.5px solid #DAE2EC",borderRadius:18,background:"#FFFFFF",boxShadow:"0 18px 48px rgba(12,35,60,.04)",opacity:(closing?1:interpolate(t,[9,10.2],[0,1],ease))*contextOpacity}}>
        <div style={{position:"absolute",left:24,top:20,display:"flex",alignItems:"center",gap:11,fontSize:28,fontWeight:600,color:"#00338D"}}><SvgIcon kind="gear" size={39}/>GDS orchestrator</div>
        <div style={{position:"absolute",left:29,top:115,width:118,textAlign:"center"}}><DataTray label="" tone="bronze" width={118}/><div style={{fontSize:23,fontWeight:600,marginTop:6}}>Bronze</div></div>
        <div style={{position:"absolute",left:176,top:115,width:118,textAlign:"center"}}><DataTray label="" tone="silver" width={118}/><div style={{fontSize:23,fontWeight:600,marginTop:6}}>Silver</div></div>
        <div style={{position:"absolute",left:323,top:115,width:118,textAlign:"center"}}><DataTray label="" tone="gold" width={118}/><div style={{fontSize:23,fontWeight:600,marginTop:6}}>Gold</div></div>
        <svg width={470} height={295} viewBox="0 0 470 295" style={{position:"absolute",inset:0}} fill="none" stroke="#B9C9DF" strokeWidth={2.3} strokeLinecap="round" strokeLinejoin="round"><path d="M149 163h24m-7-6 7 6-7 6M296 163h24m-7-6 7 6-7 6"/></svg>
        <div style={{position:"absolute",left:0,right:0,bottom:18,textAlign:"center",fontSize:19,color:"#66778B"}}>GDS lakehouse</div>
      </Interactive.Div>

      <Interactive.Div name="Delivery is a separate handoff" style={{position:"absolute",inset:0,opacity:(closing?1:interpolate(t,[10.2,11.4],[0,1],ease))*contextOpacity}}>
        <svg width={1920} height={1080} fill="none" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <path d="M520 642v89q0 44 44 44h885q44 0 44-44v-89m-8 11 8-11 8 11" stroke="#B9C9DF" strokeWidth={3} pathLength={1} strokeDasharray={1} strokeDashoffset={closing?0:interpolate(t,[10.5,12],[1,0],ease)}/>
          <path d="M938 793v-38h44v38" fill="#F8FAFD" stroke="#00338D" strokeWidth={3}/>
        </svg>
        <div style={{position:"absolute",left:775,top:698,width:370,textAlign:"center",fontSize:27,fontWeight:600,color:"#00338D"}}>Delivery</div>
        <div style={{position:"absolute",left:705,top:817,width:510,textAlign:"center",fontSize:23,color:"#66778B"}}>Metadata · DDL · SQL</div>
        <Interactive.Div name="Prepared artifact enters delivery" style={{position:"absolute",left:554,top:742,opacity:closing?0:interpolate(t,[12,12.3,14.6,15],[0,1,1,0],ease),translate:interpolate(t,[12.2,14.7],["0px 0px","885px 0px"],ease)}}><SvgIcon kind="document" size={58}/></Interactive.Div>
      </Interactive.Div>
    </Interactive.Div>
  </AbsoluteFill>;
};
