import { AbsoluteFill, Freeze, Img, Interactive, interpolate, Sequence, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { OverviewJourney } from "./OverviewJourney";
import { OverviewNarration } from "./SceneNarration";
import { WorkflowDetail } from "./WorkflowDetail";
import { CopilotChat } from "./Interface";

/** Eighteen seconds of orientation, then the familiar three-minute workflow. */
export const AtlasExplainerV3=({showCaptions=false}:{showCaptions?:boolean})=>{
  const f=useCurrentFrame();const {fps}=useVideoConfig();
  return <AbsoluteFill style={{fontFamily:"Open Sans",color:"#0C233C",backgroundColor:"#F8FAFD"}}>
    <Sequence name="00 The whole environment" durationInFrames={540}>
      <OverviewJourney/>
      <div style={{position:"absolute",left:112,top:62,display:"flex",alignItems:"center",gap:12,color:"#00338D",fontSize:31,fontWeight:600}}><Img src={staticFile("atlas.svg")} style={{width:42,height:42}}/>Atlas</div>
      <div style={{position:"absolute",left:112,top:1030,fontSize:17,color:"#8C98A9"}}>Illustrative workflow</div>
      <Interactive.Div name="Enter the Copilot workspace" style={{position:"absolute",inset:0,opacity:interpolate(f,[16.6*fps,18*fps],[0,1],{extrapolateLeft:"clamp",extrapolateRight:"clamp"})}}><Freeze frame={0}><CopilotChat/></Freeze></Interactive.Div>
      <OverviewNarration showCaptions={showCaptions}/>
    </Sequence>
    <Sequence name="Explore the workflow" from={540} durationInFrames={5400}><WorkflowDetail showCaptions={showCaptions}/></Sequence>
  </AbsoluteFill>;
};
