import { Easing, Interactive, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { SvgIcon } from "../v2/Pictorials";

/** The build path stays visible while each stage opens into its working detail. */
export const BuildJourney = ({standalone=false}: {standalone?:boolean}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;
  const ease = {extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.bezier(.22,1,.36,1)} as const;
  const focus = t < 7 ? 0 : t < 16 ? 1 : t < 23 ? 2 : 3;

  return <Interactive.Div name="Build from analysis to delivery files" style={{position:"absolute",inset:0,fontFamily:"Open Sans",color:"#00338D",backgroundColor:standalone?"#F8FAFD":undefined}}>
    <Interactive.Div name="Four connected build stages" style={{position:"absolute",left:884,top:420,width:880,height:150,translate:interpolate(t,[1.5,2.4],["0px 0px","0px -140px"],ease)}}>
      <svg width={880} height={150} style={{position:"absolute",inset:0}} aria-hidden="true">
        <path d="M158 42h75m-11-8 11 8-11 8M378 42h75m-11-8 11 8-11 8M598 42h75m-11-8 11 8-11 8" fill="none" stroke="#CAD7EC" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
      <Interactive.Div name="Profile and analyze stage" style={{position:"absolute",left:0,width:180,textAlign:"center",opacity:focus===0?1:.5}}>
        <div style={{width:78,height:78,margin:"0 auto",background:focus===0?"#E8EEFF":"#F4F6FA",borderRadius:18,display:"flex",justifyContent:"center",alignItems:"center",border:`1.5px solid ${focus===0?"#94ADF0":"#DDE5EF"}`,scale:interpolate(t,[1.5,2.4],[1,.7],ease)}}><SvgIcon kind="magnify" size={52}/></div>
        <div style={{fontSize:22,fontWeight:focus===0?600:400,marginTop:interpolate(t,[1.5,2.4],[10,-5],ease)}}>Profile & analyze</div>
      </Interactive.Div>
      <Interactive.Div name="Models stage" style={{position:"absolute",left:220,width:180,textAlign:"center",opacity:focus===1?1:.5}}>
        <div style={{width:78,height:78,margin:"0 auto",background:focus===1?"#E8EEFF":"#F4F6FA",borderRadius:18,display:"flex",justifyContent:"center",alignItems:"center",border:`1.5px solid ${focus===1?"#94ADF0":"#DDE5EF"}`,scale:interpolate(t,[1.5,2.4],[1,.7],ease)}}><SvgIcon kind="table" size={52}/></div>
        <div style={{fontSize:22,fontWeight:focus===1?600:400,marginTop:interpolate(t,[1.5,2.4],[10,-5],ease)}}>Models</div>
      </Interactive.Div>
      <Interactive.Div name="Mappings stage" style={{position:"absolute",left:440,width:180,textAlign:"center",opacity:focus===2?1:.5}}>
        <div style={{width:78,height:78,margin:"0 auto",background:focus===2?"#E8EEFF":"#F4F6FA",borderRadius:18,display:"flex",justifyContent:"center",alignItems:"center",border:`1.5px solid ${focus===2?"#94ADF0":"#DDE5EF"}`,scale:interpolate(t,[1.5,2.4],[1,.7],ease)}}><SvgIcon kind="document" size={52}/></div>
        <div style={{fontSize:22,fontWeight:focus===2?600:400,marginTop:interpolate(t,[1.5,2.4],[10,-5],ease)}}>Mappings</div>
      </Interactive.Div>
      <Interactive.Div name="Code and checks stage" style={{position:"absolute",left:660,width:180,textAlign:"center",opacity:focus===3?1:.5}}>
        <div style={{width:78,height:78,margin:"0 auto",background:focus===3?"#E8EEFF":"#F4F6FA",borderRadius:18,display:"flex",justifyContent:"center",alignItems:"center",border:`1.5px solid ${focus===3?"#94ADF0":"#DDE5EF"}`,scale:interpolate(t,[1.5,2.4],[1,.7],ease)}}><SvgIcon kind="code" size={52}/></div>
        <div style={{fontSize:22,fontWeight:focus===3?600:400,marginTop:interpolate(t,[1.5,2.4],[10,-5],ease)}}>Code & checks</div>
      </Interactive.Div>
    </Interactive.Div>

    <Interactive.Div name="Profile source information and analyze relationships" style={{position:"absolute",inset:0,opacity:interpolate(t,[2.1,2.8,6.5,7],[0,1,1,0],ease),transformOrigin:"1320px 580px",scale:interpolate(t,[2.1,2.8],[.91,1],ease)}}>
      <div style={{position:"absolute",left:1000,top:485,width:180,textAlign:"center"}}><SvgIcon kind="table" size={180}/><div style={{fontSize:29,fontWeight:600,marginTop:15}}>Customers</div></div>
      <div style={{position:"absolute",left:1470,top:485,width:180,textAlign:"center"}}><SvgIcon kind="table" size={180}/><div style={{fontSize:29,fontWeight:600,marginTop:15}}>Orders</div></div>
      <Interactive.Div name="Source profiling magnifier" style={{position:"absolute",left:1070,top:447,translate:interpolate(t,[2.8,3.5,4.6,5.3],["0px 0px","30px 0px","420px 0px","455px 15px"],ease),opacity:interpolate(t,[2.6,3,5.4,5.8],[0,1,1,0],ease)}}><SvgIcon kind="magnify" size={125} style={{filter:"drop-shadow(0 10px 12px rgba(0,51,141,.12))"}}/></Interactive.Div>
      <svg width={1920} height={1080} style={{position:"absolute",inset:0}} aria-hidden="true">
        <path d="M1194 575H1452" fill="none" stroke="#1E49E2" strokeWidth={4} pathLength={1} strokeDasharray={1} strokeDashoffset={interpolate(t,[5.2,6],[1,0],ease)}/>
        <path d="M1205 564v22m235-22-15 11 15 11" fill="none" stroke="#1E49E2" strokeWidth={3} opacity={interpolate(t,[5.6,6],[0,1],ease)}/>
      </svg>
      <div style={{position:"absolute",left:1110,top:750,width:430,textAlign:"center",fontSize:27,color:"#627994",opacity:interpolate(t,[5.5,6],[0,1],ease)}}>Sales subject area</div>
    </Interactive.Div>

    <Interactive.Div name="Source metadata to operational and dimensional models" style={{position:"absolute",inset:0,opacity:interpolate(t,[7,7.65,15.5,16],[0,1,1,0],ease),transformOrigin:"1320px 590px",scale:interpolate(t,[7,7.65],[.93,1],ease)}}>
      <svg width={1920} height={1080} style={{position:"absolute",inset:0}} aria-hidden="true" fill="none" strokeLinecap="round" strokeLinejoin="round">
        <path d="M1045 565h63m-12-9 12 9-12 9" stroke="#A9BADD" strokeWidth={3} opacity={interpolate(t,[8,9],[0,1],ease)}/>
        <path d="M1370 565h63m-12-9 12 9-12 9" stroke="#A9BADD" strokeWidth={3} opacity={interpolate(t,[11.1,12],[0,1],ease)}/>
      </svg>
      <div style={{position:"absolute",left:914,top:510,width:120,textAlign:"center"}}><SvgIcon kind="table" size={120}/><div style={{fontSize:25,fontWeight:600,marginTop:107}}>Source</div></div>
      <div style={{position:"absolute",left:1180,top:405,width:470,textAlign:"center",fontSize:24,color:"#627994"}}>Sales subject area</div>
      <Interactive.Div name="Silver operational model" style={{position:"absolute",left:1120,top:450,width:240,height:330,opacity:interpolate(t,[8.2,9.1],[0,1],ease)}}>
        <div style={{position:"absolute",inset:"18px -8px 80px",border:"1.5px solid #C7D3E4",borderRadius:21,background:"#F3F6FA"}}/>
        <svg width={240} height={260} style={{position:"absolute",inset:0}} aria-hidden="true"><path d="M86 110h68m-58-9v18m48-18-12 9 12 9" fill="none" stroke="#1E49E2" strokeWidth={2.8}/></svg>
        <div style={{position:"absolute",left:0,top:63,width:95,textAlign:"center"}}><SvgIcon kind="table" size={92}/><div style={{fontSize:20,marginTop:13}}>Customers</div></div>
        <div style={{position:"absolute",left:145,top:63,width:95,textAlign:"center"}}><SvgIcon kind="table" size={92}/><div style={{fontSize:20,marginTop:13}}>Orders</div></div>
        <div style={{position:"absolute",left:-30,top:279,width:300,textAlign:"center",fontSize:30,fontWeight:600,color:"#627994"}}>Silver</div>
        <div style={{position:"absolute",left:-30,top:322,width:300,textAlign:"center",fontSize:23,color:"#627994"}}>Operational model</div>
      </Interactive.Div>
      <Interactive.Div name="Gold dimensional model" style={{position:"absolute",left:1445,top:422,width:300,height:390,opacity:interpolate(t,[11.5,12.5],[0,1],ease),translate:interpolate(t,[11.5,12.5],["18px 0px","0px 0px"],ease)}}>
        <div style={{position:"absolute",inset:"46px -3px 94px",border:"1.5px solid #DFCA93",borderRadius:21,background:"#FFFBEE"}}/>
        <svg width={300} height={260} style={{position:"absolute",inset:0}} aria-hidden="true"><path d="M58 112L140 194M242 112L160 194" fill="none" stroke="#1E49E2" strokeWidth={3} pathLength={1} strokeDasharray={1} strokeDashoffset={interpolate(t,[12.2,13.6],[1,0],ease)}/></svg>
        <div style={{position:"absolute",left:8,top:59,width:100,textAlign:"center"}}><SvgIcon kind="table" size={78} style={{margin:"0 auto"}}/><div style={{fontSize:20,marginTop:4}}>Customers</div></div>
        <div style={{position:"absolute",left:192,top:59,width:100,textAlign:"center"}}>
          <svg width={78} height={78} viewBox="0 0 78 78" aria-hidden="true" fill="white" stroke="#00338D" strokeWidth={3.5}><rect x="8" y="15" width="62" height="55" rx="6"/><path d="M8 30h62M23 7v16M55 7v16M23 43h8m16 0h8M23 56h8" fill="none" strokeLinecap="round"/></svg><div style={{fontSize:20,marginTop:4}}>Date</div>
        </div>
        <div style={{position:"absolute",left:107,top:159,width:86,textAlign:"center",background:"#FFF5D5",borderRadius:12}}><SvgIcon kind="table" size={86}/><div style={{fontSize:21,marginTop:1}}>Sales</div></div>
        <div style={{position:"absolute",left:0,top:307,width:300,textAlign:"center",fontSize:30,fontWeight:600,color:"#A47E24"}}>Gold</div>
        <div style={{position:"absolute",left:0,top:350,width:300,textAlign:"center",fontSize:23,color:"#A47E24"}}>Dimensional model</div>
      </Interactive.Div>
    </Interactive.Div>

    <Interactive.Div name="Map source fields to the target model" style={{position:"absolute",left:940,top:440,width:790,height:350,opacity:interpolate(t,[16,16.7,22.5,23],[0,1,1,0],ease),scale:interpolate(t,[16,16.7],[.92,1],ease)}}>
      <div style={{position:"absolute",left:0,top:0,width:300,height:265,border:"1.5px solid #CEDAEB",borderRadius:19,background:"white",boxShadow:"0 16px 36px rgba(0,51,141,.05)"}}><div style={{padding:"18px 24px",fontSize:28,fontWeight:600,borderBottom:"1px solid #E4EAF3",background:"#F4F7FC",borderRadius:"19px 19px 0 0"}}>Source</div><div style={{padding:"26px 24px",fontSize:24}}>customer_id</div><div style={{padding:"8px 24px",fontSize:24}}>order_total</div></div>
      <div style={{position:"absolute",left:490,top:0,width:300,height:265,border:"1.5px solid #CEDAEB",borderRadius:19,background:"white",boxShadow:"0 16px 36px rgba(0,51,141,.05)"}}><div style={{padding:"18px 24px",fontSize:28,fontWeight:600,borderBottom:"1px solid #E4EAF3",background:"#F4F7FC",borderRadius:"19px 19px 0 0"}}>Target</div><div style={{padding:"26px 24px",fontSize:24}}>CustomerId</div><div style={{padding:"8px 24px",fontSize:24}}>SalesAmount</div></div>
      <svg width={790} height={350} style={{position:"absolute",inset:0}} aria-hidden="true" fill="none" stroke="#1E49E2" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round">
        <path d="M312 117h165m-13-9 13 9-13 9" pathLength={1} strokeDasharray={1} strokeDashoffset={interpolate(t,[17,18.2],[1,0],ease)}/>
        <path d="M312 185h165m-13-9 13 9-13 9" pathLength={1} strokeDasharray={1} strokeDashoffset={interpolate(t,[18.4,19.6],[1,0],ease)}/>
      </svg>
      <div style={{position:"absolute",left:190,top:309,width:410,textAlign:"center",fontSize:27,color:"#627994"}}>Source-to-target mappings</div>
    </Interactive.Div>

    <Interactive.Div name="Sales delivery packet" style={{position:"absolute",left:1220,top:490,width:210,textAlign:"center",opacity:interpolate(t,[23,23.7],[0,1],ease),scale:interpolate(t,[23,23.7],[.8,1],ease)}}>
      <svg width={210} height={200} style={{position:"absolute",inset:0,opacity:interpolate(t,[28.7,29.6],[0,1],ease)}} aria-hidden="true"><rect x="59" y="-10" width="82" height="115" rx="5" fill="#EDF2FF" stroke="#8BA6D2" strokeWidth={2} transform="rotate(-9 100 70)"/><rect x="74" y="-8" width="82" height="115" rx="5" fill="white" stroke="#8BA6D2" strokeWidth={2} transform="rotate(6 100 70)"/><path d="M94 14h45M94 29h45" stroke="#CAD8EF" strokeWidth={4}/></svg>
      <SvgIcon kind="folder" size={210} style={{position:"relative"}}/><div style={{fontSize:34,fontWeight:600,marginTop:-10}}>Sales</div>
    </Interactive.Div>
    <Interactive.Div name="Target DDL enters packet" style={{position:"absolute",left:970,top:475,width:150,textAlign:"center",opacity:interpolate(t,[23.2,23.8,25.7,26.3],[0,1,1,0],ease),translate:interpolate(t,[25.5,26.3],["0px 0px","277px 50px"],ease),scale:interpolate(t,[25.5,26.3],[1,.2],ease)}}><SvgIcon kind="code" size={150}/><div style={{fontSize:28,fontWeight:600,marginTop:14}}>DDL</div></Interactive.Div>
    <Interactive.Div name="Transformation SQL enters packet" style={{position:"absolute",left:1530,top:475,width:150,textAlign:"center",opacity:interpolate(t,[23.7,24.3,26,26.6],[0,1,1,0],ease),translate:interpolate(t,[25.8,26.6],["0px 0px","-277px 50px"],ease),scale:interpolate(t,[25.8,26.6],[1,.2],ease)}}><SvgIcon kind="code" size={150}/><div style={{fontSize:28,fontWeight:600,marginTop:14}}>SQL</div></Interactive.Div>
    <Interactive.Div name="Validation scripts enter packet" style={{position:"absolute",left:1010,top:475,width:170,textAlign:"center",opacity:interpolate(t,[26.8,27.4,29,29.7],[0,1,1,0],ease),translate:interpolate(t,[28.7,29.7],["0px 0px","240px 50px"],ease),scale:interpolate(t,[28.7,29.7],[1,.2],ease)}}><SvgIcon kind="checklist" size={150} style={{margin:"0 auto"}}/><div style={{fontSize:28,fontWeight:600,marginTop:14}}>Validation</div></Interactive.Div>
  </Interactive.Div>;
};
