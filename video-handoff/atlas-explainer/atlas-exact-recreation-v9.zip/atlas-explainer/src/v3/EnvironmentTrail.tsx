import { Img, Interactive, interpolate, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { SvgIcon } from "../v2/Pictorials";

/** Three familiar places from the overview keep the detailed journey oriented. */
export const EnvironmentTrail=()=>{
  const f=useCurrentFrame();const {fps}=useVideoConfig();const t=f/fps;
  const shared=(t>=20 && t<44)||(t>=90 && t<108)||t>=157;
  const active=t>=108 && t<134?2:shared?1:0;
  return <Interactive.Div name="Where we are in the environment" style={{position:"absolute",left:980,top:64,width:800,height:48,display:"flex",alignItems:"center",gap:20,opacity:interpolate(t,[161,162],[1,0],{extrapolateLeft:"clamp",extrapolateRight:"clamp"})}}>
    <div style={{display:"flex",alignItems:"center",gap:10,opacity:active===0?1:.36,color:"#00338D",fontSize:23,fontWeight:active===0?600:400}}><Img src={staticFile("icons/copilot.svg")} style={{width:29,height:29}}/>Workspace</div>
    <span style={{color:"#BCCBDD",fontSize:24}}>↔</span>
    <div style={{display:"flex",alignItems:"center",gap:10,opacity:active===1?1:.36,color:"#00338D",fontSize:23,fontWeight:active===1?600:400}}><SvgIcon kind="database" size={32}/>Shared knowledge</div>
    <span style={{width:30}}/>
    <div style={{display:"flex",alignItems:"center",gap:10,opacity:active===2?1:.36,color:"#00338D",fontSize:23,fontWeight:active===2?600:400}}><SvgIcon kind="gear" size={32}/>GDS</div>
  </Interactive.Div>;
};
