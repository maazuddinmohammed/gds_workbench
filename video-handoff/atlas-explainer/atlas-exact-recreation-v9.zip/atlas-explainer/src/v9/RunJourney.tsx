import { AbsoluteFill, Easing, Interactive, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { DataTray, SvgIcon } from "../v2/Pictorials";

export const RunJourney = ({standalone=false}: {standalone?:boolean}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <AbsoluteFill style={{fontFamily:"Open Sans",color:"#0C233C",backgroundColor:standalone?"#F8FAFD":undefined}}>
      <Interactive.Div name="Approved artifact handoff" premountFor={fps} style={{
        position: "absolute", left: 0, top: 0, width: 1920, height: 1080,
        opacity: interpolate(frame, [0, 0.7 * fps, 6.8 * fps, 7.6 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }} aria-hidden="true">
          <path d="M393 377H1250" fill="none" stroke="#D9E5FB" strokeWidth={3} strokeDasharray="8 10" />
          <path d="M1235 367l15 10-15 10" fill="none" stroke="#8BA6D2" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <div style={{ position: "absolute", left: 664, top: 272, width: 240, height: 193 }}>
          <div style={{ textAlign: "center", fontSize: 32, fontWeight: 600, color: "#00338D", marginBottom: 18 }}>Delivery</div>
          <svg width={240} height={150} viewBox="0 0 240 150" aria-hidden="true">
            <path d="M70 145V12h100v133" fill="none" stroke="#CCD8EA" strokeWidth={10} strokeLinecap="round" strokeLinejoin="round" />
            <path d="M70 145V12h100" fill="none" stroke="#00338D" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <Interactive.Div name="Metadata DDL and SQL bundle" premountFor={fps} style={{
          position: "absolute", left: 310, top: 330, width: 124, height: 104,
          translate: interpolate(frame, [1.8 * fps, 5.4 * fps], ["0px 0px", "1014px -26px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.4, 0, 0.2, 1) }),
          scale: interpolate(frame, [4 * fps, 5.3 * fps], [1, 0.55], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
          opacity: interpolate(frame, [4.4 * fps, 5.3 * fps], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        }}>
          <div style={{ position: "absolute", left: 0, top: 0, rotate: "-10deg" }}><SvgIcon kind="document" size={76} /></div>
          <div style={{ position: "absolute", left: 23, top: 8, rotate: "-3deg" }}><SvgIcon kind="table" size={76} /></div>
          <div style={{ position: "absolute", left: 46, top: 17, rotate: "6deg" }}><SvgIcon kind="code" size={76} /></div>
        </Interactive.Div>
        <div style={{ position: "absolute", left: 224, top: 500, width: 300, textAlign: "center", fontSize: 29, color: "#52677C", opacity: interpolate(frame, [1.5 * fps, 2.4 * fps], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>Approved work</div>
      </Interactive.Div>

      <Interactive.Div name="GDS Frameworks receives delivered artifacts" premountFor={fps} style={{
        position: "absolute", left: 1270, top: 300, width: 230, height: 165,
        translate: interpolate(frame, [6.5 * fps, 8.2 * fps], ["0px 0px", "-425px -25px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.16, 1, 0.3, 1) }),
        opacity: interpolate(frame, [0.4 * fps, 1.1 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <div style={{ width: 100, height: 100, margin: "0 auto", rotate: interpolate(frame, [5 * fps, 19.5 * fps], ["0deg", "180deg"], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}><SvgIcon kind="gear" size={100} /></div>
        <div style={{ marginTop: 16, width: 370, marginLeft: -70, textAlign: "center", fontSize: 34, fontWeight: 600, color: "#00338D" }}>GDS Frameworks</div>
      </Interactive.Div>

      <Interactive.Div name="Four GDS data layers" premountFor={fps} style={{ position: "absolute", inset: 0,
        opacity: interpolate(frame, [7 * fps, 8.3 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }} aria-hidden="true">
          <path d="M960 435v32H340m620 0h580M340 467v32m400-32v32m400-32v32m400-32v32" fill="none" stroke="#CCD8EA" strokeWidth={2.5} />
          <path d="M485 588h109m-12-9 12 9-12 9M885 588h109m-12-9 12 9-12 9M1285 588h109m-12-9 12 9-12 9" fill="none" stroke="#B9C9DF" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <Interactive.Div name="Source data tray" premountFor={fps} style={{ position: "absolute", left: 210, top: 505,
          opacity: interpolate(frame, [9.8 * fps, 12 * fps], [1, 0.45], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        }}><DataTray label="Source" tone="source" width={260} /></Interactive.Div>
        <Interactive.Div name="Bronze data tray" premountFor={fps} style={{ position: "absolute", left: 610, top: 505,
          opacity: interpolate(frame, [9 * fps, 9.8 * fps, 12.7 * fps, 13.5 * fps], [0.45, 1, 1, 0.45], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        }}><DataTray label="Bronze" tone="bronze" width={260} /></Interactive.Div>
        <Interactive.Div name="Silver data tray" premountFor={fps} style={{ position: "absolute", left: 1010, top: 505,
          opacity: interpolate(frame, [13 * fps, 13.8 * fps, 15.8 * fps, 16.8 * fps], [0.45, 1, 1, 0.45], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        }}><DataTray label="Silver" tone="silver" width={260} /></Interactive.Div>
        <Interactive.Div name="Gold data tray" premountFor={fps} style={{ position: "absolute", left: 1410, top: 505,
          opacity: interpolate(frame, [16 * fps, 16.8 * fps], [0.45, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        }}><DataTray label="Gold" tone="gold" width={260} /></Interactive.Div>

        <Interactive.Div name="One record flows through GDS" premountFor={fps} style={{
          position: "absolute", left: 305, top: 539, width: 70, height: 54,
          translate: interpolate(frame, [9 * fps, 12 * fps, 13 * fps, 15.8 * fps, 16 * fps, 19.5 * fps], ["0px 0px", "400px 0px", "400px 0px", "800px 0px", "800px 0px", "1200px 0px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.4, 0, 0.2, 1) }),
          opacity: interpolate(frame, [8.1 * fps, 8.8 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        }}>
          <svg width={70} height={54} viewBox="0 0 70 54" aria-hidden="true">
            <ellipse cx={35} cy={46} rx={24} ry={5} fill="#00338D" opacity={0.12} />
            <path d="M6 22L35 7l29 15-29 15z" fill="#1E49E2" stroke="#00338D" strokeWidth={1.8} strokeLinejoin="round" />
            <path d="M6 22v8l29 15v-8z" fill="#00338D" />
            <path d="M35 37v8l29-15v-8z" fill="#164795" />
            <path d="M20 21l15-8m-8 12 15-8" stroke="#FFFFFF" strokeWidth={2.2} strokeLinecap="round" />
          </svg>
        </Interactive.Div>

        <Interactive.Div name="Ingest operation" premountFor={fps} style={{ position: "absolute", left: 415, top: 741, width: 250, textAlign: "center", fontSize: 30, lineHeight: 1.1, color: "#00338D",
          opacity: interpolate(frame, [9 * fps, 9.6 * fps, 12 * fps, 12.7 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        }}>Ingest</Interactive.Div>
        <Interactive.Div name="Transform operation" premountFor={fps} style={{ position: "absolute", left: 795, top: 741, width: 660, textAlign: "center", fontSize: 30, lineHeight: 1.1, color: "#00338D",
          opacity: interpolate(frame, [13 * fps, 13.6 * fps, 19.3 * fps, 20 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        }}>Transform</Interactive.Div>
        <div style={{ position: "absolute", left: 660, top: 790, width: 600, textAlign: "center", fontSize: 27, lineHeight: 1.1, color: "#52677C" }}>GDS lakehouse · Delta Lake</div>
        <Interactive.Div name="Validation scripts accompany Gold output" premountFor={fps} style={{ position: "absolute", left: 1660, top: 532, width: 100, textAlign: "center",
          opacity: interpolate(frame, [20 * fps, 21 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
          translate: interpolate(frame, [20 * fps, 21 * fps], ["20px 0px", "0px 0px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.16, 1, 0.3, 1) }),
        }}>
          <SvgIcon kind="checklist" size={92} />
          <div style={{ fontSize: 25, color: "#52677C", marginTop: 10 }}>Checks</div>
        </Interactive.Div>
      </Interactive.Div>
    </AbsoluteFill>
  );
};
