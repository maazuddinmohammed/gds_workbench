import { AbsoluteFill, Img, Interactive, interpolate, Sequence, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { IntroJourney } from "./IntroJourney";
import { ClosingJourney } from "./ClosingJourney";
import { OnboardingJourney, AgentMessage, ChatPanel, UserMessage, WorkflowRail } from "./Interface";
import { SnapshotJourney } from "./SnapshotJourney";
import { BuildJourney } from "./BuildJourney";
import { IntroNarration, RunNarration } from "./SceneNarration";
import { ClosingNarration } from "../v8/SceneNarration";
import { TeamJourney } from "./TeamJourney";
import { EnvironmentMap } from "./EnvironmentMap";
import { ReviewJourney } from "./ReviewJourney";
import { RunJourney } from "./RunJourney";
import { LegacyCopilotChat } from "./LegacyCopilotChat";
import { ReviewNarration } from "../v2/SceneNarration";
import { OnboardingNarration, BuildNarration } from "../v5/SceneNarration";
import { SnapshotNarration, TeamNarration } from "../v4/SceneNarration";

export const BuildScene=()=>{
  const f=useCurrentFrame(),{fps}=useVideoConfig(),t=f/fps;
  const response=t<3.8?"Profiling the source evidence.":t<6.8?"Enriching the source descriptions.":t<9.7?"Analyzing keys and relationships.":t<12?"Organizing subject areas.":t<20?"Extending the Silver operational model.":t<26?"Updating the Gold dimensional model.":t<35?"Mapping fields for both layers.":t<44?"Generating code from approved inputs.":"Preparing validation for both layers.";
  return <><ChatPanel style={{top:350,height:610,scale:.82,transformOrigin:"top left"}}><UserMessage>Add returns and refunds to the existing Sales model.</UserMessage><AgentMessage>{response}</AgentMessage></ChatPanel><BuildJourney/></>;
};

const SnapshotScene=()=>{
  const f=useCurrentFrame(),{fps}=useVideoConfig();
  return <><SnapshotJourney/><Interactive.Div name="Locate shared knowledge before opening it" style={{position:"absolute",inset:0,background:"#F8FAFD",opacity:interpolate(f,[2.1*fps,3.1*fps],[1,0],{extrapolateLeft:"clamp",extrapolateRight:"clamp"})}}><div style={{position:"absolute",left:144,top:155,fontSize:44,fontWeight:600,letterSpacing:-1}}>Bring shared knowledge into your workspace.</div><EnvironmentMap highlight="knowledge"/></Interactive.Div></>;
};

const ReviewScene=()=>{
  const f=useCurrentFrame(),{fps}=useVideoConfig();
  return <><div style={{position:"absolute",left:144,top:153,fontSize:48,fontWeight:600,letterSpacing:-1.2}}>{f<6.1*fps?"Review in Atlas Local Workbench.":"Review. Then approve."}</div><Interactive.Div name="Copilot resumes after local review" style={{position:"absolute",inset:0,opacity:interpolate(f,[6.1*fps,6.8*fps],[0,1],{extrapolateLeft:"clamp",extrapolateRight:"clamp"})}}><LegacyCopilotChat timelineSeconds={76+f/fps}/></Interactive.Div><ReviewJourney/></>;
};
const RunScene=()=>{
  const f=useCurrentFrame(),{fps}=useVideoConfig();
  return <><LegacyCopilotChat timelineSeconds={108+f/fps}/><RunJourney/></>;
};

/** Explicit scene nodes preserve independent Studio editing and reproducible timing. */
export const AtlasExplainerV9=({showCaptions=false}:{showCaptions?:boolean})=><AbsoluteFill style={{fontFamily:"Open Sans",color:"#0C233C",backgroundColor:"#F8FAFD"}}>
  <Sequence name="00 Welcome to Atlas" durationInFrames={1260}><IntroJourney/><IntroNarration showCaptions={showCaptions}/></Sequence>
  <Sequence name="01 Start Atlas and select authorized scope" from={1260} durationInFrames={1260}><OnboardingJourney/><WorkflowRail active={0}/><OnboardingNarration showCaptions={showCaptions}/></Sequence>
  <Sequence name="02 Reuse local context and Atlas Bridge" from={2520} durationInFrames={840}><SnapshotScene/><Sequence name="Context progress" from={93}><WorkflowRail active={1}/></Sequence><SnapshotNarration showCaptions={showCaptions}/></Sequence>
  <Sequence name="03 Complete Atlas capability journey" from={3360} durationInFrames={1620}><BuildScene/><WorkflowRail active={2}/><BuildNarration showCaptions={showCaptions}/></Sequence>
  <Sequence name="04 Review Stage and Apply" from={4980} durationInFrames={960}><ReviewScene/><WorkflowRail active={3}/><ReviewNarration showCaptions={showCaptions}/></Sequence>
  <Sequence name="05 Deliver and run GDS" from={5940} durationInFrames={780}><RunScene/><WorkflowRail active={4}/><RunNarration showCaptions={showCaptions}/></Sequence>
  <Sequence name="06 Shared Atlas and protected access" from={6720} durationInFrames={1080}><TeamJourney/><WorkflowRail active={5}/><TeamNarration showCaptions={showCaptions}/></Sequence>
  <Sequence name="07 Return to the environment" from={7800} durationInFrames={600}><ClosingJourney/><ClosingNarration showCaptions={showCaptions}/></Sequence>
  <Interactive.Div name="Atlas identity" style={{position:"absolute",zIndex:5,left:112,top:62,display:"flex",alignItems:"center",gap:12,color:"#00338D",fontSize:31,fontWeight:600}}><Img src={staticFile("atlas.svg")} style={{width:42,height:42}}/>Atlas</Interactive.Div>
  {!showCaptions&&<div style={{position:"absolute",left:112,top:1030,fontSize:17,color:"#8C98A9"}}>Illustrative workflow</div>}
</AbsoluteFill>;
