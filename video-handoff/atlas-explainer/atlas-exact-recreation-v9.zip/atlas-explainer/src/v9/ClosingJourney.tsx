import { AbsoluteFill, Easing, Img, Interactive, interpolate, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { EnvironmentMap } from "./EnvironmentMap";

export const ClosingJourney = ({standalone=false}:{standalone?:boolean}) => {
  const frame=useCurrentFrame();const {fps}=useVideoConfig();const t=frame/fps;
  const ease={extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.bezier(.22,1,.36,1)} as const;
  return <AbsoluteFill style={{fontFamily:"Open Sans",color:"#0C233C",backgroundColor:standalone?"#F8FAFD":undefined}}>
    <Interactive.Div name="Return to the complete Atlas environment" premountFor={fps} style={{position:"absolute",inset:0,opacity:interpolate(t,[0,.9,9.5,11],[0,1,1,0],ease)}}>
      <div style={{position:"absolute",left:144,top:155,fontSize:45,fontWeight:600,letterSpacing:-1}}>One shared project. From source to lakehouse.</div>
      <EnvironmentMap progress={1} focus={{sources:interpolate(t,[.7,1.2,2,2.6],[0,1,1,0],ease),frameworks:interpolate(t,[2,2.6,3.4,4],[0,1,1,0],ease),lakehouse:interpolate(t,[3.4,4,5.1,5.7],[0,1,1,0],ease),knowledge:interpolate(t,[5.7,6.2,7.3,7.9],[0,1,1,0],ease),workspace:interpolate(t,[7.1,7.7,8.3,8.9],[0,1,1,0],ease),platform:interpolate(t,[8.2,8.8,9.5,10.1],[0,1,1,0],ease)}}/>
    </Interactive.Div>
    <Interactive.Div name="Preserved Atlas closing message" premountFor={fps} style={{position:"absolute",left:280,top:340,width:1360,textAlign:"center",opacity:interpolate(t,[10,11.5],[0,1],ease),translate:interpolate(t,[10,11.5],["0px 20px","0px 0px"],ease)}}>
      <div style={{display:"flex",gap:23,alignItems:"center",justifyContent:"center",color:"#00338D",fontSize:91,fontWeight:600,letterSpacing:-3}}><Img src={staticFile("atlas.svg")} style={{width:108,height:108}}/>Atlas</div>
      <div style={{fontSize:49,lineHeight:1.3,letterSpacing:-1,marginTop:45}}>Move GDS forward.</div>
      <div style={{fontSize:35,color:"#66778B",marginTop:17}}>Keep project knowledge central and shared.</div>
      <div style={{fontSize:25,color:"#66778B",marginTop:45,opacity:interpolate(t,[14,15],[0,1],ease)}}>Build · validate · maintain · continue together</div>
    </Interactive.Div>
  </AbsoluteFill>;
};
