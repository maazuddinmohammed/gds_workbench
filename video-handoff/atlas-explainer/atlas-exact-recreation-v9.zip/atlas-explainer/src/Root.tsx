import { Composition, Folder } from "remotion";
import { OpeningScene } from "./scenes/OpeningScene";
import { AtlasExplainer } from "./AtlasExplainer";
import { AtlasWorkflow } from "./v2/AtlasWorkflow";
import { ContextJourney } from "./v2/ContextJourney";
import { BuildJourney as BuildJourneyV2 } from "./v2/BuildJourney";
import { BuildJourney } from "./v3/BuildJourney";
import { OverviewJourney } from "./v3/OverviewJourney";
import { AtlasExplainerV3 } from "./v3/AtlasExplainer";
import { BuildJourney as BuildJourneyV4 } from "./v4/BuildJourney";
import { TeamJourney } from "./v4/TeamJourney";
import { OnboardingJourney } from "./v4/Interface";
import { SnapshotJourney } from "./v4/SnapshotJourney";
import { AtlasExplainerV4 } from "./v4/AtlasExplainer";
import { AtlasExplainerV5 } from "./v5/AtlasExplainer";
import { AtlasExplainerV6 } from "./v6/AtlasExplainer";
import { AtlasExplainerV7 } from "./v7/AtlasExplainer";
import { AtlasExplainerV8 } from "./v8/AtlasExplainer";
import { AtlasExplainerV9 } from "./v9/AtlasExplainer";
import { RunJourney as RunV9 } from "./v9/RunJourney";
import { ReviewJourney as ReviewV9 } from "./v9/ReviewJourney";
import { IntroJourney as IntroV9 } from "./v9/IntroJourney";
import { EnvironmentMap as MapV9 } from "./v9/EnvironmentMap";
import { SnapshotJourney as SnapshotV9 } from "./v9/SnapshotJourney";
import { OnboardingJourney as OnboardingV9 } from "./v9/Interface";
import { BuildJourney as BuildV9 } from "./v9/BuildJourney";
import { TeamJourney as TeamV9 } from "./v9/TeamJourney";
import { ClosingJourney as ClosingV9 } from "./v9/ClosingJourney";
import { IntroJourney } from "./v4/IntroJourney";
import { ClosingJourney } from "./v4/ClosingJourney";
import { ReviewJourney } from "./v2/ReviewJourney";
import { RunJourney } from "./v2/RunJourney";
import { ContinueJourney } from "./v2/ContinueJourney";
import { CloseJourney } from "./v2/CloseJourney";
import { NarratedOpening, NarratedArchitecture, NarratedDiscovery, NarratedModeling, NarratedReview, NarratedDelivery, NarratedContinuity, NarratedMaintenance, NarratedFuture } from "./NarratedScenes";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition id="AtlasExplainer" component={AtlasExplainerV9} defaultProps={{showCaptions:false}} width={1920} height={1080} fps={30} durationInFrames={8400} />
      <Composition id="AtlasExplainer-Captions" component={AtlasExplainerV9} defaultProps={{showCaptions:true}} width={1920} height={1080} fps={30} durationInFrames={8400} />
      <Folder name="Current-artwork">
        <Composition id="V9-Run" component={RunV9} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={780} />
        <Composition id="V9-Review" component={ReviewV9} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={960} />
        <Composition id="V9-Intro" component={IntroV9} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={1260} />
        <Composition id="V9-Environment" component={MapV9} defaultProps={{standalone:true,progress:1,highlight:"none" as const}} width={1920} height={1080} fps={30} durationInFrames={1260} />
        <Composition id="V9-Onboarding" component={OnboardingV9} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={1260} />
        <Composition id="V9-Snapshot" component={SnapshotV9} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={840} />
        <Composition id="V9-Build" component={BuildV9} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={1620} />
        <Composition id="V9-Team" component={TeamV9} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={1080} />
        <Composition id="V9-Closing" component={ClosingV9} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={600} />
      </Folder>
      <Folder name="V4-artwork">
        <Composition id="V4-Intro" component={IntroJourney} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={1260} />
        <Composition id="V4-Closing" component={ClosingJourney} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={600} />
        <Composition id="V4-Build" component={BuildJourneyV4} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={1620} />
        <Composition id="V4-Team" component={TeamJourney} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={1080} />
        <Composition id="V4-Onboarding" component={OnboardingJourney} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={840} />
        <Composition id="V4-Snapshot" component={SnapshotJourney} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={840} />
      </Folder>
      <Folder name="Workflow-artwork">
        <Composition id="Workflow-Overview" component={OverviewJourney} defaultProps={{standalone:true,closing:false}} width={1920} height={1080} fps={30} durationInFrames={540} />
        <Composition id="Workflow-Context" component={ContextJourney} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={720} />
        <Composition id="Workflow-Build" component={BuildJourney} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={960} />
        <Composition id="Workflow-Review" component={ReviewJourney} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={960} />
        <Composition id="Workflow-Run" component={RunJourney} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={780} />
        <Composition id="Workflow-Continue" component={ContinueJourney} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={840} />
        <Composition id="Workflow-Close" component={CloseJourney} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={540} />
      </Folder>
      <Folder name="Previous-review">
      <Composition id="AtlasReviewV8" component={AtlasExplainerV8} defaultProps={{showCaptions:false}} width={1920} height={1080} fps={30} durationInFrames={8400} />
      <Composition id="AtlasReviewV7" component={AtlasExplainerV7} defaultProps={{showCaptions:false}} width={1920} height={1080} fps={30} durationInFrames={8400} />
      <Composition id="AtlasReviewV6" component={AtlasExplainerV6} defaultProps={{showCaptions:false}} width={1920} height={1080} fps={30} durationInFrames={8400} />
      <Composition id="AtlasReviewV5" component={AtlasExplainerV5} defaultProps={{showCaptions:false}} width={1920} height={1080} fps={30} durationInFrames={8400} />
      <Composition id="AtlasReviewV4" component={AtlasExplainerV4} defaultProps={{showCaptions:false}} width={1920} height={1080} fps={30} durationInFrames={7980} />
      <Composition id="AtlasReviewV3" component={AtlasExplainerV3} defaultProps={{showCaptions:false}} width={1920} height={1080} fps={30} durationInFrames={5940} />
      <Composition id="AtlasReviewV2" component={AtlasWorkflow} defaultProps={{showCaptions:false}} width={1920} height={1080} fps={30} durationInFrames={5400} />
      <Composition id="V2-Build" component={BuildJourneyV2} defaultProps={{standalone:true}} width={1920} height={1080} fps={30} durationInFrames={960} />
      <Composition id="AtlasReviewV1" component={AtlasExplainer} width={1920} height={1080} fps={30} durationInFrames={5700} />
      <Folder name="Scenes">
        <Composition id="Scene01-Opening" component={NarratedOpening} width={1920} height={1080} fps={30} durationInFrames={525} />
        <Composition id="Scene02-Architecture" component={NarratedArchitecture} width={1920} height={1080} fps={30} durationInFrames={615} />
        <Composition id="Scene03-Discovery" component={NarratedDiscovery} width={1920} height={1080} fps={30} durationInFrames={600} />
        <Composition id="Scene04-Modeling" component={NarratedModeling} width={1920} height={1080} fps={30} durationInFrames={705} />
        <Composition id="Scene05-Review" component={NarratedReview} width={1920} height={1080} fps={30} durationInFrames={855} />
        <Composition id="Scene06-Delivery" component={NarratedDelivery} width={1920} height={1080} fps={30} durationInFrames={645} />
        <Composition id="Scene07-Continuity" component={NarratedContinuity} width={1920} height={1080} fps={30} durationInFrames={705} />
        <Composition id="Scene08-Maintenance" component={NarratedMaintenance} width={1920} height={1080} fps={30} durationInFrames={510} />
        <Composition id="Scene09-Future" component={NarratedFuture} width={1920} height={1080} fps={30} durationInFrames={540} />
      </Folder>
      <Composition
        id="AtlasOpening"
        component={OpeningScene}
        width={1920}
        height={1080}
        fps={30}
        durationInFrames={480}
      />
      </Folder>
    </>
  );
};
