import type { ReactNode } from "react";
import { AbsoluteFill, Img, Interactive, interpolate, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import "./fonts";

export const colors = {
  blue: "#00338D",
  accent: "#1E49E2",
  ink: "#0C233C",
  muted: "#52677C",
  paper: "#F5F6FA",
  line: "#CCD8EA",
};

// Shared canvas and typography preserve brand and caption-safe spacing across scenes.
export const SceneFrame = ({ chapter, title, subtitle, children }: {
  chapter: string;
  title: string;
  subtitle?: string;
  children: ReactNode;
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill style={{ backgroundColor: "#FFFFFF", color: "#0C233C", fontFamily: "Open Sans", overflow: "hidden" }}>
      <div style={{ position: "absolute", left: 144, top: 94, display: "flex", alignItems: "center", gap: 16.5, color: "#00338D", fontSize: 34.5, fontWeight: 600, letterSpacing: 2.7 }}>
        <Img src={staticFile("atlas.svg")} alt="Atlas" premountFor={fps} style={{ width: 48, height: 48 }} />
        ATLAS
      </div>
      <div style={{ position: "absolute", right: 144, top: 102, color: "#52677C", fontSize: 25, letterSpacing: 2, textTransform: "uppercase" }}>{chapter}</div>
      <Interactive.Div name="Scene title" premountFor={fps} style={{ position: "absolute", left: 144, top: 194, width: 1632, fontSize: 76, fontWeight: 600, lineHeight: 1.15, letterSpacing: -2.8, opacity: interpolate(frame, [0, 0.7 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>{title}</Interactive.Div>
      {subtitle ? <div style={{ position: "absolute", left: 148, top: 303, width: 1620, fontSize: 32, color: "#52677C", lineHeight: 1.35 }}>{subtitle}</div> : null}
      {children}
    </AbsoluteFill>
  );
};

// A domain connection, drawn deterministically; direction and progress stay explicit.
export const FlowArrow = ({ x1, y1, x2, y2, progress = 1, color = colors.accent, dashed = false }: {
  x1: number; y1: number; x2: number; y2: number; progress?: number; color?: string; dashed?: boolean;
}) => {
  const p = Math.min(1, Math.max(0, progress));
  const x = x1 + (x2 - x1) * p;
  const y = y1 + (y2 - y1) * p;
  const angle = Math.atan2(y2 - y1, x2 - x1);
  const ax = x - 13 * Math.cos(angle - 0.5);
  const ay = y - 13 * Math.sin(angle - 0.5);
  const bx = x - 13 * Math.cos(angle + 0.5);
  const by = y - 13 * Math.sin(angle + 0.5);
  return (
    <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{ position: "absolute", inset: 0, pointerEvents: "none", opacity: p > 0 ? 1 : 0 }} aria-hidden="true">
      <line x1={x1} y1={y1} x2={x} y2={y} stroke={color} strokeWidth={3} strokeDasharray={dashed ? "9 8" : undefined} />
      <path d={`M ${ax} ${ay} L ${x} ${y} L ${bx} ${by}`} fill="none" stroke={color} strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
};

// Reused model-table visual. Rows intentionally share one presentation template.
export const Entity = ({ x, y, width = 260, title, rows, accent = colors.blue }: {
  x: number; y: number; width?: number; title: string; rows: string[]; accent?: string;
}) => (
  <div style={{ position: "absolute", left: x, top: y, width, backgroundColor: "#FFFFFF", border: `2px solid ${accent}`, borderRadius: 6, overflow: "hidden" }}>
    <div style={{ padding: "18px 22px", fontSize: 32, fontWeight: 600, color: "#FFFFFF", backgroundColor: accent }}>{title}</div>
    {rows.map((row, index) => <div key={row} style={{ padding: "12px 22px", fontSize: 25, color: "#0C233C", borderTop: index ? "1px solid #CCD8EA" : undefined }}>{row}</div>)}
  </div>
);
