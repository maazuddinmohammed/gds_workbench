import { Easing, Img, Interactive, interpolate, staticFile, useVideoConfig } from "remotion";
import { PersonPortrait } from "../v2/Pictorials";
const ink="#0C233C",accent="#1E49E2",muted="#66778B";

/** A recognizable, deliberately simplified Copilot conversation; all content is illustrative. */
export const LegacyCopilotChat = ({timelineSeconds:t}:{timelineSeconds:number}) => {
  const {fps}=useVideoConfig();
  const f=t*fps;
  const ease={extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.bezier(.22,1,.36,1)} as const;
  const move=interpolate(t,[14,19],[0,1],ease);
  const dock=interpolate(t,[107.5,109,133,134.5],[0,1,1,0],ease);
  const close=interpolate(t,[161.5,163],[1,0],ease);
  const review=t>=76 && t<108;
  const later=t>=134;
  const question=t<76 ? "Build Sales from customers and orders." : review ? (t<82 ? "Review the Sales model." : t<93 ? "Approve Stage." : "Approve Apply.") : "Add our returns data.";
  const response=t<9 ? "" : t<20 ? "Let's build it with Atlas." : t<30 ? "Reading saved project context." : t<44 ? "Working from a local snapshot." : t<51 ? "Profiling and analyzing the sources." : t<60 ? "Building Silver and Gold models." : t<65.2 ? "Mapping source fields to targets." : t<67.7 ? "Using approved models and mappings." : t<76 ? "Preparing code and validation." : t<82 ? "Ready in Atlas Local Workbench." : t<90 ? "Staging through Atlas Bridge." : t<93 ? "Review the server result." : t<99 ? "Applying approved definitions." : t<108 ? "Saved to the shared project." : t<143 ? "Opening the Sales project." : t<151 ? "Using the saved project knowledge." : "Updating the model and files.";
  const composed=t>=1.8 && t<6.8;
  const chars=Math.floor(interpolate(t,[1.8,5.8],[0,question.length],{extrapolateLeft:"clamp",extrapolateRight:"clamp"}));
  const sent=interpolate(t,[6.8,7.35],[0,1],ease);
  return <Interactive.Div name="Copilot conversation" style={{position:"absolute",left:490-346*move,top:244-82*dock,width:940-290*move-265*dock,height:590-510*dock,boxSizing:"border-box",background:"#FFFFFF",border:"1.5px solid #DAE2EC",borderRadius:22,boxShadow:"0 24px 70px rgba(12,35,60,.08),0 3px 8px rgba(12,35,60,.025)",overflow:"hidden",opacity:close}}>
    <div style={{height:80,boxSizing:"border-box",padding:"0 27px",display:"flex",alignItems:"center",gap:15,borderBottom:dock>.7?"none":"1px solid #E5EAF1",background:"#FBFCFE"}}>
      <Img src={staticFile("icons/copilot.svg")} style={{width:39,height:39}}/>
      <div style={{fontSize:29,fontWeight:600,whiteSpace:"nowrap"}}>Copilot</div>
      <div style={{fontSize:20,color:muted,marginLeft:4,opacity:1-dock}}>via VS Code</div>
      <div style={{marginLeft:"auto",fontSize:29,color:muted,letterSpacing:3,opacity:1-dock}}>···</div>
    </div>
    <div style={{padding:"30px 30px 0",opacity:1-dock}}>
      <div style={{display:"flex",justifyContent:"flex-end",gap:12,alignItems:"flex-start",opacity:sent,transform:`translateY(${(1-sent)*38}px)`}}>
        <div style={{background:"#EDF2FF",padding:"19px 23px",borderRadius:"17px 4px 17px 17px",fontSize:29,lineHeight:1.5,maxWidth:430}}>{question}</div>
        <PersonPortrait variant={later?"second":"first"} size={48}/>
      </div>
      <div style={{marginTop:30,display:"flex",gap:17,alignItems:"flex-start",opacity:interpolate(t,[8,9],[0,1],ease)}}>
        <div style={{width:43,height:43,display:"flex",alignItems:"center",justifyContent:"center",background:"#F2F5FA",borderRadius:13,flexShrink:0}}><Img src={staticFile("icons/copilot.svg")} style={{width:30,height:30}}/></div>
        <div style={{fontSize:29,lineHeight:1.52,paddingTop:0}}>{response}
          <div style={{display:"flex",gap:9,alignItems:"center",fontSize:20,color:muted,marginTop:17}}><Img src={staticFile("atlas.svg")} style={{width:22,height:22}}/>Atlas Plugin</div>
        </div>
      </div>
    </div>
    <div style={{position:"absolute",left:25,right:25,bottom:24,minHeight:98,padding:"17px 20px",boxSizing:"border-box",border:composed?"2px solid #6C8EF0":"1.5px solid #DCE3ED",borderRadius:15,background:"#FDFEFF",opacity:1-dock}}>
      <div style={{fontSize:composed?27:23,lineHeight:1.4,color:composed?ink:"#8C97A7",paddingRight:36}}>{composed ? question.slice(0,chars):"Ask Copilot…"}{composed && <span style={{opacity:Math.floor(f/14)%2===0?1:0,color:accent}}>|</span>}</div>
      <div style={{fontSize:18,color:muted,marginTop:12}}>Agent <span style={{marginLeft:9,fontSize:15}}>⌄</span></div>
      <div style={{position:"absolute",right:15,bottom:14,width:34,height:34,background:composed?accent:"#EAF0F8",borderRadius:9,color:composed?"white":muted,fontSize:27,lineHeight:"30px",textAlign:"center"}}>↑</div>
    </div>
  </Interactive.Div>;
};

