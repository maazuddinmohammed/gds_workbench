import type { ReactNode, CSSProperties } from "react";
import { Easing, Img, Interactive, interpolate, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { PersonPortrait, SvgIcon } from "../v2/Pictorials";

export const blue="#00338D", ink="#0C233C", muted="#66778B";
export const ease={extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.bezier(.22,1,.36,1)} as const;

/** Same recognizable conversation shell as the accepted cut, with authored content. */
export const ChatPanel=({children,style,composer="Ask Copilot…",scope=true}:{children:ReactNode;style?:CSSProperties;composer?:string;scope?:boolean})=><Interactive.Div name="Copilot conversation" style={{position:"absolute",left:144,top:244,width:650,height:590,boxSizing:"border-box",background:"#fff",border:"1.5px solid #DAE2EC",borderRadius:22,boxShadow:"0 24px 70px rgba(12,35,60,.08)",overflow:"hidden",...style}}>
  <div style={{height:80,padding:"0 27px",display:"flex",alignItems:"center",gap:15,borderBottom:"1px solid #E5EAF1",background:"#FBFCFE"}}><Img src={staticFile("icons/copilot.svg")} style={{width:39,height:39}}/><span style={{fontSize:29,fontWeight:600}}>Copilot</span><span style={{fontSize:20,color:muted}}>via VS Code</span><span style={{marginLeft:"auto",fontSize:28,color:muted}}>···</span></div>
  {scope&&<div style={{padding:"14px 30px 0",fontSize:17,color:muted}}>Northwind <span style={{padding:"0 9px"}}>›</span> Commerce Lakehouse</div>}
  <div style={{padding:"22px 30px 0"}}>{children}</div>
  <div style={{position:"absolute",left:25,right:25,bottom:24,height:98,padding:"17px 20px",boxSizing:"border-box",border:"1.5px solid #DCE3ED",borderRadius:15,background:"#FDFEFF"}}><div style={{fontSize:23,color:composer==="Ask Copilot…"?"#8C97A7":ink}}>{composer}</div><div style={{fontSize:18,color:muted,marginTop:12}}>Agent ⌄</div><div style={{position:"absolute",right:15,bottom:14,width:34,height:34,background:"#EAF0F8",borderRadius:9,color:muted,fontSize:27,textAlign:"center"}}>↑</div></div>
</Interactive.Div>;

export const UserMessage=({children}:{children:ReactNode})=><div style={{display:"flex",justifyContent:"flex-end",gap:12,alignItems:"flex-start"}}><div style={{background:"#EDF2FF",padding:"16px 22px",borderRadius:"17px 4px 17px 17px",fontSize:27,lineHeight:1.45,maxWidth:470}}>{children}</div><PersonPortrait variant="first" size={46}/></div>;
export const AgentMessage=({children}:{children:ReactNode})=><div style={{marginTop:25,display:"flex",gap:16,alignItems:"flex-start"}}><Img src={staticFile("icons/copilot.svg")} style={{width:31,height:31,marginTop:5}}/><div style={{fontSize:27,lineHeight:1.45}}>{children}<div style={{display:"flex",gap:9,alignItems:"center",fontSize:19,color:muted,marginTop:14}}><Img src={staticFile("atlas.svg")} style={{width:22,height:22}}/>Atlas Plugin</div></div></div>;

export const WorkflowRail=({active}:{active:number})=><Interactive.Div name="Workflow location" style={{position:"absolute",left:270,top:937,width:1380,height:70,display:"flex",justifyContent:"space-between"}}>{["Start","Context","Build","Review","Run","Team"].map((name,i)=><div key={name} style={{fontSize:23,color:i===active?"#A34B0E":"#9AA9BC",fontWeight:i===active?600:400,display:"flex",alignItems:"center",gap:12}}><span style={{width:31,height:31,borderRadius:16,display:"inline-flex",alignItems:"center",justifyContent:"center",fontSize:18,color:i===active?"#fff":"#8195B4",background:i===active?"#A34B0E":"#EDF2F9",boxShadow:i===active?"0 0 0 5px rgba(227,117,35,.12)":"none"}}>{i<active?"✓":i+1}</span>{name}</div>)}</Interactive.Div>;

export const OnboardingJourney=({standalone=false}:{standalone?:boolean})=>{
  const f=useCurrentFrame(),{fps}=useVideoConfig(),t=f/fps;
  const shrink=interpolate(t,[40,42],[0,1],ease);
  const phase=t<4?0:t<10?1:t<16?2:t<29?3:t<36?4:5;
  const typed="Start Atlas".slice(0,Math.floor(interpolate(t,[1,3.4],[0,11],ease)));
  const requirement="Add returns and refunds to the existing Sales model.";
  return <div style={{position:"absolute",inset:0,background:standalone?"#F8FAFD":undefined,fontFamily:"Open Sans",color:ink}}>
    <Interactive.Div name="Choose the authorized project and requested work" style={{position:"absolute",left:144,top:153,fontSize:48,fontWeight:600,letterSpacing:-1.2}}>Start with access. Choose your work.</Interactive.Div>
    <ChatPanel scope={phase>=3} style={{left:420-276*shrink,width:1080-430*shrink,top:250-6*shrink,height:640-50*shrink}} composer={phase===0?typed:phase===4?requirement.slice(0,Math.floor(interpolate(t,[29.7,34.6],[0,requirement.length],ease))):"Ask Copilot…"}>
      {phase===0?<div style={{fontSize:27,color:muted,paddingTop:65,textAlign:"center"}}>Bring Atlas into the conversation.</div>:null}
      {phase===1?<>
        <UserMessage>Start Atlas</UserMessage>
        <AgentMessage>Choose a tenant you can access.</AgentMessage>
        <Interactive.Div name="Authorized tenant choices" style={{display:"flex",gap:16,marginTop:18,marginLeft:47}}>
          <div style={{padding:"12px 24px",borderRadius:12,fontSize:25,boxSizing:"border-box",border:`2px solid ${t>8?"#D86B16":"#DCE4EF"}`,background:t>8?"#FFF1E1":"white",boxShadow:t>8?"0 7px 18px rgba(227,117,35,.16)":"none"}}>Northwind {t>8?"✓":""}</div>
          <div style={{padding:"12px 24px",borderRadius:12,fontSize:25,boxSizing:"border-box",border:"2px solid #DCE4EF"}}>Fabrikam</div>
        </Interactive.Div>
      </>:null}
      {phase===2?<>
        <UserMessage>Northwind</UserMessage>
        <AgentMessage>Choose an existing project.</AgentMessage>
        <Interactive.Div name="Existing Northwind project choices" style={{display:"flex",flexDirection:"column",gap:12,marginTop:18,marginLeft:47,marginRight:18}}>
          <div style={{padding:"12px 22px",borderRadius:12,fontSize:25,boxSizing:"border-box",border:`2px solid ${t>13?"#D86B16":"#DCE4EF"}`,background:t>13?"#FFF1E1":"white",boxShadow:t>13?"0 7px 18px rgba(227,117,35,.16)":"none",display:"flex",justifyContent:"space-between",gap:15}}><span>Northwind Commerce Lakehouse</span><span style={{color:"#A34B0E"}}>{t>13?"✓":""}</span></div>
          <div style={{padding:"12px 22px",borderRadius:12,fontSize:25,boxSizing:"border-box",border:"2px solid #DCE4EF"}}>Northwind Supply Chain Modernization</div>
        </Interactive.Div>
      </>:null}
      {phase===3?<>
        <Interactive.Div name="Choose an Atlas Plugin task or a custom change" style={{display:"flex",alignItems:"center",gap:12,fontSize:27,fontWeight:600,color:blue}}><Img src={staticFile("atlas.svg")} style={{width:30,height:30}}/>Choose a task — or describe a custom change</Interactive.Div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1.1fr 1fr",gap:28,marginTop:25}}>
          <Interactive.Div name="Atlas discovery tasks" style={{opacity:interpolate(t,[16.4,17.1],[0,1],ease)}}>
            <div style={{fontSize:19,color:muted,marginBottom:11}}>Understand</div>
            <div style={{height:42,display:"flex",alignItems:"center",gap:11,fontSize:22}}><SvgIcon kind="magnify" size={28}/>Investigate</div>
            <div style={{height:42,display:"flex",alignItems:"center",gap:11,fontSize:22}}><SvgIcon kind="table" size={28}/>Source analysis</div>
            <div style={{height:42,display:"flex",alignItems:"center",gap:11,fontSize:22}}><SvgIcon kind="folder" size={28}/>Subject areas</div>
          </Interactive.Div>
          <Interactive.Div name="Atlas modeling and delivery tasks" style={{opacity:interpolate(t,[16.8,17.5],[0,1],ease)}}>
            <div style={{fontSize:19,color:muted,marginBottom:11}}>Design and build</div>
            <div style={{height:42,display:"flex",alignItems:"center",gap:11,fontSize:22}}><SvgIcon kind="table" size={28}/>Operational model</div>
            <div style={{height:42,display:"flex",alignItems:"center",gap:11,fontSize:22}}><SvgIcon kind="table" size={28}/>Dimensional model</div>
            <div style={{height:42,display:"flex",alignItems:"center",gap:11,fontSize:22}}><SvgIcon kind="document" size={28}/>Mapping</div>
            <div style={{height:42,display:"flex",alignItems:"center",gap:11,fontSize:22}}><SvgIcon kind="code" size={28}/>Code generation</div>
          </Interactive.Div>
          <Interactive.Div name="Atlas verification and maintenance tasks" style={{opacity:interpolate(t,[17.2,17.9],[0,1],ease)}}>
            <div style={{fontSize:19,color:muted,marginBottom:11}}>Maintain and verify</div>
            <div style={{height:42,display:"flex",alignItems:"center",gap:11,fontSize:22}}><SvgIcon kind="checklist" size={28}/>Validation</div>
            <div style={{height:42,display:"flex",alignItems:"center",gap:11,fontSize:22}}><SvgIcon kind="gear" size={28}/>Project change</div>
            <div style={{height:42,display:"flex",alignItems:"center",gap:11,fontSize:22}}><SvgIcon kind="database" size={28}/>Metadata</div>
            <div style={{height:42,display:"flex",alignItems:"center",gap:11,fontSize:22}}><SvgIcon kind="document" size={28}/>Registration</div>
          </Interactive.Div>
        </div>
        <Interactive.Div name="Custom change remains available alongside Atlas tasks" style={{marginTop:22,padding:"12px 18px",borderRadius:11,boxSizing:"border-box",border:`2px solid ${t>=25?"#D86B16":"#DCE4EF"}`,background:t>=25?"#FFF1E1":"#FBFCFE",boxShadow:t>=25?"0 7px 18px rgba(227,117,35,.16)":"none",display:"flex",alignItems:"center",gap:12,fontSize:23,color:t>=25?"#A34B0E":muted}}><SvgIcon kind="document" size={29}/>Describe a custom change<span style={{marginLeft:"auto",fontWeight:600,color:"#A34B0E",opacity:interpolate(t,[25,25.5],[0,1],ease)}}>Selected →</span></Interactive.Div>
      </>:null}
      {phase===4?<>
        <UserMessage>Northwind Commerce Lakehouse</UserMessage>
        <AgentMessage>What change would you like to make?</AgentMessage>
      </>:null}
      {phase===5?<>
        <UserMessage>{requirement}</UserMessage>
        <AgentMessage>Assessing impact on existing models, mappings, code and validation.</AgentMessage>
      </>:null}
    </ChatPanel>
    <Interactive.Div name="Onboarding path" style={{position:"absolute",top:909,left:420,opacity:interpolate(t,[4,5,39,40],[0,1,1,0],ease),fontSize:21,color:muted}}>Tenant → Existing project → Atlas task or custom change</Interactive.Div>
  </div>;
};
