import { AbsoluteFill, Easing, Img, Interactive, interpolate, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { SvgIcon } from "./Pictorials";
import { blue, ProjectPacket } from "./Interface";

export const CloseJourney=({standalone=false}: {standalone?:boolean})=>{
  const f=useCurrentFrame();const {fps}=useVideoConfig();const t=f/fps;
  const ease={extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.bezier(.22,1,.36,1)} as const;
  return <AbsoluteFill style={{fontFamily:"Open Sans",color:"#0C233C",backgroundColor:standalone?"#F8FAFD":undefined}}>
    <Interactive.Div name="The complete project loop" style={{position:"absolute",inset:0,opacity:interpolate(t,[0,1,8,9.5],[0,1,1,0],ease)}}>
      <svg width={1920} height={1080} style={{position:"absolute",inset:0}}><path d="M480 520C480 210 1440 210 1440 520S480 830 480 520" fill="none" stroke="#D9E4F7" strokeWidth={3}/><circle cx={960+480*Math.cos(interpolate(t,[1,8],[Math.PI,Math.PI*3],ease))} cy={520+233*Math.sin(interpolate(t,[1,8],[Math.PI,Math.PI*3],ease))} r={10} fill="#1E49E2"/></svg>
      <div style={{position:"absolute",left:425,top:450,background:"#F8FAFD",padding:20}}><Img src={staticFile("icons/copilot.svg")} style={{width:90,height:90}}/><div style={{fontSize:28,marginTop:12}}>Ask</div></div>
      <div style={{position:"absolute",left:860,top:220,background:"#F8FAFD",padding:20}}><SvgIcon kind="table" size={90}/><div style={{fontSize:28,marginTop:12}}>Build</div></div>
      <div style={{position:"absolute",left:1350,top:450,background:"#F8FAFD",padding:20}}><SvgIcon kind="checklist" size={90}/><div style={{fontSize:28,marginTop:12}}>Review</div></div>
      <div style={{position:"absolute",left:860,top:690,background:"#F8FAFD",padding:20}}><SvgIcon kind="gear" size={90}/><div style={{fontSize:28,marginTop:12}}>Deliver</div></div>
      <ProjectPacket size={180} style={{position:"absolute",left:870,top:420}}/>
    </Interactive.Div>
    <Interactive.Div name="Atlas closing message" style={{position:"absolute",left:280,top:360,width:1360,textAlign:"center",opacity:interpolate(t,[8,10],[0,1],ease),translate:interpolate(t,[8,10],["0px 20px","0px 0px"],ease)}}>
      <div style={{display:"flex",gap:23,alignItems:"center",justifyContent:"center",color:blue,fontSize:91,fontWeight:600,letterSpacing:-3}}><Img src={staticFile("atlas.svg")} style={{width:108,height:108}}/>Atlas</div>
      <div style={{fontSize:49,lineHeight:1.3,letterSpacing:-1,marginTop:45}}>Move GDS forward.</div>
      <div style={{fontSize:35,color:"#66778B",marginTop:17}}>Keep knowledge with the project.</div>
    </Interactive.Div>
  </AbsoluteFill>;
};
