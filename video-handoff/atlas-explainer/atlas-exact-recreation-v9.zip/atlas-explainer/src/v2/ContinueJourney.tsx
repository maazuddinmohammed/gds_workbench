import { AbsoluteFill, Easing, Img, Interactive, interpolate, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { PersonPortrait, SvgIcon } from "./Pictorials";
import { blue, ProjectPacket } from "./Interface";

export const ContinueJourney = ({standalone=false}: {standalone?:boolean}) => {
  const f=useCurrentFrame();const {fps}=useVideoConfig();const t=f/fps;
  const ease={extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.bezier(.22,1,.36,1)} as const;
  return <AbsoluteFill style={{fontFamily:"Open Sans",color:"#0C233C",backgroundColor:standalone?"#F8FAFD":undefined}}>
    <Interactive.Div name="Another authorized teammate" style={{position:"absolute",left:990,top:340,textAlign:"center",opacity:interpolate(t,[0,.7,12,13],[0,1,1,0],ease)}}>
      <PersonPortrait variant="second" size={164}/><SvgIcon kind="shield" size={52} style={{position:"absolute",right:-14,top:118}}/>
    </Interactive.Div>
    <Interactive.Div name="Saved Sales project returns" style={{position:"absolute",left:1465,top:325,opacity:interpolate(t,[1,2,22,23],[0,1,1,0],ease),translate:interpolate(t,[8,10,12,14],["0px 0px","-190px 160px","-190px 160px","-20px 150px"],ease)}}><ProjectPacket size={200}/></Interactive.Div>
    <Interactive.Svg name="Teammate reuses project knowledge" width={1920} height={1080} style={{position:"absolute",inset:0,opacity:interpolate(t,[3,4,11,12],[0,1,1,0],ease)}}>
      <path d="M1410 425H1190m15-11-15 11 15 11" stroke="#B7C9E7" strokeWidth={3} fill="none"/>
      <circle cx={interpolate(t,[4,8],[1400,1200],ease)} cy={425} r={9} fill="#1E49E2"/>
    </Interactive.Svg>
    <Interactive.Div name="New Returns source" style={{position:"absolute",left:980,top:495,width:170,textAlign:"center",opacity:interpolate(t,[12,13,22,23],[0,1,1,0],ease),translate:interpolate(t,[12,14],["-30px 0px","0px 0px"],ease)}}>
      <SvgIcon kind="table" size={170}/><div style={{fontSize:30,fontWeight:600,marginTop:15}}>Returns</div>
    </Interactive.Div>
    <Interactive.Svg name="New source links into Sales" width={1920} height={1080} style={{position:"absolute",inset:0,opacity:interpolate(t,[14,15,22,23],[0,1,1,0],ease)}}>
      <path d="M1180 585H1400m-15-11 15 11-15 11" stroke="#1E49E2" strokeWidth={3} fill="none" pathLength={1} strokeDasharray={1} strokeDashoffset={interpolate(t,[14,16],[1,0],ease)}/>
    </Interactive.Svg>
    <Interactive.Div name="Affected artifacts update" style={{position:"absolute",left:1250,top:730,display:"flex",gap:30,opacity:interpolate(t,[17,18,22,23],[0,1,1,0],ease)}}>
      <SvgIcon kind="table" size={62}/><SvgIcon kind="code" size={62}/><SvgIcon kind="checklist" size={62}/>
    </Interactive.Div>
    <Interactive.Div name="Atlas Platform shared results" style={{position:"absolute",left:925,top:338,width:790,height:432,border:"1.5px solid #D9E2EC",borderRadius:20,background:"white",boxShadow:"0 20px 45px rgba(0,51,141,.06)",overflow:"hidden",opacity:interpolate(t,[22,23],[0,1],ease),translate:interpolate(t,[22,23.4],["0px 25px","0px 0px"],ease)}}>
      <div style={{height:76,background:"#F7F9FC",display:"flex",alignItems:"center",padding:"0 26px",gap:13,borderBottom:"1px solid #E4EAF2",fontSize:28,fontWeight:600,color:blue}}><Img src={staticFile("atlas.svg")} style={{width:36,height:36}}/>Atlas Platform</div>
      <div style={{padding:"29px 35px",fontSize:33,fontWeight:600}}>Sales <span style={{fontSize:22,fontWeight:400,color:"#6F8096",marginLeft:20}}>Shared results</span></div>
      <div style={{display:"flex",justifyContent:"space-around",marginTop:20}}>
        <div style={{textAlign:"center"}}><SvgIcon kind="table" size={94}/><div style={{fontSize:25,marginTop:14}}>Model</div></div>
        <div style={{textAlign:"center"}}><SvgIcon kind="code" size={94}/><div style={{fontSize:25,marginTop:14}}>Code</div></div>
        <div style={{textAlign:"center"}}><SvgIcon kind="checklist" size={94}/><div style={{fontSize:25,marginTop:14}}>Checks</div></div>
      </div>
    </Interactive.Div>
  </AbsoluteFill>;
};
