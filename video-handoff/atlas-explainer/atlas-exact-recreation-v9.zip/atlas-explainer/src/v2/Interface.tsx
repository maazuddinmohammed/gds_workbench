import type { CSSProperties } from "react";
import { Easing, Img, Interactive, interpolate, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { PersonPortrait, SvgIcon } from "./Pictorials";

export const ink = "#0C233C";
export const blue = "#00338D";
export const accent = "#1E49E2";
export const muted = "#66778B";

export const ProjectPacket = ({size = 150, style}: {size?: number; style?: CSSProperties}) => (
  <div style={{width:size, textAlign:"center", ...style}}>
    <SvgIcon kind="folder" size={size}/>
    <div style={{fontSize:Math.max(24,size*.19), fontWeight:600, color:blue, marginTop:-size*.08}}>Sales</div>
  </div>
);

/** A recognizable, deliberately simplified Copilot conversation; all content is illustrative. */
export const CopilotChat = () => {
  const f=useCurrentFrame();
  const {fps}=useVideoConfig();
  const t=f/fps;
  const ease={extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.bezier(.22,1,.36,1)} as const;
  const move=interpolate(t,[14,19],[0,1],ease);
  const dock=interpolate(t,[107.5,109,133,134.5],[0,1,1,0],ease);
  const close=interpolate(t,[161.5,163],[1,0],ease);
  const review=t>=76 && t<108;
  const later=t>=134;
  const question=t<76 ? "Build Sales from customers and orders." : review ? (t<82 ? "Review the Sales model." : t<93 ? "Approve Stage." : "Approve Apply.") : "Add our returns data.";
  const response=t<9 ? "" : t<20 ? "Let's build it with Atlas." : t<30 ? "Reading saved project context." : t<44 ? "Working from a local snapshot." : t<57 ? "Connecting customers and orders." : t<66 ? "Shaping the reporting model." : t<76 ? "Preparing your delivery files." : t<82 ? "Ready in Atlas Local Workbench." : t<90 ? "Staging through Atlas Bridge." : t<93 ? "Review the server result." : t<99 ? "Applying approved definitions." : t<108 ? "Saved to the shared project." : t<143 ? "Opening the Sales project." : t<151 ? "Using the saved project knowledge." : "Updating the model and files.";
  const composed=t>=1.8 && t<6.8;
  const chars=Math.floor(interpolate(t,[1.8,5.8],[0,question.length],{extrapolateLeft:"clamp",extrapolateRight:"clamp"}));
  const sent=interpolate(t,[6.8,7.35],[0,1],ease);
  return <Interactive.Div name="Copilot conversation" style={{position:"absolute",left:490-346*move,top:244-82*dock,width:940-290*move-265*dock,height:590-510*dock,background:"#FFFFFF",border:"1.5px solid #DAE2EC",borderRadius:22,boxShadow:"0 24px 70px rgba(12,35,60,.08),0 3px 8px rgba(12,35,60,.025)",overflow:"hidden",opacity:close}}>
    <div style={{height:80,boxSizing:"border-box",padding:"0 27px",display:"flex",alignItems:"center",gap:15,borderBottom:dock>.7?"none":"1px solid #E5EAF1",background:"#FBFCFE"}}>
      <Img src={staticFile("icons/copilot.svg")} style={{width:39,height:39}}/>
      <div style={{fontSize:29,fontWeight:600,whiteSpace:"nowrap"}}>Copilot</div>
      <div style={{fontSize:20,color:muted,marginLeft:4,opacity:1-dock}}>via VS Code</div>
      <div style={{marginLeft:"auto",fontSize:29,color:muted,letterSpacing:3,opacity:1-dock}}>···</div>
    </div>
    <div style={{padding:"30px 30px 0",opacity:1-dock}}>
      <div style={{display:"flex",justifyContent:"flex-end",gap:12,alignItems:"flex-start",opacity:sent,transform:`translateY(${(1-sent)*38}px)`}}>
        <div style={{background:"#EDF2FF",padding:"19px 23px",borderRadius:"17px 4px 17px 17px",fontSize:29,lineHeight:1.5,maxWidth:430}}>{question}</div>
        <PersonPortrait variant={later?"second":"first"} size={48}/>
      </div>
      <div style={{marginTop:30,display:"flex",gap:17,alignItems:"flex-start",opacity:interpolate(t,[8,9],[0,1],ease)}}>
        <div style={{width:43,height:43,display:"flex",alignItems:"center",justifyContent:"center",background:"#F2F5FA",borderRadius:13,flexShrink:0}}><Img src={staticFile("icons/copilot.svg")} style={{width:30,height:30}}/></div>
        <div style={{fontSize:29,lineHeight:1.52,paddingTop:0}}>{response}
          <div style={{display:"flex",gap:9,alignItems:"center",fontSize:20,color:muted,marginTop:17}}><Img src={staticFile("atlas.svg")} style={{width:22,height:22}}/>Atlas Plugin</div>
        </div>
      </div>
    </div>
    <div style={{position:"absolute",left:25,right:25,bottom:24,minHeight:98,padding:"17px 20px",boxSizing:"border-box",border:composed?"2px solid #6C8EF0":"1.5px solid #DCE3ED",borderRadius:15,background:"#FDFEFF",opacity:1-dock}}>
      <div style={{fontSize:composed?27:23,lineHeight:1.4,color:composed?ink:"#8C97A7",paddingRight:36}}>{composed ? question.slice(0,chars):"Ask Copilot…"}{composed && <span style={{opacity:Math.floor(f/14)%2===0?1:0,color:accent}}>|</span>}</div>
      <div style={{fontSize:18,color:muted,marginTop:12}}>Agent <span style={{marginLeft:9,fontSize:15}}>⌄</span></div>
      <div style={{position:"absolute",right:15,bottom:14,width:34,height:34,background:composed?accent:"#EAF0F8",borderRadius:9,color:composed?"white":muted,fontSize:27,lineHeight:"30px",textAlign:"center"}}>↑</div>
    </div>
  </Interactive.Div>;
};

export const WorkflowRail = () => {
  const f=useCurrentFrame();
  const {fps}=useVideoConfig();
  const t=f/fps;
  const index=t<20?0:t<44?1:t<76?2:t<108?3:t<134?4:5;
  const labels=["Ask","Understand","Build","Review","Run","Continue"];
  const opacity=interpolate(t,[11,13,162,164],[0,1,1,0],{extrapolateLeft:"clamp",extrapolateRight:"clamp"});
  return <Interactive.Div name="Workflow progress" style={{position:"absolute",left:260,top:926,width:1400,height:80,opacity}}>
    <div style={{position:"absolute",left:57,right:57,top:18,height:2,background:"#DCE4EE"}}/>
    <div style={{position:"absolute",left:57,top:18,width:index*257,height:2,background:accent}}/>
    {labels.map((label,i)=><div key={label} style={{position:"absolute",left:i*257,width:114,textAlign:"center",color:i===index?blue:i<index?"#647C9A":"#9BA6B3"}}>
      <div style={{width:36,height:36,borderRadius:"50%",margin:"0 auto 12px",background:i===index?accent:i<index?"#E3EBFC":"#F5F7FA",border:`2px solid ${i===index?accent:i<index?"#CCD9F5":"#DAE2EB"}`,boxSizing:"border-box",color:i===index?"white":"#6F87B2",fontSize:19,fontWeight:600,lineHeight:"31px"}}>{i<index?"✓":i+1}</div>
      <div style={{fontSize:22,fontWeight:i===index?600:400,whiteSpace:"nowrap"}}>{label}</div>
    </div>)}
  </Interactive.Div>;
};
