import "../fonts";
import type { CSSProperties, ReactNode } from "react";

export type IconKind =
  | "person" | "cloud" | "database" | "folder" | "document" | "code"
  | "checklist" | "shield" | "magnify" | "table" | "gear" | "arrow";

/** Compact nouns for the workflow. Filled planes keep them readable at a distance. */
export const SvgIcon = ({ kind, size = 64, color = "#00338D", style, title }: {
  kind: IconKind;
  size?: number;
  color?: string;
  style?: CSSProperties;
  title?: string;
}) => {
  const artwork: Record<IconKind, ReactNode> = {
    person: <>
      <path d="M8 42v-5c0-8 7-13 16-13s16 5 16 13v5" fill="#EDF2FF" />
      <path d="M18 26l6 7 6-7M16 42V32m16 10V32" />
      <path d="M15 13c0-6 4-10 9-10s9 4 9 10v4c0 6-4 10-9 10s-9-4-9-10z" fill="#FFFFFF" />
      <path d="M15 14c6 0 10-3 13-7 0 3 2 5 5 6" />
    </>,
    cloud: <>
      <path d="M12 33a9 9 0 0 1-1-18 13 13 0 0 1 25-1 10 10 0 0 1 0 20H12" fill="#EDF2FF" />
      <rect x="13" y="25" width="23" height="16" rx="3" fill="#FFFFFF" />
      <path d="M13 33h23M19 29h.1M19 37h.1M25 29h6M25 37h6" />
    </>,
    database: <>
      <path d="M7 11v26c0 5 34 5 34 0V11" fill="#EDF2FF" />
      <ellipse cx="24" cy="11" rx="17" ry="7" fill="#FFFFFF" />
      <path d="M7 23c0 8 34 8 34 0M7 35c0 8 34 8 34 0" />
      <path d="M13 21v2m0 10v2" strokeWidth="3.5" />
    </>,
    folder: <>
      <path d="M5 14a4 4 0 0 1 4-4h11l5 6h15a3 3 0 0 1 3 3v19H5z" fill="#EDF2FF" />
      <path d="M5 22h40l-6 17H5z" fill="#FFFFFF" />
      <path d="M12 30h15" stroke="#8BA6D2" />
    </>,
    document: <>
      <path d="M12 4h17l10 10v30H12z" fill="#FFFFFF" />
      <path d="M29 4v10h10" fill="#EDF2FF" />
      <path d="M18 23h15M18 30h15M18 37h9" />
      <path d="M8 10H5v34h7" stroke="#8BA6D2" />
    </>,
    code: <>
      <rect x="3" y="7" width="42" height="34" rx="5" fill="#FFFFFF" />
      <path d="M3 16h42" />
      <path d="M9 11.5h.1m5 0h.1m5 0h.1" strokeWidth="3" />
      <path d="M17 23l-5 5 5 5m14-10 5 5-5 5m-5-12-4 14" stroke="#1E49E2" />
    </>,
    checklist: <>
      <rect x="9" y="8" width="31" height="36" rx="4" fill="#FFFFFF" />
      <rect x="17" y="4" width="15" height="8" rx="2.5" fill="#EDF2FF" />
      <path d="M15 22l2 2 4-5m-6 15 2 2 4-5" stroke="#1E49E2" />
      <path d="M26 22h8M26 34h8" />
    </>,
    shield: <>
      <path d="M24 3c6 5 11 7 17 8v13c0 11-9 17-17 21C16 41 7 35 7 24V11c6-1 11-3 17-8z" fill="#EDF2FF" />
      <path d="M15 24l6 6 12-13" stroke="#1E49E2" strokeWidth="3.5" />
    </>,
    magnify: <>
      <circle cx="20" cy="19" r="14" fill="#EDF2FF" />
      <path d="M30 29l13 13" strokeWidth="6" />
      <path d="M12 25V19m7 6V13m7 12V16" stroke="#1E49E2" strokeWidth="3" />
    </>,
    table: <>
      <rect x="4" y="7" width="40" height="34" rx="4" fill="#FFFFFF" />
      <path d="M4 11a4 4 0 0 1 4-4h32a4 4 0 0 1 4 4v7H4z" fill="#EDF2FF" />
      <path d="M4 18h40M4 29h40M17 18v23M31 18v23" />
    </>,
    gear: <>
      <path d="M20 4h8l1 6 5 3 6-2 4 7-5 4v6l5 4-4 7-6-2-5 3-1 6h-8l-1-6-5-3-6 2-4-7 5-4v-6l-5-4 4-7 6 2 5-3z" fill="#EDF2FF" />
      <circle cx="24" cy="25" r="8" fill="#FFFFFF" />
      <circle cx="24" cy="25" r="2" fill="currentColor" stroke="none" />
    </>,
    arrow: <>
      <path d="M6 24h34M29 13l11 11-11 11" strokeWidth="3.5" />
    </>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" role={title ? "img" : undefined} aria-hidden={title ? undefined : true}
      style={{ color, flexShrink: 0, display: "block", ...style }} fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
      {title ? <title>{title}</title> : null}
      {artwork[kind]}
    </svg>
  );
};

export type DataTone = "bronze" | "silver" | "gold" | "source";

/** A shallow data tray: repeated record tiles, rim and stacked storage planes. */
export const DataTray = ({ label, tone, width = 260, style }: {
  label: string;
  tone: DataTone;
  width?: number;
  style?: CSSProperties;
}) => {
  const palette = {
    source: { line: "#00338D", top: "#EDF2FF", side: "#C7D7F1", front: "#E0E9FA" },
    bronze: { line: "#966342", top: "#FBF0E7", side: "#CDAA8B", front: "#E8D0BA" },
    silver: { line: "#627994", top: "#F2F5F9", side: "#B7C5D6", front: "#D9E1EC" },
    gold: { line: "#A47E24", top: "#FFF7DD", side: "#D7BB72", front: "#F0DFAB" },
  }[tone];
  return (
    <div style={{ width, display: "flex", flexDirection: "column", alignItems: "center", ...style }}>
      <svg width={width} height={width * 0.68} viewBox="0 0 320 218" aria-hidden="true" fill="none" strokeLinejoin="round" strokeLinecap="round">
        <ellipse cx="160" cy="198" rx="116" ry="12" fill="#0C233C" opacity="0.07" />
        <path d="M36 133l124-62 124 62-124 62z" fill={palette.top} stroke={palette.line} strokeWidth="2" />
        <path d="M36 133v13l124 62v-13z" fill={palette.front} stroke={palette.line} strokeWidth="2" />
        <path d="M160 195v13l124-62v-13z" fill={palette.side} stroke={palette.line} strokeWidth="2" />
        <path d="M36 107l124-62 124 62-124 62z" fill={palette.top} stroke={palette.line} strokeWidth="2.2" />
        <path d="M36 107v24l124 62v-24z" fill={palette.front} stroke={palette.line} strokeWidth="2.2" />
        <path d="M160 169v24l124-62v-24z" fill={palette.side} stroke={palette.line} strokeWidth="2.2" />
        <path d="M36 107V94l124-62 124 62v13L160 45z" fill={palette.front} stroke={palette.line} strokeWidth="2.2" />
        <path d="M36 94l124 62 124-62" stroke="#FFFFFF" strokeWidth="2" opacity="0.65" />

        <g stroke="#00338D" strokeWidth="1.6">
          <path d="M86 82l34-17 36 18-34 17z" fill="#FFFFFF" />
          <path d="M86 82v7l36 18v-7z" fill="#D9E5FB" />
          <path d="M122 100v7l34-17v-7z" fill="#8BA6D2" />
          <path d="M96 81l19-9m-10 15 19-9" stroke="#1E49E2" />

          <path d="M163 82l34-17 36 18-34 17z" fill="#FFFFFF" />
          <path d="M163 82v7l36 18v-7z" fill="#D9E5FB" />
          <path d="M199 100v7l34-17v-7z" fill="#8BA6D2" />
          <path d="M173 81l19-9m-10 15 19-9" stroke="#1E49E2" />

          <path d="M124 118l34-17 36 18-34 17z" fill="#FFFFFF" />
          <path d="M124 118v7l36 18v-7z" fill="#D9E5FB" />
          <path d="M160 136v7l34-17v-7z" fill="#8BA6D2" />
          <path d="M134 117l19-9m-10 15 19-9" stroke="#1E49E2" />
        </g>
        <path d="M47 114l113 57 113-57" stroke={palette.line} strokeWidth="2.2" />
        <path d="M61 143l51 25M61 169l51 25" stroke="#FFFFFF" strokeWidth="2" opacity="0.7" />
      </svg>
      <div style={{ fontFamily: "Open Sans", fontWeight: 600, fontSize: width * 0.13, lineHeight: 1.15, color: "#0C233C", marginTop: 7 }}>{label}</div>
    </div>
  );
};

/** Two illustrative teammates, never representations of actual project users. */
export const PersonPortrait = ({ variant, size = 128, style }: {
  variant: "first" | "second";
  size?: number;
  style?: CSSProperties;
}) => {
  const second = variant === "second";
  return (
    <svg width={size} height={size} viewBox="0 0 160 160" role="img" aria-label={second ? "Second teammate" : "First teammate"} style={{ display: "block", flexShrink: 0, ...style }}>
      <rect x="4" y="4" width="152" height="152" rx="40" fill={second ? "#EDF2FF" : "#E6EEF9"} />
      <path d="M18 148c3-29 21-44 62-44s59 15 62 44v8H18z" fill={second ? "#1E49E2" : "#00338D"} />
      <path d="M55 111l25 27 25-27-13-9H68z" fill="#FFFFFF" />
      <path d="M68 91h24v20c-5 9-19 9-24 0z" fill={second ? "#B77D5B" : "#DFA984"} />
      {second ? <>
        <circle cx="83" cy="31" r="20" fill="#193047" />
        <path d="M46 58c0-28 15-38 34-38 24 0 37 16 37 39v40H43z" fill="#193047" />
      </> : <path d="M47 65c-5-26 8-43 31-43 29 0 38 18 35 43z" fill="#253A51" />}
      <ellipse cx="49" cy="76" rx="7" ry="10" fill={second ? "#C58D68" : "#EFC29F"} />
      <ellipse cx="111" cy="76" rx="7" ry="10" fill={second ? "#C58D68" : "#EFC29F"} />
      <path d="M51 57c0-18 12-27 29-27s29 9 29 27v23c0 20-13 34-29 34S51 100 51 80z" fill={second ? "#C58D68" : "#EFC29F"} />
      {second ? <path d="M48 67c-3-26 11-43 33-43 22 0 34 17 32 40-11-3-18-11-22-23-9 13-23 21-43 26z" fill="#193047" /> : <path d="M48 67c-7-28 8-44 31-44 25 0 36 17 35 38-12-2-24-11-28-19-9 11-21 16-38 17z" fill="#253A51" />}
      <path d="M62 74h8m20 0h8" stroke="#253A51" strokeWidth="2.5" strokeLinecap="round" />
      <circle cx="67" cy="81" r="2.3" fill="#253A51" />
      <circle cx="93" cy="81" r="2.3" fill="#253A51" />
      <path d="M80 82l-2 9h5" fill="none" stroke={second ? "#A2674D" : "#C58C66"} strokeWidth="2" strokeLinecap="round" />
      <path d="M72 98c5 4 11 4 16 0" fill="none" stroke="#794B3C" strokeWidth="2.2" strokeLinecap="round" />
      <path d="M40 139v17m80-17v17" stroke="#FFFFFF" strokeOpacity="0.3" strokeWidth="2" />
    </svg>
  );
};
