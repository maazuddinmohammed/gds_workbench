// Generated from brief/v2/narration-plan.json by scripts/build_narration_v2.py.
// Static cue arrays keep video rendering independent of asynchronous fetching.
import type { Caption } from "@remotion/captions";

export const NARRATION_FPS = 30;
export const NARRATION_DURATION_SECONDS = 180;
export const NARRATION_DURATION_FRAMES = 5400;

export type NarrationSceneId = "ask" | "context" | "build" | "review" | "run" | "continue" | "close";

export type NarrationScene = {
  id: NarrationSceneId;
  name: string;
  durationSeconds: number;
  durationInFrames: number;
  audioSrc: string;
  captions: Caption[];
};

export const ASK_CAPTIONS: Caption[] = [
  {
    "text": "A data engineer opens Copilot and asks:",
    "startMs": 700,
    "endMs": 3495,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "“Build a Sales project from our customers and orders.”",
    "startMs": 4000,
    "endMs": 6953,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Atlas turns that request into a guided workflow.",
    "startMs": 9500,
    "endMs": 12504,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "The conversation stays in Copilot.",
    "startMs": 14500,
    "endMs": 16846,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  }
];

export const CONTEXT_CAPTIONS: Caption[] = [
  {
    "text": "First, Atlas brings in the project’s saved requirements and metadata.",
    "startMs": 800,
    "endMs": 4958,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Copilot reaches them through Atlas MCP.",
    "startMs": 6000,
    "endMs": 8761,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "A local snapshot gives the agent a working copy,",
    "startMs": 10000,
    "endMs": 13027,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "so it can build without repeatedly fetching the same context.",
    "startMs": 16000,
    "endMs": 19706,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  }
];

export const BUILD_CAPTIONS: Caption[] = [
  {
    "text": "The agent examines the source information",
    "startMs": 700,
    "endMs": 3206,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "and proposes how customers and orders fit together.",
    "startMs": 4000,
    "endMs": 6957,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "You see the Sales model take shape,",
    "startMs": 8000,
    "endMs": 10071,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "then the dimensional model for reporting.",
    "startMs": 13000,
    "endMs": 15158,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "From those models, Atlas prepares the mappings,",
    "startMs": 21500,
    "endMs": 24520,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "table definitions, transformation SQL, and validation checks",
    "startMs": 25000,
    "endMs": 29551,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "needed for delivery.",
    "startMs": 29731,
    "endMs": 31038,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  }
];

export const REVIEW_CAPTIONS: Caption[] = [
  {
    "text": "Now you review the proposed changes in Atlas Local Workbench.",
    "startMs": 700,
    "endMs": 4445,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Approve Stage in the chat,",
    "startMs": 5600,
    "endMs": 7164,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "and Atlas Bridge sends the draft for server validation.",
    "startMs": 9000,
    "endMs": 12108,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "After reviewing that result,",
    "startMs": 14000,
    "endMs": 15726,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "approve Apply separately.",
    "startMs": 17000,
    "endMs": 18576,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "The approved definitions become shared project state.",
    "startMs": 21000,
    "endMs": 24156,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Changes are protected and audited.",
    "startMs": 27000,
    "endMs": 28983,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  }
];

export const RUN_CAPTIONS: Caption[] = [
  {
    "text": "Your delivery process deploys those artifacts.",
    "startMs": 700,
    "endMs": 3734,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Then the GDS orchestrator does the processing:",
    "startMs": 5000,
    "endMs": 7959,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "source data lands in Bronze,",
    "startMs": 9000,
    "endMs": 10837,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "becomes structured Silver data,",
    "startMs": 13000,
    "endMs": 14920,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "and flows into Gold for reporting.",
    "startMs": 16000,
    "endMs": 17982,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Atlas also prepares validation checks to accompany those outputs.",
    "startMs": 20000,
    "endMs": 24141,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  }
];

export const CONTINUE_CAPTIONS: Caption[] = [
  {
    "text": "Later, another authorized teammate opens the same project",
    "startMs": 700,
    "endMs": 4361,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "and asks to add a new source.",
    "startMs": 5000,
    "endMs": 6842,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Atlas starts from the saved project knowledge.",
    "startMs": 9000,
    "endMs": 11609,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "The team can review the impact",
    "startMs": 13500,
    "endMs": 15335,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "and update the model, code, and checks.",
    "startMs": 17000,
    "endMs": 19781,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Atlas Platform shows the shared results.",
    "startMs": 23000,
    "endMs": 25679,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  }
];

export const CLOSE_CAPTIONS: Caption[] = [
  {
    "text": "That is the loop:",
    "startMs": 500,
    "endMs": 1462,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "ask, build, review, deliver, and improve.",
    "startMs": 3000,
    "endMs": 6386,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Atlas helps GDS move faster",
    "startMs": 7500,
    "endMs": 9842,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "while keeping project knowledge with the project.",
    "startMs": 12000,
    "endMs": 14696,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  }
];

export const NARRATION: NarrationScene[] = [
{
  "id": "ask",
  "name": "Ask",
  "durationSeconds": 20,
  "durationInFrames": 600,
  "audioSrc": "audio/v2/ask.wav",
  "captions": ASK_CAPTIONS
},
{
  "id": "context",
  "name": "Context",
  "durationSeconds": 24,
  "durationInFrames": 720,
  "audioSrc": "audio/v2/context.wav",
  "captions": CONTEXT_CAPTIONS
},
{
  "id": "build",
  "name": "Build",
  "durationSeconds": 32,
  "durationInFrames": 960,
  "audioSrc": "audio/v2/build.wav",
  "captions": BUILD_CAPTIONS
},
{
  "id": "review",
  "name": "Review",
  "durationSeconds": 32,
  "durationInFrames": 960,
  "audioSrc": "audio/v2/review.wav",
  "captions": REVIEW_CAPTIONS
},
{
  "id": "run",
  "name": "Run",
  "durationSeconds": 26,
  "durationInFrames": 780,
  "audioSrc": "audio/v2/run.wav",
  "captions": RUN_CAPTIONS
},
{
  "id": "continue",
  "name": "Continue",
  "durationSeconds": 28,
  "durationInFrames": 840,
  "audioSrc": "audio/v2/continue.wav",
  "captions": CONTINUE_CAPTIONS
},
{
  "id": "close",
  "name": "Close",
  "durationSeconds": 18,
  "durationInFrames": 540,
  "audioSrc": "audio/v2/close.wav",
  "captions": CLOSE_CAPTIONS
},
];
