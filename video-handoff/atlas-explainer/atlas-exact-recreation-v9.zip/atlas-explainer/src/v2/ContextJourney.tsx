import { AbsoluteFill, Easing, Interactive, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { SvgIcon } from "./Pictorials";

export const ContextJourney = ({standalone=false}: {standalone?:boolean}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <AbsoluteFill style={{fontFamily:"Open Sans",color:"#0C233C",backgroundColor:standalone?"#F8FAFD":undefined}}>
      <Interactive.Div name="Sales project lives centrally" premountFor={fps} style={{ position: "absolute", inset: 0,
        opacity: interpolate(frame, [0, 0.6 * fps, 4.8 * fps, 5.8 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }} aria-hidden="true">
          <path d="M1070 540h190q45 0 45-45v-84q0-61 61-61h108" fill="none" stroke="#CCD8EA" strokeWidth={3} strokeLinecap="round" pathLength={1} strokeDasharray={1}
            strokeDashoffset={interpolate(frame, [1.1 * fps, 2.5 * fps], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
        </svg>
        <div style={{ position: "absolute", left: 930, top: 470, width: 140 }}>
          <SvgIcon kind="folder" size={140} />
          <div style={{ textAlign: "center", marginTop: 12, fontSize: 32, fontWeight: 600, color: "#00338D" }}>Sales</div>
        </div>
      </Interactive.Div>

      <Interactive.Div name="Central saved project context in PostgreSQL" premountFor={fps} style={{ position: "absolute", left: 1460, top: 280, width: 140,
        opacity: interpolate(frame, [1.3 * fps, 2.4 * fps, 17.3 * fps, 18.5 * fps], [0, 1, 1, 0.48], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [1.3 * fps, 2.4 * fps], ["0px 14px", "0px 0px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.16, 1, 0.3, 1) }),
      }}>
        <SvgIcon kind="database" size={140} />
        <div style={{ width: 260, marginLeft: -60, textAlign: "center", marginTop: 12, fontSize: 32, fontWeight: 600, color: "#00338D" }}>PostgreSQL</div>
      </Interactive.Div>

      <Interactive.Div name="Atlas MCP hosted in Azure App Service" premountFor={fps} style={{ position: "absolute", left: 1030, top: 280, width: 140,
        opacity: interpolate(frame, [6 * fps, 6.8 * fps, 17.3 * fps, 18.5 * fps], [0, 1, 1, 0.48], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [6 * fps, 6.8 * fps], ["0px 14px", "0px 0px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.16, 1, 0.3, 1) }),
      }}>
        <SvgIcon kind="cloud" size={140} />
        <div style={{ width: 260, marginLeft: -60, textAlign: "center", marginTop: 12, fontSize: 32, fontWeight: 600, color: "#00338D" }}>Atlas MCP</div>
        <div style={{ width: 260, marginLeft: -60, textAlign: "center", marginTop: 7, fontSize: 20, color: "#52677C" }}>Azure App Service</div>
      </Interactive.Div>

      <Interactive.Div name="Agent requests saved context through Atlas MCP" premountFor={fps} style={{ position: "absolute", inset: 0,
        opacity: interpolate(frame, [9.9 * fps, 10.6 * fps], [1, 0.2], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }} aria-hidden="true" fill="none" strokeLinecap="round" strokeLinejoin="round">
          <path d="M856 332h170" stroke="#B9C9DF" strokeWidth={3} pathLength={1} strokeDasharray={1}
            strokeDashoffset={interpolate(frame, [6.5 * fps, 7 * fps], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
          <path d="M1014 324l12 8-12 8" stroke="#8BA6D2" strokeWidth={3}
            opacity={interpolate(frame, [6.9 * fps, 7 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
          <path d="M1175 332h295" stroke="#B9C9DF" strokeWidth={3} pathLength={1} strokeDasharray={1}
            strokeDashoffset={interpolate(frame, [7.5 * fps, 8.1 * fps], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
          <path d="M1458 324l12 8-12 8" stroke="#8BA6D2" strokeWidth={3}
            opacity={interpolate(frame, [8 * fps, 8.1 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
          <path d="M856 332h170" stroke="#1E49E2" strokeWidth={7} pathLength={1} strokeDasharray="0.15 1"
            strokeDashoffset={interpolate(frame, [7.1 * fps, 8 * fps], [0, -0.85], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })}
            opacity={interpolate(frame, [7.05 * fps, 7.2 * fps, 7.9 * fps, 8.1 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
          <path d="M1175 332h295" stroke="#1E49E2" strokeWidth={7} pathLength={1} strokeDasharray="0.09 1"
            strokeDashoffset={interpolate(frame, [8.3 * fps, 9.7 * fps], [0, -0.91], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })}
            opacity={interpolate(frame, [8.2 * fps, 8.4 * fps, 9.6 * fps, 9.85 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
        </svg>
      </Interactive.Div>

      <Interactive.Div name="Saved context returns through Atlas MCP" premountFor={fps} style={{ position: "absolute", inset: 0,
        opacity: interpolate(frame, [17.3 * fps, 18.5 * fps], [1, 0.22], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }} aria-hidden="true" fill="none" strokeLinecap="round" strokeLinejoin="round">
          <path d="M1470 378H1175" stroke="#B9C9DF" strokeWidth={3} pathLength={1} strokeDasharray={1}
            strokeDashoffset={interpolate(frame, [10.1 * fps, 10.9 * fps], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
          <path d="M1187 370l-12 8 12 8" stroke="#8BA6D2" strokeWidth={3}
            opacity={interpolate(frame, [10.8 * fps, 10.9 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
          <path d="M1470 378H1175" stroke="#1E49E2" strokeWidth={7} pathLength={1} strokeDasharray="0.09 1"
            strokeDashoffset={interpolate(frame, [11.1 * fps, 13 * fps], [0, -0.91], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })}
            opacity={interpolate(frame, [11 * fps, 11.2 * fps, 12.9 * fps, 13.15 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
          <path d="M1155 400h15q40 0 40 40v170q0 40 30 40" stroke="#B9C9DF" strokeWidth={3} pathLength={1} strokeDasharray={1}
            strokeDashoffset={interpolate(frame, [13.2 * fps, 14.1 * fps], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
          <path d="M1228 642l12 8-12 8" stroke="#8BA6D2" strokeWidth={3}
            opacity={interpolate(frame, [14 * fps, 14.1 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
          <path d="M1155 400h15q40 0 40 40v170q0 40 30 40" stroke="#1E49E2" strokeWidth={7} pathLength={1} strokeDasharray="0.085 1"
            strokeDashoffset={interpolate(frame, [14.3 * fps, 16.7 * fps], [0, -0.915], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })}
            opacity={interpolate(frame, [14.2 * fps, 14.4 * fps, 16.6 * fps, 16.9 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
        </svg>
      </Interactive.Div>

      <Interactive.Div name="Reuse a local metadata snapshot" premountFor={fps} style={{ position: "absolute", left: 1230, top: 580, width: 140,
        opacity: interpolate(frame, [14.6 * fps, 15.5 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [14.6 * fps, 15.5 * fps], ["0px 12px", "0px 0px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.16, 1, 0.3, 1) }),
      }}>
        <SvgIcon kind="folder" size={140} />
        <div style={{ width: 280, marginLeft: -70, textAlign: "center", marginTop: 12, fontSize: 32, fontWeight: 600, color: "#00338D" }}>Local snapshot</div>
        <Interactive.Div name="Local context is reused" premountFor={fps} style={{ position: "absolute", left: 160, top: 37, width: 68, height: 68,
          opacity: interpolate(frame, [17.2 * fps, 18.2 * fps], [0, 0.85], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
          rotate: interpolate(frame, [18.2 * fps, 23 * fps], ["-18deg", "24deg"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.4, 0, 0.2, 1) }),
        }}>
          <svg width={68} height={68} viewBox="0 0 68 68" fill="none" aria-hidden="true" stroke="#1E49E2" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round">
            <path d="M53 21a24 24 0 1 0 5 23M42 21h12V9" />
          </svg>
        </Interactive.Div>
      </Interactive.Div>
    </AbsoluteFill>
  );
};
