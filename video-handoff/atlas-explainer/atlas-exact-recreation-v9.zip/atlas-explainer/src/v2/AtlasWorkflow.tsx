import { AbsoluteFill, Easing, Img, Interactive, interpolate, Sequence, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { BuildJourney } from "./BuildJourney";
import { ContextJourney } from "./ContextJourney";
import { ReviewJourney } from "./ReviewJourney";
import { RunJourney } from "./RunJourney";
import { ContinueJourney } from "./ContinueJourney";
import { CloseJourney } from "./CloseJourney";
import { CopilotChat, ProjectPacket, WorkflowRail } from "./Interface";
import { AskNarration, ContextNarration, BuildNarration, ReviewNarration, RunNarration, ContinueNarration, CloseNarration } from "./SceneNarration";

export const AtlasWorkflow = ({showCaptions=false}: {showCaptions?:boolean}) => {
  const f=useCurrentFrame();const {fps}=useVideoConfig();const t=f/fps;
  const title=t<20?"Start with a conversation.":t<44?"Bring the context.":t<76?"Watch the model take shape.":t<108?"Review. Then approve.":t<134?"Put the work to use.":t<162?"Pick up where the team left off.":"";
  return <AbsoluteFill style={{background:"#F8FAFD",fontFamily:"Open Sans",color:"#0C233C"}}>
    <div style={{position:"absolute",inset:"0 0 180px",background:"radial-gradient(ellipse at 70% 40%,#FFFFFF 0%,#F8FAFD 70%)"}}/>
    <div style={{position:"absolute",left:112,top:62,display:"flex",alignItems:"center",gap:12,color:"#00338D",fontSize:31,fontWeight:600}}><Img src={staticFile("atlas.svg")} style={{width:42,height:42}}/>Atlas</div>
    <div style={{position:"absolute",right:112,top:77,fontSize:17,color:"#8C98A9",letterSpacing:.3}}>Illustrative workflow</div>
    <Interactive.Div name="Current workflow beat" style={{position:"absolute",left:144,top:153,fontSize:48,lineHeight:1.2,fontWeight:600,letterSpacing:-1.2,opacity:interpolate(t,[107.5,109,133,134.5],[1,0,0,1],{extrapolateLeft:"clamp",extrapolateRight:"clamp"})}}>{title}</Interactive.Div>

    <CopilotChat/>
    <Sequence durationInFrames={600} name="01 Ask in Copilot">
      <Interactive.Div name="Request becomes Sales project" style={{position:"absolute",left:1200,top:440,opacity:interpolate(f,[15*fps,17*fps],[0,1],{extrapolateLeft:"clamp",extrapolateRight:"clamp"}),translate:interpolate(f,[15*fps,18*fps],["-70px 0px","0px 0px"],{extrapolateLeft:"clamp",extrapolateRight:"clamp",easing:Easing.bezier(.22,1,.36,1)})}}><ProjectPacket size={200}/></Interactive.Div>
      <AskNarration showCaptions={showCaptions}/>
    </Sequence>
    <Sequence from={600} durationInFrames={720} name="02 Bring project context"><ContextJourney/><ContextNarration showCaptions={showCaptions}/></Sequence>
    <Sequence from={1320} durationInFrames={960} name="03 Build models and files"><BuildJourney/><BuildNarration showCaptions={showCaptions}/></Sequence>
    <Sequence from={2280} durationInFrames={960} name="04 Review Stage and Apply"><ReviewJourney/><ReviewNarration showCaptions={showCaptions}/></Sequence>
    <Sequence from={3240} durationInFrames={780} name="05 Deliver and run GDS"><RunJourney/><RunNarration showCaptions={showCaptions}/></Sequence>
    <Sequence from={4020} durationInFrames={840} name="06 Continue as a team"><ContinueJourney/><ContinueNarration showCaptions={showCaptions}/></Sequence>
    <Sequence from={4860} durationInFrames={540} name="07 Close the loop"><CloseJourney/><CloseNarration showCaptions={showCaptions}/></Sequence>
    <WorkflowRail/>
  </AbsoluteFill>;
};
