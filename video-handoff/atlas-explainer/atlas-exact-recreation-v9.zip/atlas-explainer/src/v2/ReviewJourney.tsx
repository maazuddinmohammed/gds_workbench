import { Easing, Img, Interactive, interpolate, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { SvgIcon } from "./Pictorials";

/** Review locally, inspect the server draft, then publish the approved project context. */
export const ReviewJourney = ({standalone=false}: {standalone?:boolean}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <Interactive.Div name="Review and shared project journey" style={{ position: "absolute", inset: 0, backgroundColor:standalone?"#F8FAFD":undefined, fontFamily: "Open Sans", color: "#00338D" }}>
      <Interactive.Div name="Atlas Local Workbench model review" style={{
        position: "absolute", left: 910, top: 300, width: 820, height: 460,
        border: "1.5px solid #C7D7F1", borderRadius: 20, backgroundColor: "#FFFFFF", overflow: "hidden",
        boxShadow: "0 25px 70px rgba(0,51,141,0.10)", transformOrigin: "center center",
        opacity: interpolate(frame, [0, 0.7 * fps, 6 * fps, 6.6 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        scale: interpolate(frame, [0, 0.9 * fps, 6 * fps, 6.6 * fps], [0.96, 1, 1, 0.78], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
        translate: interpolate(frame, [6 * fps, 6.6 * fps], ["0px 0px", "-60px 40px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
      }}>
        <div style={{ height: 73, borderBottom: "1px solid #D9E5F7", backgroundColor: "#F6F9FE", display: "flex", alignItems: "center", padding: "0 30px", gap: 16 }}>
          <Img src={staticFile("atlas.svg")} style={{width:30,height:30}}/>
          <div style={{ fontSize: 28, fontWeight: 600 }}>Atlas Local Workbench</div>
          <div style={{ marginLeft: "auto", width: 8, height: 8, borderRadius: "50%", backgroundColor: "#A9BADD" }} />
          <div style={{ width: 8, height: 8, borderRadius: "50%", backgroundColor: "#A9BADD" }} />
        </div>
        <div style={{ position: "absolute", left: 36, top: 98, fontSize: 31, fontWeight: 600 }}>Sales <span style={{ color: "#A9BADD", fontWeight: 400 }}>/</span> Model</div>
        <div style={{ position: "absolute", right: 36, top: 106, fontSize: 22, color: "#627994" }}>Review</div>
        <svg width="820" height="300" viewBox="0 0 820 300" aria-hidden="true" style={{ position: "absolute", left: 0, top: 150 }}>
          <path d="M311 103H519" fill="none" stroke="#A9BADD" strokeWidth="3" />
          <path d="M322 91v24m186-24-18 12 18 12m-18-12h28" fill="none" stroke="#00338D" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <Interactive.Div name="Selected Customers model" style={{ position: "absolute", left: 115, top: 164, width: 198, display: "flex", flexDirection: "column", alignItems: "center" }}>
          <div style={{ width: 178, height: 174, borderRadius: 17, backgroundColor: "#EDF2FF", display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
            <SvgIcon kind="table" size={142} />
            <div style={{ position: "absolute", inset: -7, border: "3px solid #1E49E2", borderRadius: 22,
              opacity: interpolate(frame, [1 * fps, 1.7 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
            }} />
          </div>
          <div style={{ marginTop: 18, fontSize: 28, fontWeight: 600 }}>Customers</div>
        </Interactive.Div>
        <Interactive.Div name="Related Orders model" style={{ position: "absolute", left: 515, top: 164, width: 198, display: "flex", flexDirection: "column", alignItems: "center" }}>
          <div style={{ width: 178, height: 174, borderRadius: 17, backgroundColor: "#F2F5FB", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <SvgIcon kind="table" size={142} />
          </div>
          <div style={{ marginTop: 18, fontSize: 28, fontWeight: 600 }}>Orders</div>
        </Interactive.Div>
      </Interactive.Div>

      <Interactive.Div name="Atlas Bridge connector" style={{ position: "absolute", left: 1084, top: 416, width: 260, height: 280, display: "flex", flexDirection: "column", alignItems: "center",
        opacity: interpolate(frame, [6.8 * fps, 7.4 * fps, 11.4 * fps, 12.3 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [6.8 * fps, 7.6 * fps], ["0px 20px", "0px 0px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
      }}>
        <svg width="260" height="200" viewBox="0 0 260 200" aria-hidden="true" fill="none" strokeLinecap="round" strokeLinejoin="round">
          <ellipse cx="130" cy="180" rx="111" ry="12" fill="#00338D" opacity="0.05" />
          <path d="M17 141h226" stroke="#C7D7F1" strokeWidth="9" />
          <path d="M51 158V77a79 79 0 0 1 158 0v81" stroke="#00338D" strokeWidth="12" />
          <path d="M51 77a79 79 0 0 1 158 0" stroke="#1E49E2" strokeWidth="12" />
          <path d="M79 35v105M104 17v123M130 11v129M156 17v123M181 35v105" stroke="#A9BADD" strokeWidth="4" />
          <path d="M17 141h226" stroke="#1E49E2" strokeWidth="5" />
          <rect x="37" y="153" width="28" height="18" rx="3" fill="#EDF2FF" stroke="#00338D" strokeWidth="3" />
          <rect x="195" y="153" width="28" height="18" rx="3" fill="#EDF2FF" stroke="#00338D" strokeWidth="3" />
        </svg>
        <div style={{ marginTop: 25, fontSize: 29, fontWeight: 600 }}>Atlas Bridge</div>
      </Interactive.Div>

      <Interactive.Div name="Server draft cloud" style={{ position: "absolute", left: 1450, top: 388, width: 240, height: 270, display: "flex", flexDirection: "column", alignItems: "center",
        opacity: interpolate(frame, [7.4 * fps, 8.4 * fps, 23 * fps, 24 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [13.2 * fps, 14.4 * fps], ["0px 0px", "-420px 0px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
      }}>
        <SvgIcon kind="cloud" size={230} />
        <div style={{ marginTop: 20, fontSize: 29, fontWeight: 600 }}>Server draft</div>
        <div style={{ position: "absolute", left: 94, top: 129, width: 56, height: 56, borderRadius: 10, backgroundColor: "#FFFFFF", display: "flex", alignItems: "center", justifyContent: "center",
          opacity: interpolate(frame, [10 * fps, 10.7 * fps, 17 * fps, 17.7 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        }}><SvgIcon kind="folder" size={48} /></div>
      </Interactive.Div>

      <Interactive.Div name="Sales packet crosses Atlas Bridge" style={{ position: "absolute", left: 930, top: 455, width: 130, height: 130, display: "flex", justifyContent: "center",
        opacity: interpolate(frame, [6.5 * fps, 7.1 * fps, 10.2 * fps, 10.8 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [7.1 * fps, 10.5 * fps], ["0px 0px", "575px 18px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.45, 0, 0.55, 1) }),
        scale: interpolate(frame, [9.8 * fps, 10.8 * fps], [1, 0.48], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <div style={{ position: "absolute", width: 112, height: 92, top: 18, borderRadius: 18, backgroundColor: "#FFFFFF", boxShadow: "0 8px 24px rgba(0,51,141,0.12)" }} />
        <SvgIcon kind="folder" size={124} style={{ position: "relative" }} />
      </Interactive.Div>

      <Interactive.Div name="Server validation review result" style={{ position: "absolute", left: 1450, top: 412, width: 240, height: 260, display: "flex", flexDirection: "column", alignItems: "center",
        opacity: interpolate(frame, [14 * fps, 14.7 * fps, 16.7 * fps, 17.3 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [14 * fps, 15 * fps], ["0px 20px", "0px 0px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
      }}>
        <SvgIcon kind="checklist" size={182} />
        <div style={{ marginTop: 26, fontSize: 29, fontWeight: 600 }}>Review result</div>
      </Interactive.Div>

      <Interactive.Svg name="Approved project transfer path" width={270} height={70} viewBox="0 0 270 70" aria-hidden="true" style={{ position: "absolute", left: 1250, top: 475,
        opacity: interpolate(frame, [17.2 * fps, 18 * fps, 22 * fps, 23 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <path d="M8 35h224m-15-11 16 11-16 11" fill="none" stroke="#A9BADD" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
      </Interactive.Svg>

      <Interactive.Div name="PostgreSQL shared project" style={{ position: "absolute", left: 1450, top: 398, width: 240, height: 300, display: "flex", flexDirection: "column", alignItems: "center",
        opacity: interpolate(frame, [17.3 * fps, 18.3 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [23 * fps, 24.5 * fps], ["0px 0px", "-220px 0px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
      }}>
        <SvgIcon kind="database" size={230} />
        <div style={{ position: "absolute", left: 79, top: 113, width: 82, height: 75, borderRadius: 12, backgroundColor: "#EDF2FF", display: "flex", alignItems: "center", justifyContent: "center",
          opacity: interpolate(frame, [22 * fps, 23 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
          scale: interpolate(frame, [22 * fps, 23.2 * fps], [0.65, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
        }}><SvgIcon kind="folder" size={74} /></div>
        <div style={{ position: "relative", width: 310, height: 50, marginTop: 24, fontSize: 29, lineHeight: 1.2, fontWeight: 600, textAlign: "center" }}>
          <div style={{ position: "absolute", inset: 0,
            opacity: interpolate(frame, [22.7 * fps, 23.5 * fps], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
          }}>PostgreSQL</div>
          <div style={{ position: "absolute", inset: 0,
            opacity: interpolate(frame, [23.5 * fps, 24.3 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
          }}>Shared project</div>
        </div>
      </Interactive.Div>

      <Interactive.Div name="Approved packet reaches shared PostgreSQL" style={{ position: "absolute", left: 1085, top: 453, width: 130, height: 130, display: "flex", justifyContent: "center",
        opacity: interpolate(frame, [17.8 * fps, 18.4 * fps, 21.8 * fps, 22.7 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [18.4 * fps, 22.4 * fps], ["0px 0px", "420px 24px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.45, 0, 0.55, 1) }),
        scale: interpolate(frame, [21.5 * fps, 22.7 * fps], [1, 0.55], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <div style={{ position: "absolute", width: 112, height: 92, top: 18, borderRadius: 18, backgroundColor: "#FFFFFF", boxShadow: "0 8px 24px rgba(0,51,141,0.12)" }} />
        <SvgIcon kind="folder" size={124} style={{ position: "relative" }} />
      </Interactive.Div>

      <Interactive.Div name="Shared project protection" style={{ position: "absolute", left: 1000, top: 459, width: 150, display: "flex", justifyContent: "center",
        opacity: interpolate(frame, [27 * fps, 28 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [27 * fps, 28.2 * fps], ["35px 0px", "0px 0px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
      }}><SvgIcon kind="shield" size={120} /></Interactive.Div>

      <Interactive.Div name="Shared project audit history" style={{ position: "absolute", left: 1545, top: 459, width: 150, display: "flex", flexDirection: "column", alignItems: "center",
        opacity: interpolate(frame, [27.5 * fps, 28.5 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [27.5 * fps, 28.7 * fps], ["-35px 0px", "0px 0px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
      }}>
        <SvgIcon kind="document" size={120} />
        <div style={{ marginTop: 18, fontSize: 26, fontWeight: 600 }}>Audit</div>
      </Interactive.Div>
    </Interactive.Div>
  );
};
