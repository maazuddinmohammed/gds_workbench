import { Easing, Interactive, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { SvgIcon } from "./Pictorials";

/** The same Sales project moves from source tables to models to reviewed files. */
export const BuildJourney = ({standalone=false}: {standalone?:boolean}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <Interactive.Div name="Sales build journey" style={{ position: "absolute", inset: 0, backgroundColor:standalone?"#F8FAFD":undefined, fontFamily: "Open Sans", color: "#00338D" }}>
      <Interactive.Div name="Sales project packet" style={{
        position: "absolute", left: 1200, top: 266, width: 240, height: 240,
        display: "flex", flexDirection: "column", alignItems: "center", transformOrigin: "center top",
        scale: interpolate(frame, [0, 21.5 * fps, 23 * fps], [0.65, 0.65, 1.25], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
        translate: interpolate(frame, [21.5 * fps, 23 * fps], ["0px 0px", "0px 195px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
      }}>
        <svg width="190" height="170" viewBox="0 0 190 170" aria-hidden="true" style={{ position: "absolute", top: 0,
          opacity: interpolate(frame, [24.5 * fps, 25.5 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        }}>
          <rect x="49" y="10" width="89" height="115" rx="5" fill="#E1EAFB" stroke="#8BA6D2" strokeWidth="2" transform="rotate(-8 93 80)" />
          <rect x="58" y="5" width="89" height="115" rx="5" fill="#FFFFFF" stroke="#8BA6D2" strokeWidth="2" transform="rotate(7 102 80)" />
          <path d="M76 30h50M76 42h50M76 54h34" stroke="#C7D7F1" strokeWidth="4" strokeLinecap="round" />
        </svg>
        <SvgIcon kind="folder" size={180} style={{ position: "relative" }} />
        <div style={{ fontSize: 32, lineHeight: 1, fontWeight: 600, marginTop: -14 }}>Sales</div>
        <Interactive.Div name="Sales packet ready" style={{ position: "absolute", right: 17, top: 110,
          opacity: interpolate(frame, [30 * fps, 30.6 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
          scale: interpolate(frame, [30 * fps, 30.8 * fps], [0.6, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
        }}>
          <svg width="48" height="48" viewBox="0 0 48 48" aria-hidden="true">
            <circle cx="24" cy="24" r="22" fill="#1E49E2" stroke="#FFFFFF" strokeWidth="4" />
            <path d="M14 24l7 7 13-15" fill="none" stroke="#FFFFFF" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </Interactive.Div>
      </Interactive.Div>

      <Interactive.Svg name="Customers and Orders relationship" width={920} height={480} viewBox="0 0 920 480" aria-hidden="true" style={{
        position: "absolute", left: 850, top: 330,
        opacity: interpolate(frame, [5.7 * fps, 6.4 * fps, 12.5 * fps, 13.3 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <Interactive.Path name="Relationship draws across tables" d="M326 228H578" fill="none" stroke="#1E49E2" strokeWidth="4" strokeLinecap="round" strokeDasharray="252" style={{
          strokeDashoffset: interpolate(frame, [5.7 * fps, 6.7 * fps], [252, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
        }} />
        <path d="M336 216v24m234-24-17 12 17 12m-17-12h23" fill="none" stroke="#1E49E2" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
      </Interactive.Svg>

      <Interactive.Svg name="Gold star connections" width={920} height={490} viewBox="0 0 920 490" aria-hidden="true" style={{ position: "absolute", left: 850, top: 330,
        opacity: interpolate(frame, [14.5 * fps, 15.4 * fps, 21.1 * fps, 21.9 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <path d="M254 150L434 285M686 150L506 285" fill="none" stroke="#A9BADD" strokeWidth="4" strokeLinecap="round" />
        <Interactive.Path name="Gold relationships become visible" d="M254 150L434 285M686 150L506 285" fill="none" stroke="#1E49E2" strokeWidth="4" strokeLinecap="round" strokeDasharray="500" style={{
          strokeDashoffset: interpolate(frame, [14.5 * fps, 16.2 * fps], [500, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        }} />
      </Interactive.Svg>

      <Interactive.Div name="Customers source becomes dimension" style={{ position: "absolute", left: 964, top: 452, width: 220, display: "flex", flexDirection: "column", alignItems: "center",
        opacity: interpolate(frame, [0, 0.7 * fps, 21.1 * fps, 21.9 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [0, 0.9 * fps, 12.5 * fps, 14 * fps], ["0px 24px", "0px 0px", "0px 0px", "0px -90px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
      }}>
        <div style={{ width: 174, height: 174, borderRadius: 28, backgroundColor: "#EDF2FF", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 14px 30px rgba(0,51,141,0.07)" }}>
          <SvgIcon kind="table" size={142} />
        </div>
        <div style={{ fontSize: 30, lineHeight: 1.2, fontWeight: 600, marginTop: 14 }}>Customers</div>
      </Interactive.Div>

      <Interactive.Div name="Orders source becomes Sales fact" style={{ position: "absolute", left: 1435, top: 452, width: 220, display: "flex", flexDirection: "column", alignItems: "center",
        opacity: interpolate(frame, [0.45 * fps, 1.2 * fps, 21.1 * fps, 21.9 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [0.45 * fps, 1.3 * fps, 12.5 * fps, 14 * fps], ["0px 24px", "0px 0px", "0px 0px", "-225px 91px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
      }}>
        <div style={{ width: 174, height: 174, borderRadius: 28, backgroundColor: "#EDF2FF", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 14px 30px rgba(0,51,141,0.07)", position: "relative" }}>
          <SvgIcon kind="table" size={142} />
          <div style={{ position: "absolute", inset: 0, borderRadius: 28, border: "3px solid #A47E24", boxShadow: "0 0 0 8px #FFF7DD",
            opacity: interpolate(frame, [14 * fps, 15 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
          }} />
        </div>
        <div style={{ position: "relative", width: 220, height: 44, marginTop: 14, textAlign: "center", fontSize: 30, lineHeight: 1.2, fontWeight: 600 }}>
          <div style={{ position: "absolute", inset: 0, opacity: interpolate(frame, [13 * fps, 13.6 * fps], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>Orders</div>
          <div style={{ position: "absolute", inset: 0, opacity: interpolate(frame, [13.6 * fps, 14.2 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>Sales</div>
        </div>
      </Interactive.Div>

      <Interactive.Div name="Date dimension joins Gold star" style={{ position: "absolute", left: 1435, top: 362, width: 220, display: "flex", flexDirection: "column", alignItems: "center",
        opacity: interpolate(frame, [14 * fps, 15 * fps, 21.1 * fps, 21.9 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [14 * fps, 15.3 * fps], ["0px 24px", "0px 0px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
      }}>
        <div style={{ width: 174, height: 174, borderRadius: 28, backgroundColor: "#EDF2FF", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 14px 30px rgba(0,51,141,0.07)" }}>
          <svg width="134" height="134" viewBox="0 0 134 134" aria-hidden="true" fill="none" stroke="#00338D" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round">
            <rect x="18" y="24" width="98" height="92" rx="9" fill="#FFFFFF" />
            <path d="M18 49h98M43 16v18M91 16v18" />
            <path d="M40 71h10m17 0h10m17 0h1M40 94h10m17 0h10" stroke="#1E49E2" strokeWidth="7" />
          </svg>
        </div>
        <div style={{ fontSize: 30, lineHeight: 1.2, fontWeight: 600, marginTop: 14 }}>Date</div>
      </Interactive.Div>

      <Interactive.Div name="Examine source tables" style={{ position: "absolute", left: 1040, top: 390,
        opacity: interpolate(frame, [1.5 * fps, 2.1 * fps, 5.2 * fps, 5.8 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [1.5 * fps, 2.5 * fps, 4 * fps, 5.2 * fps], ["0px 0px", "35px 20px", "440px 0px", "470px 20px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.45, 0, 0.55, 1) }),
        rotate: interpolate(frame, [1.5 * fps, 5.2 * fps], ["-9deg", "9deg"], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <SvgIcon kind="magnify" size={132} style={{ filter: "drop-shadow(0 10px 12px rgba(0,51,141,0.14))" }} />
      </Interactive.Div>

      <Interactive.Div name="Silver model label" style={{ position: "absolute", left: 1160, top: 735, width: 320, textAlign: "center", fontSize: 30, fontWeight: 600, color: "#627994",
        opacity: interpolate(frame, [7 * fps, 8 * fps, 12 * fps, 13 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>Silver model</Interactive.Div>
      <Interactive.Div name="Gold model label" style={{ position: "absolute", left: 1160, top: 783, width: 320, textAlign: "center", fontSize: 29, fontWeight: 600, color: "#A47E24",
        opacity: interpolate(frame, [15 * fps, 16 * fps, 21 * fps, 21.8 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>Gold model</Interactive.Div>

      <Interactive.Div name="Mapping document enters Sales packet" style={{ position: "absolute", left: 960, top: 460, width: 180, display: "flex", flexDirection: "column", alignItems: "center",
        opacity: interpolate(frame, [22.1 * fps, 22.8 * fps, 25 * fps, 25.7 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [22.1 * fps, 22.8 * fps, 24.7 * fps, 25.7 * fps], ["-25px 10px", "0px 0px", "0px 0px", "275px -10px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
        scale: interpolate(frame, [24.7 * fps, 25.7 * fps], [1, 0.25], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <SvgIcon kind="document" size={150} />
        <div style={{ fontSize: 30, fontWeight: 600, marginTop: 16 }}>Mapping</div>
      </Interactive.Div>
      <Interactive.Div name="DDL document enters Sales packet" style={{ position: "absolute", left: 1500, top: 460, width: 180, display: "flex", flexDirection: "column", alignItems: "center",
        opacity: interpolate(frame, [22.8 * fps, 23.5 * fps, 25.2 * fps, 25.9 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [22.8 * fps, 23.5 * fps, 24.9 * fps, 25.9 * fps], ["25px 10px", "0px 0px", "0px 0px", "-275px -10px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
        scale: interpolate(frame, [24.9 * fps, 25.9 * fps], [1, 0.25], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <SvgIcon kind="code" size={150} />
        <div style={{ fontSize: 30, fontWeight: 600, marginTop: 16 }}>DDL</div>
      </Interactive.Div>
      <Interactive.Div name="SQL document enters Sales packet" style={{ position: "absolute", left: 960, top: 460, width: 180, display: "flex", flexDirection: "column", alignItems: "center",
        opacity: interpolate(frame, [26 * fps, 26.7 * fps, 29 * fps, 29.7 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [26 * fps, 26.7 * fps, 28.7 * fps, 29.7 * fps], ["-25px 10px", "0px 0px", "0px 0px", "275px -10px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
        scale: interpolate(frame, [28.7 * fps, 29.7 * fps], [1, 0.25], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <SvgIcon kind="code" size={150} />
        <div style={{ fontSize: 30, fontWeight: 600, marginTop: 16 }}>SQL</div>
      </Interactive.Div>
      <Interactive.Div name="Validation checks enter Sales packet" style={{ position: "absolute", left: 1500, top: 460, width: 180, display: "flex", flexDirection: "column", alignItems: "center",
        opacity: interpolate(frame, [26.7 * fps, 27.4 * fps, 29.2 * fps, 29.9 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [26.7 * fps, 27.4 * fps, 28.9 * fps, 29.9 * fps], ["25px 10px", "0px 0px", "0px 0px", "-275px -10px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.22, 1, 0.36, 1) }),
        scale: interpolate(frame, [28.9 * fps, 29.9 * fps], [1, 0.25], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <SvgIcon kind="checklist" size={150} />
        <div style={{ fontSize: 30, fontWeight: 600, marginTop: 16 }}>Checks</div>
      </Interactive.Div>
    </Interactive.Div>
  );
};
