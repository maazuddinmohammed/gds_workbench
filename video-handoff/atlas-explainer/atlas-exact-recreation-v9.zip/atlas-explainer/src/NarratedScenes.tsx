// Generated from brief/narration-plan.json by scripts/build_narration.py.
// Each authored scene keeps its own audio and captions on the same timeline.
import { AbsoluteFill, Img, Sequence, staticFile, useVideoConfig } from "remotion";
import { Audio } from "@remotion/media";
import { BasicCaptions } from "./basic-captions.element";
import { OpeningScene } from "./scenes/OpeningScene";
import { ArchitectureScene } from "./scenes/ArchitectureScene";
import { DiscoveryScene } from "./scenes/DiscoveryScene";
import { ModelingScene } from "./scenes/ModelingScene";
import { ReviewScene } from "./scenes/ReviewScene";
import { DeliveryScene } from "./scenes/DeliveryScene";
import { ContinuityScene } from "./scenes/ContinuityScene";
import { MaintenanceScene } from "./scenes/MaintenanceScene";
import { FutureScene } from "./scenes/FutureScene";


export const NarratedOpening = () => {
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill style={{backgroundColor: "#FFFFFF"}}>
      <OpeningScene />
      <Sequence name="Brand lead-in" durationInFrames={3 * fps} premountFor={fps}>
        <AbsoluteFill style={{backgroundColor: "#FFFFFF", justifyContent: "center", alignItems: "center", gap: 30, color: "#00338D", fontFamily: "Open Sans"}}>
          <Img src={staticFile("atlas.svg")} alt="Atlas" premountFor={fps} style={{width: 126, height:126}} />
          <div style={{fontSize:90, fontWeight:600, letterSpacing:7}}>ATLAS</div>
          <div style={{fontSize:34, color:"#52677C"}}>Build for GDS.</div>
        </AbsoluteFill>
      </Sequence>
      <Audio name="Opening narration" src={staticFile("audio/opening.wav")} premountFor={fps} />
      <BasicCaptions
        name="Opening captions"
        premountFor={fps}
        width={3000}
        combineTokensWithinMilliseconds={0}
        style={{position:"absolute", left:210, bottom:30, scale:0.5, transformOrigin:"left bottom"}}
        captions={[
  {
    "text": "Every GDS project needs three things:",
    "startMs": 500,
    "endMs": 3109,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "metadata, table definitions, and transformation code.",
    "startMs": 3300,
    "endMs": 7159,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Atlas helps teams build and maintain them together—",
    "startMs": 7339,
    "endMs": 10110,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "turning project requirements into the ingredients GDS needs to ingest, process, and deliver data.",
    "startMs": 10290,
    "endMs": 16792,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  }
]}
      />
    </AbsoluteFill>
  );
};


export const NarratedArchitecture = () => {
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill style={{backgroundColor: "#FFFFFF"}}>
      <ArchitectureScene />
      <Audio name="Architecture narration" src={staticFile("audio/architecture.wav")} premountFor={fps} />
      <BasicCaptions
        name="Architecture captions"
        premountFor={fps}
        width={3000}
        combineTokensWithinMilliseconds={0}
        style={{position:"absolute", left:210, bottom:30, scale:0.5, transformOrigin:"left bottom"}}
        captions={[
  {
    "text": "Start with GitHub Copilot, accessed through VS Code.",
    "startMs": 600,
    "endMs": 4050,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Atlas Plugin guides the agent’s work.",
    "startMs": 4600,
    "endMs": 6861,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Atlas MCP, hosted in Azure, provides governed access to PostgreSQL.",
    "startMs": 7800,
    "endMs": 12708,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "The lakehouse holds the data; PostgreSQL holds saved metadata, models, requirements, and project knowledge.",
    "startMs": 13000,
    "endMs": 19827,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  }
]}
      />
    </AbsoluteFill>
  );
};


export const NarratedDiscovery = () => {
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill style={{backgroundColor: "#FFFFFF"}}>
      <DiscoveryScene />
      <Audio name="Discovery narration" src={staticFile("audio/discovery.wav")} premountFor={fps} />
      <BasicCaptions
        name="Discovery captions"
        premountFor={fps}
        width={3000}
        combineTokensWithinMilliseconds={0}
        style={{position:"absolute", left:210, bottom:30, scale:0.5, transformOrigin:"left bottom"}}
        captions={[
  {
    "text": "Begin with evidence.",
    "startMs": 700,
    "endMs": 2016,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Profile the source data, enrich its metadata,",
    "startMs": 2700,
    "endMs": 5682,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "investigate relationships, and identify subject areas.",
    "startMs": 6600,
    "endMs": 10590,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "These steps help the team understand what exists, how it connects,",
    "startMs": 10770,
    "endMs": 14820,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "and which business concepts the project needs to represent.",
    "startMs": 15600,
    "endMs": 19045,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  }
]}
      />
    </AbsoluteFill>
  );
};


export const NarratedModeling = () => {
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill style={{backgroundColor: "#FFFFFF"}}>
      <ModelingScene />
      <Audio name="Modeling narration" src={staticFile("audio/modeling.wav")} premountFor={fps} />
      <BasicCaptions
        name="Modeling captions"
        premountFor={fps}
        width={3000}
        combineTokensWithinMilliseconds={0}
        style={{position:"absolute", left:210, bottom:30, scale:0.5, transformOrigin:"left bottom"}}
        captions={[
  {
    "text": "Use that foundation to build and maintain the operational, or logical, model,",
    "startMs": 600,
    "endMs": 5318,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "followed by the dimensional model.",
    "startMs": 6100,
    "endMs": 8098,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Atlas supports source-to-target mappings, mapping documents, table definitions,",
    "startMs": 9500,
    "endMs": 14733,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "transformation SQL, and validation scripts.",
    "startMs": 14913,
    "endMs": 18152,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Each deliverable connects back to the project’s saved requirements and metadata.",
    "startMs": 18332,
    "endMs": 22625,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  }
]}
      />
    </AbsoluteFill>
  );
};


export const NarratedReview = () => {
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill style={{backgroundColor: "#FFFFFF"}}>
      <ReviewScene />
      <Audio name="Review narration" src={staticFile("audio/review.wav")} premountFor={fps} />
      <BasicCaptions
        name="Review captions"
        premountFor={fps}
        width={3000}
        combineTokensWithinMilliseconds={0}
        style={{position:"absolute", left:210, bottom:30, scale:0.5, transformOrigin:"left bottom"}}
        captions={[
  {
    "text": "The agent works from a bounded metadata snapshot and prepares changes locally,",
    "startMs": 600,
    "endMs": 5289,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "reducing repeated retrieval and oversized exchanges.",
    "startMs": 6000,
    "endMs": 9444,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Review the draft in Atlas Local Workbench.",
    "startMs": 9624,
    "endMs": 12255,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Atlas Bridge stages approved changes;",
    "startMs": 13300,
    "endMs": 15723,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Apply saves the approved candidate.",
    "startMs": 18100,
    "endMs": 20256,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Locks and revision checks protect governed writes, while audit records capture actions and outcomes.",
    "startMs": 22000,
    "endMs": 27832,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  }
]}
      />
    </AbsoluteFill>
  );
};


export const NarratedDelivery = () => {
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill style={{backgroundColor: "#FFFFFF"}}>
      <DeliveryScene />
      <Audio name="Delivery narration" src={staticFile("audio/delivery.wav")} premountFor={fps} />
      <BasicCaptions
        name="Delivery captions"
        premountFor={fps}
        width={3000}
        combineTokensWithinMilliseconds={0}
        style={{position:"absolute", left:210, bottom:30, scale:0.5, transformOrigin:"left bottom"}}
        captions={[
  {
    "text": "Those approved artifacts feed your established GDS delivery process.",
    "startMs": 700,
    "endMs": 4994,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Once deployed through that process, the GDS orchestrator uses metadata and transformation logic",
    "startMs": 5174,
    "endMs": 11422,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "to move data from Source to Bronze, then Silver and Gold.",
    "startMs": 11602,
    "endMs": 15039,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Atlas prepares the work; GDS performs the ingestion and transformation.",
    "startMs": 15700,
    "endMs": 20584,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  }
]}
      />
    </AbsoluteFill>
  );
};


export const NarratedContinuity = () => {
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill style={{backgroundColor: "#FFFFFF"}}>
      <ContinuityScene />
      <Audio name="Continuity narration" src={staticFile("audio/continuity.wav")} premountFor={fps} />
      <BasicCaptions
        name="Continuity captions"
        premountFor={fps}
        width={3000}
        combineTokensWithinMilliseconds={0}
        style={{position:"absolute", left:210, bottom:30, scale:0.5, transformOrigin:"left bottom"}}
        captions={[
  {
    "text": "When another authorized user joins, they can start from the project’s saved context,",
    "startMs": 500,
    "endMs": 5482,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "without inheriting someone else’s chat history.",
    "startMs": 6000,
    "endMs": 8731,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Tenant-scoped roles govern access.",
    "startMs": 9000,
    "endMs": 11171,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Requirements, models, mappings, and approved artifacts remain shared.",
    "startMs": 11500,
    "endMs": 16302,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Each person works in a local draft.",
    "startMs": 16482,
    "endMs": 18674,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Reviewed changes become shared project state after Apply.",
    "startMs": 18854,
    "endMs": 22518,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  }
]}
      />
    </AbsoluteFill>
  );
};


export const NarratedMaintenance = () => {
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill style={{backgroundColor: "#FFFFFF"}}>
      <MaintenanceScene />
      <Audio name="Maintenance narration" src={staticFile("audio/maintenance.wav")} premountFor={fps} />
      <BasicCaptions
        name="Maintenance captions"
        premountFor={fps}
        width={3000}
        combineTokensWithinMilliseconds={0}
        style={{position:"absolute", left:210, bottom:30, scale:0.5, transformOrigin:"left bottom"}}
        captions={[
  {
    "text": "The same workflow supports new sources, changed requirements, and investigations into existing code.",
    "startMs": 500,
    "endMs": 6886,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Atlas Platform also provides a browser interface for viewing saved results and tracking work.",
    "startMs": 7066,
    "endMs": 12403,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Development continues from the project’s accumulated knowledge.",
    "startMs": 12583,
    "endMs": 16026,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  }
]}
      />
    </AbsoluteFill>
  );
};


export const NarratedFuture = () => {
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill style={{backgroundColor: "#FFFFFF"}}>
      <FutureScene />
      <Audio name="Future narration" src={staticFile("audio/future.wav")} premountFor={fps} />
      <BasicCaptions
        name="Future captions"
        premountFor={fps}
        width={3000}
        combineTokensWithinMilliseconds={0}
        style={{position:"absolute", left:210, bottom:30, scale:0.5, transformOrigin:"left bottom"}}
        captions={[
  {
    "text": "With a separate connector, ADO Boards stories can supply requirements.",
    "startMs": 500,
    "endMs": 4995,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Codex, Claude Code, and Cursor are future integration directions.",
    "startMs": 5175,
    "endMs": 9655,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "Today, the focus is Copilot:",
    "startMs": 9835,
    "endMs": 12110,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  },
  {
    "text": "helping teams accelerate GDS development while keeping project knowledge connected.",
    "startMs": 12290,
    "endMs": 17337,
    "timestampMs": null,
    "confidence": null,
    "pageBreakAfter": true
  }
]}
      />
    </AbsoluteFill>
  );
};
