import { AbsoluteFill, Easing, Img, Interactive, interpolate, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { colors, FlowArrow, SceneFrame } from "../visuals";

export const FutureScene = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <SceneFrame
      chapter="09 / THE PATH FORWARD"
      title="Start with Copilot. Grow from there."
      subtitle="One shared project foundation, with room for future integrations."
    >
      <Interactive.Div name="Copilot today" premountFor={fps} style={{
        position: "absolute", left: 160, top: 411, width: 640,
        opacity: interpolate(frame, [0, 0.8 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <div style={{ color: colors.blue, fontSize: 28, fontWeight: 600, letterSpacing: 3 }}>TODAY</div>
        <div style={{ fontSize: 43, marginTop: 35, lineHeight: 1.2 }}>GitHub</div>
        <div style={{ color: colors.blue, fontSize: 102, fontWeight: 600, lineHeight: 1.1, letterSpacing: -3 }}>Copilot</div>
        <div style={{ fontSize: 31, color: colors.muted, marginTop: 25 }}>via VS Code</div>
        <div style={{ fontSize: 32, marginTop: 44, paddingTop: 23, borderTop: "2px solid #CCD8EA" }}>Atlas Plugin + Atlas MCP</div>
      </Interactive.Div>

      <Interactive.Div name="Optional Azure Boards connector" premountFor={fps} style={{
        position: "absolute", left: 1090, top: 411, width: 680,
        opacity: interpolate(frame, [1 * fps, 1.9 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [1 * fps, 2.2 * fps], ["0px 24px", "0px 0px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.16, 1, 0.3, 1) }),
      }}>
        <div style={{ fontSize: 27, fontWeight: 600, letterSpacing: 2, color: colors.muted }}>OPTIONAL INTEGRATION</div>
        <div style={{ fontSize: 48, fontWeight: 600, marginTop: 25 }}>ADO Boards stories</div>
        <div style={{ fontSize: 29, color: colors.muted, marginTop: 12 }}>via a separate agent connector</div>
      </Interactive.Div>
      <FlowArrow x1={1025} y1={549} x2={865} y2={549} dashed
        progress={interpolate(frame, [2.2 * fps, 3.4 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />

      <Interactive.Div name="Future agent directions" premountFor={fps} style={{
        position: "absolute", left: 1090, top: 666, width: 680, paddingTop: 28, borderTop: "2px dashed #CCD8EA",
        opacity: interpolate(frame, [4.3 * fps, 5.3 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <div style={{ fontSize: 27, color: colors.muted, fontWeight: 600, letterSpacing: 2 }}>FUTURE DIRECTION</div>
        <div style={{ display: "flex", gap: 35, marginTop: 25, fontSize: 34, color: colors.ink }}>
          <span>Codex</span>
          <span>Claude Code</span>
          <span>Cursor</span>
        </div>
      </Interactive.Div>

      <AbsoluteFill style={{
        backgroundColor: colors.blue,
        color: "#FFFFFF",
        opacity: interpolate(frame, [11 * fps, 12.2 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <Interactive.Div name="Closing Atlas lockup" premountFor={fps} style={{
          position: "absolute", left: 144, top: 152, width: 1632, display: "flex", justifyContent: "center", alignItems: "center", gap: 33,
          fontSize: 69, fontWeight: 600, letterSpacing: 5.4,
          opacity: interpolate(frame, [11.4 * fps, 12.5 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        }}>
          <Img src={staticFile("atlas.svg")} alt="Atlas Meridian symbol" premountFor={fps} style={{ width: 96, height: 96, filter: "brightness(0) invert(1)" }} />
          ATLAS
        </Interactive.Div>
        <Interactive.Div name="Closing shared context message" premountFor={fps} style={{
          position: "absolute", left: 144, top: 418, width: 1632, textAlign: "center", fontSize: 112, lineHeight: 1.2, letterSpacing: -3, fontWeight: 600,
          opacity: interpolate(frame, [11.8 * fps, 13 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
          translate: interpolate(frame, [11.8 * fps, 13.2 * fps], ["0px 32px", "0px 0px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.16, 1, 0.3, 1) }),
        }}>
          Build. Maintain.<br />Keep the context.
        </Interactive.Div>
        <Interactive.Div name="Closing GDS delivery promise" premountFor={fps} style={{
          position: "absolute", left: 144, top: 800, width: 1632, textAlign: "center", fontSize: 40, color: "#D9E5FB",
          opacity: interpolate(frame, [12.8 * fps, 13.8 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        }}>Accelerate GDS delivery.</Interactive.Div>
      </AbsoluteFill>
    </SceneFrame>
  );
};
