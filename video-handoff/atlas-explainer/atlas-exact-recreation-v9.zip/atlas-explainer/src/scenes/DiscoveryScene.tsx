import { Interactive, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { Entity, FlowArrow, SceneFrame, colors } from "../visuals";

export const DiscoveryScene = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <SceneFrame chapter="03 / UNDERSTAND" title="Start with evidence." subtitle="Profile the data. Enrich the metadata. Investigate the relationships.">
      <Interactive.Div name="Sales subject area boundary" premountFor={fps} style={{ position: "absolute", left: 144, top: 425, width: 1632, height: 385, border: `2px dashed ${colors.accent}`, backgroundColor: "#F7F9FF", boxSizing: "border-box", opacity: interpolate(frame, [13 * fps, 14 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <div style={{ position: "absolute", left: 22, top: 13, color: colors.blue, fontSize: 32, fontWeight: 600 }}>Sales subject area</div>
        <div style={{ position: "absolute", right: 22, top: 18, color: colors.muted, fontSize: 24 }}>Illustrative Retail project</div>
      </Interactive.Div>

      <Interactive.Div name="Customer source metadata" premountFor={fps} style={{ position: "absolute", inset: 0, opacity: interpolate(frame, [0.8 * fps, 1.6 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <Entity x={164} y={500} width={300} title="Customer" rows={["CustomerID", "CustomerName"]} />
      </Interactive.Div>
      <Interactive.Div name="Order source metadata" premountFor={fps} style={{ position: "absolute", inset: 0, opacity: interpolate(frame, [1.1 * fps, 1.9 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <Entity x={580} y={500} width={300} title="Order" rows={["OrderID", "CustomerID"]} />
      </Interactive.Div>
      <Interactive.Div name="Order line source metadata" premountFor={fps} style={{ position: "absolute", inset: 0, opacity: interpolate(frame, [1.4 * fps, 2.2 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <Entity x={996} y={500} width={300} title="OrderLine" rows={["OrderID", "ProductID", "Quantity"]} />
      </Interactive.Div>
      <Interactive.Div name="Product source metadata" premountFor={fps} style={{ position: "absolute", inset: 0, opacity: interpolate(frame, [1.7 * fps, 2.5 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <Entity x={1412} y={500} width={300} title="Product" rows={["ProductID", "ProductName"]} />
      </Interactive.Div>

      <FlowArrow x1={578} y1={670} x2={468} y2={610} dashed progress={interpolate(frame, [8 * fps, 9.2 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
      <FlowArrow x1={994} y1={610} x2={884} y2={610} dashed progress={interpolate(frame, [9 * fps, 10.2 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
      <FlowArrow x1={1298} y1={670} x2={1408} y2={610} dashed progress={interpolate(frame, [10 * fps, 11.2 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />

      <Interactive.Div name="Profiling and enrichment evidence" premountFor={fps} style={{ position: "absolute", left: 164, top: 855, width: 1548, color: colors.blue, fontSize: 35, opacity: interpolate(frame, [2.7 * fps, 3.4 * fps, 7 * fps, 7.7 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        Completeness &amp; types <span style={{ color: colors.line, padding: "0 24px" }}>|</span> Descriptions &amp; candidate keys
      </Interactive.Div>
      <Interactive.Div name="Inferred relationships are reviewed" premountFor={fps} style={{ position: "absolute", left: 164, top: 855, width: 1548, color: colors.blue, fontSize: 35, opacity: interpolate(frame, [8 * fps, 8.7 * fps, 13 * fps, 13.7 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        Inferred relationships <span style={{ color: colors.muted }}>— checked against evidence</span>
      </Interactive.Div>
      <Interactive.Div name="Subject areas organize modeling scope" premountFor={fps} style={{ position: "absolute", left: 164, top: 855, width: 1548, color: colors.blue, fontSize: 35, opacity: interpolate(frame, [14.2 * fps, 15.2 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        Subject areas organize the work. <span style={{ color: colors.muted }}>Evidence supports the model.</span>
      </Interactive.Div>
    </SceneFrame>
  );
};
