import { Easing, Interactive, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { colors, FlowArrow, SceneFrame } from "../visuals";

export const ContinuityScene = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <SceneFrame
      chapter="07 / SHARED KNOWLEDGE"
      title="The project keeps the context."
      subtitle="Saved knowledge is ready for the next authorized teammate."
    >
      <Interactive.Div name="First teammate" premountFor={fps} style={{
        position: "absolute", left: 180, top: 426, width: 390, textAlign: "center",
        opacity: interpolate(frame, [0, 0.8 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [0, 1.1 * fps], ["0px 26px", "0px 0px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.16, 1, 0.3, 1) }),
      }}>
        <svg width="116" height="116" viewBox="0 0 116 116" role="img" aria-label="Teammate A">
          <circle cx="58" cy="58" r="56" fill="#EDF2FF" />
          <circle cx="58" cy="42" r="17" fill={colors.blue} />
          <path d="M25 92 C25 57 91 57 91 92" fill={colors.blue} />
        </svg>
        <div style={{ fontSize: 43, fontWeight: 600, marginTop: 20 }}>Teammate A</div>
        <div style={{ fontSize: 29, color: colors.muted, marginTop: 8 }}>Builds and reviews</div>
      </Interactive.Div>

      <FlowArrow x1={562} y1={591} x2={746} y2={591}
        progress={interpolate(frame, [2.2 * fps, 4 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
      <Interactive.Div name="Approved shared change" premountFor={fps} style={{
        position: "absolute", left: 560, top: 630, width: 190, textAlign: "center", fontSize: 25, color: colors.blue,
        opacity: interpolate(frame, [3 * fps, 4 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>After Apply</Interactive.Div>

      <Interactive.Div name="Shared saved project" premountFor={fps} style={{
        position: "absolute", left: 770, top: 413, width: 400, height: 335,
        opacity: interpolate(frame, [1 * fps, 1.9 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <svg width="400" height="335" viewBox="0 0 400 335" aria-hidden="true" style={{ position: "absolute" }}>
          <path d="M2 42 C2 0 398 0 398 42 L398 287 C398 329 2 329 2 287 Z" fill="#EDF2FF" stroke={colors.blue} strokeWidth="3" />
          <ellipse cx="200" cy="42" rx="198" ry="40" fill="#FFFFFF" stroke={colors.blue} strokeWidth="3" />
        </svg>
        <div style={{ position: "absolute", top: 92, width: "100%", textAlign: "center", fontSize: 39, fontWeight: 600, color: colors.blue }}>Saved project</div>
        <div style={{ position: "absolute", top: 155, width: "100%", textAlign: "center", fontSize: 29, lineHeight: 1.7 }}>
          Requirements · models<br />Mappings · SQL · checks
        </div>
        <div style={{ position: "absolute", top: 263, width: "100%", textAlign: "center", fontSize: 25, color: colors.muted }}>PostgreSQL</div>
      </Interactive.Div>

      <FlowArrow x1={1195} y1={591} x2={1380} y2={591}
        progress={interpolate(frame, [8 * fps, 10 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
      <Interactive.Div name="Reuse saved knowledge" premountFor={fps} style={{
        position: "absolute", left: 1193, top: 630, width: 190, textAlign: "center", fontSize: 25, color: colors.blue,
        opacity: interpolate(frame, [9 * fps, 10 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>Continue</Interactive.Div>

      <Interactive.Div name="Next authorized teammate" premountFor={fps} style={{
        position: "absolute", left: 1380, top: 426, width: 390, textAlign: "center",
        opacity: interpolate(frame, [6 * fps, 7 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [6 * fps, 7.3 * fps], ["0px 26px", "0px 0px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.16, 1, 0.3, 1) }),
      }}>
        <svg width="116" height="116" viewBox="0 0 116 116" role="img" aria-label="Teammate B">
          <circle cx="58" cy="58" r="56" fill="#EDF2FF" />
          <circle cx="58" cy="42" r="17" fill={colors.blue} />
          <path d="M25 92 C25 57 91 57 91 92" fill={colors.blue} />
        </svg>
        <div style={{ fontSize: 43, fontWeight: 600, marginTop: 20 }}>Teammate B</div>
        <div style={{ fontSize: 29, color: colors.muted, marginTop: 8 }}>Picks up the project</div>
      </Interactive.Div>

      <Interactive.Div name="Local drafts stay separate" premountFor={fps} style={{
        position: "absolute", left: 180, top: 741, width: 390, padding: "14px 0", borderTop: "2px dashed #CCD8EA", textAlign: "center", fontSize: 25, color: colors.muted,
        opacity: interpolate(frame, [14 * fps, 15 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>Personal working files</Interactive.Div>

      <Interactive.Div name="Secure access to shared context" premountFor={fps} style={{
        position: "absolute", left: 144, top: 854, width: 1632, paddingTop: 24,
        borderTop: "2px solid #CCD8EA", display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 30,
        opacity: interpolate(frame, [11 * fps, 12 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <span style={{ color: colors.blue, fontWeight: 600 }}>Microsoft sign-in</span>
        <span>Role-based Tenant access</span>
        <span style={{ color: colors.muted }}>No inherited chat history needed</span>
      </Interactive.Div>
    </SceneFrame>
  );
};
