import { Interactive, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { Entity, FlowArrow, SceneFrame, colors } from "../visuals";

export const ModelingScene = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <SceneFrame chapter="04 / BUILD" title="From understanding to delivery." subtitle="Operational / logical models, dimensional models, and the artifacts to implement them.">
      <Interactive.Div name="Logical and dimensional models" premountFor={fps} style={{ position: "absolute", inset: 0, opacity: interpolate(frame, [0, 0.5 * fps, 12.7 * fps, 13.5 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <div style={{ position: "absolute", left: 164, top: 381, color: colors.blue, fontSize: 31, fontWeight: 600 }}>SILVER · LOGICAL</div>
        <Interactive.Div name="Logical Customer entity" premountFor={fps} style={{ position: "absolute", inset: 0, opacity: interpolate(frame, [0.8 * fps, 1.6 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
          <Entity x={164} y={445} width={250} title="Customer" rows={["CustomerID", "Name"]} />
        </Interactive.Div>
        <Interactive.Div name="Logical Order entity" premountFor={fps} style={{ position: "absolute", inset: 0, opacity: interpolate(frame, [1.4 * fps, 2.2 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
          <Entity x={530} y={445} width={250} title="Order" rows={["OrderID", "CustomerID"]} />
        </Interactive.Div>
        <Interactive.Div name="Logical OrderLine entity" premountFor={fps} style={{ position: "absolute", inset: 0, opacity: interpolate(frame, [2 * fps, 2.8 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
          <Entity x={530} y={695} width={250} title="OrderLine" rows={["OrderID", "Quantity"]} />
        </Interactive.Div>
        <FlowArrow x1={528} y1={615} x2={418} y2={555} progress={interpolate(frame, [2.8 * fps, 3.5 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
          <path d="M 784 805 H 816 V 555 H 784" fill="none" stroke={colors.accent} strokeWidth={3} strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={interpolate(frame, [3.2 * fps, 3.9 * fps], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
          <path d="M 797 546 L 784 555 L 797 564" fill="none" stroke={colors.accent} strokeWidth={3} opacity={interpolate(frame, [3.8 * fps, 3.9 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
        </svg>
        <FlowArrow x1={850} y1={595} x2={1010} y2={595} progress={interpolate(frame, [4.7 * fps, 5.8 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />

        <Interactive.Div name="Gold dimensional model" premountFor={fps} style={{ position: "absolute", inset: 0, opacity: interpolate(frame, [5.5 * fps, 6.3 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
          <div style={{ position: "absolute", left: 1062, top: 381, color: colors.blue, fontSize: 31, fontWeight: 600 }}>GOLD · DIMENSIONAL</div>
          <Entity x={1062} y={445} width={286} title="DimCustomer" rows={["CustomerKey"]} />
          <Entity x={1490} y={445} width={286} title="DimProduct" rows={["ProductKey"]} />
        </Interactive.Div>
        <Interactive.Div name="Sales fact entity" premountFor={fps} style={{ position: "absolute", inset: 0, opacity: interpolate(frame, [6.7 * fps, 7.5 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
          <Entity x={1272} y={638} width={286} title="FactSales" rows={["CustomerKey", "ProductKey", "Quantity"]} accent={colors.accent} />
        </Interactive.Div>
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
          <path d="M 1272 748 H 1238 V 610 H 1380 V 555 H 1352" fill="none" stroke={colors.accent} strokeWidth={3} strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={interpolate(frame, [7.4 * fps, 8.2 * fps], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
          <path d="M 1365 546 L 1352 555 L 1365 564" fill="none" stroke={colors.accent} strokeWidth={3} opacity={interpolate(frame, [8.1 * fps, 8.2 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
          <path d="M 1562 808 H 1590 V 610 H 1460 V 555 H 1490" fill="none" stroke={colors.accent} strokeWidth={3} strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={interpolate(frame, [7.8 * fps, 8.6 * fps], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
          <path d="M 1477 546 L 1490 555 L 1477 564" fill="none" stroke={colors.accent} strokeWidth={3} opacity={interpolate(frame, [8.5 * fps, 8.6 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
        </svg>
        <div style={{ position: "absolute", left: 164, top: 837, color: colors.muted, fontSize: 25 }}>Illustrative Retail model</div>
      </Interactive.Div>

      <Interactive.Div name="Mapping documents deliverable" premountFor={fps} style={{ position: "absolute", left: 164, top: 459, width: 290, opacity: interpolate(frame, [13.5 * fps, 14.3 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <svg width={112} height={142} viewBox="0 0 112 142"><path d="M 6 4 H 75 L 106 35 V 136 H 6 Z M 75 4 V 35 H 106 M 26 63 H 86 M 26 83 H 86 M 26 103 H 64" fill="none" stroke={colors.blue} strokeWidth={3} strokeLinejoin="round" /></svg>
        <div style={{ fontSize: 43, fontWeight: 600, lineHeight: 1.2, color: colors.blue, marginTop: 26 }}>Mapping<br />documents</div>
      </Interactive.Div>
      <FlowArrow x1={326} y1={527} x2={515} y2={527} progress={interpolate(frame, [14.2 * fps, 14.9 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
      <Interactive.Div name="Table DDL deliverable" premountFor={fps} style={{ position: "absolute", left: 560, top: 459, width: 290, opacity: interpolate(frame, [14.6 * fps, 15.4 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <svg width={112} height={142} viewBox="0 0 112 142"><path d="M 6 4 H 75 L 106 35 V 136 H 6 Z M 75 4 V 35 H 106 M 26 63 H 86 M 26 83 H 86 M 26 103 H 64" fill="none" stroke={colors.blue} strokeWidth={3} strokeLinejoin="round" /></svg>
        <div style={{ fontSize: 43, fontWeight: 600, lineHeight: 1.2, color: colors.blue, marginTop: 26 }}>Table<br />DDL</div>
      </Interactive.Div>
      <FlowArrow x1={722} y1={527} x2={913} y2={527} progress={interpolate(frame, [15.3 * fps, 16 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
      <Interactive.Div name="Transformation SQL deliverable" premountFor={fps} style={{ position: "absolute", left: 960, top: 459, width: 370, opacity: interpolate(frame, [15.7 * fps, 16.5 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <svg width={112} height={142} viewBox="0 0 112 142"><path d="M 6 4 H 75 L 106 35 V 136 H 6 Z M 75 4 V 35 H 106 M 26 63 H 86 M 26 83 H 86 M 26 103 H 64" fill="none" stroke={colors.blue} strokeWidth={3} strokeLinejoin="round" /></svg>
        <div style={{ fontSize: 43, fontWeight: 600, lineHeight: 1.2, color: colors.blue, marginTop: 26 }}>Transformation<br />SQL</div>
      </Interactive.Div>
      <FlowArrow x1={1122} y1={527} x2={1393} y2={527} progress={interpolate(frame, [16.4 * fps, 17.1 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
      <Interactive.Div name="Validation scripts deliverable" premountFor={fps} style={{ position: "absolute", left: 1440, top: 459, width: 330, opacity: interpolate(frame, [16.8 * fps, 17.6 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <svg width={112} height={142} viewBox="0 0 112 142"><path d="M 6 4 H 75 L 106 35 V 136 H 6 Z M 75 4 V 35 H 106 M 26 63 H 86 M 26 83 H 86 M 26 103 H 64" fill="none" stroke={colors.blue} strokeWidth={3} strokeLinejoin="round" /></svg>
        <div style={{ fontSize: 43, fontWeight: 600, lineHeight: 1.2, color: colors.blue, marginTop: 26 }}>Validation<br />scripts</div>
      </Interactive.Div>
      <Interactive.Div name="Deliverables retain their project context" premountFor={fps} style={{ position: "absolute", left: 164, top: 831, width: 1608, paddingTop: 18, borderTop: `2px solid ${colors.line}`, fontSize: 34, color: colors.muted, opacity: interpolate(frame, [18.4 * fps, 19.3 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        Connected to the project’s saved requirements and metadata.
      </Interactive.Div>
    </SceneFrame>
  );
};
