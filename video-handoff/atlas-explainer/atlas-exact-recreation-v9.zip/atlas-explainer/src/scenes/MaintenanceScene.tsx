import { Easing, Img, Interactive, interpolate, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { colors, FlowArrow, SceneFrame } from "../visuals";

export const MaintenanceScene = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <SceneFrame
      chapter="08 / CONTINUOUS DEVELOPMENT"
      title="Keep improving what you build."
      subtitle="New sources. New requirements. One connected lifecycle."
    >
      <Interactive.Div name="New source trigger" premountFor={fps} style={{
        position: "absolute", left: 160, top: 434, width: 620, display: "flex", alignItems: "center", gap: 28, fontSize: 42,
        opacity: interpolate(frame, [0.3 * fps, 1.1 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <span style={{ width: 12, height: 55, backgroundColor: colors.blue }} />
        New source
      </Interactive.Div>
      <Interactive.Div name="Changed requirements trigger" premountFor={fps} style={{
        position: "absolute", left: 160, top: 548, width: 620, display: "flex", alignItems: "center", gap: 28, fontSize: 42,
        opacity: interpolate(frame, [1.7 * fps, 2.5 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <span style={{ width: 12, height: 55, backgroundColor: colors.blue }} />
        Changed requirements
      </Interactive.Div>
      <Interactive.Div name="SQL investigation trigger" premountFor={fps} style={{
        position: "absolute", left: 160, top: 662, width: 620, display: "flex", alignItems: "center", gap: 28, fontSize: 42,
        opacity: interpolate(frame, [3.1 * fps, 3.9 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <span style={{ width: 12, height: 55, backgroundColor: colors.blue }} />
        SQL investigation
      </Interactive.Div>

      <Interactive.Div name="Illustrative Atlas Platform workspace" premountFor={fps} style={{
        position: "absolute", left: 840, top: 402, width: 936, height: 404,
        backgroundColor: "#FFFFFF", border: "2px solid #CCD8EA", overflow: "hidden",
        opacity: interpolate(frame, [4.5 * fps, 5.5 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
        translate: interpolate(frame, [4.5 * fps, 5.7 * fps], ["0px 28px", "0px 0px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.16, 1, 0.3, 1) }),
      }}>
        <div style={{ position: "absolute", left: 0, top: 0, width: 180, height: "100%", backgroundColor: colors.blue, color: "#FFFFFF" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 11, padding: "23px 19px", fontSize: 23, fontWeight: 600, letterSpacing: 1.8 }}>
            <Img src={staticFile("atlas.svg")} alt="Atlas" premountFor={fps} style={{ width: 32, height: 32, filter: "brightness(0) invert(1)" }} />
            ATLAS
          </div>
          <div style={{ padding: "16px 24px", fontSize: 23 }}>Home</div>
          <div style={{ padding: "16px 24px", fontSize: 23 }}>Metadata</div>
          <div style={{ padding: "16px 24px", margin: "0 12px", fontSize: 23, color: colors.blue, backgroundColor: "#FFFFFF" }}>Projects</div>
          <div style={{ padding: "16px 24px", fontSize: 23 }}>Prompts</div>
        </div>
        <div style={{ position: "absolute", left: 180, top: 0, right: 0, padding: "22px 30px", borderBottom: "1px solid #CCD8EA", display: "flex", alignItems: "baseline", justifyContent: "space-between" }}>
          <span style={{ fontSize: 30, fontWeight: 600 }}>Atlas Platform</span>
          <span style={{ fontSize: 21, color: colors.muted }}>Shared web view</span>
        </div>
        <div style={{ position: "absolute", left: 210, top: 98, fontSize: 28, fontWeight: 600 }}>Retail project</div>
        <div style={{ position: "absolute", left: 210, right: 30, top: 150, fontSize: 21 }}>
          <div style={{ display: "grid", gridTemplateColumns: "160px 1fr", color: colors.muted, paddingBottom: 12, borderBottom: "1px solid #CCD8EA" }}>
            <span>Section</span><span>Saved artifacts</span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "160px 1fr", padding: "11px 0", borderBottom: "1px solid #E7EDF5" }}>
            <span>Models</span><span>Entities &amp; relationships</span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "160px 1fr", padding: "11px 0", borderBottom: "1px solid #E7EDF5" }}>
            <span>Mapping</span><span>Source-to-target rules</span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "160px 1fr", padding: "11px 0", borderBottom: "1px solid #E7EDF5" }}>
            <span>Code</span><span>SQL definitions</span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "160px 1fr", padding: "11px 0" }}>
            <span>Validation</span><span>Checks &amp; criteria</span>
          </div>
        </div>
      </Interactive.Div>

      <Interactive.Div name="Illustrative workspace label" premountFor={fps} style={{
        position: "absolute", left: 840, top: 820, fontSize: 24, color: colors.muted,
        opacity: interpolate(frame, [5 * fps, 5.5 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>Illustrative view · synthetic project</Interactive.Div>

      <Interactive.Div name="Maintenance cycle" premountFor={fps} style={{
        position: "absolute", left: 160, top: 866, width: 1616, color: colors.blue, fontSize: 34, fontWeight: 600,
        opacity: interpolate(frame, [8 * fps, 9 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
      }}>
        <span style={{ position: "absolute", left: 0 }}>Review impacts</span>
        <span style={{ position: "absolute", left: 565 }}>Revise the project</span>
        <span style={{ position: "absolute", left: 1218 }}>Update checks</span>
      </Interactive.Div>
      <FlowArrow x1={465} y1={890} x2={675} y2={890} progress={interpolate(frame, [8.4 * fps, 9.5 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
      <FlowArrow x1={1105} y1={890} x2={1320} y2={890} progress={interpolate(frame, [9.3 * fps, 10.4 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
    </SceneFrame>
  );
};
