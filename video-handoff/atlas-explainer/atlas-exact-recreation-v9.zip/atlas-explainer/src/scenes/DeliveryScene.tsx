import { Interactive, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { colors, FlowArrow, SceneFrame } from "../visuals";

export const DeliveryScene = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <SceneFrame
      chapter="06 / DELIVERY TO EXECUTION"
      title="GDS runs the pipeline."
      subtitle="Atlas prepares the definitions. Your delivery process deploys them."
    >
      <Interactive.Div name="Approved Atlas artifacts" premountFor={fps} style={{ position: "absolute", left: 144, top: 387, width: 430, opacity: interpolate(frame, [0.3 * fps, 1.1 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <div style={{ color: colors.muted, fontSize: 25, fontWeight: 600, letterSpacing: 1.6, marginBottom: 24 }}>APPROVED ATLAS ARTIFACTS</div>
        <div style={{ paddingLeft: 25, borderLeft: `4px solid ${colors.accent}`, color: colors.blue, fontSize: 38, lineHeight: 1.55, fontWeight: 600 }}>
          Metadata<br />Table DDL<br />Transformation SQL
        </div>
      </Interactive.Div>

      <Interactive.Div name="Separate delivery boundary" premountFor={fps} style={{ position: "absolute", inset: 0, opacity: interpolate(frame, [2.2 * fps, 3 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <div style={{ position: "absolute", left: 650, top: 387, width: 380, color: colors.muted, fontSize: 26, textAlign: "center", lineHeight: 1.35, fontWeight: 600 }}>DELIVERY / DEPLOYMENT</div>
        <div style={{ position: "absolute", left: 845, top: 432, height: 126, borderLeft: `2px dashed ${colors.line}` }} />
        <FlowArrow x1={605} y1={482} x2={1050} y2={482} progress={interpolate(frame, [2.5 * fps, 4 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
        <div style={{ position: "absolute", left: 650, top: 565, width: 380, textAlign: "center", color: colors.muted, fontSize: 26 }}>Your established process</div>
      </Interactive.Div>

      <Interactive.Div name="GDS orchestrator" premountFor={fps} style={{ position: "absolute", left: 1100, top: 414, width: 676, height: 142, backgroundColor: colors.blue, color: "#FFFFFF", display: "flex", flexDirection: "column", justifyContent: "center", paddingLeft: 38, boxSizing: "border-box", opacity: interpolate(frame, [4 * fps, 4.8 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <div style={{ fontSize: 46, fontWeight: 600, letterSpacing: -1 }}>GDS orchestrator</div>
        <div style={{ color: "#D9E5FB", fontSize: 27, marginTop: 12 }}>Uses metadata + transformation logic</div>
      </Interactive.Div>

      <Interactive.Div name="Orchestration direction" premountFor={fps} style={{ position: "absolute", inset: 0, opacity: interpolate(frame, [5.4 * fps, 6.1 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <svg width={1920} height={1080} viewBox="0 0 1920 1080" style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
          <path d="M 1438 556 V 620 M 705 653 V 620 H 1595 V 653 M 1150 620 V 653" fill="none" stroke={colors.line} strokeWidth={2} />
        </svg>
      </Interactive.Div>

      <Interactive.Div name="Source data" premountFor={fps} style={{ position: "absolute", left: 144, top: 679, width: 300, opacity: interpolate(frame, [5.5 * fps, 6.2 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <div style={{ fontSize: 48, fontWeight: 600, color: colors.ink }}>Source</div>
        <div style={{ marginTop: 14, fontSize: 28, color: colors.muted }}>Original data</div>
      </Interactive.Div>
      <FlowArrow x1={400} y1={711} x2={578} y2={711} progress={interpolate(frame, [6.5 * fps, 7.5 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
      <Interactive.Div name="Bronze ingestion" premountFor={fps} style={{ position: "absolute", left: 605, top: 679, width: 300, opacity: interpolate(frame, [7.5 * fps, 8.2 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <div style={{ fontSize: 48, fontWeight: 600, color: colors.blue }}>Bronze</div>
        <div style={{ marginTop: 14, fontSize: 28, color: colors.muted }}>Ingested data</div>
      </Interactive.Div>
      <FlowArrow x1={850} y1={711} x2={1023} y2={711} progress={interpolate(frame, [8.8 * fps, 9.8 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
      <Interactive.Div name="Silver transformation" premountFor={fps} style={{ position: "absolute", left: 1050, top: 679, width: 300, opacity: interpolate(frame, [9.8 * fps, 10.5 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <div style={{ fontSize: 48, fontWeight: 600, color: colors.blue }}>Silver</div>
        <div style={{ marginTop: 14, fontSize: 28, color: colors.muted }}>Logical models</div>
      </Interactive.Div>
      <FlowArrow x1={1295} y1={711} x2={1468} y2={711} progress={interpolate(frame, [11.1 * fps, 12.1 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
      <Interactive.Div name="Gold transformation" premountFor={fps} style={{ position: "absolute", left: 1495, top: 679, width: 281, opacity: interpolate(frame, [12.1 * fps, 12.8 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <div style={{ fontSize: 48, fontWeight: 600, color: colors.blue }}>Gold</div>
        <div style={{ marginTop: 14, fontSize: 28, color: colors.muted }}>Dimensional models</div>
      </Interactive.Div>

      <Interactive.Div name="Validation definitions follow delivery" premountFor={fps} style={{ position: "absolute", left: 605, top: 835, width: 1171, borderTop: `3px solid ${colors.accent}`, paddingTop: 18, color: colors.ink, fontSize: 29, opacity: interpolate(frame, [14.8 * fps, 15.7 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        Validation definitions accompany the delivered outputs.
      </Interactive.Div>
    </SceneFrame>
  );
};
