import { Easing, Interactive, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { SceneFrame, colors } from "../visuals";

export const ArchitectureScene = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <SceneFrame chapter="02 / CONNECT" title="One connected project." subtitle="Copilot works with Atlas. Project knowledge stays shared.">
      <Interactive.Div name="Copilot in the local workspace" premountFor={fps} style={{ position: "absolute", left: 144, top: 417, width: 450, height: 206, backgroundColor: colors.blue, color: "#FFFFFF", padding: "36px 38px", boxSizing: "border-box", opacity: interpolate(frame, [0.4 * fps, 1.2 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }), translate: interpolate(frame, [0.4 * fps, 1.5 * fps], ["0px 24px", "0px 0px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.16, 1, 0.3, 1) }) }}>
        <div style={{ fontSize: 28, color: "#D9E5FB", marginBottom: 10 }}>GitHub</div>
        <div style={{ fontSize: 62, fontWeight: 600, lineHeight: 1.1, letterSpacing: -1.5 }}>Copilot</div>
        <div style={{ fontSize: 28, marginTop: 13, color: "#D9E5FB" }}>via VS Code</div>
      </Interactive.Div>

      <Interactive.Div name="Atlas Plugin guides the agent" premountFor={fps} style={{ position: "absolute", left: 144, top: 678, width: 450, borderTop: `5px solid ${colors.accent}`, paddingTop: 21, opacity: interpolate(frame, [3 * fps, 3.8 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <div style={{ fontSize: 39, fontWeight: 600, color: colors.blue }}>Atlas Plugin</div>
        <div style={{ fontSize: 29, color: colors.muted, lineHeight: 1.5, marginTop: 7 }}>Skills, references<br />and local helpers</div>
      </Interactive.Div>

      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
        <path d="M 614 520 H 754" fill="none" stroke={colors.accent} strokeWidth={4} pathLength={1} strokeDasharray={1} strokeDashoffset={interpolate(frame, [4.5 * fps, 5.5 * fps], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
        <path d="M 741 509 L 754 520 L 741 531" fill="none" stroke={colors.accent} strokeWidth={4} opacity={interpolate(frame, [5.3 * fps, 5.6 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
        <path d="M 1148 520 H 1316" fill="none" stroke={colors.accent} strokeWidth={4} pathLength={1} strokeDasharray={1} strokeDashoffset={interpolate(frame, [7.5 * fps, 8.5 * fps], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
        <path d="M 1303 509 L 1316 520 L 1303 531" fill="none" stroke={colors.accent} strokeWidth={4} opacity={interpolate(frame, [8.3 * fps, 8.6 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
      </svg>

      <Interactive.Div name="Atlas MCP on Azure App Service" premountFor={fps} style={{ position: "absolute", left: 776, top: 382, width: 350, height: 260, border: `2px solid ${colors.line}`, boxSizing: "border-box", padding: "30px 24px", textAlign: "center", opacity: interpolate(frame, [5.3 * fps, 6.3 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <div style={{ color: colors.muted, fontSize: 28, marginBottom: 34 }}>Azure App Service</div>
        <div style={{ color: colors.blue, fontSize: 47, fontWeight: 600, letterSpacing: -1 }}>Atlas MCP</div>
        <div style={{ color: colors.ink, fontSize: 29, marginTop: 20 }}>Governed tools</div>
      </Interactive.Div>

      <Interactive.Div name="Shared PostgreSQL project knowledge" premountFor={fps} style={{ position: "absolute", left: 1344, top: 405, width: 432, opacity: interpolate(frame, [8.2 * fps, 9.2 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <svg width={432} height={238} viewBox="0 0 432 238" style={{ position: "absolute", top: -18, left: 0 }}>
          <path d="M 2 40 L 2 188 C 2 239 430 239 430 188 L 430 40" fill="#EDF2FF" stroke={colors.blue} strokeWidth={2} />
          <ellipse cx={216} cy={40} rx={214} ry={37} fill="#FFFFFF" stroke={colors.blue} strokeWidth={2} />
        </svg>
        <div style={{ position: "relative", marginTop: 72, textAlign: "center", color: colors.blue, fontSize: 46, fontWeight: 600, letterSpacing: -1 }}>PostgreSQL</div>
        <div style={{ position: "relative", marginTop: 12, textAlign: "center", fontSize: 27, color: colors.muted }}>Saved project knowledge</div>
        <div style={{ position: "relative", marginTop: 74, textAlign: "center", color: colors.muted, fontSize: 27, lineHeight: 1.5 }}>Metadata · models<br />Requirements · decisions</div>
      </Interactive.Div>

      <Interactive.Div name="The lakehouse holds physical data" premountFor={fps} style={{ position: "absolute", left: 784, top: 765, width: 992, borderTop: `2px solid ${colors.line}`, paddingTop: 20, display: "flex", alignItems: "center", gap: 35, opacity: interpolate(frame, [13 * fps, 14 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <svg width={82} height={78} viewBox="0 0 82 78" aria-hidden="true">
          <path d="M 4 21 L 41 4 L 78 21 L 41 38 Z M 4 38 L 41 55 L 78 38 M 4 55 L 41 72 L 78 55" fill="none" stroke={colors.blue} strokeWidth={3} strokeLinejoin="round" />
        </svg>
        <div style={{ color: colors.ink, fontSize: 35, fontWeight: 600 }}>GDS lakehouse</div>
        <div style={{ borderLeft: `2px solid ${colors.line}`, paddingLeft: 35, fontSize: 29, color: colors.muted, lineHeight: 1.4 }}>Delta Lake<br />Physical data</div>
      </Interactive.Div>
    </SceneFrame>
  );
};
