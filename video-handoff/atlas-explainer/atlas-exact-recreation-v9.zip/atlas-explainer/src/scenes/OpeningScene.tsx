import {
  AbsoluteFill,
  Easing,
  Img,
  Interactive,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import "../fonts";

// Scene 01. This file is the exact authored checkpoint, not a generated slide.
// Timing follows brief/STORYBOARD.md; there is no voice track yet.
export const OpeningScene = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <AbsoluteFill
      style={{
        backgroundColor: "#FFFFFF",
        color: "#0C233C",
        fontFamily: "Open Sans",
        overflow: "hidden",
      }}
      from={90}
    >
      <Interactive.Div
        name="GDS input field"
        premountFor={fps}
        style={{
          position: "absolute",
          left: 1090,
          top: 0,
          width: 830,
          height: 1080,
          backgroundColor: "#00338D",
          translate: interpolate(frame, [90, 4.2 * fps], ["830px 0px", "0px 0px"], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
            easing: [Easing.bezier(0.16, 1, 0.3, 1)]
          })
        }}
      />

      <Interactive.Div
        name="Atlas brand lockup"
        premountFor={fps}
        style={{
          position: "absolute",
          left: 144,
          top: 108,
          display: "flex",
          alignItems: "center",
          gap: 22,
          fontSize: 46,
          fontWeight: 600,
          letterSpacing: 3.6,
          color: "#00338D",
        }}
      >
        <Img
          src={staticFile("atlas.svg")}
          alt="Atlas Meridian symbol"
          premountFor={fps}
          style={{ width: 64, height: 64 }}
        />
        <span>ATLAS</span>
      </Interactive.Div>

      <Interactive.Div
        name="Accelerate GDS delivery"
        premountFor={fps}
        style={{
          position: "absolute",
          left: 144,
          top: 310,
          width: 900,
          fontSize: 132,
          fontWeight: 600,
          lineHeight: 1.12,
          letterSpacing: -5,
          opacity: interpolate(frame, [3.2 * fps, 123], [0, 1], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp"
          }),
          translate: interpolate(frame, [3.2 * fps, 4.4 * fps], ["0px 38px", "0px 0px"], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
            easing: [Easing.bezier(0.16, 1, 0.3, 1)]
          })
        }}
      >
        Accelerate
        <br />
        <span style={{ color: "#00338D" }}>GDS delivery.</span>
      </Interactive.Div>

      <Interactive.Div
        name="GDS project inputs heading"
        premountFor={fps}
        style={{
          position: "absolute",
          left: 1186,
          top: 132,
          color: "#D9E5FB",
          fontSize: 30,
          letterSpacing: 3,
          fontWeight: 600,
          opacity: interpolate(frame, [4 * fps, 4.7 * fps], [0, 1], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp"
          })
        }}
      >
        GDS PROJECT INPUTS
      </Interactive.Div>

      <Interactive.Div
        name="Metadata input"
        premountFor={fps}
        style={{
          position: "absolute",
          left: 1186,
          top: 291,
          width: 590,
          paddingBottom: 36,
          borderBottom: "1px solid #8BA6D2",
          color: "#FFFFFF",
          fontSize: 64,
          fontWeight: 600,
          letterSpacing: -1.7,
          opacity: interpolate(frame, [4.8 * fps, 5.4 * fps], [0, 1], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp"
          }),
          translate: interpolate(frame, [4.8 * fps, 5.7 * fps], ["0px 24px", "0px 0px"], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
            easing: [Easing.bezier(0.16, 1, 0.3, 1)]
          })
        }}
      >
        Metadata
      </Interactive.Div>

      <Interactive.Div
        name="Table definitions input"
        premountFor={fps}
        style={{
          position: "absolute",
          left: 1186,
          top: 471,
          width: 590,
          paddingBottom: 32,
          borderBottom: "1px solid #8BA6D2",
          color: "#FFFFFF",
          fontSize: 54,
          lineHeight: 1.15,
          fontWeight: 600,
          letterSpacing: -1.7,
          opacity: interpolate(frame, [5.8 * fps, 6.4 * fps], [0, 1], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp"
          }),
          translate: interpolate(frame, [5.8 * fps, 6.7 * fps], ["0px 24px", "0px 0px"], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
            easing: [Easing.bezier(0.16, 1, 0.3, 1)]
          })
        }}
      >
        Table definitions
        <div style={{ fontSize: 30, color: "#D9E5FB", fontWeight: 400, marginTop: 12, letterSpacing: 1 }}>
          DDL
        </div>
      </Interactive.Div>

      <Interactive.Div
        name="Transformation SQL input"
        premountFor={fps}
        style={{
          position: "absolute",
          left: 1186,
          top: 681,
          width: 590,
          color: "#FFFFFF",
          fontSize: 54,
          lineHeight: 1.15,
          fontWeight: 600,
          letterSpacing: -1.7,
          opacity: interpolate(frame, [6.9 * fps, 7.5 * fps], [0, 1], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp"
          }),
          translate: interpolate(frame, [6.9 * fps, 7.8 * fps], ["0px 24px", "0px 0px"], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
            easing: [Easing.bezier(0.16, 1, 0.3, 1)]
          })
        }}
      >
        Transformation
        <br />
        SQL
      </Interactive.Div>

      <Interactive.Div
        name="Build maintain and keep the context"
        premountFor={fps}
        style={{
          position: "absolute",
          left: 150,
          top: 800,
          width: 780,
          paddingLeft: 26,
          borderLeft: "4px solid #1E49E2",
          color: "#0C233C",
          fontSize: 44,
          lineHeight: 1.4,
          opacity: interpolate(frame, [13.5 * fps, 14.4 * fps], [0, 1], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp"
          }),
          translate: interpolate(frame, [13.5 * fps, 14.6 * fps], ["0px 18px", "0px 0px"], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
            easing: [Easing.bezier(0.16, 1, 0.3, 1)]
          })
        }}
      >
        Build. Maintain.
        <br />
        <span style={{ fontWeight: 600 }}>Keep the context.</span>
      </Interactive.Div>
    </AbsoluteFill>
  );
};
