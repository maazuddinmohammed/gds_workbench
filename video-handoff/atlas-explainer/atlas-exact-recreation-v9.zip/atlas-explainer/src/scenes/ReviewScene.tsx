import { Easing, Interactive, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { colors, FlowArrow, SceneFrame } from "../visuals";

export const ReviewScene = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();

  return (
    <SceneFrame
      chapter="05 / CONTROLLED CHANGES"
      title="Review. Approve. Apply."
      subtitle="Work locally. Keep shared changes controlled."
    >
      <Interactive.Div
        name="Local preparation"
        premountFor={fps}
        style={{
          position: "absolute", inset: 0,
          opacity: interpolate(frame, [0, 0.7 * fps, 10.7 * fps, 11.5 * fps], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }),
          translate: interpolate(frame, [10.7 * fps, 11.5 * fps], ["0px 0px", "0px -28px"], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.bezier(0.16, 1, 0.3, 1) }),
        }}
      >
        <div style={{ position: "absolute", left: 144, top: 390, width: 1632, height: 320, backgroundColor: colors.paper }} />
        <div style={{ position: "absolute", left: 180, top: 415, fontSize: 25, color: colors.muted, letterSpacing: 2, fontWeight: 600 }}>LOCAL WORKSPACE</div>
        <Interactive.Div name="Bounded snapshot" premountFor={fps} style={{ position: "absolute", left: 180, top: 490, width: 360, opacity: interpolate(frame, [0.5 * fps, 1.3 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
          <div style={{ fontSize: 46, fontWeight: 600, color: colors.blue }}>Snapshot</div>
          <div style={{ marginTop: 20, fontSize: 30, color: colors.muted, lineHeight: 1.5 }}>Saved project context<br />A bounded local copy</div>
        </Interactive.Div>
        <FlowArrow x1={520} y1={555} x2={675} y2={555} progress={interpolate(frame, [1.6 * fps, 2.5 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
        <Interactive.Div name="Local candidate" premountFor={fps} style={{ position: "absolute", left: 730, top: 490, width: 380, opacity: interpolate(frame, [2.5 * fps, 3.3 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
          <div style={{ fontSize: 46, fontWeight: 600, color: colors.blue }}>Local draft</div>
          <div style={{ marginTop: 20, fontSize: 30, color: colors.muted, lineHeight: 1.5 }}>Agent prepares changes<br />Targeted context reads</div>
        </Interactive.Div>
        <FlowArrow x1={1080} y1={555} x2={1235} y2={555} progress={interpolate(frame, [4 * fps, 4.9 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
        <Interactive.Div name="Workbench review" premountFor={fps} style={{ position: "absolute", left: 1290, top: 475, width: 420, opacity: interpolate(frame, [4.9 * fps, 5.7 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
          <div style={{ fontSize: 42, fontWeight: 600, color: colors.blue, lineHeight: 1.15 }}>Atlas Local<br />Workbench</div>
          <div style={{ marginTop: 20, fontSize: 30, color: colors.muted }}>Inspect and refine</div>
        </Interactive.Div>
        <Interactive.Div name="Snapshot efficiency" premountFor={fps} style={{ position: "absolute", left: 180, top: 800, fontSize: 34, color: colors.ink, opacity: interpolate(frame, [7 * fps, 7.8 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
          Reuse context. Reduce repeated retrieval.
        </Interactive.Div>
      </Interactive.Div>

      <Interactive.Div name="Separate Stage and Apply" premountFor={fps} style={{ position: "absolute", inset: 0, opacity: interpolate(frame, [11.8 * fps, 12.6 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
        <div style={{ position: "absolute", left: 144, top: 390, width: 625, height: 346, backgroundColor: colors.paper }} />
        <div style={{ position: "absolute", left: 795, top: 390, width: 981, height: 346, backgroundColor: "#EDF2FF" }} />
        <div style={{ position: "absolute", left: 176, top: 414, fontSize: 24, fontWeight: 600, color: colors.muted, letterSpacing: 1.5 }}>LOCAL REVIEW + HANDOFF</div>
        <div style={{ position: "absolute", left: 828, top: 414, fontSize: 24, fontWeight: 600, color: colors.blue, letterSpacing: 1.5 }}>GOVERNED SERVER CHANGES</div>

        <Interactive.Div name="First approval" premountFor={fps} style={{ position: "absolute", left: 176, top: 498, width: 235, opacity: interpolate(frame, [12 * fps, 12.8 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
          <div style={{ fontSize: 26, color: colors.blue, marginBottom: 12 }}>APPROVAL 1</div>
          <div style={{ fontSize: 39, lineHeight: 1.15, fontWeight: 600, color: colors.ink }}>Approve<br />Stage</div>
          <div style={{ marginTop: 18, fontSize: 23, lineHeight: 1.35, color: colors.muted }}>In the agent<br />conversation</div>
        </Interactive.Div>
        <FlowArrow x1={409} y1={580} x2={464} y2={580} progress={interpolate(frame, [13 * fps, 13.5 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
        <Interactive.Div name="Bridge stages approved draft" premountFor={fps} style={{ position: "absolute", left: 493, top: 540, width: 245, opacity: interpolate(frame, [13.5 * fps, 14.3 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
          <div style={{ fontSize: 38, lineHeight: 1.15, fontWeight: 600, color: colors.blue }}>Atlas<br />Bridge</div>
          <div style={{ marginTop: 18, fontSize: 23, color: colors.muted }}>Stages the draft</div>
        </Interactive.Div>
        <FlowArrow x1={729} y1={580} x2={801} y2={580} progress={interpolate(frame, [14.5 * fps, 15 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
        <Interactive.Div name="Server validates draft" premountFor={fps} style={{ position: "absolute", left: 829, top: 540, width: 245, opacity: interpolate(frame, [15 * fps, 15.8 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
          <div style={{ fontSize: 38, lineHeight: 1.15, fontWeight: 600, color: colors.blue }}>Server<br />validation</div>
          <div style={{ marginTop: 18, fontSize: 23, color: colors.muted }}>Review the candidate</div>
        </Interactive.Div>
        <FlowArrow x1={1075} y1={580} x2={1130} y2={580} progress={interpolate(frame, [17 * fps, 17.5 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
        <Interactive.Div name="Second approval" premountFor={fps} style={{ position: "absolute", left: 1159, top: 498, width: 235, opacity: interpolate(frame, [17.5 * fps, 18.3 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
          <div style={{ fontSize: 26, color: colors.blue, marginBottom: 12 }}>APPROVAL 2</div>
          <div style={{ fontSize: 39, lineHeight: 1.15, fontWeight: 600, color: colors.ink }}>Approve<br />Apply</div>
          <div style={{ marginTop: 18, fontSize: 23, color: colors.muted }}>A separate decision</div>
        </Interactive.Div>
        <FlowArrow x1={1395} y1={580} x2={1450} y2={580} progress={interpolate(frame, [19 * fps, 19.5 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })} />
        <Interactive.Div name="Shared saved project" premountFor={fps} style={{ position: "absolute", left: 1480, top: 540, width: 255, opacity: interpolate(frame, [19.5 * fps, 20.3 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
          <div style={{ fontSize: 38, lineHeight: 1.15, fontWeight: 600, color: colors.blue }}>Saved<br />project state</div>
          <div style={{ marginTop: 18, fontSize: 23, color: colors.muted }}>Approved definitions</div>
        </Interactive.Div>

        <Interactive.Div name="Write protections" premountFor={fps} style={{ position: "absolute", left: 176, top: 804, width: 1568, display: "flex", justifyContent: "space-between", color: colors.ink, fontSize: 31, opacity: interpolate(frame, [23 * fps, 24 * fps], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp" }) }}>
          <span style={{ borderTop: `3px solid ${colors.accent}`, paddingTop: 18 }}>Tenant Lock</span>
          <span style={{ borderTop: `3px solid ${colors.accent}`, paddingTop: 18 }}>Revision checks</span>
          <span style={{ borderTop: `3px solid ${colors.accent}`, paddingTop: 18 }}>Audited actions + outcomes</span>
        </Interactive.Div>
      </Interactive.Div>
    </SceneFrame>
  );
};
