import { Series, useVideoConfig } from "remotion";
import {
  NarratedOpening, NarratedArchitecture, NarratedDiscovery,
  NarratedModeling, NarratedReview, NarratedDelivery,
  NarratedContinuity, NarratedMaintenance, NarratedFuture,
} from "./NarratedScenes";

export const AtlasExplainer = () => {
  const { fps } = useVideoConfig();
  return (
    <Series>
      <Series.Sequence name="01 / GDS delivery" durationInFrames={17.5 * fps} premountFor={fps}>
        <NarratedOpening />
      </Series.Sequence>
      <Series.Sequence name="02 / Copilot and Atlas" durationInFrames={20.5 * fps} premountFor={fps}>
        <NarratedArchitecture />
      </Series.Sequence>
      <Series.Sequence name="03 / Understand the source" durationInFrames={20 * fps} premountFor={fps}>
        <NarratedDiscovery />
      </Series.Sequence>
      <Series.Sequence name="04 / Models to artifacts" durationInFrames={23.5 * fps} premountFor={fps}>
        <NarratedModeling />
      </Series.Sequence>
      <Series.Sequence name="05 / Review Stage and Apply" durationInFrames={28.5 * fps} premountFor={fps}>
        <NarratedReview />
      </Series.Sequence>
      <Series.Sequence name="06 / GDS orchestration" durationInFrames={21.5 * fps} premountFor={fps}>
        <NarratedDelivery />
      </Series.Sequence>
      <Series.Sequence name="07 / Continue shared work" durationInFrames={23.5 * fps} premountFor={fps}>
        <NarratedContinuity />
      </Series.Sequence>
      <Series.Sequence name="08 / Maintain and inspect" durationInFrames={17 * fps} premountFor={fps}>
        <NarratedMaintenance />
      </Series.Sequence>
      <Series.Sequence name="09 / Future direction" durationInFrames={18 * fps} premountFor={fps}>
        <NarratedFuture />
      </Series.Sequence>
    </Series>
  );
};
