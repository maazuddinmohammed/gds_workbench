import { loadFont } from "@remotion/fonts";
import { staticFile } from "remotion";

// Bundled assets keep type identical without a network font request.
await Promise.all([
  loadFont({
    family: "Open Sans",
    url: staticFile("fonts/OpenSans-Regular.woff2"),
    weight: "400",
  }),
  loadFont({
    family: "Open Sans",
    url: staticFile("fonts/OpenSans-SemiBold.woff2"),
    weight: "600",
  }),
]);
