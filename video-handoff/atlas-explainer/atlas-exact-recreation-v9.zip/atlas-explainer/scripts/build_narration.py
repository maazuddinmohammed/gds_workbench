"""Create local review speech, scene WAVs, timed caption JSON and authored wrappers.

Requires macOS say only when regenerating. Reproduction uses the saved WAVs.
Does not send script text to a service. Never truncate speech to fit the timeline.
"""
from pathlib import Path
import array
import json
import math
import re
import subprocess
import wave

ROOT = Path(__file__).resolve().parent.parent
plan = json.loads((ROOT / "brief/narration-plan.json").read_text())
rate_hz = plan["sampleRate"]
audio_dir = ROOT / "public/audio"
caption_dir = ROOT / "public/captions"
scratch = ROOT / "out/speech-parts"
for folder in (audio_dir, caption_dir, scratch):
    folder.mkdir(parents=True, exist_ok=True)

imports = '\n'.join(
    f'import {{ {s["name"]}Scene }} from "./scenes/{s["name"]}Scene";'
    for s in plan["scenes"]
)
wrappers = [
    '// Generated from brief/narration-plan.json by scripts/build_narration.py.\n'
    '// Each authored scene keeps its own audio and captions on the same timeline.\n'
    'import { AbsoluteFill, Img, Sequence, staticFile, useVideoConfig } from "remotion";\n'
    'import { Audio } from "@remotion/media";\n'
    'import { BasicCaptions } from "./basic-captions.element";\n'
    + imports + '\n'
]
manifest = []
for scene in plan["scenes"]:
    name = scene["name"]
    placed_clips = []
    cursor = 0
    captions = []
    spoken_seconds = 0
    clip_rates = []
    for index, segment in enumerate(scene["segments"]):
        actual_at = max(segment["at"], cursor + 0.18)
        spoken = segment["text"].replace("—", ", ")
        for original, pronunciation in (
            ("PostgreSQL", "Postgres"), ("GDS", "G D S"), ("MCP", "M C P"),
            ("ADO", "A D O"), ("SQL", "sequel"), ("VS Code", "V S Code"),
        ):
            spoken = spoken.replace(original, pronunciation)
        text_file = scratch / f"{name}-{index}.txt"
        clip_file = scratch / f"{name}-{index}.wav"
        text_file.write_text(spoken)
        speech_rate = 155
        subprocess.run([
            "say", "-v", plan["voice"], "-r", str(speech_rate),
            "--file-format=WAVE", f"--data-format=LEI16@{rate_hz}",
            "-f", str(text_file), "-o", str(clip_file),
        ], check=True, capture_output=True)
        with wave.open(str(clip_file), "rb") as clip:
            if clip.getnchannels() != 1 or clip.getsampwidth() != 2 or clip.getframerate() != rate_hz:
                raise RuntimeError("Unexpected generated audio format")
            pcm = array.array("h", clip.readframes(clip.getnframes()))
        if not pcm:
            raise RuntimeError("Local speech synthesis produced empty audio; do not use the file")
        seconds = len(pcm) / rate_hz
        cursor = actual_at + seconds
        placed_clips.append((round(actual_at * rate_hz), pcm))
        spoken_seconds += seconds
        clip_rates.append(speech_rate)
        captions.append({
            "text": segment["text"],
            "startMs": round(actual_at * 1000),
            "endMs": round(cursor * 1000),
            "timestampMs": None,
            "confidence": None,
            "pageBreakAfter": True,
        })
    # Let the final visual hold expand slightly rather than rushing or clipping
    # speech. All authored animations have clamped, stable final frames.
    duration = max(scene["duration"], math.ceil((cursor + 0.5) * 2) / 2)
    samples = array.array("h", [0]) * round(duration * rate_hz)
    for start, pcm in placed_clips:
        samples[start:start + len(pcm)] = pcm
    with wave.open(str(audio_dir / f"{name.lower()}.wav"), "wb") as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(rate_hz)
        output.writeframes(samples.tobytes())
    (caption_dir / f"{name.lower()}.json").write_text(json.dumps(captions, indent=2, ensure_ascii=False) + "\n")
    # Retain the user's three-second Studio offset in OpeningScene, with a
    # visible branded lead-in only in the assembled narrated review version.
    lead_in = '''
      <Sequence name="Brand lead-in" durationInFrames={3 * fps} premountFor={fps}>
        <AbsoluteFill style={{backgroundColor: "#FFFFFF", justifyContent: "center", alignItems: "center", gap: 30, color: "#00338D", fontFamily: "Open Sans"}}>
          <Img src={staticFile("atlas.svg")} alt="Atlas" premountFor={fps} style={{width: 126, height:126}} />
          <div style={{fontSize:90, fontWeight:600, letterSpacing:7}}>ATLAS</div>
          <div style={{fontSize:34, color:"#52677C"}}>Build for GDS.</div>
        </AbsoluteFill>
      </Sequence>''' if name == "Opening" else ""
    wrappers.append(f'''
export const Narrated{name} = () => {{
  const {{ fps }} = useVideoConfig();
  return (
    <AbsoluteFill style={{{{backgroundColor: "#FFFFFF"}}}}>
      <{name}Scene />{lead_in}
      <Audio name="{name} narration" src={{staticFile("audio/{name.lower()}.wav")}} premountFor={{fps}} />
      <BasicCaptions
        name="{name} captions"
        premountFor={{fps}}
        width={{3000}}
        combineTokensWithinMilliseconds={{0}}
        style={{{{position:"absolute", left:210, bottom:30, scale:0.5, transformOrigin:"left bottom"}}}}
        captions={{{json.dumps(captions, indent=2, ensure_ascii=False)}}}
      />
    </AbsoluteFill>
  );
}};
''')
    manifest.append({"scene": name, "durationSeconds": duration, "speechSeconds": round(spoken_seconds, 3), "speechRates": clip_rates, "voice": plan["voice"], "sampleRate": rate_hz})
    print(f"{name}: {duration}s, {len(captions)} caption cues, speech {spoken_seconds:.1f}s", flush=True)
(ROOT / "src/NarratedScenes.tsx").write_text("\n".join(wrappers))
(ROOT / "brief/NARRATION.json").write_text(json.dumps(manifest, indent=2) + "\n")

# Catch accidental divergence from the editorial narration while tolerating
# phrase boundaries introduced solely to align the spoken delivery.
story = (ROOT / "brief/STORYBOARD.md").read_text()
paragraphs = re.findall(r"\*\*Narration\*\*\n\n(.*?)\n\n\*\*Picture\*\*", story, re.S)
normal = lambda text: re.findall(r"[\w]+", text.casefold())
for scene, paragraph in zip(plan["scenes"], paragraphs, strict=True):
    if normal(" ".join(s["text"] for s in scene["segments"])) != normal(paragraph):
        raise RuntimeError(f"Narration differs from storyboard: {scene['name']}")
