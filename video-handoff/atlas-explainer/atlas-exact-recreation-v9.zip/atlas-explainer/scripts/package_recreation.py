#!/usr/bin/env python3
"""Freeze the reviewed v9 Atlas video into a deterministic local handoff ZIP.

Explicit allowlists exclude dependencies, builds, history, outputs and private
configuration. This command writes only the manifest and local handoff files.
"""

from __future__ import annotations

from pathlib import Path
import hashlib
import json
import platform
import re
import subprocess
import zipfile

from verify_recreation import FROZEN_DIRECTORIES, MANIFEST, frozen_files, safe_path, verify


ROOT = Path(__file__).resolve().parent.parent
ROOT_FILES = ("README.md", "RECREATE.md", "RECREATE-PROMPT.md", "package.json", "package-lock.json",
              "tsconfig.json", "remotion.config.ts", "eslint.config.mjs", ".gitignore", ".prettierrc")
SCENES = (("intro", "v9", 42), ("onboarding", "v5", 42), ("snapshot", "v4", 28),
          ("build", "v5", 54), ("review", "v2", 32), ("run", "v9", 26),
          ("team", "v4", 36), ("closing", "v8", 20))


def version(command: list[str]) -> str | None:
    try:
        return subprocess.run(command, cwd=ROOT, check=True, capture_output=True,
                              text=True, timeout=10).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return None


def main() -> None:
    paths = frozen_files(ROOT) | set(ROOT_FILES)
    for name in ROOT_FILES:
        if not (ROOT / name).is_file() or (ROOT / name).is_symlink():
            raise ValueError(f"Required root file is missing or linked: {name}")
    index = json.loads((ROOT / "reference-frames/index.json").read_text(encoding="utf-8"))
    references = []
    for item in index["frames"]:
        name = safe_path(item["file"])
        if "/" in name or not name.endswith(".png"):
            raise ValueError("Reference index filenames must be plain PNG filenames")
        references.append({"name": item["name"], "file": f"reference-frames/{name}", "frame": item["frame"],
                           "composition": item["composition"]})
    if len({item["file"] for item in references}) != len(references):
        raise ValueError("Reference filenames must be unique")
    package = json.loads((ROOT / "package.json").read_text(encoding="utf-8"))
    browser_version = ROOT / "node_modules/.remotion/chrome-headless-shell/VERSION"
    tested = ROOT / "node_modules/@remotion/renderer/dist/browser/get-chrome-download-url.js"
    match = re.search(r"TESTED_VERSION\s*=\s*['\"]([^'\"]+)", tested.read_text(encoding="utf-8")) if tested.is_file() else None
    sequence = []
    elapsed = 0
    for name, source_version, seconds in SCENES:
        sequence.append({"name": name, "sourceVersion": source_version, "fromFrame": elapsed * 30,
                         "seconds": seconds, "durationInFrames": seconds * 30,
                         "audio": f"public/audio/{source_version}/{name}.wav",
                         "captions": f"public/captions/{source_version}/{name}.json"})
        elapsed += seconds
    manifest = {
        "schemaVersion": 1,
        "video": {"version": "v9", "composition": "AtlasExplainer", "captionComposition": "AtlasExplainer-Captions",
                  "width": 1920, "height": 1080, "fps": 30, "durationInFrames": 8400,
                  "durationSeconds": 280, "captionCues": 58},
        "runtime": {"node": version(["node", "--version"]), "npm": version(["npm", "--version"]),
                    "python": platform.python_version(), "os": platform.system(),
                    "osVersion": platform.mac_ver()[0] if platform.system() == "Darwin" else platform.release(),
                    "architecture": platform.machine(), "remotion": package["dependencies"]["remotion"],
                    "react": package["dependencies"]["react"],
                    "installedHeadlessChrome": browser_version.read_text(encoding="utf-8").strip() if browser_version.is_file() else None,
                    "rendererTestedChrome": match.group(1) if match else None,
                    "fonts": "Main film uses bundled Open Sans. Optional BasicCaptions uses system Arial/Helvetica fallback.",
                    "pixelEquality": "Exact checkpoint pixels require a matching renderer/browser/font environment; MP4 encoder bytes can vary."},
        "frozenDirectories": list(FROZEN_DIRECTORIES),
        "rootFiles": sorted(ROOT_FILES),
        "sequence": sequence,
        "referenceFrames": references,
        "files": [{"path": name, "bytes": (ROOT / name).stat().st_size,
                   "sha256": hashlib.sha256((ROOT / name).read_bytes()).hexdigest()} for name in sorted(paths)],
    }
    verify(ROOT, manifest)
    manifest_bytes = (json.dumps(manifest, indent=2, ensure_ascii=False) + "\n").encode()
    (ROOT / MANIFEST).write_bytes(manifest_bytes)
    handoff = ROOT / "handoff"
    handoff.mkdir(exist_ok=True)
    destination = handoff / "atlas-exact-recreation-v9.zip"
    temporary = destination.with_suffix(".zip.tmp")
    hashes = {item["path"]: item["sha256"] for item in manifest["files"]}
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(paths | {MANIFEST}):
            data = manifest_bytes if name == MANIFEST else (ROOT / name).read_bytes()
            if name != MANIFEST and hashlib.sha256(data).hexdigest() != hashes[name]:
                raise ValueError(f"File changed during packaging; rerun after edits finish: {name}")
            info = zipfile.ZipInfo(f"atlas-explainer/{name}", date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = (0o100755 if name.endswith((".sh", ".py")) else 0o100644) << 16
            archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    temporary.replace(destination)
    sha256 = hashlib.sha256(destination.read_bytes()).hexdigest()
    destination.with_suffix(".zip.sha256").write_text(f"{sha256}  {destination.name}\n", encoding="utf-8")
    print(f"Created {destination.name}: {len(paths) + 1} files, {destination.stat().st_size:,} bytes.")
    print(f"SHA-256: {sha256}")
    print("Local handoff only. No dependency binaries, history, credentials or remote uploads included.")


if __name__ == "__main__":
    main()
