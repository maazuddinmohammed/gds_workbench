#!/usr/bin/env python3
"""Verify the frozen Atlas video; optionally render and pixel-compare a checkpoint.

Uses Python's standard library. Ordinary verification needs neither Node nor a
browser. Rendering uses the already installed, locked Remotion CLI.
"""

from __future__ import annotations

from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import re
import struct
import subprocess
import sys
import tempfile
import wave
import zlib


ROOT = Path(__file__).resolve().parent.parent
MANIFEST = "REPRODUCTION-MANIFEST.json"
FROZEN_DIRECTORIES = ("src", "public", "brief", "scripts", "reference-frames")
IGNORED_PARTS = {"__pycache__", ".pytest_cache", "node_modules", ".git"}
IGNORED_FILES = {".DS_Store"}


def safe_path(value: str) -> str:
    if not isinstance(value, str) or not value or "\\" in value:
        raise ValueError("Manifest contains an invalid relative path")
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts or ":" in value or str(path) != value:
        raise ValueError("Manifest path is not a normalized relative path")
    return value


def frozen_files(root: Path) -> set[str]:
    paths = set()
    for directory in FROZEN_DIRECTORIES:
        folder = root / directory
        if folder.is_symlink() or not folder.is_dir():
            raise ValueError(f"Missing or linked frozen directory: {directory}")
        for path in folder.rglob("*"):
            relative = path.relative_to(root)
            if any(part in IGNORED_PARTS for part in relative.parts) or path.name in IGNORED_FILES:
                continue
            if path.is_symlink():
                raise ValueError(f"Linked files are not part of this frozen kit: {relative}")
            if path.is_file():
                if path.name.startswith(".env") or path.name in {".npmrc", ".netrc", ".pypirc"}:
                    raise ValueError(f"Private configuration is not allowed in the frozen directories: {relative}")
                paths.add(relative.as_posix())
    return paths


def verify(root: Path, manifest: dict) -> dict:
    if manifest.get("schemaVersion") != 1:
        raise ValueError("Unsupported reproduction manifest schema")
    video = manifest.get("video", {})
    expected = {"version": "v9", "width": 1920, "height": 1080, "fps": 30,
                "durationInFrames": 8400, "durationSeconds": 280, "captionCues": 58}
    if any(video.get(key) != value for key, value in expected.items()):
        raise ValueError("The frozen video dimensions, duration or cue count differ from v9")
    if tuple(manifest.get("frozenDirectories", [])) != FROZEN_DIRECTORIES:
        raise ValueError("Unexpected frozen directory list")
    entries = manifest.get("files", [])
    if not isinstance(entries, list) or not entries:
        raise ValueError("The manifest has no files")
    expected_paths = set()
    for entry in entries:
        name = safe_path(entry["path"])
        if name == MANIFEST or name in expected_paths:
            raise ValueError("Duplicate or self-referential manifest entry")
        expected_paths.add(name)
        path = root / name
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"Missing or linked frozen file: {name}")
        data = path.read_bytes()
        if len(data) != entry["bytes"] or hashlib.sha256(data).hexdigest() != entry["sha256"]:
            raise ValueError(f"Frozen file differs: {name}")
    actual_frozen = frozen_files(root)
    expected_frozen = {name for name in expected_paths if name.split("/", 1)[0] in FROZEN_DIRECTORIES}
    extras = sorted(actual_frozen - expected_frozen)
    if extras:
        raise ValueError(f"Unexpected files in frozen directories: {', '.join(extras[:5])}")
    root_files = manifest.get("rootFiles", [])
    if set(root_files) != expected_paths - expected_frozen:
        raise ValueError("Manifest root-file inventory is inconsistent")

    # Static asset references in all retained compositions must stay portable.
    for name in sorted(expected_paths):
        if name.startswith("src/") and Path(name).suffix in {".ts", ".tsx", ".js", ".jsx"}:
            source = (root / name).read_text(encoding="utf-8")
            for match in re.finditer(r"staticFile\(\s*(['\"])([^'\"]+)\1\s*\)", source):
                asset = "public/" + safe_path(match.group(2))
                if asset not in expected_paths:
                    raise ValueError(f"Static media is absent from the kit: {asset}")

    elapsed = 0
    cue_count = 0
    sequence = manifest.get("sequence", [])
    if len(sequence) != 8:
        raise ValueError("The current film requires eight audio segments")
    for scene in sequence:
        if scene["fromFrame"] != elapsed * video["fps"]:
            raise ValueError(f"Noncontiguous scene: {scene['name']}")
        duration = scene["seconds"]
        if scene["durationInFrames"] != duration * video["fps"]:
            raise ValueError(f"Scene frame duration differs: {scene['name']}")
        audio_name, captions_name = safe_path(scene["audio"]), safe_path(scene["captions"])
        if audio_name not in expected_paths or captions_name not in expected_paths:
            raise ValueError("Scene assets are not frozen by the manifest")
        with wave.open(str(root / audio_name), "rb") as audio:
            if (audio.getnchannels(), audio.getsampwidth(), audio.getframerate()) != (1, 2, 24000):
                raise ValueError(f"Narration format differs: {scene['name']}")
            if abs(audio.getnframes() / audio.getframerate() - duration) > 0.001:
                raise ValueError(f"Narration duration differs: {scene['name']}")
        cues = json.loads((root / captions_name).read_text(encoding="utf-8"))
        previous_end = 0
        for cue in cues:
            if not previous_end <= cue["startMs"] < cue["endMs"] <= duration * 1000:
                raise ValueError(f"Caption timing overlaps or exceeds its scene: {scene['name']}")
            if not isinstance(cue["text"], str) or not cue["text"].strip():
                raise ValueError("A caption has no text")
            previous_end = cue["endMs"]
        cue_count += len(cues)
        elapsed += duration
    if elapsed != video["durationSeconds"] or cue_count != video["captionCues"]:
        raise ValueError("Total audio duration or caption count differs")
    references = manifest.get("referenceFrames", [])
    if not references:
        raise ValueError("The kit requires rendered reference frames")
    reference_names = set()
    for reference in references:
        label = reference["name"]
        if not isinstance(label, str) or not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", label):
            raise ValueError("Invalid reference checkpoint name")
        if label in reference_names:
            raise ValueError("Duplicate reference checkpoint name")
        reference_names.add(label)
        name = safe_path(reference["file"])
        if not name.startswith("reference-frames/") or name not in expected_paths:
            raise ValueError("A reference frame is not frozen by the manifest")
        if reference["composition"] not in {"AtlasExplainer", "AtlasExplainer-Captions"}:
            raise ValueError("Unexpected reference composition")
        if type(reference["frame"]) is not int or not 0 <= reference["frame"] < video["durationInFrames"]:
            raise ValueError("Reference frame is outside the composition")
    return {"files": len(entries), "seconds": elapsed, "captionCues": cue_count,
            "referenceFrames": len(references)}


def png_pixels(path: Path) -> tuple[int, int, bytes]:
    """Decode non-interlaced 8-bit RGB/RGBA PNGs, ignoring encoder metadata."""
    data = path.read_bytes()
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError("Reference comparison requires PNG files")
    cursor, compressed = 8, bytearray()
    width = height = channels = 0
    while cursor < len(data):
        size = struct.unpack(">I", data[cursor:cursor + 4])[0]
        kind = data[cursor + 4:cursor + 8]
        payload = data[cursor + 8:cursor + 8 + size]
        if kind == b"IHDR":
            width, height, depth, color, compression, filtering, interlace = struct.unpack(">IIBBBBB", payload)
            if depth != 8 or color not in (2, 6) or compression or filtering or interlace:
                raise ValueError("Pixel comparison supports non-interlaced 8-bit RGB/RGBA PNGs")
            channels = 3 if color == 2 else 4
        elif kind == b"IDAT":
            compressed.extend(payload)
        elif kind == b"IEND":
            break
        cursor += size + 12
    if not width or not height or width * height > 20_000_000:
        raise ValueError("Invalid reference PNG dimensions")
    raw = zlib.decompress(compressed)
    stride = width * channels
    if len(raw) != height * (stride + 1):
        raise ValueError("Invalid PNG scanline size")
    output, previous = bytearray(), bytearray(stride)
    for y in range(height):
        offset = y * (stride + 1)
        method = raw[offset]
        row = bytearray(raw[offset + 1:offset + 1 + stride])
        if method not in range(5):
            raise ValueError("Invalid PNG scanline filter")
        for x in range(stride):
            left = row[x - channels] if x >= channels else 0
            above = previous[x]
            upper_left = previous[x - channels] if x >= channels else 0
            if method == 1:
                predictor = left
            elif method == 2:
                predictor = above
            elif method == 3:
                predictor = (left + above) // 2
            elif method == 4:
                prediction = left + above - upper_left
                a, b, c = abs(prediction - left), abs(prediction - above), abs(prediction - upper_left)
                predictor = left if a <= b and a <= c else above if b <= c else upper_left
            else:
                predictor = 0
            row[x] = (row[x] + predictor) & 255
        if channels == 4:
            output.extend(row)
        else:
            for x in range(0, stride, 3):
                output.extend(row[x:x + 3])
                output.append(255)
        previous = row
    return width, height, bytes(output)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--render-reference", action="append", default=[], metavar="NAME",
                        help="Render a checkpoint name or PNG filename (or 'all') and compare exact RGBA pixels")
    args = parser.parse_args()
    try:
        manifest = json.loads((ROOT / MANIFEST).read_text(encoding="utf-8"))
        result = verify(ROOT, manifest)
        print(f"Verified {result['files']} frozen files; {result['seconds']}s; "
              f"{result['captionCues']} caption cues; {result['referenceFrames']} reference frames.")
        if args.render_reference:
            references = manifest["referenceFrames"]
            names = {name for item in references for name in (item["name"], Path(item["file"]).name)}
            unknown = set(args.render_reference) - names - {"all"}
            if unknown:
                raise ValueError("Unknown reference checkpoint: " + ", ".join(sorted(unknown)))
            selected = references if "all" in args.render_reference else [
                item for item in references if item["name"] in args.render_reference
                or Path(item["file"]).name in args.render_reference]
            cli = ROOT / "node_modules/@remotion/cli/remotion-cli.js"
            if not cli.is_file():
                raise ValueError("Run npm ci before rendering reference frames")
            for item in selected:
                with tempfile.TemporaryDirectory(prefix="atlas-reference-") as temporary:
                    output = Path(temporary) / "render.png"
                    subprocess.run(["node", str(cli), "still", "src/index.ts", item["composition"],
                                    str(output), f"--frame={item['frame']}", "--log=error"],
                                   cwd=ROOT, check=True)
                    expected = png_pixels(ROOT / item["file"])
                    actual = png_pixels(output)
                    if actual != expected:
                        raise ValueError(f"Rendered pixels differ: {Path(item['file']).name}. "
                                         "Source hashes passed; inspect runtime/browser/font differences. "
                                         "Do not silently alter the frozen design or accept a new baseline.")
                    print(f"Exact pixels matched: {Path(item['file']).name} (frame {item['frame']}).")
        return 0
    except (OSError, ValueError, KeyError, TypeError, subprocess.CalledProcessError, wave.Error, zlib.error) as error:
        print(f"Recreation verification failed: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
