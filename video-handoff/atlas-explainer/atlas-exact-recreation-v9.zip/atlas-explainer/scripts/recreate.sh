#!/usr/bin/env bash
set -euo pipefail

# Recreate the saved checkpoint from this directory, never from a global version.
atlas_video_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd -- "$atlas_video_dir"
test -f package-lock.json
if [[ -f REPRODUCTION-MANIFEST.json ]]; then
  python3 scripts/verify_recreation.py
fi
npm ci --no-fund --no-audit
npm run check
exec npm run studio
