#!/usr/bin/env python3
"""Copy the actual local workbench and attach a fictional, in-memory workspace.

The app's HTML/CSS/JS is unchanged except a local bootstrap script inserted in the
copied index. No existing workspace, database, browser automation or remote API is
used. The browser's in-memory directory adapter follows the repository test fixture.
"""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

VIDEO = Path(__file__).resolve().parents[1]
REPO = VIDEO.parents[1]
SOURCE = REPO / 'atlas/atlas-plugin/atlas-local-workbench'
DEST = VIDEO / 'brief/v6/workbench-demo'
APP = DEST / 'app'
FIXTURE = DEST / 'workspace'


def dump(value):
    return json.dumps(value, ensure_ascii=False, indent=2) + '\n'


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value, encoding='utf-8')


def digest(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def main():
    APP.mkdir(parents=True, exist_ok=True)
    shutil.copytree(SOURCE, APP, dirs_exist_ok=True)
    project = {'project_id': 7, 'project_name': 'Northwind Commerce Lakehouse', 'project_revision': 12, 'tenant_code': 'Northwind'}
    task = '00000000-0000-4000-8000-000000000006'
    files = {
        '.atlas/session.json': dump({'schema_version': '2.0', 'tenant': {'id': 1, 'code': 'Northwind'}, 'project': {'id': 7, 'name': project['project_name']}, 'active_task': task, 'sql': {'policy': 'never'}, 'subagent_policy': {'mode': 'current'}}),
        f'.atlas/tasks/{task}.json': dump({'schema_version': '2.0', 'outcome': 'Review returns and refunds in the existing Sales model'}),
    }
    def entity(name, kind, definition, source, order):
        return {'dimensional_entity_schema_name': 'gold', 'dimensional_entity_name': name,
                'dimensional_entity_definition': definition, 'dimensional_entity_type': kind,
                'dimensional_fact_type': 'transaction' if kind == 'fact' else None,
                'dimensional_entity_grain_definition': 'One row per returned order line' if kind == 'fact' else None,
                'dimensional_entity_dependency_order': order, 'dimensional_entity_is_active': True,
                'dimensional_entity_is_locked': False,
                'sources': [{'support_source_type': 'logical_entity', 'source_logical_entity': {'logical_entity_schema_name': 'silver', 'logical_entity_name': source}, 'rationale': 'Reusable Sales model source.', 'is_active': True, 'is_locked': False}]}
    dims = [entity('DimCustomer', 'dimension', 'Customer identity and reporting attributes.', 'Customer', 0),
            entity('DimDate', 'dimension', 'Calendar dates for order and return analysis.', 'Date', 0),
            entity('FactReturns', 'fact', 'Returned order lines and return quantities.', 'Returns', 1)]
    proposed = {**dims[2], 'dimensional_entity_definition': 'Returned order lines, return quantities and refund amounts.'}
    files['project-change-set/dimensional_entity.json'] = dump([proposed])
    datasets = [('dimensional_entity', ['dimensional_entity_schema_name', 'dimensional_entity_name'], dims),
                ('dimensional_attribute', ['dimensional_entity_schema_name', 'dimensional_entity_name', 'dimensional_attribute_name'], []),
                ('dimensional_relationship', ['from_dimensional_entity_schema_name', 'from_dimensional_entity_name', 'from_dimensional_attribute_name'], [])]
    members = []
    definitions = []
    with zipfile.ZipFile(REPO / 'tests/atlas/eval/fixtures/project-snapshot.zip') as source_zip:
        for name, keys, rows in datasets:
            rows_text = ''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in rows)
            schema_text = source_zip.read(f'project-snapshot/schemas/project/{name}.schema.json').decode()
            rows_path = f'data/{name}.jsonl'
            schema_path = f'schemas/{name}.schema.json'
            for path, text in [(rows_path, rows_text), (schema_path, schema_text)]:
                files[f'project/project-snapshot/{path}'] = text
                members.append({'path': path, 'size_bytes': len(text.encode()), 'sha256': digest(text)})
            definitions.append({'name': name, 'record_type': name, 'row_count': len(rows), 'canonical_key': keys, 'rows_file': rows_path, 'schema_file': schema_path})
    catalog = dump({'schema_version': '3.0', 'snapshot_kind': 'project', 'project': project, 'sections': [{'name': 'dimensional', 'datasets': definitions}]})
    files['project/project-snapshot/catalog.json'] = catalog
    members.insert(0, {'path': 'catalog.json', 'size_bytes': len(catalog.encode()), 'sha256': digest(catalog)})
    files['project/project-snapshot/manifest.json'] = dump({'schema_version': '3.0', 'snapshot_kind': 'project', 'snapshot_id': 'northwind-demo-project-snapshot', **project, 'catalog': {'path': 'catalog.json', 'sha256': digest(catalog)}, 'members': members})
    for name, value in files.items():
        write(FIXTURE / name, value)
    write(APP / 'demo-data.js', 'globalThis.AtlasDemoFiles = ' + json.dumps(files, ensure_ascii=False) + ';\n')
    write(APP / 'demo-bootstrap.js', '''/* Fictional in-memory workspace. Actual Atlas UI code is unmodified. */
class DemoFile {
  constructor(name, text='') { this.kind='file'; this.name=name; this.text=text; }
  async getFile() { const text=this.text; return {arrayBuffer:async()=>new TextEncoder().encode(text).buffer}; }
  async createWritable() { let value; return {write:async text=>{value=text;},close:async()=>{this.text=value;},abort:async()=>{}}; }
}
class DemoDirectory {
  constructor(name) { this.kind='directory'; this.name=name; this.entries=new Map(); }
  async getDirectoryHandle(name,{create}={}) { const value=this.entries.get(name); if(value?.kind==='directory')return value; if(create){const dir=new DemoDirectory(name);this.entries.set(name,dir);return dir;}throw new DOMException('Missing directory','NotFoundError'); }
  async getFileHandle(name,{create}={}) { const value=this.entries.get(name);if(value?.kind==='file')return value;if(create){const file=new DemoFile(name);this.entries.set(name,file);return file;}throw new DOMException('Missing file','NotFoundError'); }
  async *values(){yield* this.entries.values();}
  async removeEntry(name){this.entries.delete(name);}
}
(async()=>{
  const working=new DemoDirectory('northwind-returns');
  for(const [path,text] of Object.entries(globalThis.AtlasDemoFiles)){
    const parts=path.split('/');let parent=working;
    for(const name of parts.slice(0,-1))parent=await parent.getDirectoryHandle(name,{create:true});
    parent.entries.set(parts.at(-1),new DemoFile(parts.at(-1),text));
  }
  const app=globalThis.AtlasLocalWorkbenchApp;
  app.state.columns['project:dimensional_entity']=['dimensional_entity_schema_name','dimensional_entity_name','dimensional_entity_definition','dimensional_entity_type'];
  await app.connectDirectoryHandle(working);
  await app.switchArea('project','dimensional_entity');
})();
''')
    index = (APP / 'index.html').read_text()
    index = index.replace('  </body>', '    <script src="demo-data.js"></script>\n    <script src="demo-bootstrap.js"></script>\n  </body>')
    write(APP / 'index.html', index)
    provenance = {'purpose': 'Authentic Atlas Local Workbench screenshot using fictional in-memory Northwind metadata.', 'source': str(SOURCE.relative_to(REPO)), 'fixture_origin': 'Synthetic; no database or user workspace read.', 'app_files': []}
    for source_file in sorted(SOURCE.rglob('*')):
        if source_file.is_file():
            provenance['app_files'].append({'path': str(source_file.relative_to(SOURCE)), 'sha256': hashlib.sha256(source_file.read_bytes()).hexdigest()})
    write(DEST / 'PROVENANCE.json', dump(provenance))
    write(DEST / 'README.md', '''# Atlas Local Workbench screenshot fixture

This is the actual bundled Atlas Local Workbench, copied without changing its
application code, styles or markup. The copied index only adds local demo data
and a bootstrap script. A synthetic directory-handle adapter follows the
repository's local-workbench test fixture and calls the public connection API.
It never opens a user directory, connects to a database, or transmits data.
All displayed rows are fictional. Changes in this browser last only until reload.

Regenerate from the repository with:

```bash
python3 scripts/prepare_workbench_demo.py
python3 -m http.server 8036 --bind 127.0.0.1 --directory brief/v6/workbench-demo/app
```

Open `http://127.0.0.1:8036/`. Capture at 1600×650 (or 1600×760 if the
viewport requires more height). It opens to Project / Dimensional Entity with
DimCustomer, DimDate, FactReturns and one proposed refund-related change.
The four selected columns are a supported existing app preference. For a closer
review, click Show details in the FactReturns row; compare Snapshot and Proposed.
Do not run validation for this intentionally bounded display fixture: other
Project sections are omitted. No validation result or server approval is claimed.

`workspace/` contains the actual synthetic session/snapshot/change-set files.
`PROVENANCE.json` records source fingerprints. To reproduce the screenshot
without the repository, serve the included app copy. The source CSP keeps
connect-src disabled; no network API is needed.
''')
    print(f'Prepared {APP} with {len(files)} fictional workspace files.')

if __name__ == '__main__':
    main()
