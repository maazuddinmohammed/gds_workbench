"""Replace three naming/pronoun cues with local Samantha speech.

Exact recreation uses the saved WAV files, never this generator. Each replacement
occupies its original cue start through the next cue start; all PCM outside those
windows is preserved byte-for-byte. Original scene lengths and cue counts remain.
"""
from pathlib import Path
import argparse
import array
import json
import subprocess
import sys
import wave

ROOT = Path(__file__).resolve().parent.parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--wrappers-only", action="store_true")
    args = parser.parse_args()
    plan = json.loads((ROOT / "brief/v9/narration-plan.json").read_text(encoding="utf-8"))
    rate = plan["sampleRate"]
    pending = []
    report = {"voice": plan["voice"], "wordsPerMinute": plan["wordsPerMinute"],
              "sampleRate": rate, "scenes": []}
    if not args.wrappers_only:
        scratch = ROOT / "out/speech-parts/v9"
        scratch.mkdir(parents=True, exist_ok=True)
        for scene in plan["scenes"]:
            name, version = scene["name"], scene["sourceVersion"]
            captions = json.loads((ROOT / f"public/captions/{version}/{name}.json").read_text(encoding="utf-8"))
            with wave.open(str(ROOT / f"public/audio/{version}/{name}.wav"), "rb") as old:
                expected_frames = scene["durationSeconds"] * rate
                assert (old.getnchannels(), old.getsampwidth(), old.getframerate(), old.getnframes()) == (1, 2, rate, expected_frames)
                original = old.readframes(old.getnframes())
            combined = bytearray(original)
            windows, changes = [], []
            for replacement in scene["replacements"]:
                index = replacement["cueIndex"]
                cue = captions[index]
                start = round(cue["startMs"] * rate / 1000)
                stop = round(captions[index + 1]["startMs"] * rate / 1000) if index + 1 < len(captions) else expected_frames
                text_file = scratch / f"{name}-{index + 1}.txt"
                clip_file = scratch / f"{name}-{index + 1}.wav"
                text_file.write_text(replacement["text"], encoding="utf-8")
                clip_file.unlink(missing_ok=True)
                subprocess.run(["say", "-v", plan["voice"], "-r", str(plan["wordsPerMinute"]),
                                "--file-format=WAVE", f"--data-format=LEI16@{rate}",
                                "-f", str(text_file), "-o", str(clip_file)], check=True, capture_output=True)
                with wave.open(str(clip_file), "rb") as clip:
                    assert (clip.getnchannels(), clip.getsampwidth(), clip.getframerate()) == (1, 2, rate)
                    pcm = clip.readframes(clip.getnframes())
                samples = array.array("h", pcm)
                if sys.byteorder != "little":
                    samples.byteswap()
                peak = max((abs(value) for value in samples), default=0)
                if peak < 100:
                    raise RuntimeError("Local speech is silent; no final assets written.")
                end = start + len(samples)
                if end > stop:
                    raise RuntimeError(f"{name} cue {index + 1} overlaps the next cue; no final assets written.")
                combined[start * 2:stop * 2] = pcm + bytes((stop - end) * 2)
                cue["text"] = replacement["text"]
                cue["endMs"] = round(end * 1000 / rate)
                windows.append((start, stop))
                changes.append({"cue": index + 1, "text": cue["text"], "startMs": cue["startMs"],
                                "endMs": cue["endMs"], "replacementWindowEndMs": round(stop * 1000 / rate),
                                "peak": peak})
            cursor = 0
            for start, stop in sorted(windows):
                assert combined[cursor * 2:start * 2] == original[cursor * 2:start * 2]
                cursor = stop
            assert combined[cursor * 2:] == original[cursor * 2:]
            assert len(combined) == len(original)
            previous_end = 0
            for cue in captions:
                assert previous_end <= cue["startMs"] < cue["endMs"] <= scene["durationSeconds"] * 1000
                previous_end = cue["endMs"]
            pending.append((name, bytes(combined), captions))
            report["scenes"].append({"name": name, "sourceVersion": version,
                                     "durationSeconds": scene["durationSeconds"], "captionCues": len(captions),
                                     "outsideReplacementWindowsIdentical": True, "replacements": changes})
        for name, pcm, captions in pending:
            audio_path = ROOT / f"public/audio/v9/{name}.wav"
            caption_path = ROOT / f"public/captions/v9/{name}.json"
            audio_path.parent.mkdir(parents=True, exist_ok=True)
            caption_path.parent.mkdir(parents=True, exist_ok=True)
            with wave.open(str(audio_path), "wb") as output:
                output.setnchannels(1)
                output.setsampwidth(2)
                output.setframerate(rate)
                output.writeframes(pcm)
            caption_path.write_text(json.dumps(captions, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        (ROOT / "out/narration-v9-report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(report))

    source = '''// Saved v9 narration; generated by scripts/build_narration_v9.py.
import { Audio } from "@remotion/media";
import { staticFile, useVideoConfig } from "remotion";
import { BasicCaptions } from "../basic-captions.element";

'''
    for scene in plan["scenes"]:
        name = scene["name"]
        title = name.title()
        captions = json.loads((ROOT / f"public/captions/v9/{name}.json").read_text(encoding="utf-8"))
        literal = json.dumps(captions, indent=2, ensure_ascii=False)
        source += f'''export const {title}Narration = ({{showCaptions}}:{{showCaptions:boolean}}) => {{
  const {{fps}}=useVideoConfig();
  return <>
    <Audio name="{title} narration" src={{staticFile("audio/v9/{name}.wav")}} premountFor={{fps}}/>
    {{showCaptions ? <BasicCaptions name="{title} captions" premountFor={{fps}} width={{3200}} combineTokensWithinMilliseconds={{0}} style={{{{position:"absolute",left:160,bottom:18,scale:.5,transformOrigin:"left bottom"}}}} captions={{{literal}}}/> : null}}
  </>;
}};

'''
    (ROOT / "src/v9/SceneNarration.tsx").write_text(source, encoding="utf-8")


if __name__ == "__main__":
    main()
