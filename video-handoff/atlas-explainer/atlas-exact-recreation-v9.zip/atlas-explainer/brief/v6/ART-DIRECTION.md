# Atlas v6 visual direction

Preserve the accepted v5 story, 4:40 timing and orchestration. V6 directs attention
with narration-led focus, gives the Build visuals more room, and shows the actual
Atlas Local Workbench during review. No narration changes.

## Visual system

Light paper, white surfaces, blue `#00338D`, accent `#1E49E2`, ink `#0C233C`,
bundled Open Sans and canonical Atlas mark. Recognizable Copilot stays present;
VS Code remains its subordinate host label. Use soft blue fills, borders and
shadows to emphasize the box being discussed. Ease highlights in and out without
layout jumps, repeated pulses or competing emphasis. Keep official future-client
marks explicitly future-labeled.

## Scene treatment

1. **Intro, 42s.** Preserve Welcome. Highlight Copilot, Atlas Plugin and future
   integrations in time with the reused voiceover. Continue narrated focus across
   the environment: workspace, shared MCP/PostgreSQL knowledge, Atlas Platform,
   source systems, GDS orchestrator and lakehouse. Preserve the clean two-row map.
2. **Onboarding, 42s.** Retain Start Atlas → authorized Tenant → existing named
   Project → task choices → custom change. The project names and eleven task
   choices remain readable. The request is “Add returns and refunds to the
   existing Sales model.” Preserve the accepted typing, selection and shrink.
3. **Snapshot, 28s.** Return briefly to highlighted shared knowledge, then focus
   the narrated snapshot/Bridge elements. Keep the direct transfer aligned and
   token/context efficiency explanation. Stage ends at a server draft.
4. **Build, 54s.** Keep the nine-stage icon strip and active-stage highlight.
   Reduce Copilot to `.82` scale, top-left origin, leaving more room for diagrams.
   Retain simple, large visuals for profiling, enrichment, analysis and subject
   areas. Show the operational extension and use PascalCase `DimCustomer`,
   `DimDate`, `FactReturns` for dimensional entities. Remove redundant approval
   annotations and the constant metadata-management footer. Their underlying
   governance/capability remains in the unchanged narration and claim evidence.
5. **Review, 32s.** Replace the invented model-review drawing with the actual
   Workbench capture `public/screenshots/workbench-v6.jpg`. Display it at
   x144/y246, width 1632/height 663. Ease in over the first .6–.8s; hold until
   5.5s, then fade out by 6.1s with subtle scale 1 → .975. Copilot returns over
   6.1–6.8s, after the screenshot clears. Change the heading from “Review in
   Atlas Local Workbench.” to “Review. Then approve.” at 6.1s. Preserve the existing
   Bridge, server-draft review, separate Apply, shared knowledge and audit flow.
6. **Run, 26s.** Preserve accepted delivery and Source → Bronze → Silver → Gold.
7. **Team, 36s.** Preserve central Atlas, separate Copilot sessions, tenant roles,
   saved-context continuity, Tenant Lock ownership and revision fencing.
8. **Closing, 20s.** Return to the same environment map with focused emphasis,
   then retain “Move GDS forward. Keep knowledge with the project.”

## Authentic screenshot

The saved JPEG is a direct 2276×920 browser capture (1707×690 CSS clip from
a 1707×960 CSS viewport) of the real local app populated
with fictional Northwind metadata. Preserve its whole UI and header; use contain
fitting, not a redrawn imitation. The copied app and synthetic fixture are under
`workbench-demo/`, including provenance and recapture instructions. No actual
user workspace, database, validation pass or server approval is implied. Exact
video replay uses the saved image and requires no app server.

## Implementation and preservation

Use frame-driven eased motion and named Interactive JSX. Keep overview locations
consistent with the detail views. Stage, Apply, delivery and runtime data movement
remain separate. Nine-stage coverage is a capability view, not a compulsory
unreviewed chain for every request. Existing Project/input scope is assumed.

Current artwork lives in `src/v6/`; older sources stay unchanged. Eight standalone
V6 compositions include Review. `AtlasReviewV5` and `archive/review-v5/` preserve
the last cut. Audio is reused: v5 Onboarding/Build 96s, v4 Intro/Snapshot/Team/
Closing 126s, v2 Review/Run 58s. V6 has no new narration generator. Saved audio,
captions, icons and fonts are required for exact replay.

Follow `STORYBOARD.md`, `ASSETS.json`, the v5/v4/v2 narration sources and
`../v4/CLAIMS.md`. V6 lint/types, bundle, clean recreation, audio timing, representative renders
and audio-enabled Studio playback passed; see README for recorded evidence.
