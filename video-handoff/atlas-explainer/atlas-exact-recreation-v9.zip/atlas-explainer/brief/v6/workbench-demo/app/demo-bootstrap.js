/* Fictional in-memory workspace. Actual Atlas UI code is unmodified. */
class DemoFile {
  constructor(name, text='') { this.kind='file'; this.name=name; this.text=text; }
  async getFile() { const text=this.text; return {arrayBuffer:async()=>new TextEncoder().encode(text).buffer}; }
  async createWritable() { let value; return {write:async text=>{value=text;},close:async()=>{this.text=value;},abort:async()=>{}}; }
}
class DemoDirectory {
  constructor(name) { this.kind='directory'; this.name=name; this.entries=new Map(); }
  async getDirectoryHandle(name,{create}={}) { const value=this.entries.get(name); if(value?.kind==='directory')return value; if(create){const dir=new DemoDirectory(name);this.entries.set(name,dir);return dir;}throw new DOMException('Missing directory','NotFoundError'); }
  async getFileHandle(name,{create}={}) { const value=this.entries.get(name);if(value?.kind==='file')return value;if(create){const file=new DemoFile(name);this.entries.set(name,file);return file;}throw new DOMException('Missing file','NotFoundError'); }
  async *values(){yield* this.entries.values();}
  async removeEntry(name){this.entries.delete(name);}
}
(async()=>{
  const working=new DemoDirectory('northwind-returns');
  for(const [path,text] of Object.entries(globalThis.AtlasDemoFiles)){
    const parts=path.split('/');let parent=working;
    for(const name of parts.slice(0,-1))parent=await parent.getDirectoryHandle(name,{create:true});
    parent.entries.set(parts.at(-1),new DemoFile(parts.at(-1),text));
  }
  const app=globalThis.AtlasLocalWorkbenchApp;
  app.state.columns['project:dimensional_entity']=['dimensional_entity_schema_name','dimensional_entity_name','dimensional_entity_definition','dimensional_entity_type'];
  await app.connectDirectoryHandle(working);
  await app.switchArea('project','dimensional_entity');
})();
