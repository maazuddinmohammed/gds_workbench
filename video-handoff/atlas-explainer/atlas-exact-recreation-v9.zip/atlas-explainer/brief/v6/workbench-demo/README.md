# Atlas Local Workbench screenshot fixture

This is the actual bundled Atlas Local Workbench, copied without changing its
application code, styles or markup. The copied index only adds local demo data
and a bootstrap script. A synthetic directory-handle adapter follows the
repository's local-workbench test fixture and calls the public connection API.
It never opens a user directory, connects to a database, or transmits data.
All displayed rows are fictional. Changes in this browser last only until reload.

Regenerate from the repository with:

```bash
python3 scripts/prepare_workbench_demo.py
python3 -m http.server 8036 --bind 127.0.0.1 --directory brief/v6/workbench-demo/app
```

Open `http://127.0.0.1:8036/`. Capture at 1600×650 (or 1600×760 if the
viewport requires more height). It opens to Project / Dimensional Entity with
DimCustomer, DimDate, FactReturns and one proposed refund-related change.
The four selected columns are a supported existing app preference. For a closer
review, click Show details in the FactReturns row; compare Snapshot and Proposed.
Do not run validation for this intentionally bounded display fixture: other
Project sections are omitted. No validation result or server approval is claimed.

`workspace/` contains the actual synthetic session/snapshot/change-set files.
`PROVENANCE.json` records source fingerprints. To reproduce the screenshot
without the repository, serve the included app copy. The source CSP keeps
connect-src disabled; no network API is needed.
