# V3: orientation, then the familiar workflow

Retain the accepted v2 blue/white style, Copilot chat, vector pictorials, quiet
motion, project packet and readable labels. V3 adds context and clearer design
flow; it is not a visual redesign.

## First-time viewer

Start with one sentence defining Atlas and three places: the engineer's Copilot
workspace, shared project knowledge through Atlas MCP/PostgreSQL, and GDS
execution. Reveal these groups progressively. A separate Delivery path carries
metadata, DDL and SQL into GDS; the context arrows do not carry physical data.
Zoom the Copilot box into the existing chat. Match header and composer geometry
before crossfading so there is no doubled text. Keep the overview available as
a closing return and small location indicator in the detailed workflow.

## Build

Show the whole design path first: Profile & analyze → Models → Mappings →
Code & checks. Move that path into a small rail; focus on one stage at a time.
Show the Sales subject area, then separate Silver operational and Gold
dimensional models with lineage arrows. This is a design flow, distinct from
the physical Source → Bronze → Silver → Gold pipeline later in the film.

Use an illustrative source-to-target mapping with visible field arrows.
Then show table definitions, SQL and validation scripts entering the Sales
packet. Narration and chat acknowledge approved/saved upstream inputs; the
compressed overview does not remove required review cycles.

## Reuse and scope

Only Overview and Build narration are new. Six saved v2 audio clips remain
unchanged. Context, review, GDS execution and teammate scenes reuse their v2
components. The v2 close is covered briefly by the returning environment map,
then retains its final Atlas message. The complete film is 198 seconds.

Keep optional captions off in the main cut. Preserve the official Copilot mark,
canonical Atlas SVG, bundled Open Sans, licenses and deterministic frame motion.
No live data, fake measurements, production execution results or strengthened
security/compatibility claims. See ../CLAIMS.md.
