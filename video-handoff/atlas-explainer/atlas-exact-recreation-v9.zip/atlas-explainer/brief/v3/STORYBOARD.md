# Atlas — the big picture, then one project

V3 overview/build revision · 198 seconds / 5,940 frames · 1920×1080 · 30 fps
Audience: stakeholders and data engineers seeing Atlas for the first time.

Preserve the accepted v2 style, Copilot chat, pictorials and most scene content.
Add an 18-second environment overview before the existing workflow; replace
only the 32-second Build narration. The two new audio clips total 50 seconds,
not the complete film. Other narration uses the saved v2 audio unchanged.
Narration is temporary local macOS Samantha; captions remain optional.

## Full editorial timeline

| Time | Duration | Scene | Narration source |
| --- | ---: | --- | --- |
| 0:00–0:18 | 18s | Overview: who uses Atlas and how the big pieces connect | v3 Overview |
| 0:18–0:38 | 20s | Ask Copilot to build the Sales project | v2 Ask |
| 0:38–1:02 | 24s | Bring shared project context through Atlas MCP | v2 Context |
| 1:02–1:34 | 32s | Profile, analyze, model, map and generate | v3 Build |
| 1:34–2:06 | 32s | Review locally; separately approve Stage and Apply | v2 Review |
| 2:06–2:32 | 26s | Deliver artifacts; GDS runs Bronze → Silver → Gold | v2 Run |
| 2:32–3:00 | 28s | Another teammate continues from saved project context | v2 Continue |
| 3:00–3:18 | 18s | Close the development and maintenance loop | v2 Close |

Unchanged narration and its original detailed beats remain in
`../v2/STORYBOARD.md`. Source evidence and boundaries remain in `../CLAIMS.md`.

## Overview · 00:00–00:18

**Narration**

Atlas helps data engineers build and maintain GDS projects. You work in Copilot,
connected through Atlas MCP to shared project knowledge. Atlas prepares the
models, metadata and code; GDS runs the data pipeline from source to Gold.

**Picture**

Show three spatially stable groups: an engineer with Copilot and Atlas Plugin;
shared project knowledge with Atlas MCP and PostgreSQL; GDS orchestrator above
Bronze, Silver and Gold. Atlas MCP and PostgreSQL exchange project context.
Approved work reaches GDS through a separate Delivery path. A short Metadata /
DDL / SQL bundle label identifies its inputs. Do not imply Atlas Apply starts
GDS or directly deploys artifacts. Zoom into the Copilot group to enter the
existing chat journey. Keep the three-group environment recognizable when later
scenes focus on its individual components.

**Cue targets:** 0.6s product/user; 4.9s Copilot and shared context; 9.8s prepared
artifacts; 13.2s GDS execution. Reveal the corresponding group before or with its
spoken clause. PostgreSQL and Atlas Plugin are visible labels; narration does
not need to list every product component.

## Build · 01:02–01:34

**Narration**

First, profile the source data, then analyze its keys and relationships. Organize
related tables into subject areas. Build a normalized operational model for
Silver, then dimensions and facts for Gold. Mappings explain how source fields
populate each target. With the required inputs approved and saved, Atlas
generates table definitions, transformation SQL, and validation checks.

**Picture**

Make the design workflow visible: Profiling and analysis → Models → Mappings →
Code and checks. Source sheets first reveal a magnifier and key/relationship
links. Group related tables into the Sales subject area. Show the Silver
operational model feeding the Gold dimensional model, keeping a connecting
arrow and short layer labels visible. A mapping sheet connects source fields
to targets. Finally reveal DDL, transformation SQL and validation documents.
Use proposed examples, not invented profiling measurements or execution passes.

The design sequence is distinct from the later physical data pipeline. Each
stage requires the appropriate approved/applied inputs: dimensional modeling
uses the applied logical model; mappings use applied targets; code uses applied
mappings. A high-level sequence may compress those repeated review cycles, but
must not show an unreviewed draft automatically generating all downstream work.

**Cue targets:** 0.6s profiling/analysis; 5.7s subject areas; 9.4s operational
Silver; 13.0s dimensional Gold; 16.4s mappings; 21.2s approved/saved inputs;
24.9s generated table definitions, SQL and checks.

## Preservation and scope

- Preserve all v2 source and saved narration for comparison/recreation.
- Keep the accepted visual language: large pictorials, recognizable Copilot,
  sparse text and continuous cause-and-effect motion.
- Narration plan contains only these two changed scenes. The generator must not
  overwrite any v2 files or resynthesize unchanged voice clips.
- Do not strengthen RLS, native ADO, future-client or automatic-execution claims.
- Keep the implementation, current storyboard and recreation guide synchronized.
