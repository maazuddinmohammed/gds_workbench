# Atlas — one Sales project, end to end

Revision 03 · 2026-11-10 · 180-second fixed timeline · 251 narration words
1920×1080 · 30 fps · stakeholders and data engineers

This replaces the information-heavy presentation with a single visible workflow.
The viewer follows one Sales project from a request in Copilot to delivery and
the next teammate's change. This is an illustrative workflow, not a recorded
production execution. Preserve the factual boundaries in `../CLAIMS.md`.

Copilot chat is the protagonist. VS Code remains a small context label. Keep the
same blue Sales project packet visible through the workflow; it gives continuity
to the chat, shared knowledge, local draft, approved artifacts and maintenance.

Narration is temporary local macOS Samantha. Caption display is optional and off
by default; when enabled, use short phrase pages. Cue targets are in
`narration-plan.json`. Preserve natural phrase gaps without rushing or truncating
speech. Cue timing may shift slightly; the seven scene durations stay fixed.

## 01 · Ask · 00:00–00:20

**On-screen takeaway:** Ask Copilot

**Narration**

A data engineer opens Copilot and asks: “Build a Sales project from our customers
and orders.” Atlas turns that request into a guided workflow. The conversation
stays in Copilot.

**Picture**

Start directly inside a large, recognizable Copilot chat. Type the request,
send it, then show one concise response. Use the official Copilot mark, clear
chat bubbles and a restrained “via VS Code” label. The request becomes the blue
Sales project packet. Do not introduce a separate title slide or feature list.

**Beats:** request typing → send → Atlas response → project packet appears.

## 02 · Context · 00:20–00:44

**On-screen takeaway:** Bring in project context

**Narration**

First, Atlas brings in the project’s saved requirements and metadata. Copilot
reaches them through Atlas MCP. A local snapshot gives the agent a working copy,
so it can build without repeatedly fetching the same context.

**Picture**

Move the chat aside without making it disappear. The packet travels through an
Atlas MCP cloud to PostgreSQL, then returns as a local folder. Reveal Azure,
MCP and PostgreSQL labels only when the associated object is active. Show an
authorized-user symbol briefly. Keep physical lakehouse data separate from the
saved metadata and project knowledge. The picture explains the path; narration
carries the technical detail.

**Beats:** shared project store → governed access → local snapshot → back to chat.

## 03 · Build · 00:44–01:16

**On-screen takeaway:** Build the Sales project

**Narration**

The agent examines the source information and proposes how customers and orders
fit together. You see the Sales model take shape, then the dimensional model
for reporting. From those models, Atlas prepares the mappings, table definitions,
transformation SQL, and validation checks needed for delivery.

**Picture**

Customers and Orders pictorial sheets emerge from the packet. A magnifier
examines them, then a relationship joins the correct matching fields. The same
objects rearrange into a Silver model and then a Gold star. The model folds into
a small artifact bundle. Reveal each deliverable briefly instead of showing a
complete list beside the narration. Illustrate proposed relationships, not
fabricated measured outcomes. Validation is a prepared check, not a Pass result.

**Beats:** examine source → propose model → reporting model → delivery bundle.

## 04 · Review · 01:16–01:48

**On-screen takeaway:** Review, then approve

**Narration**

Now you review the proposed changes in Atlas Local Workbench. Approve Stage in
the chat, and Atlas Bridge sends the draft for server validation. After reviewing
that result, approve Apply separately. The approved definitions become shared
project state. Changes are protected and audited.

**Picture**

Open one understandable proposed change in a Workbench review sheet. Return
focus to chat: the person approves Stage and the packet moves to a server draft.
Show the validation response. A second chat message approves Apply, then the
packet enters the shared project store. These are two separate decisions. Do not
invent Stage or Apply buttons inside Atlas Local Workbench. A small lock/revision
motif and audit receipt support the ending without expanding into a security list.

**Beats:** inspect → approve Stage → validate → separately approve Apply → save.

## 05 · Run · 01:48–02:14

**On-screen takeaway:** GDS runs the pipeline

**Narration**

Your delivery process deploys those artifacts. Then the GDS orchestrator does
the processing: source data lands in Bronze, becomes structured Silver data,
and flows into Gold for reporting. Atlas also prepares validation checks to
accompany those outputs.

**Picture**

The artifact bundle crosses a visible Delivery gate before GDS execution begins.
The GDS orchestrator activates and illustrated records flow through three
recognizable layered trays: Bronze, Silver and Gold. A checks document accompanies
the output. Do not imply that Atlas Apply executes DDL, deploys code, starts GDS
or proves that real data passed validation. Keep the Source → Bronze → Silver →
Gold motion causal and easy to follow.

**Beats:** deployment handoff → orchestrator → Bronze → Silver → Gold + checks.

## 06 · Continue · 02:14–02:42

**On-screen takeaway:** Continue from saved work

**Narration**

Later, another authorized teammate opens the same project and asks to add a new
source. Atlas starts from the saved project knowledge. The team can review the
impact and update the model, code, and checks. Atlas Platform shows the shared
results.

**Picture**

A different teammate enters the same Copilot chat layout and asks, “Add our
returns data.” The familiar Sales packet arrives intact from the shared store.
A Returns sheet joins the model; affected artifacts highlight in sequence. Show
a brief illustrative Atlas Platform shared-results view, then return to the
workflow. Shared saved context is reused; do not depict another person's private
chat or unfinished local files transferring automatically.

**Beats:** new teammate → shared Sales context → new source → impact → updates.

## 07 · Close · 02:42–03:00

**On-screen takeaway:** Keep improving

**Narration**

That is the loop: ask, build, review, deliver, and improve. Atlas helps GDS move
faster while keeping project knowledge with the project.

**Picture**

Pull back to the already-familiar workflow as the Sales packet completes the
loop. Five meaningful icons and five short labels are enough. Close on the
canonical Atlas mark. Introduce no new products, claims or architecture here.

**Beats:** pull back → trace familiar loop → Atlas closing hold.

## Editorial decisions

- One concrete request replaces an abstract capability inventory.
- Keep one hero action at a time and about 15–25 visible words in the active shot.
- Chat exchanges replace explanatory bullet lists. Narration carries detail.
- Use familiar pictorials and the official Copilot mark, with original Atlas
  branding. Keep the illustrative chat recognizable without a large VS Code shell.
- Maintain spatial continuity: objects move, transform or connect; they do not
  repeatedly restart in disconnected slide layouts.
- ADO Boards and future clients are removed from the core cut. They are optional
  appendix material: ADO requires a separate authorized agent connector; Codex,
  Claude Code and Cursor remain future directions, not current supported hosts.
- Do not add the appendix to the core cut without a specific reason; it would
  interrupt the workflow and reintroduce the information overload being corrected.
