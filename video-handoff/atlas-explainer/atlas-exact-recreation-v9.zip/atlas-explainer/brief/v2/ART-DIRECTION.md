# Atlas workflow film — art direction

## Visual thesis

A calm, bright product film in which a recognizable Copilot conversation turns
one blue Sales project packet into a working GDS project; clear pictorials and
continuous movement make each handoff understandable.

## Content plan

1. **Ask:** begin in Copilot chat with a concrete Sales request.
2. **Context:** bring saved project knowledge to the agent through Atlas MCP.
3. **Build:** source sheets become a model, then a delivery bundle.
4. **Review:** a human inspects the work and approves Stage and Apply separately.
5. **Run:** the deployment handoff leads to GDS's Bronze, Silver and Gold flow.
6. **Continue:** another teammate extends the same saved project.
7. **Close:** pull back to the familiar loop; introduce no new concepts.

ADO Boards and additional agent clients belong in an optional appendix, not in
the core workflow. Their current/future boundaries remain in `../CLAIMS.md`.

## Motion thesis

- **Follow one object.** The Sales project packet is the visual thread. It moves
  from chat to shared context, local work, review and delivery, then returns for
  the next change. The packet symbolizes the project; it must not imply raw
  physical data or private chat is copied into shared metadata.
- **Make cause and effect visible.** A message is sent before a workflow begins.
  A source joins before a model changes. The person's approval happens before
  Stage or Apply. Artifacts cross a deployment gate before GDS processing.
- **Transform in place.** Keep locations consistent and morph familiar objects
  into their next form. Use restrained easing and enough still time to read the
  result. Do not replace every thought with a new slide entrance.

## Composition rules

- One hero action and one dominant visual at a time.
- Target **15–25 visible words** in the active shot, including chat content and
  active labels. A quiet persistent navigation rail may use very short labels.
- No header plus explanatory paragraph. No repeated subtitle plus caption plus
  diagram sentence explaining the same concept.
- Use a recognizable **GitHub Copilot chat**: official Copilot mark, readable
  user/assistant bubbles, a short project indicator and one active exchange.
  Keep VS Code to a small secondary label or thin contextual frame.
- The same **Sales** packet and source pictorials recur. Do not invent a fresh
  visual language for each chapter.
- Use larger, semantically clear pictures: chat, cloud gateway, shared database,
  source sheet, model relationships, artifact folder, review sheet, person and
  pipeline trays. Pictures must explain an action; decorative imagery is expendable.
- Show no more than three active picture groups at once. Fade inactive context
  back rather than accumulating an ever-larger architecture chart.
- A lightweight workflow rail can orient the viewer. It should highlight the
  current action and must not become a second diagram competing for attention.
- Preserve the Atlas Meridian mark, Open Sans and blue/white identity. Use depth,
  scale and restrained shadows to separate working objects without a card grid.
- Keep primary content inside the 144-pixel horizontal safe area. Reserve a
  lower caption band even when captions are hidden.

## Text and sound

- Narration carries detail. The picture demonstrates what the words describe.
- Temporary voice: locally generated macOS Samantha; no external speech upload.
- **Captions default off.** Keep an optional captioned version or editable toggle.
  When enabled, show short phrase pages, not paragraph subtitles.
- Chat messages are concise illustrative actions. Use one user message and one
  useful agent response at a time; avoid a rapidly scrolling transcript.
- Do not show status text, narration text and a takeaway that all repeat each other.

## Accuracy boundaries in pictures

- Atlas Local Workbench is the review surface. Stage/Apply approvals occur in
  chat; do not fabricate those buttons inside Workbench.
- Stage creates a server draft. Apply saves approved shared definitions.
- Delivery/deployment is a separate visible handoff before GDS runs.
- Roles and authorization are server enforced; do not show an unverified RLS badge.
- Use synthetic source/model examples and clearly illustrative UI. Do not invent
  profiling statistics, validation passes or production-success evidence.
- Shared saved project context persists. Private conversations and unfinished
  local work do not automatically transfer to another teammate.

## Review questions

- Without the narration, can a viewer identify the current actor and action?
- Can the viewer see where the result goes next?
- Does Copilot look like a conversation rather than a rectangle with its name?
- Does every picture explain a step in the same Sales project?
- Would removing another sentence make the action clearer?
