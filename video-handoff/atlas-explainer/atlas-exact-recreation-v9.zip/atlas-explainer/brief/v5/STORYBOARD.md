# Atlas v5 — clearer architecture and task selection

Duration: 4:40 / 280 seconds / 8,400 frames at 30 fps.

| Time | Scene |
|---|---|
| 0:00–0:42 | Welcome, agent integrations and cleaner environment map |
| 0:42–1:24 | Start Atlas, tenant, named project, task choices, custom enhancement |
| 1:24–1:52 | Local snapshot and aligned Bridge transfer diagram |
| 1:52–2:46 | Nine-stage highlighted capability strip with enhancement example |
| 2:46–3:18 | Review / Stage / Apply |
| 3:18–3:44 | Delivery and GDS orchestration |
| 3:44–4:20 | Shared Atlas and scoped team access |
| 4:20–4:40 | Return to architecture and preserved ending |

Only Onboarding and Build narration change. Intro/Snapshot/Team/Closing use v4 saved audio; Review/Run use v2. The nine stages illustrate Atlas capabilities; a particular request follows its actual dependencies. Project and input scope already exist. Adding project scope is not an exposed Plugin operation.

## Onboarding — 42s

**Narration**

Start by typing, Start Atlas, in Copilot. Atlas lists only the tenants you can access. Choose your tenant, then an existing project. Choose a task: investigate, analyze sources, or manage metadata. Build models, mappings, code and validation, or register delivery artifacts. You can also describe a custom enhancement. Add returns and refunds to the existing Sales model. Atlas assesses the impact and routes the work to the right skills.

**Picture**

Start Atlas → authorized tenant → Northwind Commerce Lakehouse or Northwind Supply Chain Modernization. Show Plugin task choices, then a custom change: add returns and refunds to the existing Sales model. Atlas assesses dependencies and scope readiness.

## Build — 54s

**Narration**

Profile the new source evidence. Enrich descriptions and technical metadata. Analyze keys, grain and relationships. Group related objects into subject areas. Extend the existing operational model with returns and refunds. Then update the dimensions and facts for Gold. Update operational mappings from new source fields to Silver targets. Update dimensional mappings for Gold. With required inputs approved, generate operational transformation SQL and table definitions. Generate dimensional code for the Gold layer. Prepare validation scripts for both operational and dimensional outputs. Manage metadata throughout the project lifecycle.

**Picture**

One top strip: Profiling, Enrichment, Analysis, Subject Areas, Operational Data Model, Dimensional Data Model, Mapping, Code Generation, Validation. Icon boxes highlight the current stage. Existing model context extends with Returns; both operational/dimensional outputs stay visible. Remove the old heading and duplicate discovery labels.

