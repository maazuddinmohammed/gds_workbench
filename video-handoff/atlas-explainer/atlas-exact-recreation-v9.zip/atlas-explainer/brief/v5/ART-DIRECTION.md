# Atlas v5 visual direction

Preserve the accepted v4 style and orchestration. V5 clarifies the architecture,
puts real task choices before custom requirements, and consolidates the Build
navigation. Duration is 4:40; the longer onboarding gets 42 seconds.

## Retained visual system

Light paper, white surfaces, blue `#00338D`, accent `#1E49E2`, ink `#0C233C`,
bundled Open Sans and canonical Atlas mark. Large reused pictorials and short
labels carry the story. Copilot remains recognizable; VS Code is subordinate.
No emoji, invented metrics, paragraph slides or dense dashboard screenshots.
Official agent marks retain their source records and future-integration labels.

## Sequence and emphasis

1. **Intro, 42s.** Preserve Welcome and current/future client explanation. Replace
   the old environment layout with clearer boxes for source systems, GDS
   orchestrator and lakehouse. Arrows make the source → orchestrator → lakehouse
   relationship explicit. Keep Atlas Plugin, Bridge, MCP, PostgreSQL and Platform
   identifiable, with artifact delivery separate from physical data movement.
2. **Onboarding, 42s.** Type Start Atlas. Choose authorized Northwind, then show
   stacked existing Projects: Northwind Commerce Lakehouse and Northwind Supply
   Chain Modernization. Present eleven Plugin task choices in three legible
   groups. Let the viewer read them, highlight the custom option after 25s,
   then type “Add returns and refunds to the existing Sales model.” Submit at
   36s; Atlas assesses impact on existing artifacts. Shrink chat over 40–42s.
3. **Snapshot, 28s.** Return briefly to the map with shared knowledge highlighted,
   then open its local working-copy view. Explain focused reuse and token/context
   efficiency. Align the final transfer as approved local files → Atlas Bridge →
   Atlas MCP → PostgreSQL server draft. Keep the separate Apply later in the film.
4. **Build, 54s.** One top strip of nine icon boxes: Profiling, Enrichment,
   Analysis, Subject Areas, Operational Data Model, Dimensional Data Model,
   Mapping, Code Generation and Validation. Highlight the current box. Remove
   the old heading and repeated discovery labels. The detail area extends an
   existing Sales model with Returns, then shows both layers' mappings, code and
   validation. Metadata management remains the lifecycle foundation.
5. **Review, 32s.** Preserve review, Stage, server validation and separate Apply.
6. **Run, 26s.** Preserve accepted delivery and Source/Bronze/Silver/Gold
   orchestration. Adapt chat context to the enhancement without rewriting the
   established physical pipeline picture.
7. **Team, 36s.** Preserve central Atlas, separate Copilot sessions and tenant
   compartments. Access follows roles/Tenants; saved knowledge enables handoff;
   locks coordinate writes and revisions reject stale changes.
8. **Closing, 20s.** Return to the same cleaner map, then preserve “Move GDS
   forward. Keep knowledge with the project.”

## Layout, timing and preservation

Keep model-design flow separate from physical pipeline flow. Stage ends at a
server draft; no picture should imply Bridge automatically Applies or deploys.
Avoid unnecessary new details while making the requested relationships explicit.
The nine-stage strip represents capabilities, not an obligation to run all stages
for every enhancement. Project and authorized input scope already exist.

Use named Interactive JSX, independently editable scene nodes and frame-based
eased motion. Preserve spatial consistency between overview and detail. Chat
keeps a compact Northwind › Commerce Lakehouse scope; task menu labels and long
project names must fit without truncation. Review at reduced preview size.

Current visuals live in `src/v5/`; older versions stay unchanged. Saved narration
is mixed intentionally: v5 Onboarding/Build = 96s; v4 Intro/Snapshot/Team/Closing =
126s; v2 Review/Run = 58s. Do not regenerate reused clips. Keep saved captions and
local fonts for exact replay. Current script is `scripts/build_narration_v5.py`.

Follow `STORYBOARD.md`, `narration-plan.json` and the reused `../v4/CLAIMS.md`.
Native PostgreSQL RLS is not claimed; future client icons remain future-labeled.
Final integrated verification remains pending until the root agent records it.
