# Atlas v7 — narrated focus and authentic review

Duration unchanged: **4:40 / 280 seconds / 8,400 frames, 1920×1080 at 30 fps**.
V7 is a visual revision. All narration and caption timings are reused.

| Time | Seconds | Scene and current visual focus |
| --- | --- | --- |
| 0:00–0:42 | 0–42 | Welcome; narrated client and architecture highlights |
| 0:42–1:24 | 42–84 | Start Atlas; Tenant, named Project, tasks, custom enhancement |
| 1:24–1:52 | 84–112 | Shared knowledge, local snapshot and focused Bridge transfer |
| 1:52–2:46 | 112–166 | Nine capabilities; smaller chat and clearer model visuals |
| 2:46–3:18 | 166–198 | Actual Atlas Local Workbench, then Stage and separate Apply |
| 3:18–3:44 | 198–224 | Preserved delivery and GDS orchestration |
| 3:44–4:20 | 224–260 | Preserved shared Atlas and scoped team access |
| 4:20–4:40 | 260–280 | Highlighted architecture return and preserved ending |

## Narration sources

| Reused version | Clips | Seconds |
| --- | --- | --- |
| v5 | Onboarding 42; Build 54 | 96 |
| v4 | Intro 42; Snapshot 28; Team 36; Closing 20 | 126 |
| v2 | Review 32; Run 26 | 58 |

Total 280 seconds. The eight saved WAV files, matching JSON captions and versioned
SceneNarration wrappers remain the replay source. V7 has no new voice generator.
The Onboarding/Build text and cue plan stay in `../v5/STORYBOARD.md` and
`../v5/narration-plan.json`. Other clip wording stays in the reused v4/v2 sources.

## Intro and map

Welcome to Atlas, then focus the current Copilot surface, Atlas Plugin and future
integrations as narrated. Use a soft background/shadow emphasis rather than
leaving viewers to choose among equally weighted boxes. Carry the same focus
language into the two-row environment map: workspace, shared knowledge, Platform,
source systems, orchestrator and lakehouse. Highlight only the relevant area;
keep source-data movement distinct from delivery of project definitions.

## Onboarding and context

Keep the existing clear entry: Start Atlas → authorized Tenant → Northwind
Commerce Lakehouse or Northwind Supply Chain Modernization → Plugin task menu.
Then show the custom request: **Add returns and refunds to the existing Sales
model.** Atlas assesses impact and routes to relevant skills. Existing Project
and input scope are prerequisites, not objects the Plugin creates here.

Return briefly to shared knowledge on the map. Show focused local snapshot reuse
and direct Bridge staging, with emphasis following narration. Local work reduces
unnecessary calls/context; do not claim measured savings. The transfer ends at a
server draft and is distinct from later Apply.

## Build

The unchanged 54-second voiceover walks through Profiling, Enrichment, Analysis,
Subject Areas, Operational Data Model, Dimensional Data Model, Mapping, Code
Generation and Validation. The nine icon boxes highlight the active capability.
Copilot is scaled to 82% to give the right-hand diagrams more space. Dimensional
examples are `DimCustomer`, `DimDate`, `FactReturns` (PascalCase, no spaces).

Remove static “Using approved target models” and similar approval annotations,
and remove the “Metadata management throughout” footer. The unchanged narration
still explains approved inputs and metadata capability. Do not infer that real
dependency or approval requirements disappeared. The final validation visuals hold
calmly through the concluding metadata sentence.

## Review

At 2:46, the actual Atlas Local Workbench screenshot fills the primary review
area. It shows fictional Northwind rows and one local proposal in the current
app's real header, navigation and table. File: `public/screenshots/workbench-v6.jpg`.

Show it at x144/y246, w1632/h663 through 6.1 seconds of this scene. Fade in by .6s,
complete the subtle entrance scale by .8s, hold through 5.5s, then fade out through
6.1s with scale 1 → .975. Copilot fades back in over 6.1–6.8s, after the screenshot
clears; the established Bridge transfer follows. The heading begins “Review in
Atlas Local Workbench.” and changes to “Review. Then approve.” at 6.1s.
Preserve server-draft review, separately approved Apply, audit and shared context.
The screenshot is illustrative data, not evidence of a production action or
validation pass. Exact replay requires only the saved image, not an app server.

## Run, team and closing

Preserve the accepted GDS orchestration sequence and multi-user access story.
Use the same architecture at closing, with restrained focus where the voiceover
calls for it. End with the accepted message: **Move GDS forward. Keep knowledge
with the project.** Claim boundaries remain in `../v4/CLAIMS.md`.

V7 verification passed; see README for compile, recreation, audio/caption,
visual and Studio playback evidence.

## V7 refinement

Narration and sequence unchanged. Replace authored blue focus with visible warm
orange. Correct opening card geometry and icon/title baselines; audit overview,
onboarding, Build, Snapshot and Review alignment. Preserve the authentic workbench
image, GDS pipeline animation and established ending. V7 verification passed; see README and `out/v7-recreation-check.json`.
