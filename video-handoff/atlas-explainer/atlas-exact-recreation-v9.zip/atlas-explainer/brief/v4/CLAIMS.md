# V4 claim boundaries

Repository code is the evidence for this illustrative video. No live Atlas,
cloud, GDS or database state was queried. All tenant, project and user names in
the video are fictional examples.

## Architecture and clients

- **Atlas Plugin** supplies agent skills, references and local helpers. **Atlas
  Bridge** supplies VS Code sign-in, readiness checks and approved Stage transport.
  **Atlas MCP** exposes governed tools. **Atlas Local Workbench** reviews local
  drafts; **Atlas Platform** is the central web application.
- MCP is a Python Azure App Service; PostgreSQL stores governed metadata and
  project knowledge. GDS orchestrator and lakehouse are the connected execution
  environment, not interchangeable names for Atlas components.
- Copilot via VS Code with Atlas Bridge is the implemented client integration.
  Codex, Claude Code and Cursor are **future extension directions**. Portable
  plugin packaging does not establish a working Stage flow in those clients.
- Source-system pictures illustrate the GDS ingestion environment. They do not
  assert that Atlas has a direct connector for every pictured source.

Sources: `CONTEXT.md:8`, `atlas/README.md:3`,
`docs/architecture/decisions.md:448`, `mcp_server/README.md:3`,
`docs/architecture/overview.md:37`.

## Start Atlas and local work

- `Start atlas.` is the documented entry prompt. Resolve authorized Tenant,
  existing Project and the user's task. Ask only for missing identity; a menu is
  an illustrative first-time flow, not a mandatory questionnaire.
- Project and its source-table scope must already exist in Atlas Platform.
  Plugin authoring cannot change Project Input Scope. SQL policy/environment are
  relevant when measurements or SQL execution are requested.
- Snapshots are authorized immutable saved-record baselines. The local effective
  view overlays pending drafts; saved central records remain authoritative.
- Defensible benefit: **Local snapshots and focused reads reduce repeated tool
  calls and unnecessary context. Atlas Bridge transfers approved files directly,
  helping keep token use down.** This describes the mechanism and intended benefit,
  not measured savings or a guaranteed bill reduction. Necessary governed reads,
  snapshot refreshes, validation and Apply still occur.
- Local reads are bounded and support filters, pagination and field projection.
  Bridge reads payload files directly and returns bounded receipts, avoiding
  large staged record payloads in agent tool arguments.

Sources: `atlas/atlas-plugin/docs/usage-guide.md:39`,
`atlas/atlas-plugin/references/tools/initialization.md:5`,
`atlas/atlas-plugin/references/local-runtime.md:51`,
`atlas/atlas-bridge/README.md:38`, `atlas/atlas-bridge/README.md:50`.

## Capability coverage and prerequisites

The capability journey covers profiling, Project enrichment, relationship
analysis, Subject Areas, operational/Logical models for Silver, dimensional
models for Gold, mappings, SQL generation and validation for both layers.
Metadata management covers physical Objects/Attributes, ingestion mappings,
copies and processes. Target DDL/process registration is a separate handoff.

These are available capabilities, not required stages for every request.
Profiling measures; enrichment records meaning; analysis interprets relationships.
Subject Areas group work and are not modeling evidence. Dimensional work consumes
applied Logical models; Mapping needs applied targets; Code consumes applied
Mapping. Required inputs must be saved/refreshed before dependent work. Saved SQL
validation definitions are not proof that checks were executed or passed.

Sources: `atlas/atlas-plugin/skills/atlas/SKILL.md:23`,
`atlas/atlas-plugin/skills/atlas-source-analysis/SKILL.md:9`,
`atlas/atlas-plugin/skills/atlas-code-generation/SKILL.md:3`,
`atlas/atlas-plugin/skills/atlas-verify/SKILL.md:12`,
`atlas/atlas-plugin/skills/atlas-metadata/SKILL.md:3`.

## Access, concurrent work and continuity

- **Use “Tenant access · Role permissions,” not “native PostgreSQL RLS.”** The
  repository implements Tenant RBAC through governed authorization functions.
  The SQL audit found no `CREATE POLICY`, `ENABLE ROW LEVEL SECURITY` or
  `FORCE ROW LEVEL SECURITY` statements. There is no evidence here for claiming
  native PostgreSQL row-level-security policies.
- Project access derives from its owning Tenant. No separate per-project grant
  system was found. “Authorized tenants and their projects” is faithful wording.
  Private tenants require current access; global tenants can be readable by all
  active registered Principals; explicit Super Admin capability has broader access.
- Each user has their own Copilot session. Authorized readers can use central
  saved project knowledge without another user's local chat. Unsaved local drafts
  and personal session evidence do not automatically transfer.
- Tenant Locks require an exact Principal's current lease for ordinary writes;
  another reader can continue reading while waiting to save. Revision checks reject
  stale updates. Do not claim that all parallel reading/local drafting is blocked.
  Workflow-run exclusivity is a separate guard.
- Three illustrated users show two tenant scopes: Engineers A/B access Northwind's
  Sales project; Engineer C has Viewer access to Contoso's Procurement project.
  The scene intentionally does not imply they share one Copilot instance.

Sources: `database/03_security.sql:204`,
`mcp_server/atlas_mcp/tools/tenants/list_tenants.py:71`,
`mcp_server/atlas_mcp/tools/modeling/project_details.py:143`,
`mcp_server/atlas_mcp/application/project_read.py:64`, `docs/security.md:18`,
`docs/security.md:31`, `CONTEXT.md:192`.

## Saving and execution

Stage uploads a reviewed server draft; server validation and a separate Apply
approval follow. Apply saves definitions. Delivery, DDL execution, deployment,
GDS pipeline execution and actual validation runs remain separate operations.
Audit stores bounded identifiers, counts and outcomes, not complete raw prompts,
rows or tool dumps. Do not claim that every raw result is logged.

Sources: `atlas/atlas-bridge/README.md:46`,
`atlas/atlas-plugin/references/change-set-lifecycle.md:44`,
`docs/security.md:75`, `docs/architecture/overview.md:37`.
