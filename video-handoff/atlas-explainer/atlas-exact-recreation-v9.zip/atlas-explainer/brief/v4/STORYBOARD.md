# Atlas v4 — introduction, complete capability journey and shared access

Duration: 4:26 / 266 seconds / 7,980 frames, 30 fps.

Preserve accepted visuals and GDS orchestration. This is an illustrative capability journey, not a mandatory single uninterrupted workflow. Project and scoped sources already exist in Atlas Platform. Native PostgreSQL RLS and non-Copilot client support are not claimed.

| Time | Scene |
|---|---|
| 0:00–0:42 | Welcome and environment |
| 0:42–1:10 | Start Atlas, tenant, project, requirement |
| 1:10–1:38 | Local snapshot and Bridge efficiency |
| 1:38–2:32 | Full discovery and delivery capability journey |
| 2:32–3:04 | Review / Stage / Apply (v2 unchanged) |
| 3:04–3:30 | Delivery and GDS orchestration (v2 unchanged) |
| 3:30–4:06 | Shared Atlas, separate users, scoped access |
| 4:06–4:26 | Return to architecture and close |

## Intro — 42s

**Narration**

Welcome to Atlas. Build and maintain GDS data projects with shared project knowledge. Use Atlas Plugin in Copilot, with VS Code and Atlas Bridge. Codex, Claude Code and Cursor are future integration directions. Atlas MCP connects the workspace to metadata and project context in PostgreSQL. Atlas Platform provides another view for review and tracking. Delivered metadata, table definitions and SQL support the GDS orchestrator. It loads source data into the lakehouse, through Bronze, Silver and Gold. Let’s open Atlas in Copilot.

**Picture**

Welcome, agent icons (future labels), Atlas Plugin and Bridge, MCP/PostgreSQL/Platform, separate GDS orchestrator and lakehouse; source icons feed ingestion. Return focus to Copilot.

## Onboarding — 28s

**Narration**

Start by typing, Start Atlas, in Copilot. Atlas lists only the tenants you can access. Choose your tenant, then an existing project. Tell Atlas what you need. For Sales, build models, mappings, SQL and validation from customers and orders. Atlas works within that authorized project scope.

**Picture**

Type Start Atlas. Reveal only accessible tenants, select Northwind and existing Sales project. Enter a custom requirement. All names illustrative.

## Snapshot — 28s

**Narration**

Atlas brings in saved requirements and metadata through Atlas MCP. A local metadata snapshot gives the agent a working copy. Focused local reads avoid repeated tool calls and unnecessary context. This helps keep token use and costs down. Atlas Bridge transfers approved files directly, without copying large payloads into chat.

**Picture**

PostgreSQL → MCP → local snapshot. Local reuse loop. Fewer repeated calls and smaller context. Bridge handles approved file transport directly.

## Build — 54s

**Narration**

Profile the sources for measured evidence. Enrich descriptions and technical metadata. Analyze keys, grain and relationships. Group related objects into subject areas. Build the normalized operational model for Silver. Then build dimensions and facts for Gold. Create operational mappings from source fields to Silver targets. Create dimensional mappings for Gold. With required inputs approved, generate operational transformation SQL and table definitions. Generate dimensional code for the Gold layer. Prepare validation scripts for both operational and dimensional outputs. Manage metadata throughout the project lifecycle.

**Picture**

Profiling, enrichment, analysis, subject areas; Source → Silver operational → Gold dimensional; paired operational and dimensional mapping, code and validation. Metadata foundation throughout. Applied dependencies acknowledged.

## Team — 36s

**Narration**

Each engineer uses their own Copilot session to connect to central Atlas. Teammates can work on the same tenant and project. Tenant access and role permissions govern what each signed-in user can reach. Other tenants remain isolated. Saved project knowledge lets the next teammate continue without inheriting someone else’s chat. Tenant locks coordinate saved writes. Revision checks reject stale updates, and changes are audited.

**Picture**

Three users with separate Copilot sessions around central Atlas. Two share Northwind/Sales; another uses isolated Contoso. Tenant/role authorization gate; saved project knowledge; locks, revision fencing and audit.

## Closing — 20s

**Narration**

One connected environment, from source understanding to delivery and ongoing improvement. Shared metadata. Guided development. Controlled changes. Atlas helps GDS move faster, while keeping project knowledge with the project.

**Picture**

Full architecture returns, then the established closing message: Move GDS forward. Keep knowledge with the project.

