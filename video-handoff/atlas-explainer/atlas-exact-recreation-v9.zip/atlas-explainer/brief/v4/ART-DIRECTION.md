# Atlas v4 visual direction

Keep the accepted v2/v3 style. V4 adds orientation and complete capability coverage;
it does not replace the film with a feature list. The 4:26 timeline allows each
idea room without crowding the screen.

## Visual language

Light paper, white surfaces, KPMG-inspired blue `#00338D`, accent `#1E49E2`, ink
`#0C233C`, bundled Open Sans and the canonical Atlas mark. Use large, consistent
pictorials from `src/v2/Pictorials.tsx`; few short labels per view. No invented
statistics, emoji, paragraph slides or screenshots with unreadable detail.
Keep the small global Atlas brand and unobtrusive illustrative-workflow label.

## Sequence

1. **Welcome, 42s.** “Welcome to Atlas” gives the product a clear entrance. Show
   Copilot and Atlas Plugin/skills with Atlas Bridge. Codex, Claude Code and
   Cursor appear with official marks under “Future integrations.” Build the
   architecture progressively: workspace → Atlas MCP → PostgreSQL, with Atlas
   Platform for shared review; separate delivery → GDS orchestrator/lakehouse.
   Source pictures feed Bronze ingestion, then Silver and Gold. Open Copilot.
2. **Onboarding, 28s.** Begin with typed “Start Atlas.” Show authorized Tenant
   choices, an existing Project and a custom requirement. Preserve recognizable
   Copilot chat with VS Code as a small host label. Northwind/Sales is illustrative.
3. **Snapshot, 28s.** Return to the full EnvironmentMap with shared knowledge
   highlighted for 2.1s, then dissolve into the local Snapshot view by 3.1s. This
   repeats overview → highlighted component → working detail. Show focused local
   reuse and fewer unnecessary calls/context. The final 8s explicitly show
   approved local files → Atlas Bridge → Atlas MCP as direct file transport,
   supporting the intended token-cost benefit.
4. **Build, 54s.** Reveal profiling, enrichment, analysis and Subject Areas in
   order, then compact them. Open Silver operational and Gold dimensional models
   as a connected flow. Show both layers' mappings, code and validation. Metadata
   management supports the lifecycle. Highlight the active work; preserve applied
   prerequisites without overloading the picture with implementation prose.
5. **Review, 32s.** Reuse the accepted review, separate Stage and Apply sequence.
6. **Run, 26s.** Reuse the accepted delivery and GDS Source/Bronze/Silver/Gold
   orchestration. Keep physical data movement distinct from earlier model design.
7. **Team, 36s.** Three engineers, three Copilot sessions, one central Atlas. Two
   access Northwind/Sales, a third Contoso/Procurement. Separate tenant compartments
   and shields show Tenant access/roles. Saved knowledge reaches the next teammate.
   One editor holds a Tenant Lock while another can read and waits to save;
   revision checks require stale work to refresh. Do not label the gate native RLS.
8. **Closing, 20s.** Return to the same full environment map. Fade to the established
   close: “Move GDS forward. Keep knowledge with the project.” Add the lifecycle
   reminder: build, validate, maintain and continue together.

## Motion and source boundaries

Use named Interactive JSX layers, explicit scene nodes and frame-based eased
motion. Preserve spatial relationships while moving between overview and detail.
Do not animate every element at once. Scene-specific changes stay in `src/v4/`;
keep earlier review sources and saved narration intact. The shared EnvironmentMap
must remain consistent between introduction, orientation and closing.

Use the official icon files and provenance in `public/icons/SOURCES.json` and
`public/icons/v4/SOURCES.json`. Codex uses the labeled official OpenAI developer
site mark; do not imply endorsement or current client support.

Narration carries detail; optional captions fit the lower safe area. Current v4
has six new clips totaling 208s and two preserved v2 clips totaling 58s. Exact
scene times, text and implementation boundaries are in `STORYBOARD.md`,
`narration-plan.json` and `CLAIMS.md`. Integrated visual/audio QA remains pending
until the root agent records final checks.
