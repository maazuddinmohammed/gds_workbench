# Atlas v9 — locked art direction

Reproduce the approved visual language. V9 changes the product label to GDS Frameworks and its three matching spoken cues; it does not introduce a new design. Exact measurements and motion are in `DESIGN-SPEC.md` and the bundled TSX. The frozen reference frames are the visual checkpoints.

## The visual story

Start wide enough that a first-time viewer can name the pieces. Open the relevant component, then return to the same map for orientation. Repeat recognizable objects: Copilot chat, a local snapshot/folder, Atlas Bridge, Atlas MCP, PostgreSQL, models and the GDS pipeline. Repetition connects the story; a succession of unrelated informational slides does not.

The user sees **Copilot** as the primary interaction. VS Code is its smaller host label. Copilot's visible typed exchange makes the example concrete: Start Atlas → authorized Tenant → existing Project → task choices → custom enhancement. Maintain that progression. The running example is returns/refunds added to an existing Sales model, not a new generic sales model.

Use pictorials and motion for the workflow. Text stays at the level of names, short actions and useful distinctions. The saved narration supplies technical detail. Do not add explanatory paragraphs, duplicate section titles, a constant metadata-management footer or decorative “approved target” captions.

## Look and hierarchy

The canvas is light paper with white cards, dark ink and Atlas blue. Open Sans supplies a consistent warm, clear voice. Use the canonical Atlas SVG and bundled brand/client marks, not newly drawn approximations. Main cards have generous whitespace, gentle rounding and restrained shadows. The diagrams remain clean enough to parse before the narration finishes a sentence.

Warm **orange** is the attention signal. It adds a visible border, pale background and soft halo to the item being explained. Atlas blue remains the brand/icon color. Focus follows speech and leaves when attention moves; it must not become a constant glow on every component. The focus overlay does not alter card dimensions or displace neighboring content.

Alignment is part of the approved design. Preserve the v7/v8/v9 border-box sizing, matching icon/title baselines in the first client cards, regular future-client columns, two-row environment grid, Snapshot boxes and grouped service labels. Do not “simplify” these fixes back into earlier layouts.

## Composition rhythm

- **Welcome:** one centered identity with an immediate product introduction.
- **Clients:** two equally weighted cards and a quieter future-client row. Copilot is current; Codex, Claude Code and Cursor are explicitly future.
- **Environment:** two rows of three clear components. Box Source systems, GDS Frameworks and GDS Lakehouse separately; show their connections without cluttering the upper row.
- **Onboarding:** large familiar chat while the viewer learns access and choices; it docks smaller as work begins.
- **Snapshot:** chat left; aligned local and central boxes right; Bridge below local. Documents/folders visibly follow the route.
- **Build:** all nine capabilities visible as an icon strip. Smaller chat at left; larger source/model/mapping/code/validation pictures at right. Show one active capability at a time.
- **Review:** genuine Local Workbench screenshot first, then the established Stage/Apply picture. Do not invent a product mockup.
- **Run:** preserve the accepted four-layer data movement and GDS Frameworks control animation.
- **Team:** central Atlas, separate personal Copilot sessions, distinct tenant compartments, visible roles and write protection.
- **Closing:** return to the same environment, then the quiet centered message about faster GDS delivery and central/shared knowledge.

## Motion

Use source-defined frame-driven interpolation; never CSS keyframes, wall-clock time or random animation. Preserve eased entrances, short opacity handoffs and gentle translation. Use motion to indicate causality: a snapshot arrives, a document goes through Bridge, a relationship is drawn, a record advances through lakehouse layers. Avoid decorative movement that competes with the explanation.

The main curve is cubic Bézier `(0.22, 1, 0.36, 1)` with clamped endpoints. Existing Run and other inherited artwork retain their own authored curves. Do not normalize all motion into one new helper or change scene lengths. Focus timing is keyed to saved narration; keeping the WAVs preserves that relationship.

## Typography and exact copy

Preserve case, spelling and line breaks in source. Gold model examples are `DimCustomer`, `DimDate`, `FactReturns`. Project choices are Northwind Commerce Lakehouse and Northwind Supply Chain Modernization. The requirement is “Add returns and refunds to the existing Sales model.” The final line is **“Keep project knowledge central and shared.”**

Main film text uses the two bundled Open Sans weights, 400 and 600. Keep `src/fonts.ts` and all font files/licenses. The optional existing caption component uses Arial/Helvetica fallback; do not change it during exact recreation. Its pixels may vary across operating systems even with identical text/timing.

## Asset handling

All film assets are local. `public/atlas.svg` is the canonical identity. Brand marks keep their existing provenance files. Shared pictorials are code-native SVG in `src/v2/Pictorials.tsx`; do not substitute external images. The workbench is `public/screenshots/workbench-v6.jpg`, a saved 2276×920 image of the actual app with synthetic metadata. Replay requires no app server or live account.

The supplied reference images cover 20 main-film checkpoints plus three caption checkpoints. Use `reference-frames/index.json` for exact positions and `REPRODUCTION-MANIFEST.json` for runtime information. Retain original image dimensions and bytes. A matching picture depends on source, media, fonts, browser and viewport together; document an environment mismatch rather than redesigning to approximate it.

## Content boundaries that shape visuals

The diagram distinguishes authoring, staging, applying, delivery and execution. Keep Stage/Apply separate. Do not draw automatic deployment, direct arbitrary database work or a shared private chat. The access diagram communicates Tenant RBAC and protected writes, not native PostgreSQL RLS. Central knowledge is saved project context; individual unsaved work remains local. Those distinctions are essential to an accurate, understandable film.
