# Atlas v9 — complete narration and cue timings

This is the complete saved script, consolidated from the eight current caption JSON files. Read the saved WAVs for exact voice, pacing and silence. Do not regenerate speech for reproduction. All timestamps are milliseconds expressed as `mm:ss.mmm`; global time is measured from the first frame of **AtlasExplainer**. Cue times can fall between 30 fps frame boundaries.

The film is 280 seconds / 8,400 frames. Saved narration is mono 24 kHz PCM, temporary review voice Samantha at 160 words/minute; the saved samples are authoritative. There is no music. Main captions are off; the optional caption composition uses these same cue words/timings.

V9 changes three spoken cues to match **GDS Frameworks**: Intro cues 7 and 8, and Run cue 2. All other cues and scene durations remain unchanged. The complete v8 closing WAV is retained; its final phrase runs **04:34.000–04:36.882**, and the film holds to **04:40.000**.

## Exact script by scene

### Intro — 00:00.000–00:42.000

Audio: `public/audio/v9/intro.wav` · cues: `public/captions/v9/intro.json`

Welcome to Atlas. Build and maintain GDS data projects with shared project knowledge. Use Atlas Plugin in Copilot, with VS Code and Atlas Bridge. Codex, Claude Code and Cursor are future integration directions. Atlas MCP connects the workspace to metadata and project context in PostgreSQL. Atlas Platform provides another view for review and tracking. Delivered metadata, table definitions and SQL support GDS Frameworks. They load source data into the lakehouse, through Bronze, Silver and Gold. Let’s open Atlas in Copilot.

| Cue | Scene start–end | Global start–end | Exact spoken text |
| ---: | --- | --- | --- |
| 1 | 00:00.800–00:02.091 | 00:00.800–00:02.091 | Welcome to Atlas. |
| 2 | 00:03.000–00:07.091 | 00:03.000–00:07.091 | Build and maintain GDS data projects with shared project knowledge. |
| 3 | 00:07.271–00:11.350 | 00:07.271–00:11.350 | Use Atlas Plugin in Copilot, with VS Code and Atlas Bridge. |
| 4 | 00:11.800–00:15.931 | 00:11.800–00:15.931 | Codex, Claude Code and Cursor are future integration directions. |
| 5 | 00:16.300–00:21.440 | 00:16.300–00:21.440 | Atlas MCP connects the workspace to metadata and project context in PostgreSQL. |
| 6 | 00:22.000–00:25.526 | 00:22.000–00:25.526 | Atlas Platform provides another view for review and tracking. |
| 7 | 00:27.000–00:31.963 | 00:27.000–00:31.963 | Delivered metadata, table definitions and SQL support GDS Frameworks. |
| 8 | 00:32.294–00:36.635 | 00:32.294–00:36.635 | They load source data into the lakehouse, through Bronze, Silver and Gold. |
| 9 | 00:38.000–00:40.001 | 00:38.000–00:40.001 | Let’s open Atlas in Copilot. |

### Onboarding — 00:42.000–01:24.000

Audio: `public/audio/v5/onboarding.wav` · cues: `public/captions/v5/onboarding.json`

Start by typing, Start Atlas, in Copilot. Atlas lists only the tenants you can access. Choose your tenant, then an existing project. Choose a task: investigate, analyze sources, or manage metadata. Build models, mappings, code and validation, or register delivery artifacts. You can also describe a custom enhancement. Add returns and refunds to the existing Sales model. Atlas assesses the impact and routes the work to the right skills.

| Cue | Scene start–end | Global start–end | Exact spoken text |
| ---: | --- | --- | --- |
| 1 | 00:00.700–00:04.150 | 00:42.700–00:46.150 | Start by typing, Start Atlas, in Copilot. |
| 2 | 00:05.000–00:07.655 | 00:47.000–00:49.655 | Atlas lists only the tenants you can access. |
| 3 | 00:09.800–00:12.515 | 00:51.800–00:54.515 | Choose your tenant, then an existing project. |
| 4 | 00:15.800–00:20.628 | 00:57.800–01:02.628 | Choose a task: investigate, analyze sources, or manage metadata. |
| 5 | 00:20.808–00:26.222 | 01:02.808–01:08.222 | Build models, mappings, code and validation, or register delivery artifacts. |
| 6 | 00:26.402–00:29.030 | 01:08.402–01:11.030 | You can also describe a custom enhancement. |
| 7 | 00:29.210–00:32.260 | 01:11.210–01:14.260 | Add returns and refunds to the existing Sales model. |
| 8 | 00:35.000–00:38.468 | 01:17.000–01:20.468 | Atlas assesses the impact and routes the work to the right skills. |

### Snapshot — 01:24.000–01:52.000

Audio: `public/audio/v4/snapshot.wav` · cues: `public/captions/v4/snapshot.json`

Atlas brings in saved requirements and metadata through Atlas MCP. A local metadata snapshot gives the agent a working copy. Focused local reads avoid repeated tool calls and unnecessary context. This helps keep token use and costs down. Atlas Bridge transfers approved files directly, without copying large payloads into chat.

| Cue | Scene start–end | Global start–end | Exact spoken text |
| ---: | --- | --- | --- |
| 1 | 00:00.700–00:04.876 | 01:24.700–01:28.876 | Atlas brings in saved requirements and metadata through Atlas MCP. |
| 2 | 00:05.700–00:09.296 | 01:29.700–01:33.296 | A local metadata snapshot gives the agent a working copy. |
| 3 | 00:10.500–00:15.041 | 01:34.500–01:39.041 | Focused local reads avoid repeated tool calls and unnecessary context. |
| 4 | 00:16.000–00:18.541 | 01:40.000–01:42.541 | This helps keep token use and costs down. |
| 5 | 00:20.000–00:25.465 | 01:44.000–01:49.465 | Atlas Bridge transfers approved files directly, without copying large payloads into chat. |

### Build — 01:52.000–02:46.000

Audio: `public/audio/v5/build.wav` · cues: `public/captions/v5/build.json`

Profile the new source evidence. Enrich descriptions and technical metadata. Analyze keys, grain and relationships. Group related objects into subject areas. Extend the existing operational model with returns and refunds. Then update the dimensions and facts for Gold. Update operational mappings from new source fields to Silver targets. Update dimensional mappings for Gold. With required inputs approved, generate operational transformation SQL and table definitions. Generate dimensional code for the Gold layer. Prepare validation scripts for both operational and dimensional outputs. Manage metadata throughout the project lifecycle.

| Cue | Scene start–end | Global start–end | Exact spoken text |
| ---: | --- | --- | --- |
| 1 | 00:00.700–00:02.695 | 01:52.700–01:54.695 | Profile the new source evidence. |
| 2 | 00:04.000–00:06.574 | 01:56.000–01:58.574 | Enrich descriptions and technical metadata. |
| 3 | 00:07.000–00:09.713 | 01:59.000–02:01.713 | Analyze keys, grain and relationships. |
| 4 | 00:10.000–00:12.593 | 02:02.000–02:04.593 | Group related objects into subject areas. |
| 5 | 00:14.000–00:17.770 | 02:06.000–02:09.770 | Extend the existing operational model with returns and refunds. |
| 6 | 00:20.000–00:22.483 | 02:12.000–02:14.483 | Then update the dimensions and facts for Gold. |
| 7 | 00:26.000–00:30.058 | 02:18.000–02:22.058 | Update operational mappings from new source fields to Silver targets. |
| 8 | 00:30.500–00:32.747 | 02:22.500–02:24.747 | Update dimensional mappings for Gold. |
| 9 | 00:35.500–00:41.423 | 02:27.500–02:33.423 | With required inputs approved, generate operational transformation SQL and table definitions. |
| 10 | 00:41.603–00:44.058 | 02:33.603–02:36.058 | Generate dimensional code for the Gold layer. |
| 11 | 00:45.500–00:49.689 | 02:37.500–02:41.689 | Prepare validation scripts for both operational and dimensional outputs. |
| 12 | 00:50.500–00:53.476 | 02:42.500–02:45.476 | Manage metadata throughout the project lifecycle. |

### Review — 02:46.000–03:18.000

Audio: `public/audio/v2/review.wav` · cues: `public/captions/v2/review.json`

Now you review the proposed changes in Atlas Local Workbench. Approve Stage in the chat, and Atlas Bridge sends the draft for server validation. After reviewing that result, approve Apply separately. The approved definitions become shared project state. Changes are protected and audited.

| Cue | Scene start–end | Global start–end | Exact spoken text |
| ---: | --- | --- | --- |
| 1 | 00:00.700–00:04.445 | 02:46.700–02:50.445 | Now you review the proposed changes in Atlas Local Workbench. |
| 2 | 00:05.600–00:07.164 | 02:51.600–02:53.164 | Approve Stage in the chat, |
| 3 | 00:09.000–00:12.108 | 02:55.000–02:58.108 | and Atlas Bridge sends the draft for server validation. |
| 4 | 00:14.000–00:15.726 | 03:00.000–03:01.726 | After reviewing that result, |
| 5 | 00:17.000–00:18.576 | 03:03.000–03:04.576 | approve Apply separately. |
| 6 | 00:21.000–00:24.156 | 03:07.000–03:10.156 | The approved definitions become shared project state. |
| 7 | 00:27.000–00:28.983 | 03:13.000–03:14.983 | Changes are protected and audited. |

### Run — 03:18.000–03:44.000

Audio: `public/audio/v9/run.wav` · cues: `public/captions/v9/run.json`

Your delivery process deploys those artifacts. Then GDS Frameworks processes the data: source data lands in Bronze, becomes structured Silver data, and flows into Gold for reporting. Atlas also prepares validation checks to accompany those outputs.

| Cue | Scene start–end | Global start–end | Exact spoken text |
| ---: | --- | --- | --- |
| 1 | 00:00.700–00:03.734 | 03:18.700–03:21.734 | Your delivery process deploys those artifacts. |
| 2 | 00:05.000–00:07.738 | 03:23.000–03:25.738 | Then GDS Frameworks processes the data: |
| 3 | 00:09.000–00:10.837 | 03:27.000–03:28.837 | source data lands in Bronze, |
| 4 | 00:13.000–00:14.920 | 03:31.000–03:32.920 | becomes structured Silver data, |
| 5 | 00:16.000–00:17.982 | 03:34.000–03:35.982 | and flows into Gold for reporting. |
| 6 | 00:20.000–00:24.141 | 03:38.000–03:42.141 | Atlas also prepares validation checks to accompany those outputs. |

### Team — 03:44.000–04:20.000

Audio: `public/audio/v4/team.wav` · cues: `public/captions/v4/team.json`

Each engineer uses their own Copilot session to connect to central Atlas. Teammates can work on the same tenant and project. Tenant access and role permissions govern what each signed-in user can reach. Other tenants remain isolated. Saved project knowledge lets the next teammate continue without inheriting someone else’s chat. Tenant locks coordinate saved writes. Revision checks reject stale updates, and changes are audited.

| Cue | Scene start–end | Global start–end | Exact spoken text |
| ---: | --- | --- | --- |
| 1 | 00:00.700–00:05.028 | 03:44.700–03:49.028 | Each engineer uses their own Copilot session to connect to central Atlas. |
| 2 | 00:06.500–00:09.391 | 03:50.500–03:53.391 | Teammates can work on the same tenant and project. |
| 3 | 00:11.500–00:15.587 | 03:55.500–03:59.587 | Tenant access and role permissions govern what each signed-in user can reach. |
| 4 | 00:17.500–00:19.447 | 04:01.500–04:03.447 | Other tenants remain isolated. |
| 5 | 00:21.000–00:26.413 | 04:05.000–04:10.413 | Saved project knowledge lets the next teammate continue without inheriting someone else’s chat. |
| 6 | 00:27.000–00:29.334 | 04:11.000–04:13.334 | Tenant locks coordinate saved writes. |
| 7 | 00:30.500–00:34.397 | 04:14.500–04:18.397 | Revision checks reject stale updates, and changes are audited. |

### Closing — 04:20.000–04:40.000

Audio: `public/audio/v8/closing.wav` · cues: `public/captions/v8/closing.json`

One connected environment, from source understanding to delivery and ongoing improvement. Shared metadata. Guided development. Controlled changes. Atlas helps GDS move faster, while keeping project knowledge central and shared.

| Cue | Scene start–end | Global start–end | Exact spoken text |
| ---: | --- | --- | --- |
| 1 | 00:00.600–00:05.687 | 04:20.600–04:25.687 | One connected environment, from source understanding to delivery and ongoing improvement. |
| 2 | 00:06.000–00:09.876 | 04:26.000–04:29.876 | Shared metadata. Guided development. Controlled changes. |
| 3 | 00:10.500–00:12.842 | 04:30.500–04:32.842 | Atlas helps GDS move faster, |
| 4 | 00:14.000–00:16.882 | 04:34.000–04:36.882 | while keeping project knowledge central and shared. |

## Synchronization rules

- Keep each WAV at the beginning of its matching scene; its silence already positions the individual utterances. Do not concatenate phrases without the saved gaps.
- The explicit scene boundaries, rather than the final spoken sample, determine scene length. Keep quiet holds.
- Keep `showCaptions:false` for the main composition. The optional caption variant changes visibility, not audio or sequence timing.
- Saved caption JSON contains text, `startMs`, `endMs`, null transcription metadata and `pageBreakAfter:true`; wrappers keep the same captions inline for Studio editing. Do not retime or re-transcribe them.
- The final closing message is **“Keep project knowledge central and shared.”** The voice uses the sentence continuation **“while keeping project knowledge central and shared.”**
- V9 Intro/Run wrappers live in `src/v9/SceneNarration.tsx`; the closing still imports `src/v8/SceneNarration.tsx`. `scripts/build_narration_v9.py` and `brief/v9/narration-plan.json` document the three intentional replacements. Do not run the generator for replay.

Total saved cues: **58**. Current script word count by whitespace: **457**.
