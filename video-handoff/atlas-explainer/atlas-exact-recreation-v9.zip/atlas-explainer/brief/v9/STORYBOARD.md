# Atlas v9 — locked storyboard

Audience: stakeholders and data engineers. Tone: clear, warm and lightly technical. The accepted expanded cut is **4:40**, 1920×1080 at 30 fps. Recreate its saved design and pacing; do not shorten it back to the original three-minute brief.

The story moves from the complete environment into a concrete enhancement, then returns to the environment. Copilot is the user's visible entry point; VS Code is a small host label. Atlas is the product family, with distinct Plugin, Bridge, MCP, Platform and Local Workbench roles. Narration carries detail while pictures carry the workflow.

V9 preserves the accepted v8 cut and updates the product label to **GDS Frameworks**. Only the relevant visible labels and three spoken cues change: two in Intro, one in Run. Geometry, focus, motion, scene durations and the central/shared closing remain unchanged. The exact full script and all 58 cues are in `NARRATION.md`; do not substitute the summaries below for that transcript.

## Timeline

| Scene | Global interval | Frame interval | Purpose |
| --- | --- | --- | --- |
| Intro | 00:00–00:42 | 0–1259 | Introduce Atlas, clients and complete environment |
| Onboarding | 00:42–01:24 | 1260–2519 | Establish authorized scope, choices and custom requirement |
| Snapshot | 01:24–01:52 | 2520–3359 | Explain central knowledge, local context efficiency and Bridge |
| Build | 01:52–02:46 | 3360–4979 | Open nine capabilities while evolving one example |
| Review | 02:46–03:18 | 4980–5939 | Show real Local Workbench, Stage and separate Apply |
| Run | 03:18–03:44 | 5940–6719 | Deliver approved artifacts for GDS Frameworks execution |
| Team | 03:44–04:20 | 6720–7799 | Show central continuity with scoped access/protected writes |
| Closing | 04:20–04:40 | 7800–8399 | Return to complete environment and state the benefit |

All timings below are **scene-relative seconds**, unless identified as global. Source interpolation arrays define exact fades; descriptions explain intent.

## 1. Intro — 42 seconds

**0–6:** Center the Atlas identity and “Welcome to Atlas.” Give the newcomer a plain introduction before workflow detail. Preserve the saved welcome subtitle/support copy.

**5.4–16.3:** Show “Your agent. Atlas expertise.” with balanced Copilot and Atlas Plugin cards. Copilot is accessed through VS Code. Atlas Plugin supplies skills and Atlas Bridge supplies the sign-in/staging connection. Warm orange focus follows the corresponding spoken phrases. The future-client row enters later and clearly labels Codex, Claude Code and Cursor as future integrations.

**15.6–39.2:** Open the same six-box architecture used later. Upper row: user workspace, shared knowledge (Atlas MCP/PostgreSQL), Atlas Platform. Lower row: boxed source systems, GDS Frameworks, GDS Lakehouse. GDS Frameworks sits between source and lakehouse. Separate the definitions/delivery link from actual source-to-lakehouse data flow. Focus introduces each part without moving the boxes.

**38.4–42:** Enter the recognizable Copilot chat panel to begin the user's journey. Keep the high-level view connected to what follows, rather than introducing an unrelated slide style.

## 2. Onboarding — 42 seconds

Heading: “Start with access. Choose your work.”

| Local time | Screen action |
| --- | --- |
| 1–3.4 | Type `Start Atlas` into Copilot. |
| 4–10 | Show only authorized Tenant choices; choose Northwind. |
| 10–16 | Choose an existing Project; show **Northwind Commerce Lakehouse** and **Northwind Supply Chain Modernization**. Select the first. |
| 16–29 | Show the Plugin task choices in three groups, then highlight the custom option at 25 seconds. |
| 29.7–34.6 | Type **“Add returns and refunds to the existing Sales model.”** |
| 36–40 | Submit and show the impact-aware response about existing artifacts. |
| 40–42 | Shrink/reposition chat into the established left-hand workflow layout. |

The eleven task options are: Investigate, Source analysis, Subject areas; Operational model, Dimensional model, Mapping, Code generation; Validation, Project change, Metadata, Registration. The example shows that the user can select a known task **or** describe an enhancement. An existing Project and registered input scope are prerequisites; no project-scope creation is depicted.

The compact subsequent chat scope reads **Northwind › Commerce Lakehouse**. Preserve the projecty names, spelling and custom requirement.

## 3. Snapshot — 28 seconds

**0–3.1:** Briefly revisit the environment map and highlight shared knowledge. Heading: “Bring shared knowledge into your workspace.” This connects the close-up to the introduction.

**3.1–20:** Transition to “Shared knowledge. Focused local work.” Copilot stays left, local workspace center-right, Atlas central service far right. A document leaves PostgreSQL through Atlas MCP, and a snapshot arrives locally. Focus the local box while the agent reuses focused local reads.

The visible cost story is **“Fewer repeated calls. Less context to resend.”** followed by **“Helps keep token use and costs down.”** Do not add unsupported numbers or guarantees.

**20–28:** The local snapshot label becomes Approved files. The boxed Atlas Bridge appears below the local workspace. Animate an approved file down into Bridge, across/up to Atlas MCP, then into PostgreSQL as **Server draft**. Show **“Small receipts keep large payloads out of chat.”** and **“Stage creates a draft. Apply is a separate approval.”** Preserve the clear aligned service grouping and direction of motion.

## 4. Build — 54 seconds

Keep nine icon boxes across the top throughout; active orange focus moves from one to the next. Keep Copilot smaller at the left, responding to the same returns/refunds enhancement. The larger right side changes pictorials. Do not restore the old duplicate “Discovery → delivery” heading or permanent metadata footer.

| Local interval | Active box | Main picture |
| --- | --- | --- |
| 0–3.8 | Profiling | Magnifier examines Returns and Refunds source tables. |
| 3.8–6.8 | Enrichment | Document adds business meaning to the source objects. |
| 6.8–9.7 | Analysis | Relationship line connects related objects. |
| 9.7–12 | Subject areas | Related objects are grouped into the Sales subject area. |
| 12–20 | Operational Data Model | Existing Customers/Orders model gains Returns; Silver operational model. |
| 20–26 | Dimensional Data Model | Gold model shows **DimCustomer**, **DimDate**, **FactReturns**. |
| 26–35 | Mapping | Operational source field `refund_amount` → `RefundAmount`; then Silver Returns → Gold FactReturns. |
| 35–44 | Code Generation | Separate Silver operational and Gold dimensional code cards; DDL + transformation SQL. |
| 44–54 | Validation | Operational and dimensional validation-script cards for both layers. |

Dimensional names keep PascalCase and `Dim`/`Fact` prefixes. The display covers capabilities while narration states the real approved-input dependencies. Metadata management is acknowledged in the saved narration, without a constant text footer. These are authored assets and governed steps, not a promise that all nine run unattended every time.

## 5. Review — 32 seconds

**0–6.1:** Show the saved real **Atlas Local Workbench** screenshot prominently, with the heading “Review in Atlas Local Workbench.” It contains synthetic Northwind metadata and `DimCustomer`, `DimDate`, `FactReturns`. Preserve the actual screenshot bytes. Fade out over 5.5–6.1 seconds.

**6.1–6.8:** Change heading to “Review. Then approve.” Fade Copilot back in after the screenshot leaves. Continue the established Bridge/review artwork.

**7–17:** Approved local work is staged through Atlas Bridge into a server draft; review server validation/results. **17–23:** Apply is a distinct approval action. **23–32:** Save shared context and show governed audit/protection. Keep Stage, Apply and deployment distinct. Do not recreate the workbench as fictional UI or overlap its screenshot with the returning chat.

## 6. Run — 26 seconds

Reuse the accepted GDS Frameworks execution sequence without redesign. First show separate delivery of approved artifacts. Then GDS Frameworks uses metadata, DDL and transformation code.

Source → Bronze → Silver → Gold trays show actual data movement: ingestion into Bronze, transformations through Silver/Gold, then checks. Keep the control role of GDS Frameworks clear. This is different from the preceding model-design illustration. Atlas supports building and maintaining the definitions; GDS performs the load/transform execution.

## 7. Team — 36 seconds

**0–10:** “Many engineers. One shared Atlas.” Separate Engineer A and B Copilot sessions connect to Northwind's Commerce Lakehouse. Engineer C connects to a separate Contoso scope. Atlas MCP/PostgreSQL sit centrally.

**10–20:** “Access follows the signed-in user.” Show Tenant boundaries, shields and role labels: A/B Northwind · Architect; C Contoso · Viewer. The narration uses Tenant RBAC, not native PostgreSQL RLS. Project access follows owning Tenant.

**20–28:** “Saved knowledge stays with the project.” The second engineer continues using centrally saved project context; private chat and unsaved drafts do not transfer. This middle-scene phrase and the central/shared closing are preserved from the accepted cut.

**28–36:** “Shared reads. Protected writes.” A holds the Tenant Lock while editing; B can read and waits to save. Revision checks protect against stale changes. Do not imply that everyone shares one Copilot instance or that all concurrent reads/drafts are prohibited.

## 8. Closing — 20 seconds

**0–11:** Return to the complete architecture. Heading: “One shared project. From source to lakehouse.” Follow the orange focus through Sources → GDS Frameworks → GDS Lakehouse → Shared knowledge → Workspace → Atlas Platform.

**10–20:** Transition to the final centered Atlas identity. Preserve these three lines exactly:

> Move GDS forward.
>
> Keep project knowledge central and shared.
>
> Build · validate · maintain · continue together

The voice closes: “Atlas helps GDS move faster, while keeping project knowledge central and shared.” Its second phrase starts at local 14 seconds, ends at 16.882, then leaves a quiet visual hold until 20 seconds. The full saved v8 closing WAV and all four closing cues are preserved.

## Review landmarks

`reference-frames/index.json` records exact compositions and frame numbers for 23 checkpoints. Names: welcome, copilot, future-clients, architecture, project-choice, task-menu, snapshot, bridge, profiling, models, mapping, code, validation, workbench, stage, gds, team, closing, closing-captions, frameworks-intro, frameworks-intro-captions, frameworks-run-captions, frameworks-closing. Twenty check the main film and three check captions. The GDS Frameworks checkpoints explicitly cover its current labels and changed narration. Use these frozen images with the source, not a screenshot from an older review.
