# Atlas v9 — geometry, typography and motion specification

This specification records the approved implementation for another agent to inspect and maintain. V9 updates the product label to GDS Frameworks; focus-object keys use `frameworks`, with unchanged timings and geometry. **Exact reproduction runs the bundled source; it does not redraw from these tables.** Source is authoritative for SVG paths, every inline value and cue interpolation. All coordinates/sizes below are CSS pixels in the 1920×1080 composition. Time values are scene-relative seconds; multiply by 30 for frame positions unless source supplies fractional-frame timing.

## Global contract

| Property | Value |
| --- | --- |
| Main composition | `AtlasExplainer`, `src/v9/AtlasExplainer.tsx` |
| Optional captions | `AtlasExplainer-Captions`, same scene/audio timeline |
| Frame | 1920×1080, 30 fps, 8,400 frames, 280 seconds |
| Paper / card | `#F8FAFD` / `#FFFFFF` |
| Main ink / brand | `#0C233C` / `#00338D` |
| Muted labels | `#66778B`, `#627994` as authored |
| Typical neutral border | `#DAE2EC`, 1.5px |
| Typeface | Bundled Open Sans 400 and 600; `src/fonts.ts` |
| Main easing | `Easing.bezier(.22,1,.36,1)`, clamp left/right |
| Persistent identity | x112, y62; 42×42 Atlas mark, gap 12, label31px/600 |
| Main footer | x112, y1030; 17px `#8C98A9`, “Illustrative workflow”; hidden when captions enabled |
| Typical scene heading | x144, y153 or155; 43–48px/600, tracking −1 or −1.2 |
| Workflow rail | x270, y937, 1380×70; Start, Context, Build, Review, Run, Team |

The rail's labels are 23px, numbered/check circles 31px. Current step uses warm orange; completed steps show checks. The rail appears in Onboarding through Team; Snapshot delays it until local frame93 (3.1 seconds). Keep it away from the header and main drawings.

### Focus treatment

Use the exact treatment, already in source:

```css
border: 3px solid #D86B16;
background: rgba(245,147,58,.13);
box-shadow: 0 16px 42px rgba(227,117,35,.22), 0 0 0 7px rgba(227,117,35,.10);
```

Focus overlays are positioned independently, with border-box sizing and no pointer events. Standard cards retain their geometry as the overlay fades. Build uses `#FFF1E1`, the same 3px border, and `0 12px 30px rgba(227,117,35,.22),0 0 0 5px rgba(227,117,35,.10)`. Active rail accents use `#A34B0E`. Blue brand/icon colors remain intact.

## Intro: `src/v9/IntroJourney.tsx`

| Element | Geometry / type |
| --- | --- |
| Welcome group | x260, y300, width 1400, centered |
| Welcome identity | mark110; title76px/600, tracking−2 |
| Welcome supporting type | subtitle37px, support29px |
| Client heading | x144,y155; 47px/600, tracking−1 |
| Copilot card | x320,y330,480×310, radius24, border-box |
| Atlas Plugin card | x1120,y330,480×310, radius24, border-box |
| Both client logos | 84×84 at relative x198,y34 |
| Both client titles | relative y135, 35px, line-height 1.2 |
| Both subtitles | relative y190, 23px, line-height 1.3 |
| Bridge row in Plugin card | relative y243,height 37; shield37,type 24px |
| Client connection | x830–1090, horizontal paths y470 and 500 |
| Future panel | x320,y710,1280×164,radius24 |
| Future label / clients | label top24,22px; three equal columns left/right70,top76,h53; marks 53,gap 17,type 27px |

Welcome opacity uses `[0,.7,5.2,6] → [0,1,1,0]`; it rises 22px over the first .9 seconds. The client group occupies approximately 5.4–16.3. Keep equal logo/title baselines and border-box sizing.

Client focus opacity arrays (`times → values`):

| Focus | Times | Values |
| --- | --- | --- |
| Copilot | 8.2,8.7,10.1,10.6 | 0,1,1,0 |
| Plugin | 7,7.4,8.1,8.6,10.1,10.6,11.35,11.9 | 0,1,1,0,0,1,1,0 |
| Future clients | 11.6,12.2,15.3,16 | 0,1,1,0 |

Future clients enter 11.4–12.2. Architecture opacity uses15.6,16.5,38.3,39.2. Its progress times `[15.6,16.8,21.6,22.2,26.4,27,31.5,32.1]` map to `[.12,.29,.34,.5,.53,.73,.85,1]`. Preserve this authored reveal order.

Architecture focus intervals (rise → hold → fall; exact arrays in source): workspace17.1–18.9; knowledge16–17.7 and 18.3–22; Platform21.7–26.1; frameworks 26.7–32.6; sources32.1–33.9; lakehouse33.3–37.4. At38.4, Copilot enters at x490,y285,940×485; opacity reaches1 at 39.3 and scale .94→1 completes39.8.

## Environment map: `src/v9/EnvironmentMap.tsx`

| Row | First column | Second column | Third column |
| --- | --- | --- | --- |
| Upper, y285,h270 | Workspace, x144,w470 | Shared knowledge, x725,w470 | Atlas Platform, x1306,w470 |
| Lower, y730,h225 | Source systems, x144,w470 | GDS Frameworks, x725,w470 | GDS Lakehouse, x1306,w470 |

Cards use border-box sizing and radius20. Preserve internal icon/title coordinates, equal baselines and warm focus overlays. The lower connections are solid source→GDS Frameworks→lakehouse. The definitions/delivery link from workspace to GDS Frameworks is dashed and visibly separate; its caption is around x505,y600,width 350, with 23px title and 20px support. Do not replace the lower row with floating unlabeled icons or merge sources into the lakehouse box.

The same component is used in Intro, Snapshot orientation and Closing. Updating one changes all three; exact recreation makes no such edit.

## Onboarding: `src/v9/Interface.tsx`

The main chat begins at x420,y250,1080×640. Its header is80px. At local40–42 seconds it docks at x144,y244,650×590. Default later ChatPanel uses that docked geometry; Build overrides it separately. Preserve the compact scope Northwind › Commerce Lakehouse.

Phases change at 4,10,16,29 and 36 seconds. `Start Atlas` types1–3.4. Northwind is selected after 8; the first named Project is selected after 13. Task menu shows from16 to29, with the custom option emphasized at 25. Requirement types29.7–34.6 and sends36. The lower access path at x420,y909 fades in4–5 and out39–40. Avoid changing wrapping in project rows or the three task-menu groups.

## Snapshot: `src/v9/SnapshotJourney.tsx`

The master overlays EnvironmentMap first: fully visible through 2.1, fading to0 by 3.1. After this, heading is x144,y153,48px/600.

| Element | Geometry |
| --- | --- |
| Docked chat | x144,y244,650×590 |
| Local workspace | x885,y335,310×295,radius20,border-box |
| Atlas central service | x1300,y335,475×295,radius20,border-box |
| Atlas Bridge | x885,y695,310×135,radius20,border-box |
| Efficiency copy | x885,y850,width 890,centered; 26px title,21px support |

Local and central titles are26px at relative margin-top22. Icons sit at relative y89; local icon98px centered in307px, central MCP/PostgreSQL icons98px centered in160px columns,20px from each side. Their labels share25px baselines, with 17–18px support. Bridge identity is37px, label26px, row gap 13, margin-top26; its support19px is13px below.

Focus local5.2–20; Bridge20–25.5; central .5–5.4 and 24.8–28. The central icon arrow reverses at 20 seconds. Saved knowledge changes to Server draft at 26. Exact movement: PostgreSQL document x1620→1440 at 3.3–5.1; snapshot x1370→1020 at 5.5–7.7; file y620→687 at 21–22 into Bridge; next file x1185→1381 then y743→620 at 22.4–24.9; server draft document x1440→1620 at 25.2–27. Keep the separate short fade envelopes around each path.

Local icon is a folder before 20 and a document after 20. The reuse arrow rotates0→35 degrees over 11–20. Efficiency text enters 10–11, changes cost-support text at 16 and Bridge wording at 20.

## Build: `src/v9/BuildJourney.tsx` and master wrapper

| Element | Geometry / type |
| --- | --- |
| Copilot | x144,y350,650×610 before scale; scale .82, origin top-left; visible533×500.2 |
| Nine-stage strip | x132,y145,1656×140 |
| Each stage |168×140,radius16,3px active/inactive border; left offsets0,186,372,558,744,930,1116,1302,1488 |
| Stage icons |42px at relative x60,y13 |
| Stage labels |top69,h50,left/right6;20px,line-height 1.22,centered |
| Discovery/model artwork |x760,y405,1016×430 |
| Mapping/code/validation artwork |x760,y438,width 1016 |

Stage changes are at 0,3.8,6.8,9.7,12,20,26,35,44 seconds. Keep stable box widths when focus changes; arrows occupy18px gaps. Match the existing two-line labels.

Discovery: Returns and Refunds icons175px, inside190px columns82px from the respective edges. A132px magnifier moves across; enrichment document105px; relationship path draws; a966×320 subject-area border atrelative25,49 groups them. Discovery group fades11.6–12.

Model group: source140px column atrelative0,126; Silver group x220,y51,350×380; Gold x630,y51,380×380. Silver appears 13.4–14.2 and adds Returns15.1–15.9. Gold appears 19.4–20.2 with an18px horizontal entrance. Preserve **DimCustomer**, **DimDate**, **FactReturns**, labels23px; Silver/Gold layer labels32px atrelativey309; model-type labels25px at 354. Model group fades25.5–26.

Mappings: two1016×150 rows atrelativey0 and 188; second enters 29.6–30.2. Preserve source `refund_amount`→`RefundAmount` and Returns→FactReturns. Code/validation pairs use478×305 cards atrelativex0 and 538; headings32px,icons136px,descriptions29px atrelativey249. Gold code enters 39.5–40.2; Gold validation47.5–48.2. Supporting line is28px atrelativey350. Do not restore removed decorative approval-input labels or metadata footer.

## Review: `src/v9/ReviewJourney.tsx`

| Element | Geometry / timing |
| --- | --- |
| Heading |x144,y153,48px/600,tracking−1.2 |
| Screenshot frame |x144,y246,1632×663,radius18,border-box |
| Image |`public/screenshots/workbench-v6.jpg`,2276×920,object-fit contain,center top |
| Screenshot entrance |opacity0→1 in0–.6;scale.975→1 in0–.8 |
| Screenshot exit |opacity1→0 in5.5–6.1;scale1→.975 |
| Returning chat |opacity0→1 in6.1–6.8; heading changes at 6.1 |

Do not show the screenshot and chat at full opacity together. Keep existing Bridge/server-draft/validation/Apply artwork and alignment. `LegacyCopilotChat` receives `timelineSeconds=76+localSeconds`; this adapter preserves accepted chat phases. Do not wrap it in a nested Freeze or independently retime it.

## Run: `src/v9/RunJourney.tsx`

This is the accepted Run artwork copied into v9 with its current GDS Frameworks label. Preserve all geometry and motion. Legacy chat receives `timelineSeconds=108+localSeconds`. Delivery precedes the pipeline; GDS Frameworks moves into place by 8.2. Source/Bronze/Silver/Gold trays start atx210,610,1010,1410,y505,width 260. The record atx305, y539, 70×54 moves across the layers over approximately 9–19.5 seconds. Ingest then transform, followed by checks at 20–21. Delta Lake caption is atx660,y790,width 600. Preserve the inherited animation curves and pictorial paths.

## Team: `src/v9/TeamJourney.tsx`

| Element | Geometry |
| --- | --- |
| Heading |x144,y153,right144,43px/600,line-height 1.25,tracking−1 |
| Engineer A |x155,y332,350×183 |
| Engineer B |x155,y604,350×194 |
| Engineer C |x1415,y466,350×183 |
| Central Atlas |x683,y306,554×440,radius24,border-box |
| Person portraits |94px; Copilot marks 32px; names28px; agent label25px; roles23px |
| Central header |height 91; Atlas mark44px,label34px; MCP/database marks 48px |
| Tenant compartments |relativeleft/right24; Northwindtop156,h116; Contosotop294,h116 |

Heading changes at 10,20,28. A enters.7–1.5; B3.8–4.6; C5.8–6.6. Connections appear 2–8; shields/role enforcement10–12. Saved-context notices enter 20–23. A's label switches to Tenant Lock held at 28; B's becomes “Can read · waits to save.” Revision checks enter 29.5–30.5. Keep separate tenant paths and role labels.

## Closing: `src/v9/ClosingJourney.tsx`

The environment group fades in0–.9, holds through 9.5 and fades out by 11. Its heading isx144,y155,45px/600,tracking−1. Orange focus intervals: sources .7–2.6; frameworks 2–4; lakehouse3.4–5.7; knowledge5.7–7.9; workspace7.1–8.9; Platform8.2–10.1. Source arrays retain the rise/hold/fall points within those spans.

Final centered group:x280,y340,width 1360. It fades in10–11.5 and translates20px upward into place. Atlas mark108px; word91px/600,tracking−3,gap 23. “Move GDS forward.” is49px,line-height 1.3,tracking−1,margin-top45. **“Keep project knowledge central and shared.”** is35px,`#66778B`,margin-top17. The supporting25px line hasmargin-top45 and fades14–15. Final audio phrase starts14,ends16.882; scene ends20.

## Captions, determinism and references

Saved narration wrappers use the official existing BasicCaptions implementation. Caption block is left160,bottom18,scale.5 with bottom-left origin and width 3200; cue combining is0. Caption text uses Arial/Helvetica fallback. Preserve this component for exact current behavior; main film text remains bundled Open Sans.

All motion derives from frame/fps and deterministic interpolation. No live data, random state, network image requests or wall-clock animation participates in the film. Named Interactive nodes support inspection; explicit master scene nodes preserve timeline editing.

`reference-frames/index.json` lists exact frame numbers for 23 named checkpoints: welcome, copilot, future-clients, architecture, project-choice, task-menu, snapshot, bridge, profiling, models, mapping, code, validation, workbench, stage, gds, team, closing, closing-captions, frameworks-intro, frameworks-intro-captions, frameworks-run-captions, frameworks-closing. Twenty use the main film and three use the caption variant. The additional GDS Frameworks checkpoints cover the Intro label, Intro caption, Run caption and Closing architecture. Compare decoded pixels in the captured runtime; do not treat encoded PNG/MP4 bytes as cross-platform identity. Hashes verify the unchanged source/media/reference files independently of rendering.

### Frozen reference positions

| Name | Composition | Global frame | Global seconds | Image |
| --- | --- | ---: | ---: | --- |
| welcome | AtlasExplainer | 90 | 3 | `reference-frames/welcome.png` |
| copilot | AtlasExplainer | 270 | 9 | `reference-frames/copilot.png` |
| future-clients | AtlasExplainer | 390 | 13 | `reference-frames/future-clients.png` |
| architecture | AtlasExplainer | 1050 | 35 | `reference-frames/architecture.png` |
| project-choice | AtlasExplainer | 1695 | 56.5 | `reference-frames/project-choice.png` |
| task-menu | AtlasExplainer | 2070 | 69 | `reference-frames/task-menu.png` |
| snapshot | AtlasExplainer | 2850 | 95 | `reference-frames/snapshot.png` |
| bridge | AtlasExplainer | 3210 | 107 | `reference-frames/bridge.png` |
| profiling | AtlasExplainer | 3420 | 114 | `reference-frames/profiling.png` |
| models | AtlasExplainer | 4050 | 135 | `reference-frames/models.png` |
| mapping | AtlasExplainer | 4320 | 144 | `reference-frames/mapping.png` |
| code | AtlasExplainer | 4590 | 153 | `reference-frames/code.png` |
| validation | AtlasExplainer | 4890 | 163 | `reference-frames/validation.png` |
| workbench | AtlasExplainer | 5040 | 168 | `reference-frames/workbench.png` |
| stage | AtlasExplainer | 5280 | 176 | `reference-frames/stage.png` |
| gds | AtlasExplainer | 6480 | 216 | `reference-frames/gds.png` |
| team | AtlasExplainer | 7440 | 248 | `reference-frames/team.png` |
| closing | AtlasExplainer | 8280 | 276 | `reference-frames/closing.png` |
| closing-captions | AtlasExplainer-Captions | 8280 | 276 | `reference-frames/closing-captions.png` |
| frameworks-intro | AtlasExplainer | 885 | 29.5 | `reference-frames/frameworks-intro.png` |
| frameworks-intro-captions | AtlasExplainer-Captions | 885 | 29.5 | `reference-frames/frameworks-intro-captions.png` |
| frameworks-run-captions | AtlasExplainer-Captions | 6120 | 204 | `reference-frames/frameworks-run-captions.png` |
| frameworks-closing | AtlasExplainer | 7905 | 263.5 | `reference-frames/frameworks-closing.png` |

Runtime details belong to `REPRODUCTION-MANIFEST.json`; the index records frame positions and composition names.
