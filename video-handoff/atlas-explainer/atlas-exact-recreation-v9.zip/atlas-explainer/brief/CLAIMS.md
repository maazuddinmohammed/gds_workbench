# Claim boundaries

Checked against the local Atlas repository on 2026-11-10. Source paths below are
relative to the repository root. Code and SQL remain authoritative. The video
depicts architecture and capabilities; no production deployment was inspected.

| Topic | Video-safe claim | Evidence / limit |
| --- | --- | --- |
| Current agent host | GitHub Copilot via VS Code, Atlas Plugin and Atlas Bridge | `atlas/atlas-plugin/references/release-scope.md`; `atlas/README.md` |
| Future hosts | Codex, Claude Code and Cursor are desired future integrations | User direction; no release support established. Stage transport currently depends on Atlas Bridge in VS Code. |
| Azure and PostgreSQL | Atlas MCP is designed for Azure App Service and governed PostgreSQL access | `mcp_server/README.md`; `docs/architecture/overview.md` |
| Modeling | Profiling, enrichment, relationship analysis, Subject Areas, Logical and Dimensional models | `CONTEXT.md`; `atlas/atlas-plugin/docs/usage-guide.md` |
| Deliverables | Mappings/documents, target DDL, transformation SQL and validation definitions | `CONTEXT.md`; `atlas/atlas-plugin/skills/atlas-registration/SKILL.md`; `atlas/atlas-plugin/skills/atlas-verify/SKILL.md` |
| Code | Generate and maintain SQL | `references/release-scope.md` under Atlas Plugin. New Python generation is deferred. |
| Maintenance | Review downstream impacts and revise models, mappings, SQL and checks | `atlas/atlas-plugin/skills/atlas-project-change/SKILL.md` |
| Central context | Shared saved requirements, models, mappings, code and checks | `atlas/atlas-plugin/references/project/context.md`; `atlas/atlas-plugin/references/platform/state.md`. Unsaved local sessions/drafts do not transfer automatically. |
| Permissions | Server-enforced, role-based Tenant access | `docs/security.md`; `database/03_security.sql`. Projects follow Tenant authorization; independent Project membership is not established. |
| RLS | Do not claim PostgreSQL RLS enabled | No `CREATE POLICY` or `ENABLE/FORCE ROW LEVEL SECURITY` found in repository SQL. `NOBYPASSRLS` flags alone do not establish table policies. External configuration has not been inspected. |
| Concurrent work | Tenant Locks and revision checks protect shared writes | `docs/security.md`; `docs/architecture/overview.md`. Concurrent local drafts remain possible. |
| Audit | Governed actions and outcomes have a bounded audit trail | `docs/security.md`; `mcp_server/atlas_mcp/adapters/mcp/tool_audit.py`. Raw prompts, model/tool output, physical rows and credentials are excluded. |
| Local efficiency | Snapshot reuse and targeted reads reduce repeated retrieval and unnecessary agent context | `atlas/atlas-plugin/references/platform/state.md`. No measured cost percentage or minimum-cost claim. |
| Approval | Review → approve Stage → server validation → separately approve Apply | `atlas/atlas-plugin/docs/usage-guide.md`; `atlas/atlas-plugin/references/release-scope.md`. Atlas Local Workbench has no Stage/Apply approval buttons. Profiling directly persists measurements as a documented exception. |
| Execution | Approved artifacts support a separate GDS delivery and orchestration process | `CONTEXT.md`; `docs/security.md`. Apply saves definitions; it does not deploy files, run pipelines, execute DDL or prove data correctness. |
| ADO Boards | Requirements may arrive via a separately authorized agent connector | User's desired integration. No native Atlas Boards connector found. Treat as optional ecosystem integration, not an existing Atlas feature. |
| UI | Atlas Local Workbench reviews local drafts; Atlas Platform shows shared work | `docs/architecture/overview.md`; `docs/design-system.md`. Platform calls shared application rules directly, not Atlas MCP. |

## Remotion production references

Used the installed official Remotion skills (4.0.534) for creation, markup,
composition structure, local fonts and Studio preview. Checked current official
guidance online:

- https://www.remotion.dev/docs/ai/skills
- https://www.remotion.dev/docs/cli/studio

The generated project's package lock pins the actual installed runtime. Do not
upgrade packages while recreating the existing video.
