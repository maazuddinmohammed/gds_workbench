# Atlas — accelerate GDS delivery

Review cut 02 · 2026-11-10 · 190 seconds · 354 narration words · 1920×1080 · 30 fps

Audience: stakeholders and data engineers. Clear story, light technical detail.
Focus: Atlas Plugin with GitHub Copilot, accessed through VS Code.
Central message: Atlas helps teams deliver and maintain GDS projects while keeping
saved project knowledge shared, governed and reusable.

All nine scenes are implemented in the assembled review cut, with temporary
local macOS Samantha narration and timed captions. The timeline is 3:10
(5,700 frames). Actual durations below follow `brief/NARRATION.json`; speech
finishes naturally rather than being truncated to the original three-minute
target. Audio and captions are saved in `public/audio/` and `public/captions/`.
No music is used. Full-cut visual/audio verification is being completed.

## 01 · The outcome · 00:00–00:17.5

**Narration**

Every GDS project needs three things: metadata, table definitions, and
transformation code. Atlas helps teams build and maintain them together—turning
project requirements into the ingredients GDS needs to ingest, process, and
deliver data.

**Picture**

Open on the existing Atlas Meridian lockup. Headline: “Accelerate GDS delivery.”
Reveal three clear inputs in sequence: Metadata, Table definitions / DDL, and
Transformation SQL. A short closing line ties them together: “Build. Maintain.
Keep the context.” This is the promise; explain the processing handoff in scene 06.

**Motion beats**

- 0–3 seconds: branded lead-in fills the user's preserved Studio timing offset.
- 3–5 seconds: lockup and headline establish the outcome.
- 5–8 seconds: three inputs appear one by one.
- 8–14 seconds: hold the complete composition for comprehension.
- 14–17.5 seconds: close on the shared-context message; hold into the cut.

## 02 · How Atlas connects · 00:17.5–00:38

**Narration**

Start with GitHub Copilot, accessed through VS Code. Atlas Plugin guides the
agent’s work. Atlas MCP, hosted in Azure, provides governed access to PostgreSQL.
The lakehouse holds the data; PostgreSQL holds saved metadata, models,
requirements, and project knowledge.

**Picture**

Copilot is the visual entry point; “via VS Code” is a small secondary label,
without a full editor window. Draw Atlas Plugin beside the agent as its
instructions and local helpers. Draw the access path Copilot → Atlas MCP →
PostgreSQL. Label MCP's boundary “Azure App Service.” Keep the GDS lakehouse
(Delta Lake)
separate from PostgreSQL: data versus metadata/project state. This depicts the
supported deployment architecture, not a live environment inspection.

## 03 · Understand the source · 00:38–00:58

**Narration**

Begin with evidence. Profile the source data, enrich its metadata, investigate
relationships, and identify subject areas. These steps help the team understand
what exists, how it connects, and which business concepts the project needs to
represent.

**Picture**

Use a small synthetic Retail project: Customer, Order, OrderLine, Product.
Reveal profile summaries, then inferred relationships, then the Sales subject
area. Distinguish inferred links from measured validation. These are
illustrations, not real project records or reported execution results.

## 04 · Build the project · 00:58–01:21.5

**Narration**

Use that foundation to build and maintain the operational, or logical, model,
followed by the dimensional model. Atlas supports source-to-target mappings,
mapping documents, table definitions, transformation SQL, and validation
scripts. Each deliverable connects back to the project’s saved requirements
and metadata.

**Picture**

Move from a small normalized Silver model to a Gold star: FactSales with
DimCustomer and DimProduct. Name the layer once: “Operational / logical model.”
Then use “Logical” consistently. Reveal mapping → SQL → validation artifacts,
one focus at a time. Show validation definitions/checks, never invented Pass
results. New code generation is SQL; do not imply Python generation.

## 05 · Review before changing · 01:21.5–01:50

**Narration**

The agent works from a bounded metadata snapshot and prepares changes locally,
reducing repeated retrieval and oversized exchanges. Review the draft in Atlas
Local Workbench. Atlas Bridge stages approved changes; Apply saves the approved
candidate. Locks and revision checks protect governed writes, while audit
records capture actions and outcomes.

**Picture**

Snapshot → local drafting → Atlas Local Workbench review → approve Stage →
Atlas Bridge → server validation → separately approve Apply → shared saved state.
Use two visually distinct approval gates. Stage is not Apply. A small Tenant
Lock and revision marker protect the shared write. Do not invent Stage/Apply
buttons in Atlas Local Workbench: approvals occur in the agent conversation.
Do not depict profiling as necessarily passing through this draft path; the
current profiling workflow saves its measured results directly.

## 06 · GDS does the processing · 01:50–02:11.5

**Narration**

Those approved artifacts feed your established GDS delivery process. Once
deployed through that process, the GDS orchestrator uses metadata and
transformation logic to move data from Source to Bronze, then Silver and Gold.
Atlas prepares the work; GDS performs the ingestion and transformation.

**Picture**

Metadata + DDL + transformation SQL cross a visible “Delivery / deployment”
handoff. Then show the GDS orchestrator directing Source → Bronze → Silver →
Gold. DDL establishes physical tables through the delivery process; do not
animate Atlas Apply creating them. A separate validation track follows the
outputs without implying tests have run or passed. The exact deployment and
orchestrator integration are outside this repository's demonstrated runtime.

## 07 · Project knowledge survives handoffs · 02:11.5–02:35

**Narration**

When another authorized user joins, they can start from the project’s saved
context, without inheriting someone else’s chat history. Tenant-scoped roles
govern access. Requirements, models, mappings, and approved artifacts remain
shared. Each person works in a local draft. Reviewed changes become shared
project state after Apply.

**Picture**

Teammate A saves shared project knowledge. Teammate B signs in and opens the
same authorized project. Keep an unsaved local draft outside the shared store.
Show Microsoft sign-in and “Role-based Tenant access,” not an unverified RLS
badge or separate per-Project membership model.

## 08 · Maintain and inspect · 02:35–02:52

**Narration**

The same workflow supports new sources, changed requirements, and investigations
into existing code. Atlas Platform also provides a browser interface for
viewing saved results and tracking work. Development continues from the
project’s accumulated knowledge.

**Picture**

A new source or requirement loops back through impact review, model, mapping,
SQL and validation changes. Brief Atlas Platform view with synthetic content.
Distinguish it from Atlas Local Workbench. If an architecture connector is
shown, Platform reaches shared backend/storage directly, not through Atlas MCP.

## 09 · Extend the approach · 02:52–03:10

**Narration**

With a separate connector, ADO Boards stories can supply requirements. Codex,
Claude Code, and Cursor are future integration directions. Today, the focus is
Copilot: helping teams accelerate GDS development while keeping project
knowledge connected.

**Picture**

Copilot remains primary under “Today.” ADO Boards appears briefly under
“Optional agent connector.” Codex, Claude Code and Cursor are explicitly marked
“Future direction,” with no dates or support claims. Close with the Atlas
lockup and “Build. Maintain. Keep the context.”

The user said “Cloud Code”; this draft interprets that as Claude Code.

## Editorial decisions

- Lead with the GDS outcome before component architecture.
- Treat validation and maintenance as part of delivery, not an afterthought.
- Explain shared context through a teammate handoff rather than a database slogan.
- Keep VS Code subordinate; the protagonist is the Copilot-assisted user.
- Keep optional and future integrations at the end.
- No fabricated benchmarks, deployment success, query results or customer data.
- Temporary review narration uses macOS Samantha, generated locally. No music.
- The user authorized building all scenes for review; verify changes incrementally
  without adding scene-by-scene approval barriers.
