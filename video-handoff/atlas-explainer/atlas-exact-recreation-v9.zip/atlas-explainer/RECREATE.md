# Recreate the approved Atlas explainer — v9

This is an executable reproduction guide for the saved video, not a request to design a similar one. Give another agent **the frozen `atlas-exact-recreation-v9.zip` kit and `RECREATE-PROMPT.md`**. The kit contains this guide, exact source, narration, captions, fonts, icons, screenshot, lockfile, reference frames and integrity manifest. Those are the two handoff artifacts. A prose guide and prompt without the bundled files cannot recreate the exact voice, artwork or motion.

V9 updates the current product label to **GDS Frameworks** everywhere in the film. It changes visible labels and three spoken cues only: Intro cues 7 and 8, plus Run cue 2. All other design, motion, saved narration and the 280-second timeline remain the accepted v8 cut. The final message remains **“Keep project knowledge central and shared.”**, with the spoken phrase **“while keeping project knowledge central and shared.”** Preserve the orange focus, alignment and accepted workflow.

## 1. What “exact” means

Reproduce the same 1920×1080 composition, typography, assets, geometry, animation, narration samples, captions and 8,400-frame timeline from the bundled files. Do not reinterpret this document into newly generated source. The manifest authenticates the files; supplied reference frames provide visual comparison points.

Identical source and media are not a promise of byte-identical MP4 files across operating systems, browsers or encoders. Browser rasterization may differ. The main film uses bundled Open Sans; the optional captions component retains its existing Arial/Helvetica system-font fallback, so caption pixels can vary across operating systems. For pixel comparison, use the captured environment listed in `REPRODUCTION-MANIFEST.json` and the frame positions in `reference-frames/index.json`. Do not silently change fonts or regenerate references to hide a mismatch.

## 2. Read in this order

1. This file: reproduction procedure and boundaries.
2. `brief/v9/STORYBOARD.md`: exact scene sequence, actions and screen story.
3. `brief/v9/NARRATION.md`: all 58 cues, exact words and global timestamps.
4. `brief/v9/ART-DIRECTION.md` and `brief/v9/DESIGN-SPEC.md`: design intent, geometry and animation specifications.
5. `REPRODUCTION-MANIFEST.json`: frozen inventory, hashes, runtime details and references.
6. `src/Root.tsx`, `src/v9/AtlasExplainer.tsx` and their imports: executable authority.

The source and saved media resolve any prose ambiguity. The guide explains the files; it does not supersede them. If a required file is absent or a manifest hash fails, report the specific discrepancy before attempting exact replay. Do not invent a replacement.

## 3. Keep the project local and excluded from Git

The original directory is `.scratch/atlas-explainer/` inside the Atlas repository; its parent's `.scratch/` ignore rule excludes it. Preserve that exclusion. When transferring the kit, extract into a standalone directory outside any Git repository, or an already ignored location. Do not initialize a nested repository, force-add files, alter ignore rules, publish, upload, push or deploy.

No account, API key, production workspace, database, cloud resource or external data is needed. All video media is local. The screenshot uses fictional demo metadata. This is a video reproduction task, not authorization to run Atlas workflows against actual systems.

## 4. Install and preview the frozen project

Work from the extracted directory containing `package.json` and this file. Keep the ZIP untouched as the source copy. Use Python 3 for the verifier and a compatible Node runtime. The captured environment uses Node 24.10.0, npm 11.6.0, Remotion 4.0.542 and Chrome Headless Shell 158.0.8127.2; confirm the final environment fields in the manifest. `package.json` accepts Node `^20.19.0 || ^22.13.0 || >=24`, but the captured version is preferred for comparison.

Run these sequentially:

```bash
python3 scripts/verify_recreation.py
npm ci --no-fund --no-audit
npm run check
npm run build
npm run studio
```

Open the exact local URL printed by Studio. Select **AtlasExplainer**. It is v9, captions off. **AtlasExplainer-Captions** is the identical film with its saved timed captions enabled. Do not select a previous review or a standalone artwork composition as the final film.

Dependencies and Remotion's browser are not bundled in the handoff ZIP. A first installation may need npm registry/browser-download access; an appropriately populated cache can supply them. Once installed, playback uses local assets. Saved narration does not require macOS `say` or a text-to-speech service.

`bash scripts/recreate.sh` is a convenience installer/checker/Studio launcher; run the manifest verification separately first. For a verified copy whose dependencies are already installed, use `npm run check` and `npm run studio`. Do not run `npm update`, `npm run upgrade`, replace the lockfile, install “latest” packages or rewrite working markup.

## 5. Verify the result

The verifier checks bundled-file hashes, required media and the eight-scene audio/caption contract. Read its actual result; this guide does not certify a run that has not occurred. `npm run check` checks source lint/types; `npm run build` checks bundle creation. These checks do not substitute for watching the video.

Compare the frozen reference frames at the named composition/frame positions in `reference-frames/index.json`. After installation, the verifier can render a named reference and compare decoded PNG pixels:

```bash
python3 scripts/verify_recreation.py --render-reference closing
```

`closing` is one example. Use another exact name from the index/manifest, or `--render-reference all` to compare all 23 checkpoints. A failed comparison is evidence to inspect, not permission to replace the baseline. Check browser version, operating system, font availability and source/media hashes first. Preserve the original reference images.

Watch or scrub these sequences in **AtlasExplainer**:

- Opening: welcome, Copilot/Plugin/future-client focus, then the six-box environment map. Orange emphasis must follow narration without card movement.
- Onboarding: `Start Atlas`, authorized Tenant, existing named Project, full task menu, then the custom enhancement.
- Snapshot: focus moves from shared knowledge to local work, then approved files through Atlas Bridge to a server draft. Token-cost line appears before Bridge transfer.
- Build: nine icon boxes remain visible; one is active at a time. Copilot stays smaller; model labels are `DimCustomer`, `DimDate`, `FactReturns`.
- Review/Run: actual saved workbench image, Stage, separate Apply, separate delivery, then the accepted Source → Bronze → Silver → Gold animation.
- Team: separate individual Copilot sessions, tenant scopes, roles, central saved knowledge, Tenant Lock and revision checks.
- Closing: architecture returns, then “Move GDS forward.” and **“Keep project knowledge central and shared.”** The final voice says the same idea and leaves a quiet hold.

Listen for overlap, truncation or misplaced cues at all scene boundaries. Check the optional caption composition separately. Report verification commands and their actual outcomes, any environment mismatch, and the local preview location. Do not claim a visual comparison passed unless it was performed.

## 6. Composition and timing contract

The master is **4:40 / 280 seconds / 8,400 frames at 30 fps, 1920×1080**. Times below are half-open intervals; the final valid frame is 8,399.

| Scene | Global time | Start frame | Duration frames | Artwork |
| --- | --- | ---: | ---: | --- |
| Intro | 0:00–0:42 | 0 | 1260 | `src/v9/IntroJourney.tsx`, `EnvironmentMap.tsx` |
| Onboarding | 0:42–1:24 | 1260 | 1260 | `src/v9/Interface.tsx` |
| Snapshot | 1:24–1:52 | 2520 | 840 | `src/v9/SnapshotJourney.tsx`, map overlay in master |
| Build | 1:52–2:46 | 3360 | 1620 | `src/v9/BuildJourney.tsx`, chat wrapper in master |
| Review | 2:46–3:18 | 4980 | 960 | `src/v9/ReviewJourney.tsx`, `LegacyCopilotChat.tsx` |
| Run | 3:18–3:44 | 5940 | 780 | `src/v9/RunJourney.tsx`, v9 legacy chat adapter |
| Team | 3:44–4:20 | 6720 | 1080 | `src/v9/TeamJourney.tsx` |
| Closing | 4:20–4:40 | 7800 | 600 | `src/v9/ClosingJourney.tsx` |

`src/v9/AtlasExplainer.tsx` owns the eight explicit `Sequence` nodes, audio wrappers, persistent brand and workflow rail. `src/Root.tsx` registers the master and optional caption variant. `Current-artwork` contains nine editable **V9-** views: Intro, Environment, Onboarding, Snapshot, Build, Review, Run, Team and Closing. These are artwork inspection tools, not alternate masters; some omit master overlays/audio. Run is now a v9 copy of the accepted artwork, with only the GDS Frameworks label updated.

## 7. Exact media and dependencies

| Saved version | Scene WAVs and caption JSON | Duration |
| --- | --- | ---: |
| v9 | Intro 42s, Run 26s | 68s |
| v4 | Snapshot 28s, Team 36s | 64s |
| v5 | Onboarding 42s, Build 54s | 96s |
| v2 | Review 32s | 32s |
| v8 | Closing 20s | 20s |

Paths are `public/audio/VERSION/SCENE.wav` and `public/captions/VERSION/SCENE.json`, with lowercase scene names. Total: **280 seconds, 58 saved cues**. WAVs are mono 24 kHz PCM. There is no music. Saved silence and cue spacing are intentional. The saved WAVs, not a voice name or generator settings, are the exact replay source.

Keep all bundled version folders. The v9 master deliberately imports unchanged narration from v2/v4/v5/v8, the renamed Intro/Run narration from v9, and pictorial components from v2. Run artwork is a v9 copy preserving the accepted visuals with the current label. Keep `src/fonts.ts` and its import chain through shared pictorials. Removing an “old” folder can break the current film or change previous reviews.

Retain `public/atlas.svg`, all local icon files and their `SOURCES.json` provenance, Open Sans Regular/SemiBold WOFF2 and license, and `public/screenshots/workbench-v6.jpg` unchanged. The workbench image is a real **2276×920 JPEG** capture of Atlas Local Workbench with synthetic Northwind metadata. Exact replay uses that JPEG; do not recreate the interface, recapture a live app, crop differently or substitute an AI mockup. The copied synthetic fixture and provenance are retained under `brief/v6/workbench-demo/` for intentional future maintenance, not required for playback.

## 8. Narration: replay versus intentional revision

**Do not run any narration generator for exact replay.** Existing generators document provenance; they are not an installation step. Re-synthesizing Samantha at 160 words/minute can produce different duration or samples on another OS voice version. V9 replaces only Intro cues 7 and 8 and Run cue 2; its saved WAVs preserve the other audio regions. The inherited closing remains the v8 WAV. `scripts/build_narration_v9.py` and `brief/v9/narration-plan.json` document these three replacements; wrappers are in `src/v9/SceneNarration.tsx`. The unchanged closing uses `src/v8/SceneNarration.tsx`. Do not run generators during exact replay.

The full consolidated transcript is `brief/v9/NARRATION.md`; authoritative cue timings remain saved JSON and inline wrapper captions. For a separately requested future revision, change only the relevant new-version source/cue plan, generate only authorized changed audio, check cue endpoints fit the fixed scene, update docs and refresh the package deliberately. Preserve previous versions. Never “fix” timing by stretching audio or extending the master without approval of that editorial change.

## 9. Preserve product meaning

- **Atlas Plugin** supplies agent skills/references/local helpers. **Atlas Bridge** is the VS Code extension handling Microsoft sign-in and approved staging. **Atlas MCP** is the governed agent-facing server. **Atlas Platform** is the web application. **Atlas Local Workbench** is the local browser review/edit interface.
- Copilot via VS Code and Atlas Bridge is the current illustrated client. Codex, Claude Code and Cursor remain explicitly future integrations.
- Access is implemented Tenant RBAC. Do not claim native PostgreSQL RLS or independent per-Project grants. A Project inherits its owning Tenant's access. Evidence is retained in `brief/v4/CLAIMS.md`.
- Shared **saved project knowledge** persists centrally. Private conversation history and unsaved local drafts do not transfer automatically. Separate users keep separate Copilot sessions.
- Reads and local drafting can coexist. Tenant Locks protect saved writes; revision fencing rejects stale changes. Do not imply that all parallel activity is disabled.
- An existing Project and input scope are prerequisites. The Plugin is not shown creating Project Input Scope.
- Applied Logical inputs precede dimensional modeling, applied target models precede Mapping, and applied Mapping precedes Code. The nine-stage display shows capabilities, not an unattended mandatory one-pass process.
- Stage creates a server draft; Apply is a separate approved action. Delivery and GDS execution are separate again. Do not imply automatic deployment or execution.
- Snapshot reuse, focused reads and Bridge transport help reduce repeated tool calls and oversized chat context. No numerical or guaranteed cost-saving claim is made.
- Audit describes governed actions/outcomes, not every raw result. ADO Board access is outside this cut and would need a separately authorized connector.

## 10. Packaging and later handoff

The frozen ZIP contains the executable project and guide. The separate `RECREATE-PROMPT.md` tells the receiving agent how to use it. Preserve the accompanying SHA-256 sidecar if supplied. Do not send only the Markdown guide and expect exact reconstruction.

For a deliberate refreshed handoff after authorized edits and verification, the maintainer runs:

```bash
python3 scripts/package_recreation.py
```

It creates `handoff/atlas-exact-recreation-v9.zip`, a SHA-256 sidecar and the root `REPRODUCTION-MANIFEST.json`. Packaging records the current files; it is not a repair mechanism for a failed incoming manifest. Run the verifier against the final packaged/extracted content as part of maintenance. Dependency installations, generated bundles and caches are excluded; source, required media and references must remain included.

`Previous-review` retains v8 and earlier compositions; `archive/review-v8/` and preceding archives retain previous documentation/source snapshots. Do not reset `AtlasOpening` or change earlier cuts while recreating v9. Put future editorial changes in a new version and update imports intentionally.

Preview is the requested deliverable. Only when an MP4 export is explicitly requested, use `npm run render:review` (H.264, CRF 18) and review that export. Rendering does not authorize publishing.
