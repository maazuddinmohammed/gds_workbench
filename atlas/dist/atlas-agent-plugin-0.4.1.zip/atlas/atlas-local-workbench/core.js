(function (root, factory) {
  "use strict";
  let unicode = root.GDSUnicode;
  if (typeof module === "object" && module.exports) unicode = require("./unicode.js");
  const api = factory(unicode);
  if (typeof module === "object" && module.exports) module.exports = api;
  root.GDSCore = api;
})(typeof globalThis === "object" ? globalThis : this, function (unicode) {
  "use strict";

  // Python str ordering: compare Unicode code points, not UTF-16 code units.
  function compareCodePoints(left, right) {
    const a = [...left], b = [...right];
    for (let index = 0; index < Math.min(a.length, b.length); index += 1) {
      const difference = a[index].codePointAt(0) - b[index].codePointAt(0);
      if (difference) return difference;
    }
    return a.length - b.length;
  }

  function stableStringify(value) {
    // Match Python json.dumps after the MCP request's JSON decoding.
    if (typeof value === "number" && value !== 0 && Math.abs(value) < 0.0001) {
      return value.toExponential().replace(/e-(\d)$/, "e-0$1");
    }
    if (value === null || typeof value !== "object") return JSON.stringify(value);
    if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
    return `{${Object.keys(value)
      .sort(compareCodePoints)
      .map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`)
      .join(",")}}`;
  }

  // Project Input Scope is managed in the Atlas Platform and Profiling runs on the backend.
  // Atlas reads both from Snapshots but never drafts or stages them.
  const WEB_MANAGED_PROJECT_DATASETS = Object.freeze(["profiling_profile", "project_input_scope"]);

  // UTF-16 code-unit order, matching .NET StringComparer.Ordinal. Use it for anything that is
  // hashed or bound; localeCompare depends on the host locale and differs from PowerShell.
  function compareOrdinal(left, right) {
    return left < right ? -1 : left > right ? 1 : 0;
  }

  function validateSubagentPolicy(value) {
    if (!value || typeof value !== "object" || Array.isArray(value) ||
        !["current", "auto", "custom"].includes(value.mode) ||
        Object.keys(value).some(key => !["mode", "model"].includes(key))) {
      throw new Error("Invalid sub-agent policy. Choose current, auto or custom.");
    }
    if (value.mode === "custom") {
      if (typeof value.model !== "string" || !value.model || value.model.length > 200 ||
          value.model !== value.model.trim() || /[\u0000-\u001f\u007f-\u009f]/.test(value.model)) {
        throw new Error("Custom sub-agent policy requires one model name or ID, at most 200 characters, without surrounding whitespace or control characters.");
      }
    } else if (Object.hasOwn(value, "model")) {
      throw new Error("Only the custom sub-agent policy accepts a model.");
    }
    return value;
  }

  function normalize(area, field, value) {
    if (typeof value !== "string") return value;
    const trimmed = value.replace(/^ +| +$/g, "");
    if (area === "project") {
      return unicode?.casefold ? unicode.casefold(trimmed) : trimmed.toLowerCase();
    }
    if (/(_code|_name|_schema)$/.test(field)) {
      return unicode?.lower ? unicode.lower(trimmed) : trimmed.toLowerCase();
    }
    return value;
  }

  function key(area, definition, record) {
    if (!Array.isArray(definition.canonical_key)) {
      throw new Error(`${definition.name} canonical key is invalid.`);
    }
    return definition.canonical_key.map((field) => {
      if (!Object.prototype.hasOwnProperty.call(record, field)) {
        throw new Error(`${definition.name}.${field} is required.`);
      }
      return normalize(area, field, record[field]);
    });
  }

  function isEntityOwnedProjectCatalog(catalog) {
    if (!Array.isArray(catalog?.sections)) return false;
    for (const section of catalog.sections) {
      if (section?.name === "project_binding" || !Array.isArray(section?.datasets)) return false;
      for (const dataset of section.datasets) {
        // Retired datasets mark a Snapshot from before the current record contract.
        if (["project_object_binding", "project_attribute_binding", "mapping_dependency", "logical_submodel", "dimensional_submodel"].includes(dataset?.name)) return false;
        let required = [];
        if (["mapping_object", "mapping_attribute", "generated_code", "generated_code_source_system"].includes(dataset?.name)) required = ["modeled_entity_schema_name"];
        for (const layer of ["logical", "dimensional"]) {
          if ([`${layer}_entity`, `${layer}_attribute`].includes(dataset?.name)) required = [`${layer}_entity_schema_name`];
          // Child -> parent: the child's foreign-key Attribute alone identifies a Relationship.
          if (dataset?.name === `${layer}_relationship`) required = [`from_${layer}_entity_schema_name`];
        }
        if (required.some(field => !Array.isArray(dataset.canonical_key) || !dataset.canonical_key.includes(field))) return false;
      }
    }
    return true;
  }

  function overlay(area, definition, baseline, pending) {
    const records = new Map(
      baseline.map((record) => [stableStringify(key(area, definition, record)), record]),
    );
    for (const record of pending) {
      records.set(stableStringify(key(area, definition, record)), record);
    }
    return [...records.values()].sort((left, right) => {
      const leftKey = stableStringify(key(area, definition, left));
      const rightKey = stableStringify(key(area, definition, right));
      return leftKey < rightKey ? -1 : leftKey > rightKey ? 1 : 0;
    });
  }

  // Model records use `<prefix>_is_active`; nested sources and Metadata use `is_active`;
  // Context, Mapping and Code keep a named status. Some datasets have none.
  function active(record) {
    if (typeof record.is_active === "boolean") return record.is_active;
    if (typeof record.status === "string") return record.status === "active";
    for (const [field, value] of Object.entries(record)) {
      if (field.endsWith("_is_active") && typeof value === "boolean") return value;
    }
    for (const [field, value] of Object.entries(record)) {
      if (field.endsWith("_status") && typeof value === "string") return value === "active";
    }
    return null;
  }

  function reviewActions(area, definition, baseline, pending) {
    const originals = new Map(
      baseline.map((record) => [stableStringify(key(area, definition, record)), record]),
    );
    return pending.map((record) => {
      const naturalKey = key(area, definition, record);
      const original = originals.get(stableStringify(naturalKey));
      let action = "added";
      if (original) {
        if (stableStringify(original) === stableStringify(record)) action = "unchanged";
        else if (active(original) === true && active(record) === false) action = "deactivated";
        else if (active(original) === false && active(record) === true) action = "reactivated";
        else action = "changed";
      }
      return {
        action,
        key: Object.fromEntries(
          definition.canonical_key.map((field, index) => [field, naturalKey[index]]),
        ),
        record,
      };
    });
  }

  return { WEB_MANAGED_PROJECT_DATASETS, active, compareCodePoints, compareOrdinal, isEntityOwnedProjectCatalog, key, normalize, overlay, reviewActions, stableStringify, validateSubagentPolicy };
});
