# Dimension history and lookup

Use when Dimensional Build, Mapping or Code needs changing-value or temporal behavior. [Dimensional records](../project/dimensional.md) owns accepted fields; [keys/audit](../project/keys-and-audit.md) owns shared columns. The user confirms Type 1 and Type 2 support and framework population of Type 2 fields using the natural keys. Select behavior from requirements and use the actual configured column names/types.

## Select behavior from analytical needs

Read the effective Project's `dimensional_entity_scd_type`. `type_1` overwrites eligible business values; `type_2` preserves dimension row versions. Null is unspecified, not a default. Natural and surrogate identity remain fixed; configured foreign keys, audit fields and history fields follow their own governed population rules. Facts and bridges do not inherit dimension history.

There are no per-Attribute history flags. Ask only when the existing Project, requirements and user decisions do not resolve the applicable policy or temporal lookup. A useful question is: "After CustomerSegment changes, should earlier sales report the segment at sale time, the current segment, or support both?" Keep the answer in existing definitions and Mapping rules. If a requirement needs different behavior for individual columns, record the policy limitation instead of inventing an unsupported field.

## If row versions are required

Type 2 commonly assigns a distinct surrogate to each version and adds validity boundaries plus a current-row marker. Retain a stable business identity so versions can be related. See [Kimball Type 2](https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/type-2/).

Before completing the affected design, resolve:

- Which eligible business-value changes create a version under the Project policy; how duplicates, unchanged inputs and repeated loads are recognized.
- Effective-time source, timezone, boundary convention and open-ended representation; avoid overlapping intervals for one business member.
- Whether a fact resolves the current version or the version valid at its business event time. The complete business-key/time predicate must select exactly one eligible version, or follow the confirmed missing-member policy; handle validity gaps as well as overlaps. Late facts cannot automatically use today's version.
- How late/missing members, unknown versus not-applicable values, corrections and backdated changes are handled. Do not invent a sentinel key, discard a fact or substitute an arbitrary current row.
- The technical columns' actual names/types/nullability. The framework supplies the Type 2 fields; use the configured contract without inventing placeholder values.

These are decision criteria, not a mandatory interview checklist or new payload fields. Put concise rules in existing Entity/Attribute definitions, relationship basis and source rationale; preserve the full executable decision for later Mapping. Use a Context only for a reusable attributable rule that benefits from one.

## Technical columns and framework boundary

History columns are additional modeled Attributes, separate from the confirmed audit block. Do not repurpose `IsActive`, `CreatedDate` or `UpdatedDate` as version markers without an explicit consumer contract. A technical Attribute is not automatically a framework-generated or SQL-omitted field.

The backend projects the configured effective-from, effective-to and current-marker columns for dimensions governed by Project Type 2 policy. That creates Project columns; the external framework populates them at load time using natural keys. Surrogate placement and fact/bridge coverage follow [keys/audit](../project/keys-and-audit.md#population-boundary-and-implementation-alignment).

A Project with no custom Gold template uses these defaults. Read the effective `type_2` entries from the Project [settings](../project/settings.md#existing-dimensional-technical-template), including pending settings; a customized Project may use other names.

| Purpose | Default name | Type / nullability |
|---|---|---|
| Version start | `RecordStartTime` | TIMESTAMP, non-null; inclusive start. |
| Version end | `RecordEndTime` | TIMESTAMP, nullable; exclusive end, null for the current version. |
| Current-version marker | `IsCurrentRecord` | BOOLEAN, non-null. |

In a Type 2 dimension these fields sit in the audit block immediately after `SourceSystemID` and before `GDSBatchID`. `IsActive` remains a separate audit field; do not substitute it for the current-version marker. Actual clock and boundary behavior must agree with the consumer.

Retain these history Attributes in the Project, target metadata and DDL. In each applicable Attribute Mapping, state "Framework-populated Type 2 field; omitted from transformation SQL." Do not invent source lineage, timestamp/boolean expressions or SQL that maintains these values. This adds the configured Type 2 fields to the own-surrogate/nine-audit exclusions; other technical fields still follow their explicit population rule.

Preserve the complete natural/business-key tuple, including source namespace where required, through Project, target metadata and Mapping. Transformation SQL supplies the mapped business-key values; the generated surrogate is not a substitute for the framework's natural-key matching. Explain current-member identity separately from version identity: repeating a natural key across historical versions is intentional. Framework-owned version maintenance does not decide a fact's current-versus-event-time dimension lookup; that analytical rule still belongs in Mapping.

If a particular history requirement exceeds the confirmed consumer behavior, keep that requirement and execution gap explicit. Continue independent modeling work; do not silently flatten history, claim load readiness or invent a second executable artifact. Do not re-ask the settled Type 1/Type 2 capability or history-field population questions.
