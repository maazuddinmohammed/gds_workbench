# Dimensional design

Shared method for Guided and Grill Me. [Context](context.md) defines eligible inputs; [Dimensional records](../project/dimensional.md) defines fields/sources. Use [naming](../project/naming.md) and [keys/audit](../project/keys-and-audit.md) rather than copying their policies here.

## Build or Optimize

A Project has one Dimensional model. **Build** one Subject Area at a time when the user names areas or asks to model Logical Entities that no Dimensional Entity uses yet. **Optimize** existing facts and dimensions across the model when the user asks to improve, review or repair what is built; it needs no Subject Area.

## Build one Subject Area at a time

1. Read the area's active member Objects, then the active Logical Entities with an active Object source among them: those are the area's inputs. Read the active Logical Relationships that touch them, the Dimensional Entities already built from those Logical Entities (a Dimensional Entity belongs to the areas of its Logical sources) and their neighbours, such as shared dimensions.
2. Reuse a dimension an earlier area already built, such as Customer or Date; extend it or add a relationship to it, never a second copy.
3. Return only changes: write new and changed records only, and retire a record by setting its `*_is_active` field to `false` instead of deleting it. Retire dependent Attributes, Relationships and foreign keys with it.
4. Run `coverage --session <dir> --layer dimensional --subject-area <area>`, then `validate` for the whole Project. Build several areas one after another, most shared first, validating each.

The area only chooses inputs; it is never evidence for grain, conformance or measures.

## Process and grain first

Apply the fact-specific decisions below when facts are in scope. A dimension-only request instead defines its member/version or calendar grain and intended use, then follows the relevant dimension/history/source rules. It does not require inventing a fact, measures or a physical source.

1. Start from the analytical outcome and an operational business process, such as taking orders, recording payments or measuring daily stock. Propose plausible processes from the eligible context; do not turn every Silver table or report into a fact.
2. State one row's business meaning before choosing measures or dimension keys: for example, one posted order line, one account at each day-end, or one claim moving through milestones. Include identity, time boundary and whether repeats/corrections create a new occurrence. A list of foreign keys or a generated surrogate alone is not a grain definition.
3. Check that the source actually supports that detail and requested history. Prefer useful atomic detail; create deliberate aggregate structures only for a justified analytical need with their own grain. Do not invent missing historical states.
4. Resolve inconsistent header/line, event/current-state or time-period meanings before proceeding. A header charge cannot be repeated on every line and then summed; retain its own grain or use an explicit supported allocation rule.

This sequence follows [Kimball's four design decisions](https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/four-4-step-design-process/): process, grain, dimensions and facts.

## Dimensions and conformance

- Identify descriptive context true to the fact grain. Favor useful flattened business hierarchies; do not mechanically reproduce Logical normalization as a chain of dimension tables. A separate dimension/bridge needs a real semantic or analytical reason. See [flattened dimensions](https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/denormalized-flattened-dimension/).
- Reuse a shared dimension only when meaning, business identity, values and relevant history agree. Matching names, column layouts or IDs across Systems do not prove conformance. Keep distinct identities until the reconciliation rule is known. See [conformed dimensions](https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/conformed-dimension/).
- Reuse one dimension for genuine roles, with distinct FK Attributes, relationship roles and query aliases—for example OrderDate and ShipDate. Do not copy the dimension's rows/definition for each role. See [role-playing dimensions](https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/role-playing-dimension/).
- A transaction identifier with no independent descriptive context may remain a degenerate dimension Attribute on the fact. A repeated label or low-cardinality field alone does not justify another table. Retain useful business descriptors and identifiers without forcing arbitrary dimension-count targets.
- Compare processes with a compact process-to-dimension view when it helps reveal reuse or incompatible meanings. Keep it in existing task/review context, not a new required Project dataset. Reuse one shared dimension across processes and Subject Areas rather than creating process-specific copies.

## Facts and measures

| Pattern | Row meaning and decisions |
|---|---|
| Transaction | One business event at the declared detail; preserve event identity and timestamp meaning. |
| Periodic snapshot | One reporting entity at a defined period boundary; define cadence, as-of meaning and required population, including no-activity cases. |
| Accumulating snapshot | One process occurrence updated across known milestones; define milestone roles, repeated events and completion/reopening behavior. |
| Factless | An event, coverage or eligibility relationship without numeric measures; define exactly what a row counts. Do not invent a measure merely to fill the project. |

Choose the pattern from behavior, not its table name, and record it as an active code from the read-only `dimensional_fact_type` list. The first three have different time/row semantics; see [Kimball fact-table patterns](https://www.kimballgroup.com/2008/11/fact-tables/). Factless does not by itself specify whether rows mean events or coverage.

For each measure, describe its meaning, units/currency, supported type/precision, additivity and default aggregation in its Attribute definition. Name valid axes for a semi-additive measure: an account balance may sum across accounts but not across dates. Ratios need a valid calculation basis, often summed numerator/denominator rather than averaging row ratios. Do not sum identifiers, mix currencies/units or manufacture a default aggregation. See [additivity guidance](https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/additive-semi-additive-non-additive-fact/).

The Attribute definition holds aggregation conditions and the basis for semi/non-additive measures. Bridge weights likewise explain allocation meaning in their definitions. These are business rules in prose; there are no separate role or measure-policy fields.

## Relationships, history and bridges

1. Point each `dimensional_relationship` child -> parent: from a fact, bridge or outrigger foreign-key Attribute to the dimension's key, normally its surrogate, with compatible types. Every Relationship is many-to-one; its kind follows the Entity types and it is optional when the foreign key is nullable, so set nullability deliberately. Name a role only for a role-playing dimension, and write a basis only when the link does not follow a Logical Relationship. Foreign-key values require the complete business-key lookup, not copying a Silver identifier into an unrelated generated key.
2. Apply [history and lookup rules](history.md) to current versus event-time membership, late arrivals and corrections. Resolve essential business decisions before dependent Mapping; keep unverified execution support explicit.
3. Introduce a bridge only for meaningful multiple membership at the stated grain. Declare one bridge row, membership identity, applicable time and how filtering/aggregation avoids double counting. Allocation weights are used only when the business defines allocation; never invent equal weights. See [multivalued dimensions and bridges](https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/multivalued-dimension-bridge-table/).
4. Review joins for row multiplication and loss. Avoid joining unrelated atomic facts just on shared dimension keys; compare their separately aggregated results at a compatible grain. See [fact-to-fact join guidance](https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/multipass-sql/).
5. Set project dependency order from known lookups and relationships; retain cycles/repeated-pass needs explicitly. It is not a Process schedule or permission to execute code. SQL evidence is optional under [query scope](../query-scope.md), including explicit batch choices and qualified coordinates.

## Lineage and standalone structures

- Trace derived Entity/Attribute sources to applied Logical Entities/Attributes using schema-qualified keys. Every Attribute's Logical source needs its corresponding Logical Entity source on the Dimensional Entity; the order of sources is not executable transformation logic.
- Use multiple real contributors where needed, with concise contribution rationale. Do not duplicate the same source key merely to label a second role. Keep reconciliation or generation decisions available for later Mapping.
- Calendar, constant/reference sets and other justified generated structures can have empty sources. Define calendar grain/range/fiscal rules or the constant values/meanings and change ownership. Use an applicable [Context](../project/context.md) when useful, never just to satisfy an imagined support requirement. Do not fabricate an Object or System.
- A source-less design still needs a supported population/provenance path before executable Mapping/Code. Current Mapping requires a real source-System context; do not hide this gap with a fake `SourceSystemID` or promise unsupported execution.
- Account for selected Silver contributions as represented, context-only, excluded with reason or unresolved. Completeness means the requested analytical outcome and useful lineage, not copying every source field into Gold.

## Quality checks

| Rule | Required review |
|---|---|
| `dimensional.grain` | One supported row meaning per Entity; fact/bridge grain explicit, no mixed detail or hidden duplicate business identity. |
| `dimensional.dimensions` | Context fits grain; conformance and role reuse preserve meaning, identity and history. |
| `dimensional.measures` | Facts fit grain; aggregation, units, precision and valid axes prevent wrong totals. |
| `dimensional.joins` | Child -> parent from a real foreign key to the dimension's key; compatible keys, deliberate nullability and role names; bridges and time lookups avoid fan-out/loss. |
| `dimensional.history` | Attribute changes and fact lookup time agree; required technical fields and their population are explicit. |
| `dimensional.lineage` | Valid Silver sources, matching parent sources and useful coverage; justified standalone structures have no fabricated lineage. |
| `dimensional.population` | Confirmed first generated surrogate on every table, complete shared audit block and explicit extra technical-column responsibility. |
| `dimensional.reuse` | Shared dimensions are built once and reused across processes and Subject Areas; cross-process effects stay visible. |

Run [local validation](../local-validation.md) over the complete effective graph and review actual analytical examples. A parser pass, a small table count or a plausible star diagram does not establish correct totals. Preserve locks and unrelated work; keep material uncertainty explicit rather than creating unsupported records.
