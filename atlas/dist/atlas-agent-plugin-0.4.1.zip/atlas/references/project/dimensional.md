# Dimensional records

Owns the four Dimensional dataset contracts and nested membership/source fields. Use [dimensional design](../dimensional-build/design.md) for modeling decisions, [naming](naming.md) and [keys and audit columns](keys-and-audit.md) for policy. [Project Change Sets](change-sets.md), [record state](../record-state.md) and [local validation](../local-validation.md) own shared mechanics.

## Files, identity and common values

Write complete changed records as JSON arrays under `project-change-set/<dataset>.json`. No section wrappers, internal numeric database IDs (including Project IDs), SQL, batch bindings or invented policy fields. Context source references require the portable `context_record_id` UUID; preserve that identity. Preserve nested arrays when editing.

| Dataset | Natural key within the Project |
|---|---|
| `dimensional_submodel` | `dimensional_submodel_name` |
| `dimensional_entity` | `dimensional_entity_schema_name` + `dimensional_entity_name` |
| `dimensional_attribute` | `dimensional_entity_schema_name` + `dimensional_entity_name` + `dimensional_attribute_name` |
| `dimensional_relationship` | Both schema-qualified Entity/Attribute endpoints + `dimensional_relationship_kind` + nullable `dimensional_relationship_role_name` |

Relationship **name is not its key**. Role and kind are key components; changing them changes identity. Use shared normalization and preserve existing spelling. Below, **name** is a nonblank string ≤255 characters, **text** is a nonblank string, **status** is `active`, `inactive` or `deprecated`. All dataset fields are required, including nullable fields.

## Dimensional Submodel fields

| Field | Accepted value / meaning |
|---|---|
| `dimensional_submodel_name` | Name; business grouping identity. |
| `dimensional_submodel_definition` | Text defining the business grouping. |
| `dimensional_submodel_status` | Status. |
| `dimensional_submodel_is_locked` | Boolean; shared record-state rules apply. |

## Dimensional Entity fields

| Field | Accepted value / meaning |
|---|---|
| `dimensional_entity_schema_name` | Required configured Dimensional schema name; part of Entity identity. |
| `dimensional_entity_name` | Name; Entity identity. |
| `dimensional_entity_definition` | Text defining the business meaning. |
| `dimensional_entity_type` | `fact`, `dimension` or `bridge`. |
| `dimensional_fact_type` | Facts: `transaction`, `periodic_snapshot`, `accumulating_snapshot` or `factless`. Other Entity types: null. |
| `dimensional_entity_grain_definition` | Text defining one row; required non-null for facts/bridges. Dimensions permit null in the schema; provide explicit grain for a complete design. |
| `dimensional_entity_dependency_order` | Integer ≥0; modeled dependency order, not Process Group scheduling. |
| `dimensional_entity_status` | Status. |
| `dimensional_entity_is_locked` | Boolean. |
| `submodels` | Array of membership records below; `[]` is valid. |
| `sources` | Array of Entity/Logical Entity or Entity/Context sources below; `[]` is valid. |

## Dimensional Attribute fields

| Field | Accepted value / meaning |
|---|---|
| `dimensional_entity_schema_name` | Required configured Dimensional schema name; part of Entity identity. |
| `dimensional_entity_name` | Name of the parent Dimensional Entity. |
| `dimensional_attribute_name` | Name; Attribute identity within its Entity. |
| `dimensional_attribute_definition` | Text defining meaning, units and relevant behavior. |
| `dimensional_attribute_data_type` | Nonblank string ≤100 characters; approved modeled type, not a fixed schema enum. |
| `dimensional_attribute_is_nullable` | Boolean; whether null is allowed. |
| `dimensional_attribute_is_natural_key` | Boolean; participates in the complete business-key tuple. |
| `dimensional_attribute_is_surrogate_key` | Boolean; generated own-row identifier. |
| `dimensional_attribute_ordinal_position` | Integer >0; column position. |
| `dimensional_attribute_is_audit_column` | Boolean; identifies approved audit columns. |
| `dimensional_attribute_status` | Status. |
| `dimensional_attribute_is_locked` | Boolean. |
| `sources` | Array of Logical Attribute or Context sources below; `[]` is valid. |

Natural and surrogate flags are mutually exclusive; either requires non-nullability. Multiple natural-key Attributes describe a complete business-key tuple. A generated surrogate does not by itself establish business grain. Foreign-key participation comes from effective relationships; technical and audit fields follow the configured Project templates. Explain measure meaning, units, aggregation rules, grain participation and allocation semantics in the Attribute definition. History follows the Project's `dimensional_entity_scd_type`; no per-Attribute history choice exists.

## Dimensional Relationship fields

| Field | Accepted value / meaning |
|---|---|
| `dimensional_relationship_name` | Name; readable association label, outside the natural key. |
| `dimensional_relationship_definition` | Text describing the association. |
| `from_dimensional_entity_schema_name` | Required configured Dimensional schema name; part of Entity identity. |
| `from_dimensional_entity_name` | Name of the from Entity. |
| `from_dimensional_attribute_name` | Name of its from Attribute. |
| `to_dimensional_entity_schema_name` | Required configured Dimensional schema name; part of Entity identity. |
| `to_dimensional_entity_name` | Name of the to Entity. |
| `to_dimensional_attribute_name` | Name of its to Attribute. |
| `dimensional_relationship_kind` | Nonblank string ≤50 characters; reuse the Project's established relationship vocabulary, not an invented enum. |
| `dimensional_relationship_cardinality` | `one_to_one`, `one_to_many`, `many_to_one` or `many_to_many`, interpreted from → to. |
| `dimensional_relationship_is_optional` | Boolean; explicit association optionality, distinct from cardinality. |
| `dimensional_relationship_role_name` | Name or null; distinguishes meaningful roles such as OrderDate versus ShipDate. |
| `dimensional_relationship_basis` | Text explaining meaning and evidence. |
| `dimensional_relationship_cardinality_basis` | Text explaining multiplicity and any conditions needed to preserve it. |
| `dimensional_relationship_status` | Status. |
| `dimensional_relationship_is_locked` | Boolean. |

No `unknown` cardinality, composite endpoint array or nested sources field exists. Same-Entity relationships are allowed when Attributes differ; identical normalized Entity/Attribute endpoints are rejected. Explain complete composite joins and history predicates in the basis; a one-column edge alone cannot encode them. SQL is not required for supported inference.

## Nested memberships and sources

Membership has exactly three required fields. An Entity may belong to multiple Submodels; each normalized Submodel name appears once.

| Field | Accepted value / meaning |
|---|---|
| `submodel_name` | Name of a real effective Dimensional Submodel. |
| `membership_status` | Status. |
| `membership_is_locked` | Boolean; independent nested lock. |

Each source variant contains its one matching source field plus all applicable common fields. Only `source_order` may be omitted, defaulting to null; include it explicitly in complete authored records. Both Entity and Attribute sources have six fields.

| Field | Accepted value / meaning |
|---|---|
| `support_source_type` | Entity: `logical_entity` or `context_record`. Attribute: `logical_attribute` or `context_record`. |
| `source_logical_entity` | Only Logical Entity variant: schema-qualified Logical Entity key below. |
| `source_logical_attribute` | Only Logical Attribute variant: schema-qualified Logical Attribute key below. |
| `context_record` | Only Context variant: object containing `context_record_id`. |
| `source_order` | Positive integer or null; source ordering, not a unique identifier. |
| `rationale` | Text explaining the contribution. |
| `status` | Status. |
| `is_locked` | Boolean; independent nested source lock. |

Logical Entity key: `logical_entity_schema_name` (nonblank string ≤400) and `logical_entity_name` (name). Logical Attribute key adds `logical_attribute_name` (name). Context identity is a stable lowercase UUID; see [Context records](context.md).

Sources refer directly to the current Project's applied Logical design. Target registration and Logical Mapping are separate downstream readiness concerns.

Within one parent, each source type + normalized Logical/Context key is unique **regardless order**. Describe each source's complete contribution once in its rationale. Source arrays record provenance, not transformation SQL or join aliases.

## Scope and current enforcement

- New/changed Logical sources must belong to the current Project and resolve by schema/name. Active support requires active Logical Entities and Attributes.
- An Attribute's Logical source requires matching Logical Entity support on its parent Dimensional Entity.
- Context records must exist and be relevant to the dimensional design. Follow shared evidence/state rules; an Attribute's Context does not require a duplicate Context source on its Entity.
- Empty sources/memberships are valid. Generated calendars, constants and other justified standalone structures need no fake source or compulsory Context. Explain their generation/business meaning; attach a real applicable Context only when useful.
- Attributes require real parents; active Attributes require active Entities. Active relationships require active endpoint Attributes and Entities. Membership references must resolve; existing reference checks alone do not require an active Submodel for an active membership.
- Preserve locked records and nested members. Apply retains omitted nested sources/memberships; preserve complete arrays so the local effective graph represents what will remain.
- The workflow starts from applied Logical Entities and Attributes. Subject Areas are neither an input nor a prerequisite. Physical registration and Logical Mapping are not prerequisites for Dimensional design.

## Additional Atlas checks and unresolved capabilities

These are design/local-validation requirements; current record-schema validation alone does not prove them.

| Check | Why it matters |
|---|---|
| One own generated BIGINT surrogate first; approved key naming, nullability and audit policy | Key flags alone do not enforce the complete layout. |
| Unique active ordinals and complete target columns | Positive ordinals alone permit duplicate positions and missing columns. |
| Complete business key, row grain and compatible key types | Flags/edge existence cannot prove identity or correct joins. |
| Measure meaning, additivity and aggregation at the stated grain | Definitions must explain valid totals and prevent double-counting. |
| Active memberships and applicable sources resolve to usable records | Reference existence is weaker than active evidence. |
| Relationships preserve grain, including complete composite/history predicates | Each record has only one Attribute per endpoint. |
| History behavior has an executable consumer contract before Mapping/code | A Project Type 2 setting does not prove that the framework implements loading. |

Entity/Attribute records have no dedicated SCD type, effective-date, current-row, unknown-member, late-arrival, allocation or bridge-policy fields. The Project supplies `dimensional_entity_scd_type` for dimensions; facts and bridges do not inherit dimension history. Use approved modeled technical Attributes/templates plus concise definitions/bases; do not invent payload fields or assume generic `IsActive` implements history. The user confirms Type 1/Type 2 support and framework population of the configured Type 2 fields using natural keys; [history rules](../dimensional-build/history.md) own this population contract.

## Complete synthetic records

These examples illustrate record shapes, not a complete new table build. Assume complete existing Customer/SalesLine graphs, configured keys/audits and active Logical contributions where referenced. New tables must include all columns from [keys and audit columns](keys-and-audit.md).

`project-change-set/dimensional_submodel.json`:

```json
[{"dimensional_submodel_name":"Sales","dimensional_submodel_definition":"Completed sales and their purchasing context.","dimensional_submodel_status":"active","dimensional_submodel_is_locked":false}]
```

`project-change-set/dimensional_entity.json`:

```json
[
  {
    "dimensional_entity_schema_name": "gold", "dimensional_entity_name": "SalesLine",
    "dimensional_entity_definition": "A completed sale line available for product and customer analysis.",
    "dimensional_entity_type": "fact",
    "dimensional_fact_type": "transaction",
    "dimensional_entity_grain_definition": "One completed order line within its originating System.",
    "dimensional_entity_dependency_order": 1,
    "dimensional_entity_status": "active",
    "dimensional_entity_is_locked": false,
    "submodels": [{"submodel_name":"Sales","membership_status":"active","membership_is_locked":false}],
    "sources": [{"support_source_type":"logical_entity","source_logical_entity":{"logical_entity_schema_name":"silver","logical_entity_name":"OrderLine"},"source_order":1,"rationale":"Synthetic completed order lines supply the fact grain and line measures.","status":"active","is_locked":false}]
  }
]
```

`project-change-set/dimensional_attribute.json`; assumes its Logical Entity source above and existing preceding Attributes:

```json
[
  {
    "dimensional_entity_schema_name": "gold", "dimensional_entity_name": "SalesLine",
    "dimensional_attribute_name": "Quantity",
    "dimensional_attribute_definition": "Number of units sold on this completed order line, in the governed common unit. SUM is valid across associated dimensions because sale lines are disjoint.",
    "dimensional_attribute_data_type": "DECIMAL(18,4)",
    "dimensional_attribute_is_nullable": false,
    "dimensional_attribute_is_natural_key": false,
    "dimensional_attribute_is_surrogate_key": false,
    "dimensional_attribute_ordinal_position": 5,
    "dimensional_attribute_is_audit_column": false,
    "dimensional_attribute_status": "active",
    "dimensional_attribute_is_locked": false,
    "sources": [{"support_source_type":"logical_attribute","source_logical_attribute":{"logical_entity_schema_name":"silver","logical_entity_name":"OrderLine","logical_attribute_name":"Quantity"},"source_order":1,"rationale":"Preserves the governed line quantity.","status":"active","is_locked":false}]
  }
]
```

`project-change-set/dimensional_relationship.json`; assumes active `SalesLine.CustomerKey` and `Customer.CustomerKey`, with the latter unique and no version ambiguity in this synthetic design:

```json
[
  {
    "dimensional_relationship_name": "PurchasedByCustomer",
    "dimensional_relationship_definition": "A completed SalesLine belongs to its purchasing Customer.",
    "from_dimensional_entity_schema_name": "gold", "from_dimensional_entity_name": "SalesLine",
    "from_dimensional_attribute_name": "CustomerKey",
    "to_dimensional_entity_schema_name": "gold", "to_dimensional_entity_name": "Customer",
    "to_dimensional_attribute_name": "CustomerKey",
    "dimensional_relationship_kind": "FactToDimension",
    "dimensional_relationship_cardinality": "many_to_one",
    "dimensional_relationship_is_optional": false,
    "dimensional_relationship_role_name": "Purchaser",
    "dimensional_relationship_basis": "Synthetic policy requires every completed line to resolve its purchasing Customer surrogate.",
    "dimensional_relationship_cardinality_basis": "Many completed lines can reference one unique Customer row; inferred from the declared business roles, without SQL execution.",
    "dimensional_relationship_status": "active",
    "dimensional_relationship_is_locked": false
  }
]
```

`FactToDimension`, `Purchaser` and `SalesEvents` are illustrative vocabulary, not enforced enums or defaults.
