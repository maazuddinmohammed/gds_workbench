# SQL transformation generation

Shared by Code Generation and its later review/Validation. The [Code Generation skill](../../skills/atlas-code-generation/SKILL.md) owns intake and sequence; [Code records](../project/generated-code.md) owns payloads/assignments; [Mapping documents](../project/mapping-documents.md) owns transformation intent and the complete consumer context. This guide owns SQL file structure and translation checks.

## Translate Mapping without redesigning it

1. Read all five components/pages of one target Mapping view, including all assigned Systems, actual input/lookup metadata and ordered target columns. Each selected Entity/System needs at least one saved transformation. Partial Mapping stays `complete=false`: preserve its issues and review findings. No extra modeling traversal should be required; do not invent missing source identities, joins or business rules.
2. Translate substantial Object steps into successive `CREATE OR REPLACE TEMPORARY VIEW` statements. Each stage implements preparation, joins/filters or projection and consumes earlier results where needed. A simple direct branch needs only one view and a final SELECT; do not create a view per sentence or repeat the full pipeline in every stage.
3. Use unique unqualified temporary names including target/System context as needed. Declare every temporary dependency before use in the same artifact. Carry all needed later join/expression columns forward; drop unnecessary intermediates from the final result.
4. Apply Attribute Mapping expressions at their specified stage. Use resolved SQL source names and exact physical target aliases; modeled names may differ. Preserve identifiers, decimal capacity, timezone, nullability and invalid-value behavior. An absent Attribute transformation becomes `CAST(NULL AS <target type>) AS <target column>` and an explicit per-System review finding. It is a placeholder, not a new business rule. If no evidenced row-producing source/join exists, emit a typed zero-row projection; never fabricate a row or join. Proven database/framework omissions still apply. Do not add DISTINCT, TRY_CAST, rounding, COALESCE, deduplication or defaults unless Mapping requires them.
5. Finish with one explicit target-column SELECT. Use the exact mapped column order through `SourceSystemID`; omit the own generated surrogate, nine framework audit fields and applicable framework-populated Type 2 fields per the [population contract](../project/keys-and-audit.md#population-boundary-and-implementation-alignment). Supply mapped natural-key values, foreign keys and optional Source audit fields. Do not generate history-maintenance SQL. No final `SELECT *`.

Framework SQL uses resolved `schema.table` references, with the catalog supplied by runtime. Quote physical identifiers correctly using Databricks syntax; temporary views remain unqualified. Preserve cross-placement requirements and reject unsupported access rather than silently redirecting a source. Governed evidence queries use their separate registered coordinates.

The transformation returns rows. It contains no persistent CREATE/ALTER, INSERT/MERGE/UPDATE/DELETE, loading operation or deployment command. Metadata registration supplies DDL separately; the framework owns target writes.

SQL artifacts contain code only, without Markdown, prose or explanatory comments. Keep rationale and validation findings in the review/task. Teaching explanations below are not content to copy into output files.

## Combined or separate Systems

| Chosen layout | Generation rule |
|---|---|
| One file per target | Build isolated System branches in the file. Align physical aliases, types and order. Combine only according to Mapping's disjoint-key or explicit reconciliation policy; final result is for one target. |
| Separate System/target files | Each file includes its own preparation and final projection. Assign each mapped System exactly once. No cross-file temporary state; the mapped collision/dependency policy must still work with separate executions. |

Distinct source files do not make overlapping identities safe. A rule needing joint System comparison cannot be replaced by separate unrelated SELECTs. Do not duplicate the same System into two active artifacts or create an extra active reconciliation/helper artifact without a supported assignment/consumer contract. Code record assignments, not filenames, identify contributing Systems.

Mapping carries Object dependency order; no order property belongs on a Code record or its source-System entry. Preserve target lookup prerequisites, explicit business precedence and SQL stage order when assessing artifact grouping and later Process handoff. Process Groups and Processes own scheduling. An earlier target's persisted lookup is different from a temporary result in another artifact.

## Runtime parameters and optional preflight

For a batched Bronze driver use its registered column with the quoted token `'wid_gdsbatchid'`. Orchestration replaces it with the requested ID. Keep that batch on replays even when later batches contain the same keys. Translate the join plan and any object-level transformation steps in the applied Mapping into SQL. Match registered batch columns in joined Bronze inputs alongside their business keys. Omit batch predicates on inputs without a registered column. Silver/Gold lookups use their modeled keys and version rules. Resolve each required System ID with a LEFT JOIN to `meta.system` on `SystemCode` alone, including any explicitly different parent System. Use schema.table names in the runtime-selected catalog.

Static review is the default. If a permitted execution probe is useful, follow [query scope](../query-scope.md): authorized Connection/environment, actual evidence coordinates, masking, approved row/batch scope, bounds and exact evidence recording. Keep concrete test substitutions and diagnostic queries separate from the production artifact; describe any scope difference. SQL Never permits generation and static review, not execution.

Each `execute_databricks_sql` call has independent temporary state and bounded statements/text/results. Do not split a view chain across calls or append independent final queries expecting multiple result sets. Use a self-contained bounded probe, or report that the artifact cannot be preflighted under the current tool limits. Do not weaken Mapping or truncate production SQL to fit. Prefer aggregates for evidence; never persist raw rows or claim that a successful/empty sample proves correctness.

## Staged example

Fictional Mapping: posted Order Lines, grain `(OrderID, LineNumber)`. Posted headers are unique by source System/order code; the Silver Order lookup has exactly one match on `(SourceSystemID, OrderCode)`. LineNumber is a significant STRING identifier. Quantity is a valid whole number; price and resulting amount fit DECIMAL(18,2). SourceSystemID values are valid, non-null BIGINT. No batch filtering or deduplication applies; the generated OrderLineID and framework fields are omitted.

```sql
CREATE OR REPLACE TEMPORARY VIEW temp_order_line_erp_posted AS
SELECT h.order_code
FROM `bronze`.`order_headers` AS h
WHERE h.status = 'posted';

CREATE OR REPLACE TEMPORARY VIEW temp_order_line_erp_joined AS
SELECT o.OrderID, l.line_number, l.quantity, l.unit_price,
       sys.SystemID AS SourceSystemID
FROM `bronze`.`order_lines` AS l
INNER JOIN temp_order_line_erp_posted AS h
  ON l.order_code = h.order_code
LEFT JOIN meta.system AS sys ON sys.SystemCode = 'ERP'
INNER JOIN `silver`.`Order` AS o
  ON o.OrderCode = h.order_code
 AND o.SourceSystemID = sys.SystemID;

CREATE OR REPLACE TEMPORARY VIEW temp_order_line_erp_projected AS
SELECT j.OrderID,
       j.line_number AS LineNumber,
       CAST(CAST(j.quantity AS BIGINT) * CAST(j.unit_price AS DECIMAL(18,2)) AS DECIMAL(18,2)) AS Amount,
       j.SourceSystemID
FROM temp_order_line_erp_joined AS j;

SELECT OrderID, LineNumber, Amount, SourceSystemID
FROM temp_order_line_erp_projected;
```

This demonstrates read/preparation → joins → field projection → final output. The actual Mapping determines predicates, joins and type rules; none of these business choices is a default for other targets.

## Local content checks

| Rule | Check / reason |
|---|---|
| `code.mapping-input` | Read every component/page at one applied revision/digest; retain partial-Mapping issues, explicit typed NULL placeholders and missing Object findings. No invented transformation assumptions or lookup metadata. Validation still requires complete Mapping. |
| `code.statements` | Parse as Databricks SQL; only the agreed temporary-view preparation and final query. No persistent writes/DDL, prose or repeated complete pipelines. |
| `code.stage-flow` | Temporary names are unique/unqualified, declared before use and self-contained; later stages receive needed columns. |
| `code.translation` | Every Mapping step and Attribute rule is implemented at the right stage, preserving join/filter semantics, grain, keys and value behavior. |
| `code.projection` | Final names/types/order match Mapping; SourceSystemID last, own surrogate/framework columns omitted, mapped FKs retained. |
| `code.systems` | Chosen grouping implements mapped cross-System policy; each mapped System has exactly one active artifact assignment. |
| `code.parameters` | Only confirmed runtime placeholders; production content contains no profiling/test batch substitutions. |
| `code.content-sync` | Local file text equals the generated_code_content being reviewed/staged; protected and unaffected content is preserved. |

Current generic record validation checks field shape, references, locks and assignment coverage; it does not establish SQL semantics. Existing backend SQL parsing accepts a broader statement set than this transformation contract, including writes. A parser pass therefore cannot replace the explicit statement/content checks above. Atlas's shared `validation/sql.js` additionally checks transformation statement classes, temporary stages, explicit final projection and runtime coordinate shape. It is not a complete SQL parser or proof of transformation fidelity.

Review with Mapping as the source of expected behavior. Formal Validation definitions belong to the later Validation workflow; local checking here does not create them automatically.

## Confirmed behavior

Preserve confirmed Atlas runtime coordinates over incompatible catalog-qualified seed examples. Python record storage is distinct from actual authoring, download and runtime support; no Python execution contract is invented in this guide.
