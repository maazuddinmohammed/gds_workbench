# Ingestion attribute mapping — `core.ingestion_attribute_mapping`

Optional reference correspondence from a Source Attribute to a Bronze Attribute beneath an Ingestion Object Mapping. Usually empty; the current orchestration framework does not use these records to select or transform columns.

**Datasets:** `ingestion_attribute_mapping`.
**Change Set:** editable.

## Keys

- Natural key: `source_tenant_code`, `source_system_code`, `source_connection_code`, `source_object_schema`, `source_object_name`, `source_attribute_name`, `target_tenant_code`, `target_system_code`, `target_connection_code`, `target_object_schema`, `target_object_name`, `target_attribute_name`.
- No additional unique tuple is published in the Snapshot registry.
- Use the published key normalization. Database IDs are not authoring fields.

## Fields

Run `describe --dataset ingestion_attribute_mapping` for every field's type, limits, required and null rules, description and population guidance. This table lists only fields with rules that `describe` does not state.

| Field | Meaning and use |
|---|---|
| `source_tenant_code` | Tenant code of the source physical endpoint; resolve the complete referenced key. This is placement, not the referenced Object's owner field. Reference: [ingestion object mapping](ingestion-object-mapping.md), [attribute](attribute.md). |
| `source_system_code` | System code of the source physical endpoint; resolve the complete referenced key. Reference: [ingestion object mapping](ingestion-object-mapping.md), [attribute](attribute.md). |
| `source_connection_code` | Connection code of the source physical endpoint; resolve the complete referenced key. Reference: [ingestion object mapping](ingestion-object-mapping.md), [attribute](attribute.md). |
| `source_object_schema` | Object schema of the source physical endpoint; resolve the complete referenced key. Reference: [ingestion object mapping](ingestion-object-mapping.md), [attribute](attribute.md). |
| `source_object_name` | Object name of the source physical endpoint; resolve the complete referenced key. Reference: [ingestion object mapping](ingestion-object-mapping.md), [attribute](attribute.md). |
| `source_attribute_name` | Actual registered source Attribute name. An extraction alias in custom code does not rename this identity. Reference: [attribute](attribute.md). |
| `target_tenant_code` | Tenant code of the target physical endpoint; resolve the complete referenced key. This is placement, not the referenced Object's owner field. Reference: [ingestion object mapping](ingestion-object-mapping.md), [attribute](attribute.md). |
| `target_system_code` | System code of the target physical endpoint; resolve the complete referenced key. Reference: [ingestion object mapping](ingestion-object-mapping.md), [attribute](attribute.md). |
| `target_connection_code` | Connection code of the target physical endpoint; resolve the complete referenced key. Reference: [ingestion object mapping](ingestion-object-mapping.md), [attribute](attribute.md). |
| `target_object_schema` | Object schema of the target physical endpoint; resolve the complete referenced key. Reference: [ingestion object mapping](ingestion-object-mapping.md), [attribute](attribute.md). |
| `target_object_name` | Object name of the target physical endpoint; resolve the complete referenced key. Reference: [ingestion object mapping](ingestion-object-mapping.md), [attribute](attribute.md). |
| `target_attribute_name` | Exact registered Bronze Attribute name; account for the field name actually emitted by extraction or supplied files. Reference: [attribute](attribute.md). |
| `is_active` | Default true for new records unless requested otherwise; preserve existing values on unrelated edits. Active status of this optional reference record does not control column ingestion. Attribute is_mapped remains unused; no synchronization is required. |

## References and dependencies

- `source_tenant_code`, `source_system_code`, `source_connection_code`, `source_object_schema`, `source_object_name`, `target_tenant_code`, `target_system_code`, `target_connection_code`, `target_object_schema`, `target_object_name` → [ingestion object mapping](ingestion-object-mapping.md): `source_tenant_code`, `source_system_code`, `source_connection_code`, `source_object_schema`, `source_object_name`, `target_tenant_code`, `target_system_code`, `target_connection_code`, `target_object_schema`, `target_object_name`. Required reference.
- `source_tenant_code`, `source_system_code`, `source_connection_code`, `source_object_schema`, `source_object_name`, `source_attribute_name` → [attribute](attribute.md): `tenant_code`, `system_code`, `connection_code`, `object_schema`, `object_name`, `attribute_name`. Required reference.
- `target_tenant_code`, `target_system_code`, `target_connection_code`, `target_object_schema`, `target_object_name`, `target_attribute_name` → [attribute](attribute.md): `tenant_code`, `system_code`, `connection_code`, `object_schema`, `object_name`, `attribute_name`. Required reference.
- Referenced by: no direct published metadata reference.

## Making changes

- Leave this dataset empty by default. Add records only for an explicit reference/documentation need; absence does not block ingestion or imply incomplete authoring.
- For supplied records, resolve the parent Object pair plus the two exact Attribute identities; each Attribute must belong to its stated endpoint Object.
- Source extraction and Bronze metadata/custom code drive the actual values and selected columns. Do not enforce complete column coverage, one-to-one correspondence, or a Source mapping for a Bronze constant.
- Read Source and Bronze [custom SELECT expressions](attribute.md#custom-select-expressions) when interpreting extraction aliases and conversion; do not invent a mapping transformation field.
- Changing an existing mapping endpoint requires the user's [manual database correction](../editing.md#manual-natural-key-changes); the agent supplies instructions only.
- Do not update or reconcile Attribute is_mapped when authoring mappings; it is currently unused downstream. See [Attribute](attribute.md) for new-record defaults.
- Follow [shared editing rules](../editing.md); validate the complete effective result and preserve unrelated fields.

## Validation checklist

Enforcement is explained in [common checks](../validation.md#interpreting-table-checklists); run the local validator, then review anything marked for you.

Apply these checks only to records that are present. No minimum record count or ingestion-coverage check is required.

| Rule | Check / why | Enforced by |
|---|---|
| `ingestion_attribute_mapping.shape` | Complete source/target Object and Attribute keys; required is_active boolean. Reject malformed complete records before staging. | Local validator + server |
| `ingestion_attribute_mapping.unique` | Parent Object Mapping + source Attribute + target Attribute unique. Prevent duplicate identity; inactive rows still reserve their keys. | Local validator + server |
| `ingestion_attribute_mapping.references` | Parent Object Mapping exists; each Attribute belongs to its stated endpoint Object. Resolve dependencies using snapshot plus pending rows. | Local validator + server |
| `ingestion_attribute_mapping.distinct` | Source and target Attribute must differ after key normalization. Prevent a self-Attribute mapping. | Local validator + server |
| `ingestion_attribute_mapping.scope` | Both endpoint Objects belong to selected Tenant; Connections owned or configured GDS. Keep edits in the authorized Tenant. | Local validator + server |
| `ingestion_attribute_mapping.live-dependencies` | Re-resolve dependencies at Apply; reject unexpected affected-row count. Snapshot checks cannot guarantee current server state. | Server only, at Apply |

## Confirmed behavior

These optional records are not required by ingestion or downstream workflows. Profiling still propagates masking from active mappings; an empty mapping dataset does not prove a column is unmasked. Preserve existing masking safeguards.

[All metadata tables](../index.md) · [Common validation](../validation.md)
