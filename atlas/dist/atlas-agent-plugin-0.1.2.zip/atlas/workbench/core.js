(function (root, factory) {
  "use strict";
  let unicode = root.GDSUnicode;
  if (typeof module === "object" && module.exports) unicode = require("./unicode.js");
  const api = factory(unicode);
  if (typeof module === "object" && module.exports) module.exports = api;
  root.GDSCore = api;
})(typeof globalThis === "object" ? globalThis : this, function (unicode) {
  "use strict";

  function stableStringify(value) {
    // Match Python json.dumps after the MCP request's JSON decoding.
    if (typeof value === "number" && value !== 0 && Math.abs(value) < 0.0001) {
      return value.toExponential().replace(/e-(\d)$/, "e-0$1");
    }
    if (value === null || typeof value !== "object") return JSON.stringify(value);
    if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
    return `{${Object.keys(value)
      .sort((left, right) => {
        const a = [...left], b = [...right];
        for (let index = 0; index < Math.min(a.length, b.length); index += 1) {
          const difference = a[index].codePointAt(0) - b[index].codePointAt(0);
          if (difference) return difference;
        }
        return a.length - b.length;
      })
      .map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`)
      .join(",")}}`;
  }

  function normalize(area, field, value) {
    if (typeof value !== "string") return value;
    const trimmed = value.replace(/^ +| +$/g, "");
    if (area === "model") {
      return unicode?.casefold ? unicode.casefold(trimmed) : trimmed.toLowerCase();
    }
    if (/(_code|_name|_schema)$/.test(field)) {
      return unicode?.lower ? unicode.lower(trimmed) : trimmed.toLowerCase();
    }
    return value;
  }

  function key(area, definition, record) {
    if (!Array.isArray(definition.canonical_key)) {
      throw new Error(`${definition.name} canonical key is invalid.`);
    }
    return definition.canonical_key.map((field) => {
      if (!Object.prototype.hasOwnProperty.call(record, field)) {
        throw new Error(`${definition.name}.${field} is required.`);
      }
      return normalize(area, field, record[field]);
    });
  }

  function isEntityOwnedModelCatalog(catalog) {
    if (!Array.isArray(catalog?.sections)) return false;
    for (const section of catalog.sections) {
      if (section?.name === "model_binding" || !Array.isArray(section?.datasets)) return false;
      for (const dataset of section.datasets) {
        if (["model_object_binding", "model_attribute_binding", "mapping_dependency"].includes(dataset?.name)) return false;
        let required = [];
        if (["mapping_object", "mapping_attribute", "generated_code", "generated_code_source_system"].includes(dataset?.name)) required = ["modeled_entity_schema_name"];
        for (const layer of ["logical", "dimensional"]) {
          if ([`${layer}_entity`, `${layer}_attribute`].includes(dataset?.name)) required = [`${layer}_entity_schema_name`];
          if (dataset?.name === `${layer}_relationship`) required = [`from_${layer}_entity_schema_name`, `to_${layer}_entity_schema_name`];
        }
        if (required.some(field => !Array.isArray(dataset.canonical_key) || !dataset.canonical_key.includes(field))) return false;
      }
    }
    return true;
  }

  function overlay(area, definition, baseline, pending) {
    const records = new Map(
      baseline.map((record) => [stableStringify(key(area, definition, record)), record]),
    );
    for (const record of pending) {
      records.set(stableStringify(key(area, definition, record)), record);
    }
    return [...records.values()].sort((left, right) => {
      const leftKey = stableStringify(key(area, definition, left));
      const rightKey = stableStringify(key(area, definition, right));
      return leftKey < rightKey ? -1 : leftKey > rightKey ? 1 : 0;
    });
  }

  function active(record) {
    if (typeof record.is_active === "boolean") return record.is_active;
    if (typeof record.status === "string") return record.status === "active";
    const statusField = Object.keys(record).find((field) => field.endsWith("_status"));
    if (statusField && typeof record[statusField] === "string") {
      return record[statusField] === "active";
    }
    return null;
  }

  function reviewActions(area, definition, baseline, pending) {
    const originals = new Map(
      baseline.map((record) => [stableStringify(key(area, definition, record)), record]),
    );
    return pending.map((record) => {
      const naturalKey = key(area, definition, record);
      const original = originals.get(stableStringify(naturalKey));
      let action = "added";
      if (original) {
        if (stableStringify(original) === stableStringify(record)) action = "unchanged";
        else if (active(original) === true && active(record) === false) action = "deactivated";
        else if (active(original) === false && active(record) === true) action = "reactivated";
        else action = "changed";
      }
      return {
        action,
        key: Object.fromEntries(
          definition.canonical_key.map((field, index) => [field, naturalKey[index]]),
        ),
        record,
      };
    });
  }

  return { active, isEntityOwnedModelCatalog, key, normalize, overlay, reviewActions, stableStringify };
});
