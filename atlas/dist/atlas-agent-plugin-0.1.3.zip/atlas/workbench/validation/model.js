(function (root, factory) {
  "use strict";
  let core = root.GDSCore;
  if (typeof module === "object" && module.exports) core = require("../core.js");
  const sql = typeof module === "object" && module.exports ? require("./sql.js") : root.AtlasSql;
  const api = factory(core, sql);
  if (typeof module === "object" && module.exports) module.exports = api;
  root.GDSModelValidation = api;
})(typeof globalThis === "object" ? globalThis : this, function (core, sql) {
  "use strict";

  const { validateReadSql } = sql;

  const OBJECT_FIELDS = [
    "tenant_code", "system_code", "connection_code", "object_schema", "object_name",
  ];
  const ATTRIBUTE_FIELDS = [...OBJECT_FIELDS, "attribute_name"];

  function normalized(value) { return core.normalize("model", "value", value); }
  function tuple(values) { return core.stableStringify(values.map(value => normalized(value ?? null))); }
  function physicalKey(record, attribute = false) {
    return tuple((attribute ? ATTRIBUTE_FIELDS : OBJECT_FIELDS).map((field) => record?.[field]));
  }
  function prefixedPhysicalKey(record, prefix, attribute = false) {
    return tuple((attribute ? ATTRIBUTE_FIELDS : OBJECT_FIELDS)
      .map((field) => record?.[`${prefix}_${field}`]));
  }
  function entityKey(record) {
    let type = record?.modeled_entity_type;
    if (!type) type = Object.hasOwn(record || {}, "logical_entity_name")
      ? "logical_entity" : "dimensional_entity";
    const name = record?.modeled_entity_name ?? record?.[
      type === "logical_entity" ? "logical_entity_name" : "dimensional_entity_name"
    ];
    const schema = record?.modeled_entity_schema_name ?? record?.[`${type}_schema_name`];
    return tuple([type, schema, name]);
  }
  function attributeKey(record) {
    let type = record?.modeled_entity_type;
    if (!type) type = Object.hasOwn(record || {}, "logical_attribute_name")
      ? "logical_entity" : "dimensional_entity";
    const entity = record?.modeled_entity_name ?? record?.[
      type === "logical_entity" ? "logical_entity_name" : "dimensional_entity_name"
    ];
    const attribute = record?.modeled_attribute_name ?? record?.[
      type === "logical_entity" ? "logical_attribute_name" : "dimensional_attribute_name"
    ];
    const schema = record?.modeled_entity_schema_name ?? record?.[`${type}_schema_name`];
    return tuple([type, schema, entity, attribute]);
  }
  function mappingObjectKey(record) {
    return tuple([record.modeled_entity_type, record.modeled_entity_schema_name, record.modeled_entity_name, record.source_system_code]);
  }
  function artifactKey(record) {
    return tuple([record.modeled_entity_type, record.modeled_entity_schema_name, record.modeled_entity_name, record.artifact_name]);
  }
  function validationGroupKey(record) {
    return tuple([record.tenant_code, record.system_code, record.validation_group_name]);
  }
  function recordType(value) {
    return value.schema?.["x-gds-record-type"] || value.definition?.record_type || value.definition?.name;
  }
  function records(datasets, name, source = "records") {
    return datasets?.get(name)?.[source] || [];
  }
  function active(record, field = null) {
    return field ? record?.[field] === "active" : core.active(record) !== false;
  }
  function hasTransformationContent(value) {
    if (value && typeof value === "object") return Object.values(value).some(hasTransformationContent);
    if (typeof value === "string") return /[^\u0009-\u000d\u001c-\u0020\u0085\u00a0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000]/u.test(value);
    return value != null;
  }
  function issue(issues, code, dataset, field, message, record = null) {
    issues.push({ code, dataset, record, field, message });
  }

  function candidateGroups(model, metadata) {
    const groups = new Map();
    function add(area, datasets) {
      if (!(datasets instanceof Map)) return;
      for (const value of datasets.values()) {
        const type = recordType(value);
        if (typeof type !== "string" || !type) continue;
        if (!groups.has(type)) groups.set(type, []);
        groups.get(type).push({
          area,
          records: value.records || value.effective || value.baseline || [],
        });
      }
    }
    add("model", model);
    add("metadata", metadata);
    return groups;
  }

  function validateReferences(model, metadata) {
    const targets = candidateGroups(model, metadata);
    const issues = [];
    for (const [datasetName, value] of model) {
      const references = value.schema?.["x-gds-references"];
      if (references === undefined) continue;
      if (!Array.isArray(references)) {
        issue(issues, "invalid_reference_contract", datasetName, null,
          "Reference metadata must be an array.");
        continue;
      }
      value.records.forEach((record, recordIndex) => {
        for (const reference of references) {
          const columns = reference?.columns;
          const targetColumns = reference?.target_columns;
          const candidates = targets.get(reference?.target_record_type) || [];
          if (!Array.isArray(columns) || !columns.length || !Array.isArray(targetColumns) ||
              columns.length !== targetColumns.length || !candidates.length) {
            issue(issues, "invalid_reference_contract", datasetName, null,
              `Invalid reference to ${reference?.target_record_type || "unknown"}.`, recordIndex + 1);
            continue;
          }
          const values = columns.map((field) => record[field]);
          const nullCount = values.filter((item) => item === null || item === undefined).length;
          if (nullCount === values.length && reference.nullable === true) continue;
          if (nullCount > 0) {
            issue(issues, "partial_null_reference", datasetName, columns[0],
              `Reference to ${reference.target_record_type} is incomplete.`, recordIndex + 1);
            continue;
          }
          const found = candidates.some((candidate) => {
            const wanted = core.stableStringify(values.map((item, index) =>
              core.normalize(candidate.area, targetColumns[index], item)));
            return candidate.records.some((target) =>
              core.stableStringify(targetColumns.map((field) =>
                core.normalize(candidate.area, field, target[field]))) === wanted);
          });
          if (!found) issue(issues, "broken_reference", datasetName, columns[0],
            `Referenced ${reference.target_record_type} was not found.`, recordIndex + 1);
        }
      });
    }
    return issues;
  }

  function nestedKey(record) {
    if (record?.submodel_name !== undefined) return tuple(["submodel", record.submodel_name]);
    if (record?.support_source_type === "assertion") {
      return tuple(["assertion", record.assertion_record?.modeling_assertion_record_key]);
    }
    if (record?.support_source_type === "logical_entity") return tuple(["logical_entity",
      record.source_logical_entity?.logical_entity_schema_name, record.source_logical_entity?.logical_entity_name]);
    if (record?.support_source_type === "logical_attribute") return tuple(["logical_attribute",
      record.source_logical_attribute?.logical_entity_schema_name, record.source_logical_attribute?.logical_entity_name,
      record.source_logical_attribute?.logical_attribute_name]);
    const source = record?.support_source_type === "attribute"
      ? record.source_attribute : record?.source_object;
    return tuple([record?.support_source_type, ...(record?.support_source_type === "attribute"
      ? ATTRIBUTE_FIELDS : OBJECT_FIELDS).map((field) => source?.[field])]);
  }
  function locked(record) {
    return Object.entries(record || {}).some(([field, value]) =>
      value === true && (field === "is_locked" || field.endsWith("_is_locked")));
  }
  function validateNestedLocks(model) {
    const issues = [];
    for (const [name, value] of model) {
      const baseline = new Map();
      for (const record of value.baseline || []) {
        baseline.set(core.stableStringify(core.key("model", value.definition, record)), record);
      }
      for (const changed of value.pending || []) {
        let existing;
        try {
          existing = baseline.get(core.stableStringify(core.key("model", value.definition, changed)));
        } catch (_error) { continue; }
        if (!existing) continue;
        for (const field of ["supports", "submodels", "sources"]) {
          const changedItems = new Map((changed[field] || []).map((item) => [nestedKey(item), item]));
          for (const item of existing[field] || []) {
            const replacement = changedItems.get(nestedKey(item));
            if (replacement && locked(item) &&
                core.stableStringify(item) !== core.stableStringify(replacement)) {
              issue(issues, "record_locked", name, field,
                `A locked applied nested ${field} record cannot be changed.`);
            }
          }
        }
      }
    }
    return issues;
  }

  function attributesFor(attributeKeys, objectSet) {
    return new Set([...attributeKeys].filter((key) =>
      objectSet.has(core.stableStringify(JSON.parse(key).slice(0, 5)))));
  }

  function retainsPhysicalReferences(previous, changed) {
    if (core.stableStringify(previous) === core.stableStringify(changed)) return true;
    if (!previous || !changed || typeof previous !== "object" || typeof changed !== "object" ||
        Array.isArray(previous) || Array.isArray(changed) ||
        !sameSet(new Set(Object.keys(previous)), new Set(Object.keys(changed)))) return false;
    return Object.keys(previous).every((field) => {
      const before = previous[field];
      const after = changed[field];
      if (core.stableStringify(before) === core.stableStringify(after)) return true;
      if ((field === "is_locked" || field.endsWith("_is_locked")) &&
          typeof before === "boolean" && typeof after === "boolean") return true;
      if (field === "is_active" && before === true && after === false) return true;
      if ((field === "status" || field.endsWith("_status")) &&
          before === "active" && after === "inactive") return true;
      return ["supports", "sources", "submodels"].includes(field) &&
        Array.isArray(before) && Array.isArray(after) && before.length === after.length &&
        before.every((item, index) => retainsPhysicalReferences(item, after[index]));
    });
  }

  function historicalRecords(model) {
    const retained = new Map();
    for (const [name, value] of model) {
      const baseline = new Map((value.baseline || []).map((record) => [
        core.stableStringify(core.key("model", value.definition, record)), record,
      ]));
      retained.set(name, new Set((value.records || []).filter((record) =>
        retainsPhysicalReferences(baseline.get(
          core.stableStringify(core.key("model", value.definition, record))), record))));
    }
    return retained;
  }

  function buildPhysicalCatalog(model, metadata, context) {
    if (!(metadata instanceof Map) || typeof context?.tenantCode !== "string") return null;
    const objects = [];
    const attributes = [];
    const systems = [];
    for (const value of metadata.values()) {
      const type = recordType(value);
      const source = value.records || value.effective || value.baseline || [];
      if (type === "object") objects.push(...source.filter((record) =>
        normalized(record.source_tenant_code) === normalized(context.tenantCode) ||
        ["source", "bronze"].includes(normalized(record.zone_code))));
      else if (type === "attribute") attributes.push(...source);
      else if (type === "system") systems.push(...source.filter((record) => record.is_active !== false));
    }
    const objectKeys = new Set(objects.map((record) => physicalKey(record)));
    const activeObjectKeys = new Set(objects.filter((record) => record.is_active !== false)
      .map((record) => physicalKey(record)));
    const attributeKeys = new Set(attributes
      .filter((record) => objectKeys.has(physicalKey(record)))
      .map((record) => physicalKey(record, true)));
    const activeAttributeKeys = new Set(attributes.filter((record) => record.is_active !== false &&
      activeObjectKeys.has(physicalKey(record))).map((record) => physicalKey(record, true)));
    const inputObjects = new Set(objects
      .filter((record) => record.is_active !== false &&
        ["source", "bronze"].includes(normalized(record.zone_code)))
      .map((record) => physicalKey(record)));


    return {
      tenant: normalized(context.tenantCode),
      otherModelNames: new Set((context.model?.other_active_model_names || []).map(normalized)),
      activeSystems: new Set(systems.map((record) => normalized(record.system_code))),
      objects: objectKeys,
      attributes: attributeKeys,
      inputObjects,
      inputAttributes: attributesFor(activeAttributeKeys, inputObjects),
    };
  }

  function scopeIssue(issues, dataset, field, message) {
    issue(issues, "model_input_reference_invalid", dataset, field, message);
  }
  function requireSystem(catalog, value, dataset, field, issues) {
    if (!catalog.activeSystems.has(normalized(value))) {
      scopeIssue(issues, dataset, field, "Referenced System is not active.");
    }
  }
  function sourcePhysical(source) {
    if (source?.support_source_type === "object") return [source.source_object, false];
    if (source?.support_source_type === "attribute") return [source.source_attribute, true];
    return null;
  }

  function sameSet(left, right) {
    return left.size === right.size && [...left].every((value) => right.has(value));
  }

  function validatePhysicalScope(model, catalog) {
    const issues = [];
    const historical = historicalRecords(model);
    const retained = (dataset, record) => historical.get(dataset)?.has(record) === true;
    const details = records(model, "model_details");
    if (details.length !== 1) issue(issues, "model_details_invalid", "model_details", null,
      "The future Model must contain exactly one Model details record.");
    else if (catalog.otherModelNames.has(normalized(details[0].model_name))) issue(issues,
      "model_name_conflict", "model_details", "model_name",
      "Another active Model in this Tenant already uses this name.");
    const activeInputs = new Set();
    for (const record of records(model, "model_input_scope")) {
      const key = physicalKey(record);
      if (!catalog.objects.has(key)) scopeIssue(issues, "model_input_scope", "object_name",
        "Referenced physical Object is not available to this Model Tenant.");
      else if (!retained("model_input_scope", record) && !catalog.inputObjects.has(key))
        scopeIssue(issues, "model_input_scope", "object_name",
        "Model Input Scope accepts only Source or Bronze Objects.");
      else if (record.is_active && catalog.inputObjects.has(key)) activeInputs.add(key);
    }
    const activeInputAttributes = attributesFor(catalog.inputAttributes, activeInputs);
    for (const record of records(model, "profiling_profile"))
      if (!(retained("profiling_profile", record) ? catalog.attributes : activeInputAttributes)
        .has(physicalKey(record, true))) scopeIssue(issues,
        "profiling_profile", "attribute_name", "Profile Attribute is not in active Model Input Scope.");
    for (const record of records(model, "analysis_result"))
      for (const endpoint of ["from", "to"])
        if (!(retained("analysis_result", record) ? catalog.attributes : activeInputAttributes)
          .has(prefixedPhysicalKey(record, endpoint, true))) scopeIssue(
          issues, "analysis_result", `${endpoint}_attribute_name`,
          "Analysis Attribute is not in active Model Input Scope.");
    for (const record of records(model, "modeling_assertion_document")) {
      if (record.tenant_code !== null && normalized(record.tenant_code) !== catalog.tenant)
        scopeIssue(issues, "modeling_assertion_document", "tenant_code",
          "Assertion document Tenant does not own this Model.");
      if (record.system_code !== null) requireSystem(catalog, record.system_code,
        "modeling_assertion_document", "system_code", issues);
    }
    const requireSource = (source, dataset, objects, attributes, message) => {
      const physical = sourcePhysical(source);
      if (!physical) return;
      const [target, isAttribute] = physical;
      if (!(isAttribute ? attributes : objects).has(physicalKey(target, isAttribute)))
        scopeIssue(issues, dataset, isAttribute ? "source_attribute" : "source_object", message);
    };
    for (const name of ["conceptual_object", "conceptual_relationship"])
      for (const record of records(model, name))
        for (const source of record.supports || []) requireSource(source, name,
          retained(name, record) ? catalog.objects : activeInputs,
          retained(name, record) ? catalog.attributes : activeInputAttributes,
          "Physical support is not in active Model Input Scope.");
    for (const name of ["logical_entity", "logical_attribute"])
      for (const record of records(model, name))
        for (const source of record.sources || []) requireSource(source, name,
          retained(name, record) ? catalog.objects : activeInputs,
          retained(name, record) ? catalog.attributes : activeInputAttributes,
          name === "logical_entity"
            ? "Logical source Object is not in active Model Input Scope."
            : "Logical source Attribute is not in active Model Input Scope.");

    for (const name of ["mapping_object", "mapping_attribute",
      "generated_code_source_system"])
      for (const record of records(model, name)) requireSystem(catalog, record.source_system_code,
        name, "source_system_code", issues);
    for (const name of ["validation_group", "validation_check"]) {
      for (const record of records(model, name)) {
        if (normalized(record.tenant_code) !== catalog.tenant) scopeIssue(issues, name, "tenant_code",
          "Validation record Tenant does not own this Model.");
        requireSystem(catalog, record.system_code, name, "system_code", issues);
        if (name === "validation_check" && record.is_active) {
          const query = validateReadSql(record.validation_query_sql);
          if (!query.valid) issue(issues,
            "validation_query_invalid", name, "validation_query_sql",
            "Validation query is not governed read-only Databricks SQL.");
          else if (record.validation_comparison_operator !== "executes_successfully" &&
              !query.finalReturnsRows) issue(issues, "validation_query_result_invalid", name,
            "validation_query_sql", "Validation query must end with a row-returning statement.");
          if (record.validation_comparison_query_sql !== null) {
            const comparison = validateReadSql(record.validation_comparison_query_sql);
            if (!comparison.valid) issue(issues, "validation_query_invalid", name,
              "validation_comparison_query_sql",
              "Validation comparison query is not governed read-only Databricks SQL.");
            else if (!comparison.finalReturnsRows) issue(issues,
              "validation_query_result_invalid", name, "validation_comparison_query_sql",
              "Validation query must end with a row-returning statement.");
          }
        }
      }
    }
    return issues;
  }

  function validateAssertionSource(source, layer, dataset, assertions, issues) {
    if (source.support_source_type !== "assertion") return;
    const assertion = assertions.get(normalized(
      source.assertion_record?.modeling_assertion_record_key));
    if (!assertion) issue(issues, "reference_not_found", dataset,
      "modeling_assertion_record_key", "Referenced record is not present in the future Model graph.");
    else if (!(assertion.modeling_assertion_applicable_layers || []).includes(layer)) issue(issues,
      "assertion_layer_invalid", dataset, "modeling_assertion_record_key",
      "Referenced Assertion does not apply to this modeling layer.");
  }

  function validateBackendReferences(model) {
    const issues = [];
    const documents = new Set(records(model, "modeling_assertion_document")
      .map((record) => normalized(record.modeling_assertion_document_name)));
    const assertions = new Map(records(model, "modeling_assertion_record")
      .map((record) => [normalized(record.modeling_assertion_record_key), record]));
    for (const record of records(model, "modeling_assertion_record"))
      if (!documents.has(normalized(record.modeling_assertion_document_name))) issue(issues,
        "reference_not_found", "modeling_assertion_record", "modeling_assertion_document_name",
        "Referenced record is not present in the future Model graph.");
    const conceptual = new Set(records(model, "conceptual_object")
      .map((record) => normalized(record.conceptual_object_name)));
    for (const record of records(model, "conceptual_object"))
      for (const source of record.supports || []) validateAssertionSource(source, "conceptual",
        "conceptual_object", assertions, issues);
    for (const record of records(model, "conceptual_relationship")) {
      if (!conceptual.has(normalized(record.from_conceptual_object_name)) ||
          !conceptual.has(normalized(record.to_conceptual_object_name))) issue(issues,
        "reference_not_found", "conceptual_relationship", "conceptual_object_name",
        "Referenced record is not present in the future Model graph.");
      for (const source of record.supports || []) validateAssertionSource(source, "conceptual",
        "conceptual_relationship", assertions, issues);
    }
    for (const layer of ["logical", "dimensional"]) {
      const submodels = new Set(records(model, `${layer}_submodel`)
        .map((record) => normalized(record[`${layer}_submodel_name`])));
      const entities = new Set(records(model, `${layer}_entity`)
        .map((record) => tuple([record[`${layer}_entity_schema_name`], record[`${layer}_entity_name`]])));
      const attributes = new Set(records(model, `${layer}_attribute`).map((record) =>
        tuple([record[`${layer}_entity_schema_name`], record[`${layer}_entity_name`], record[`${layer}_attribute_name`]])));
      for (const record of records(model, `${layer}_entity`)) {
        if ((record.submodels || []).some((item) => !submodels.has(normalized(item.submodel_name))))
          issue(issues, "reference_not_found", `${layer}_entity`, "submodel_name",
            "Referenced record is not present in the future Model graph.");
        for (const source of record.sources || []) validateAssertionSource(source, layer,
          `${layer}_entity`, assertions, issues);
      }
      for (const record of records(model, `${layer}_attribute`)) {
        if (!entities.has(tuple([record[`${layer}_entity_schema_name`], record[`${layer}_entity_name`]]))) issue(issues,
          "reference_not_found", `${layer}_attribute`, `${layer}_entity_name`,
          "Referenced record is not present in the future Model graph.");
        for (const source of record.sources || []) validateAssertionSource(source, layer,
          `${layer}_attribute`, assertions, issues);
      }
      for (const record of records(model, `${layer}_relationship`)) {
        const endpoints = ["from", "to"].map((prefix) => tuple([
          record[`${prefix}_${layer}_entity_schema_name`], record[`${prefix}_${layer}_entity_name`], record[`${prefix}_${layer}_attribute_name`],
        ]));
        if (endpoints.some((endpoint) => !attributes.has(endpoint))) issue(issues,
          "reference_not_found", `${layer}_relationship`, `${layer}_attribute_name`,
          "Referenced record is not present in the future Model graph.");
      }
    }
    const entities = new Set([
      ...records(model, "logical_entity").map(entityKey),
      ...records(model, "dimensional_entity").map(entityKey),
    ]);
    const attributes = new Set([
      ...records(model, "logical_attribute").map(attributeKey),
      ...records(model, "dimensional_attribute").map(attributeKey),
    ]);
    const mappings = new Set(records(model, "mapping_object").map(mappingObjectKey));
    for (const record of records(model, "mapping_object")) {
      if (!entities.has(entityKey(record))) issue(issues, "reference_not_found",
        "mapping_object", "modeled_entity_name",
        "Referenced record is not present in the future Model graph.");
    }
    for (const record of records(model, "mapping_attribute")) {
      if (!mappings.has(mappingObjectKey(record))) issue(issues, "reference_not_found",
        "mapping_attribute", "mapping_object",
        "Referenced record is not present in the future Model graph.");
      if (!attributes.has(attributeKey(record))) issue(issues, "reference_not_found",
        "mapping_attribute", "modeled_attribute_name",
        "Referenced record is not present in the future Model graph.");
    }
    const artifacts = new Set(records(model, "generated_code").map(artifactKey));
    for (const record of records(model, "generated_code"))
      if (!entities.has(entityKey(record))) issue(issues, "reference_not_found",
        "generated_code", "modeled_entity_name",
        "Referenced record is not present in the future Model graph.");
    for (const record of records(model, "generated_code_source_system"))
      if (!artifacts.has(artifactKey(record))) issue(issues, "reference_not_found",
        "generated_code_source_system", "generated_code",
        "Referenced record is not present in the future Model graph.");
    const logicalEntities = new Map(records(model, "logical_entity").map((record) => [entityKey(record), record]));
    const logicalAttributes = new Map(records(model, "logical_attribute").map((record) => [attributeKey(record), record]));
    for (const layer of ["entity", "attribute"]) for (const record of records(model, `dimensional_${layer}`)) {
      for (const source of record.sources || []) {
        const isAttribute = source.support_source_type === "logical_attribute";
        if (!isAttribute && source.support_source_type !== "logical_entity") continue;
        const target = isAttribute ? source.source_logical_attribute : source.source_logical_entity;
        const found = isAttribute ? logicalAttributes.get(attributeKey(target)) : logicalEntities.get(entityKey(target));
        const field = isAttribute ? "logical_attribute" : "logical_entity";
        if (!found) issue(issues, "reference_not_found", `dimensional_${layer}`, field,
          "Referenced Logical design is not present in the future Model graph.");
        else if (active(record, `dimensional_${layer}_status`) && active(source) &&
            (!active(found, `${field}_status`) || !active(logicalEntities.get(entityKey(target)), "logical_entity_status")))
          issue(issues, "active_dependency_invalid", `dimensional_${layer}`, field,
            "Active Dimensional support requires active Logical Entity and Attribute definitions.");
      }
    }
    const groups = new Set(records(model, "validation_group").map(validationGroupKey));
    for (const record of records(model, "validation_check"))
      if (!groups.has(validationGroupKey(record))) issue(issues, "reference_not_found",
        "validation_check", "validation_group_name",
        "Referenced record is not present in the future Model graph.");
    return issues;
  }

  function validateActiveDependencies(model) {
    const issues = [];
    const invalid = (dataset, field, message) => issue(issues,
      "active_dependency_invalid", dataset, field, message);
    for (const [dataset, field, status] of [
      ["mapping_object", "mapping_transformation_document", "object_mapping_status"],
      ["mapping_attribute", "attribute_mapping_transformation_document", "attribute_mapping_status"],
    ]) {
      const identity = record => tuple([mappingObjectKey(record), record.modeled_attribute_name]);
      const baseline = new Map(records(model, dataset, "baseline").map(record => [identity(record), record]));
      for (const record of records(model, dataset, "pending")) {
        const original = baseline.get(identity(record));
        const document = record[field];
        if (active(record, status) && document != null && !hasTransformationContent(document) &&
            (!original || !active(original, status) || core.stableStringify(original[field]) !== core.stableStringify(document)))
          issue(issues, "mapping_document_empty", dataset, field,
            "A content-free Mapping document must be explicit null; do not invent transformation logic.");
      }
    }
    const activeEntities = new Set([
      ...records(model, "logical_entity").filter((record) =>
        active(record, "logical_entity_status")).map(entityKey),
      ...records(model, "dimensional_entity").filter((record) =>
        active(record, "dimensional_entity_status")).map(entityKey),
    ]);
    const activeAttributes = new Set([
      ...records(model, "logical_attribute").filter((record) =>
        active(record, "logical_attribute_status")).map(attributeKey),
      ...records(model, "dimensional_attribute").filter((record) =>
        active(record, "dimensional_attribute_status")).map(attributeKey),
    ]);
    const activeConcepts = new Set(records(model, "conceptual_object")
      .filter((record) => active(record, "conceptual_object_status"))
      .map((record) => normalized(record.conceptual_object_name)));
    for (const record of records(model, "conceptual_relationship")) {
      if (active(record, "conceptual_relationship_status") &&
          [record.from_conceptual_object_name, record.to_conceptual_object_name]
            .some((name) => !activeConcepts.has(normalized(name)))) invalid(
        "conceptual_relationship", "conceptual_object_name",
        "Active Conceptual Relationship requires active endpoint Objects.");
    }
    for (const layer of ["logical", "dimensional"]) {
      const label = layer === "logical" ? "Logical" : "Dimensional";
      for (const record of records(model, `${layer}_attribute`)) {
        if (active(record, `${layer}_attribute_status`) &&
            !activeEntities.has(entityKey(record))) invalid(
          `${layer}_attribute`, `${layer}_entity_name`,
          `Active ${label} Attribute requires an active parent Entity.`);
      }
      for (const record of records(model, `${layer}_relationship`)) {
        if (!active(record, `${layer}_relationship_status`)) continue;
        if (["from", "to"].some((prefix) => {
          const entity = record[`${prefix}_${layer}_entity_name`];
          const schema = record[`${prefix}_${layer}_entity_schema_name`];
          return !activeEntities.has(tuple([`${layer}_entity`, schema, entity])) ||
            !activeAttributes.has(tuple([
              `${layer}_entity`, schema, entity, record[`${prefix}_${layer}_attribute_name`],
            ]));
        })) invalid(`${layer}_relationship`, `${layer}_attribute_name`,
          `Active ${label} Relationship requires active endpoint Attributes and Entities.`);
      }
    }
    const activeMappings = new Set();
    const objectTransformations = new Set();
    const existingMappings = new Set(records(model, "mapping_object", "baseline").map(mappingObjectKey));
    const codeAuthoringEntities = new Set(["generated_code", "generated_code_source_system"]
      .flatMap((dataset) => records(model, dataset, "pending")).map(entityKey));
    const mappingSystems = new Map();
    for (const record of records(model, "mapping_object")) {
      if (!active(record, "object_mapping_status")) continue;
      const entity = entityKey(record);
      const system = normalized(record.source_system_code);
      if (!activeEntities.has(entity)) {
        invalid("mapping_object", "modeled_entity_name",
          "Active Mapping Object requires an active Entity.");
        continue;
      }
      activeMappings.add(mappingObjectKey(record));
      if (record.mapping_transformation_document != null) objectTransformations.add(mappingObjectKey(record));
      if (!mappingSystems.has(entity)) mappingSystems.set(entity, new Set());
      mappingSystems.get(entity).add(system);
    }
    const activeMappingAttributes = new Set();
    for (const record of records(model, "mapping_attribute")) {
      if (!active(record, "attribute_mapping_status")) continue;
      if (!activeMappings.has(mappingObjectKey(record)) ||
          !activeAttributes.has(attributeKey(record))) {
        invalid("mapping_attribute", "modeled_attribute_name",
          "Active Mapping Attribute requires active Mapping and modeled Attribute.");
        continue;
      }
      if (record.attribute_mapping_transformation_document == null) continue;
      const [type, schema, entity, attribute] = JSON.parse(attributeKey(record));
      activeMappingAttributes.add(tuple([type, schema, entity, record.source_system_code, attribute]));
    }
    for (const [entity, systems] of mappingSystems) {
      const names = [...activeAttributes].filter((attribute) =>
        core.stableStringify(JSON.parse(attribute).slice(0, 3)) === entity)
        .map((attribute) => JSON.parse(attribute)[3]);
      for (const system of systems) {
        const branch = tuple([...JSON.parse(entity), system]);
        const hasObject = objectTransformations.has(branch);
        if (!existingMappings.has(branch) && !hasObject && !names.some((name) =>
          activeMappingAttributes.has(tuple([...JSON.parse(entity), system, name])))) invalid(
          "mapping_object", "mapping_transformation_document",
          "New active Mapping requires an Object or Attribute transformation.");
        if (!codeAuthoringEntities.has(entity)) continue;
        if (!hasObject) invalid("mapping_object", "mapping_transformation_document",
          "Code authoring requires an Object transformation for every mapped System.");
        if (names.some((name) =>
          !activeMappingAttributes.has(tuple([...JSON.parse(entity), system, name])))) invalid(
          "mapping_attribute", "modeled_attribute_name",
          "Code authoring must cover every active modeled Attribute per mapped System.");
      }
    }
    const artifacts = new Map(records(model, "generated_code")
      .filter((record) => active(record, "generated_code_status"))
      .map((record) => [artifactKey(record), record]));
    const assignments = new Map();
    for (const record of artifacts.values()) if (!activeEntities.has(entityKey(record))) invalid(
      "generated_code", "modeled_entity_name",
      "Active Code artifact requires an active modeled Entity.");
    for (const record of records(model, "generated_code_source_system")) {
      if (!active(record, "generated_code_source_system_status")) continue;
      const entity = entityKey(record);
      const system = normalized(record.source_system_code);
      if (!artifacts.has(artifactKey(record)) || !mappingSystems.get(entity)?.has(system)) {
        invalid("generated_code_source_system", "source_system_code",
          "Active Code source assignment requires active Code and Mapping.");
        continue;
      }
      const key = tuple([...JSON.parse(entity), system]);
      assignments.set(key, (assignments.get(key) || 0) + 1);
    }
    for (const [entity, systems] of mappingSystems) {
      if (![...artifacts.values()].some((record) => entityKey(record) === entity)) continue;
      for (const system of systems) {
        // Mapping can make unchanged Code stale; newly authored Code needs exact coverage.
        const count = assignments.get(tuple([...JSON.parse(entity), system])) || 0;
        if (count > 1 || (count === 0 && codeAuthoringEntities.has(entity))) invalid(
          "generated_code_source_system", "source_system_code",
          "Each mapped source System must be assigned to exactly one active artifact.");
      }
    }
    const groups = new Set(records(model, "validation_group")
      .filter((record) => record.is_active).map(validationGroupKey));
    const mappingSystemValues = new Set([...mappingSystems.values()].flatMap((value) => [...value]));
    for (const record of records(model, "validation_group"))
      if (record.is_active && !mappingSystemValues.has(normalized(record.system_code))) invalid(
        "validation_group", "system_code",
        "Active Validation Group requires active Mapping for its source System.");
    for (const record of records(model, "validation_check"))
      if (record.is_active && !groups.has(validationGroupKey(record))) invalid(
        "validation_check", "validation_group_name",
        "Active Validation Check requires an active Validation Group.");
    return issues;
  }

  function validateGraph(model, metadata = null, context = {}) {
    const issues = validateReferences(model, metadata);
    const completeGraph = model.has("model_details") && model.has("model_input_scope");
    if (!completeGraph) return issues;
    issues.push(...validateNestedLocks(model));
    const catalog = buildPhysicalCatalog(model, metadata, context);
    if (!catalog) issue(issues, "validation_context_missing", "model_input_scope", null,
      "A current Metadata Snapshot and Model Tenant are required for local Model validation.");
    else issues.push(...validatePhysicalScope(model, catalog));
    issues.push(...validateBackendReferences(model));
    issues.push(...validateActiveDependencies(model));
    return issues;
  }

  return {
    buildPhysicalCatalog,
    validateActiveDependencies,
    validateBackendReferences,
    validateGraph,
    validateNestedLocks,
    validatePhysicalScope,
    validateReferences,
    validateReadSql,
    retainsPhysicalReferences,
  };
});
