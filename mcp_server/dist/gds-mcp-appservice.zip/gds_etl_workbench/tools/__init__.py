"""Vertical MCP tool modules."""
