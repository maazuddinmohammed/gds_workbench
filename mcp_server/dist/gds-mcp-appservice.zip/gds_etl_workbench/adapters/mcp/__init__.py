"""MCP transport adapter."""
