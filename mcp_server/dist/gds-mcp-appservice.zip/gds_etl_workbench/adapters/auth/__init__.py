"""Authentication adapters."""
